using Microsoft.Playwright;

namespace InsuranceAutomation.Core;

public static class InteractionHighlighter
{
    public static async Task PulseAsync(ILocator locator, int durationMs)
    {
        if (durationMs <= 0) return;
        var token = Guid.NewGuid().ToString("N");
        var applied = false;
        try
        {
            await locator.EvaluateAsync(@"(el, token) => {
                const key = `qairaHighlight${token}`;
                el[key] = {
                    outline: el.style.outline,
                    outlineOffset: el.style.outlineOffset,
                    boxShadow: el.style.boxShadow,
                    transition: el.style.transition
                };
                el.style.transition = 'outline 50ms ease, box-shadow 50ms ease';
                el.style.outline = '3px solid #ff8a00';
                el.style.outlineOffset = '2px';
                el.style.boxShadow = '0 0 0 4px rgba(255,138,0,.20)';
            }", token);
            applied = true;
            await Task.Delay(durationMs);
        }
        catch
        {
        }
        finally
        {
            if (applied)
            {
                try
                {
                    await locator.EvaluateAsync(@"(el, token) => {
                    const key = `qairaHighlight${token}`;
                    const state = el[key];
                    if (!state) return;
                    el.style.outline = state.outline || '';
                    el.style.outlineOffset = state.outlineOffset || '';
                    el.style.boxShadow = state.boxShadow || '';
                    el.style.transition = state.transition || '';
                    delete el[key];
                }", token);
                }
                catch
                {
                }
            }
        }
    }
}
