using System.Text.RegularExpressions;
using InsuranceAutomation.Core;
using Microsoft.Playwright;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class ApplicationPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly UiActions _ui;

    public ApplicationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _ui = ui;
    }

    private ILocator Username => _page.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions { NameRegex = new Regex("User ?Name|Username", RegexOptions.IgnoreCase) });
    private ILocator Password => _page.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions { NameRegex = new Regex("Password", RegexOptions.IgnoreCase) });
    private ILocator SignIn => _page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { NameRegex = new Regex("Sign On|Sign In|Login", RegexOptions.IgnoreCase) });

    public async Task NavigateAsync(string url)
    {
        if (string.IsNullOrWhiteSpace(url)) throw new ArgumentException("Application URL is required.", nameof(url));
        await _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
    }

    public async Task SignInAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Username is required.", nameof(username));
        if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Password is required.", nameof(password));
        await _ui.FillAsync(Username, username);
        await _ui.FillAsync(Password, password);
        await _ui.ClickAsync(SignIn);

        // Keep the login wait authoritative while allowing an optional business-step timeout override.
        await _page.WaitForLoadStateAsync(LoadState.NetworkIdle, new PageWaitForLoadStateOptions { Timeout = StepTimeoutContext.Resolve(60000) });

        // Confirm that the first post-login business action is available.
        var newQuoteButton = _page.GetByRole(AriaRole.Button, new() { Name = "New Quote", Exact = true });
        await newQuoteButton.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = StepTimeoutContext.Resolve(30000) });
    }
}
