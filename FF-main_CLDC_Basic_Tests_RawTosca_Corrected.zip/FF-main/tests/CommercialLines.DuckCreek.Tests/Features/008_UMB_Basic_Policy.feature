@CL_DC @UMB @basic_new_business_policy

Feature: UMB Basic Policy
  As a Commercial Lines Duck Creek policy processing user
  I want to complete the UMB Basic Policy workflow
  So that the business transaction is executed with maintainable test data and verification

  Background: Prepare Commercial Lines Duck Creek for policy processing
    Given I open a browser session
  Scenario Outline: UMB Basic Policy - <stateCode> <stateVariant>
    Given test data "<dataFile>" and external data "<externalDataFile>" are loaded
    And I open the configured Commercial Lines Duck Creek application
    And I sign in to Commercial Lines Duck Creek using configured credentials
    When I enter business client information
    And I add a new Associated Client - Business Owner Type - Click Add Client
    And I complete aJAX Error Check
    And I complete required billing information
    And I complete the Associated Client Info
    And I navigate to Underwriting Info Screen
    And I complete required policy information
    And I complete required policy covg information
    And I add Commercial Auto Underlying LOB
    And I add General Liability Underlying LOB
    And I add Businessowners Underlying LOB
    And I add SFP - 10 Liability Farm Underlying LOB
    And I add Commercial Package Policy Liability Underlying LOB
    And I add Employers Liability Underlying LOB
    And I complete required location information
    And I complete required commercial auto information
    And I complete required general liability information
    And I complete required businessowners information
    And I complete required employers liability information
    And I complete required cpp information
    And I complete required sfp 10 information
    And I complete required endorsement information
    And I complete required underwriting question information
    And I navigate to Pricing Screen
    And I complete required billing information for billing
    And I add notepad comment
    And I complete required submission information
    And I run Stoplight
    And I verify values in premium fields
    And I complete forms verification UMB
    And I sign out of the application

    Examples:
      | stateCode | dataFile                                             | stateVariant | stateName      | externalDataFile                    |
      | AL        | TestData/Basic/AL.json      | AL           | Alabama        | TestData/ExternalDataOverrides.json |
      | AR        | TestData/Basic/AR.json      | AR           | Arkansas       | TestData/ExternalDataOverrides.json |
      | AZ        | TestData/Basic/AZ.json      | AZ           | Arizona        | TestData/ExternalDataOverrides.json |
      | CA        | TestData/Basic/CA.json      | CA           | California     | TestData/ExternalDataOverrides.json |
      | CO        | TestData/Basic/CO.json      | CO           | Colorado       | TestData/ExternalDataOverrides.json |
      | CT        | TestData/Basic/CT.json      | CT           | Connecticut    | TestData/ExternalDataOverrides.json |
      | DE        | TestData/Basic/DE.json      | DE           | Delaware       | TestData/ExternalDataOverrides.json |
      | GA        | TestData/Basic/GA.json      | GA           | Georgia        | TestData/ExternalDataOverrides.json |
      | IA        | TestData/Basic/IA.json      | IA           | Iowa           | TestData/ExternalDataOverrides.json |
      | ID        | TestData/Basic/ID.json      | ID           | Idaho          | TestData/ExternalDataOverrides.json |
      | IL        | TestData/Basic/IL.json      | IL           | Illinois       | TestData/ExternalDataOverrides.json |
      | IN        | TestData/Basic/IN.json      | IN           | Indiana        | TestData/ExternalDataOverrides.json |
      | KS        | TestData/Basic/KS.json      | KS           | Kansas         | TestData/ExternalDataOverrides.json |
      | KY        | TestData/Basic/KY.json      | KY           | Kentucky       | TestData/ExternalDataOverrides.json |
      | LA        | TestData/Basic/LA.json      | LA           | Louisiana      | TestData/ExternalDataOverrides.json |
      | MA        | TestData/Basic/MA.json      | MA           | Massachusetts  | TestData/ExternalDataOverrides.json |
      | MA        | TestData/Basic/MA_AUTO.json | MA Auto      | Massachusetts  | TestData/ExternalDataOverrides.json |
      | MD        | TestData/Basic/MD.json      | MD           | Maryland       | TestData/ExternalDataOverrides.json |
      | ME        | TestData/Basic/ME.json      | ME           | Maine          | TestData/ExternalDataOverrides.json |
      | MN        | TestData/Basic/MN.json      | MN           | Minnesota      | TestData/ExternalDataOverrides.json |
      | MO        | TestData/Basic/MO.json      | MO           | Missouri       | TestData/ExternalDataOverrides.json |
      | MS        | TestData/Basic/MS.json      | MS           | Mississippi    | TestData/ExternalDataOverrides.json |
      | MT        | TestData/Basic/MT.json      | MT           | Montana        | TestData/ExternalDataOverrides.json |
      | ND        | TestData/Basic/ND.json      | ND           | North Dakota   | TestData/ExternalDataOverrides.json |
      | NE        | TestData/Basic/NE.json      | NE           | Nebraska       | TestData/ExternalDataOverrides.json |
      | NH        | TestData/Basic/NH.json      | NH           | New Hampshire  | TestData/ExternalDataOverrides.json |
      | NJ        | TestData/Basic/NJ.json      | NJ           | New Jersey     | TestData/ExternalDataOverrides.json |
      | NM        | TestData/Basic/NM.json      | NM           | New Mexico     | TestData/ExternalDataOverrides.json |
      | NV        | TestData/Basic/NV.json      | NV           | Nevada         | TestData/ExternalDataOverrides.json |
      | NY        | TestData/Basic/NY.json      | NY           | New York       | TestData/ExternalDataOverrides.json |
      | OH        | TestData/Basic/OH.json      | OH           | Ohio           | TestData/ExternalDataOverrides.json |
      | OK        | TestData/Basic/OK.json      | OK           | Oklahoma       | TestData/ExternalDataOverrides.json |
      | OR        | TestData/Basic/OR.json      | OR           | Oregon         | TestData/ExternalDataOverrides.json |
      | PA        | TestData/Basic/PA.json      | PA           | Pennsylvania   | TestData/ExternalDataOverrides.json |
      | RI        | TestData/Basic/RI.json      | RI           | Rhode Island   | TestData/ExternalDataOverrides.json |
      | SC        | TestData/Basic/SC.json      | SC           | South Carolina | TestData/ExternalDataOverrides.json |
      | SD        | TestData/Basic/SD.json      | SD           | South Dakota   | TestData/ExternalDataOverrides.json |
      | TN        | TestData/Basic/TN.json      | TN           | Tennessee      | TestData/ExternalDataOverrides.json |
      | TX        | TestData/Basic/TX.json      | TX           | Texas          | TestData/ExternalDataOverrides.json |
      | UT        | TestData/Basic/UT.json      | UT           | Utah           | TestData/ExternalDataOverrides.json |
      | VA        | TestData/Basic/VA.json      | VA           | Virginia       | TestData/ExternalDataOverrides.json |
      | VT        | TestData/Basic/VT.json      | VT           | Vermont        | TestData/ExternalDataOverrides.json |
      | WA        | TestData/Basic/WA.json      | WA           | Washington     | TestData/ExternalDataOverrides.json |
      | WI        | TestData/Basic/WI.json      | WI           | Wisconsin      | TestData/ExternalDataOverrides.json |
      | WV        | TestData/Basic/WV.json      | WV           | West Virginia  | TestData/ExternalDataOverrides.json |
      | WY        | TestData/Basic/WY.json      | WY           | Wyoming        | TestData/ExternalDataOverrides.json |

