# ==================================================================================================
# Manual Gherkin conversion of Tosca TestCase: UW Cancellation - Cycle - Post - ALL
# Representative iteration: Arizona (AZ)
# Source revision: 48026
# Browser: Microsoft Edge
# Tosca synchronization timeout: 45000 ms
# Tosca retries: TestCase=1, TestStep=2, TestStepValue=3
#
# Data policy used in this feature:
#   - Every fixed source value is written directly in the step that uses it.
#   - RANDOM values are explicitly labelled RANDOM and retain the exact source pattern.
#   - RUNTIME-DERIVED values, including TDM, buffers, dates, and environment values, are explicitly labelled.
#   - Source-disabled Tosca actions are not executed; they are listed at the end of this file.
#
# Security notice: this file contains source test data, URLs, identifiers, and potentially test credentials.
# Handle it as sensitive test material.
# ==================================================================================================

@PL_DC @Cycle @cancellation @Arizona @Edge @manual @archive
Feature: Execute UW Cancellation - Cycle - Post - ALL for one representative PL|DC iteration
  As a PL|DC policy processing user
  I want to complete the UW Cancellation - Cycle - Post - ALL workflow for the selected source iteration
  So that every source-defined action, test datum, runtime dependency, and expected result is preserved in sequence

  Background: Prepare the source-defined PL|DC session for UW Cancellation - Cycle - Post - ALL
    # Source step 0001: Force Close Edge | Module: TBox Start Program
    # Section: Precondition | Reusable flow: Common | 00 Force Close Edge Browser | Source XTestStep: 3a19dd55-d3cb-4c12-291b-70baf4eb5889
    Given I force-close browser/process "msedge.exe" using command "taskkill /im msedge.exe /f"

    # Source step 0002: OpenUrl | Module: OpenUrl
    # Section: Precondition | Reusable flow: zz Open URL | Source XTestStep: 3a19dd55-d3bc-f112-92ef-4713bf05610b
    When I open the unresolved source parameter "URL" (not supplied by this reusable-block invocation)

    # Source step 0006: TBox Wait | Module: TBox Wait
    # Section: Precondition | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "3000" milliseconds

    # Source step 0007: TestData - Find & provide item | Module: Old_TestData - Find & provide item
    # Section: Precondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b17-cd01-13ca-139b0c5806fc
    When I retrieve test data through TDM operation "TestData - Find & provide item"
    And I use TDM parameter "Existing TDS type" with "Regression_Temp_Data"
    And I use TDM parameter "Alias name (item)" with "Regression_Temp_Data"
    And I use TDM parameter "Data search filter > State" with "AZ"
    And I use TDM parameter "Data search filter > TestCaseName" with "UW Cancellation - Cycle - AZ"
    And I use TDM parameter "Sorting > Date" with "Descending"

    # Source step 0008: TBox Set Buffer | Module: TBox Set Buffer
    # Section: Precondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b17-9f0b-bb96-7028e131cd8f
    When I retrieve and retain the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber" as runtime value "Policy"
    When I retain hard-coded value "UW Cancellation - Cycle - AZ" as runtime value "TCName"

  Scenario: UW Cancellation - Cycle - Post - ALL using representative iteration Arizona (AZ)
    # Source step 0009: EU||Login | Module: EU||Login
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b17-4e82-b5cf-43b9486c815a
    When I enter or select "AQ7314" in "Txt_Login ID_1"
    When I enter the RUNTIME-CONFIGURED value "ExpressPassword" in "Txt_Password_1"
    When I click "Lnk_LOGIN"

    # Source step 0010: EU||Home | Module: EU||Home
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b17-d0dc-4aa9-b85fb54abb70
    When I enter the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber" in "Txt_Search Text"
    When I click "Btn_Search"

    # Source step 0012: EU|Home | Module: EU|Home/Motorcycle/PersonalAuto
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-ba7f-e4d8-f4eaab582a66
    When I click "Lnk_Insured Name"
    When I click "Btn_Download XML"

    # Source step 0013: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0015: TBox Send Keys | Module: TBox Send Keys
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-1470-8a06-65a8bf7c4ac3
    When I enter or select "^(j)" in "Keys"

    # Source step 0016: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0017: TBox Send Keys | Module: TBox Send Keys
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-8f0f-5518-e58bd4f420e8
    When I enter or select "\"\"\"\"" in "Keys"

    # Source step 0018: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0019: TBox Save As_1-To Upload the file | Module: TBox Save As
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-00b3-a145-74615c01155e
    When I enter or select "Save As" in "Caption"
    When I enter the RUNTIME-DERIVED buffer expression "\\\\fs1\\public\\Tosca\\PL DC Automation\\XML\\{B[TCName]}_{B[Policy]}.xml" in "FilePath"
    When I enter or select "Save" in "Button"

    # Source step 0020: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0021: TBox Send Keys | Module: TBox Send Keys
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-42ea-768b-3cc322f4041f
    When I enter or select "\"\"" in "Keys"

    # Source step 0022: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0023: Open/Create XML file | Module: Open/Create XML file
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-9cfd-6d81-3603d54ef629
    When I enter or select "XML" in "Resource"
    When I enter the RUNTIME-DERIVED buffer expression "\\\\fs1\\public\\Tosca\\PL DC Automation\\XML\\{B[TCName]}_{B[Policy]}.xml" in "Filepath"

    # Source step 0024: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0025: Verify XML | Module: Verify XML
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-d8a3-1e97-be02d4cfe7cf
    When I use source configuration "Resource" = "XML" for "Verify XML"
    When I use source configuration "XPath" = "//FormNumber[text()=\"\"CoverageOptionOverview\"\"]" for "Verify XML"
    Then "XPath > Value" should equal "CoverageOptionOverview"
    When I use source configuration "XPath" = "//FormNumber[text()=\"\"IDCard0180\"\"]" for "Verify XML"
    Then "XPath > Value" should equal "IDCard0180"
    When I use source configuration "XPath" = "//FormNumber[text()=\"\"AutoProposal\"\"]" for "Verify XML"
    Then "XPath > Value" should equal "AutoProposal"
    When I use source configuration "XPath" = "//FormNumber[text()=\"\"AutoDeclarations0180\"\"]" for "Verify XML"
    Then "XPath > Value" should equal "AutoDeclarations0180"

    # Source step 0026: CloseBrowser | Module: CloseBrowser
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-16a7-8c25-310c146a9fee
    When I close the active browser

    # Source step 0041: OpenUrl | Module: OpenUrl
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  > zz Open URL | Source XTestStep: 3a19dd55-d3bc-f112-92ef-4713bf05610b
    When I open the unresolved source parameter "URL" (not supplied by this reusable-block invocation)

    # Source step 0045: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  > zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "3000" milliseconds

    # Source step 0046: TestData - Find & provide item | Module: Old_TestData - Find & provide item
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-7724-6813-a6ef09bf6135
    When I retrieve test data through TDM operation "TestData - Find & provide item"
    And I use TDM parameter "Existing TDS type" with "RateEffectiveDate_Reference"
    And I use TDM parameter "Alias name (item)" with "RateEffectiveDate_Reference"
    And I use TDM parameter "Data search filter > State" with "AZ"
    And I use TDM parameter "Data search filter > Veh Type" with "Cycle"
    And I use TDM parameter "Data search filter > NB/RB" with "NB"
    And I use TDM parameter "Data search filter > Company" with "ANG"
    And I use TDM parameter "Data search filter > LOB" with "Auto"

    # Source step 0047: TBox Set Buffer | Module: TBox Set Buffer
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-fe46-783a-b4d589dd84f7
    When I retrieve and retain the RUNTIME-DERIVED TDM value "RateEffectiveDate_Reference.Rate Effective Date" as runtime value "Expected_RateEffectiveDate"

    # Source step 0048: EU||Login | Module: EU||Login
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-9b39-0af8-770307ff3d33
    When I enter or select "AQ7314" in "Txt_Login ID_1"
    When I enter the RUNTIME-CONFIGURED value "ExpressPassword" in "Txt_Password_1"
    When I click "Lnk_LOGIN"

    # Source step 0049: EU||Home | Module: EU||Home
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-8acd-9f51-428a07c16ad8
    When I enter the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber" in "Txt_Search Text"
    When I click "Btn_Search"

    # Source step 0050: EU|Home | Module: EU|Home/Motorcycle/PersonalAuto
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-6775-27f9-92067a39a6f0
    When I click "Lnk_Insured Name"
    Then I wait until "Lnk_Motorcycle" exists
    When I click "Lnk_Motorcycle"

    # Source step 0052: EU||Transact | Module: EU||Transact
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-6d02-49e3-d2943b420b5f
    Then I wait until "Btn_ViewPolicy" is visible
    When I click "Btn_ViewPolicy"

    # Source step 0053: EU||Applicant | Module: EU||Applicant
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-8857-6859-f279ad8a27bf
    When I click "LNK_PolicyTerm"

    # Source step 0054: EU||Policy Term-Verify Rate Date/Rate Effective Date | Module: EU||Policy Term
    # Section: Process | Reusable flow: Cycle | Express|Verify Rate Effective Date  | Source XTestStep: 3a19dd55-d3da-4fd1-f55f-c02f92a88c31
    When I capture "InnerText" from "lbl_RateDate_Value" as runtime value "ActualRateDate"
    Then "lbl_RateDate_Value" should equal captured runtime value "Expected_RateEffectiveDate"

    # Source step 0056: CloseBrowser | Module: CloseBrowser
    # Section: Postcondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3b1d-8c7a-3455-54179dd2733d
    When I close the active browser

# --------------------------------------------------------------------------------------------------
# SOURCE-DISABLED TOSCA ACTIONS — intentionally excluded from the executable scenario
# --------------------------------------------------------------------------------------------------
# 1. Source step 0003 "Enter Sign On Credentials" in module "EQ||Sign On" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - VERIFY "Txt_Username" with "True"
# 2. Source step 0004 "TBox Wait" in module "TBox Wait" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Duration" with "1000"
# 3. Source step 0005 "Maximize Window" in module "TBox Window Operation" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Caption" with "*Sign On*"
#    - INPUT "Operation" with "Maximize"
# 4. Source step 0011 "EU||Home" in module "EU||Home" was disabled. Reason: 29.05.24 19:12:21 [ct2634]
#    - INPUT "Txt_Search Text" with the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber"
#    - INPUT "Btn_Search" with "X"
#    - INPUT "Lbl_Insured Name" with "X"
#    - INPUT "Lnk_Policyholder_name" with "X"
#    - INPUT "Btn_Download XML" with "X"
# 5. Source step 0012 field "Lnk_PersonalAuto" in "EU|Home" was disabled. Reason:  
#    - Preserved source value: "X"
# 6. Source step 0014 "Evaluate XPath" in module "Evaluate XPath" was disabled. Reason: 06.12.23 01:10:12 [ct2453]
#    - INPUT "Resource" with a blank value
#    - INPUT "XPathExpression" with a blank value
#    - VERIFY "EvaluationResult" with a blank value
# 7. Source step 0027 "OpenUrl" in module "OpenUrl" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Url" with the unresolved source parameter "URL" (not supplied by this reusable-block invocation)
#    - INPUT "UseActiveTab" with a blank value
#    - INPUT "WebDriverBrowserArguments > Argument" with "--silent-debugger-extension-api"
# 8. Source step 0028 "Enter Sign On Credentials" in module "EQ||Sign On" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - VERIFY "Txt_Username" with "True"
# 9. Source step 0029 "TBox Wait" in module "TBox Wait" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Duration" with "1000"
# 10. Source step 0030 "Maximize Window" in module "TBox Window Operation" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Caption" with "*Sign On*"
#    - INPUT "Operation" with "Maximize"
# 11. Source step 0031 "TBox Wait" in module "TBox Wait" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Duration" with "3000"
# 12. Source step 0032 "TestData - Find & provide item" in module "Old_TestData - Find & provide item" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Existing TDS type" with "PremiumValidation_Reference"
#    - INPUT "Alias name (item)" with "PremiumValidation_Reference"
#    - INPUT "Data search filter > TestCaseName" with "Mega Auto Policy 01 - NM"
#    - INPUT "Data search filter > State" with "NM"
#    - INPUT "Data search filter > LOB" with "Auto"
# 13. Source step 0033 "TBox Set Buffer" in module "TBox Set Buffer" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Expected_ValidatedPremium" with the RUNTIME-DERIVED TDM value "PremiumValidation_Reference.ValidatedPremium"
# 14. Source step 0034 "EU||Login" in module "EU||Login" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Txt_Login ID_1" with "AQ7314"
#    - INPUT "Txt_Password_1" with the RUNTIME-CONFIGURED value "ExpressPassword"
#    - INPUT "Lnk_LOGIN" with "X"
# 15. Source step 0035 "EU||Home" in module "EU||Home" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Txt_Search Text" with the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber"
#    - INPUT "Btn_Search" with "X"
# 16. Source step 0036 "EU|Home" in module "EU|Home/Motorcycle/PersonalAuto" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Lnk_Insured Name" with "X"
#    - INPUT "Lnk_PersonalAuto" with "X"
#    - INPUT "Btn_Download XML" with "X"
# 17. Source step 0037 "EU||Home" in module "EU||Home" was disabled. Reason: 04.04.24 09:51:35 [ct2452]
#    - INPUT "Txt_Search Text" with the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber"
#    - INPUT "Btn_Search" with "X"
#    - INPUT "Lbl_Insured Name" with "X"
#    - INPUT "Lnk_Policyholder_name" with "X"
# 18. Source step 0038 "Client Information Page" in module "EU||Client Information Page" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - WAIT "lnk_PersonalAuto" with "True"
#    - INPUT "lnk_PersonalAuto" with "X"
#    - WAIT "btn_ViewDetailsandHistory" with "True"
# 19. Source step 0039 "EU||Transact - Verify Premium Value" in module "EU||Transact" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - WAIT "Btn_ViewPolicy" with "True"
#    - INPUT "Btn_ViewPolicy" with "X"
#    - BUFFER "Txt_New Premium" with "Premium"
#    - VERIFY "Txt_New Premium" with captured runtime value "Expected_ValidatedPremium"
# 20. Source step 0040 "CloseBrowser" in module "CloseBrowser" was disabled. Reason: 29.05.24 19:19:11 [ct2634]
#    - INPUT "Title" with "*"
# 21. Source step 0042 "Enter Sign On Credentials" in module "EQ||Sign On" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - VERIFY "Txt_Username" with "True"
# 22. Source step 0043 "TBox Wait" in module "TBox Wait" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Duration" with "1000"
# 23. Source step 0044 "Maximize Window" in module "TBox Window Operation" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Caption" with "*Sign On*"
#    - INPUT "Operation" with "Maximize"
# 24. Source step 0049 field "Lbl_Insured Name" in "EU||Home" was disabled. Reason:  
#    - Preserved source value: "X"
# 25. Source step 0050 field "Lbl_Insured Name" in "EU|Home" was disabled. Reason:  
#    - Preserved source value: "True"
# 26. Source step 0050 field "Lbl_Insured Name" in "EU|Home" was disabled. Reason:  
#    - Preserved source value: "{Click}"
# 27. Source step 0051 "Client Information Page" in module "EU||Client Information Page" was disabled. Reason: 03.04.24 21:30:42 [ct2451]
#    - WAIT "lnk_PersonalAuto" with "True"
#    - INPUT "lnk_PersonalAuto" with "X"
#    - WAIT "btn_ViewDetailsandHistory" with "True"
# 28. Source step 0055 "EU||Home" in module "EU||Home" was disabled. Reason: 06.12.23 10:36:47 [ct2453]
#    - INPUT "Lnk_Home_Left Navigation Pane" with "X"
#    - INPUT "Btn_Log Out" with "X"
#
# RECOVERY BEHAVIOR FROM TOSCA — automation support, not normal manual business flow
# No RecoveryScenario was exported for the selected iteration.
