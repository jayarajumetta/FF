# ==================================================================================================
# Manual Gherkin conversion of Tosca TestCase: Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02
# Representative iteration: New Mexico (NM)
# Source revision: 48026
# Browser: Microsoft Edge
# Tosca synchronization timeout: 45000 ms
# Tosca retries: TestCase=1, TestStep=2, TestStepValue=3
#
# Data policy used in this feature:
#   - Every fixed source value is written directly in the step that uses it.
#   - RANDOM values are explicitly labelled RANDOM and retain the exact source pattern.
#   - RUNTIME-DERIVED values, including TDM, buffers, dates, and environment values, are explicitly labelled.
#   - Source-disabled Tosca actions are not executed; they are listed at the end of this file.
#
# Security notice: this file contains source test data, URLs, identifiers, and potentially test credentials.
# Handle it as sensitive test material.
# ==================================================================================================

@PL_DC @Home @post_validation @New_Mexico @Edge @manual @archive
Feature: Execute Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02 for one representative PL|DC iteration
  As a PL|DC policy processing user
  I want to complete the Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02 workflow for the selected source iteration
  So that every source-defined action, test datum, runtime dependency, and expected result is preserved in sequence

  Background: Prepare the source-defined PL|DC session for Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02
    # Source step 0007: Force Close Edge | Module: TBox Start Program
    # Section: Precondition | Reusable flow: Common | 00 Force Close Edge Browser | Source XTestStep: 3a19dd55-d3cb-4c12-291b-70baf4eb5889
    Given I force-close browser/process "msedge.exe" using command "taskkill /im msedge.exe /f"

    # Source step 0008: OpenUrl | Module: OpenUrl
    # Section: Precondition | Reusable flow: zz Open URL | Source XTestStep: 3a19dd55-d3bc-f112-92ef-4713bf05610b
    When I open the unresolved source parameter "URL" (not supplied by this reusable-block invocation)

    # Source step 0012: TBox Wait | Module: TBox Wait
    # Section: Precondition | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "3000" milliseconds

    # Source step 0013: TestData - Find & provide item | Module: Old_TestData - Find & provide item
    # Section: Precondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-b31d-8226-df2b7370e251
    When I retrieve test data through TDM operation "TestData - Find & provide item"
    And I use TDM parameter "Existing TDS type" with "Regression_Temp_Data"
    And I use TDM parameter "Alias name (item)" with "Regression_Temp_Data"
    And I use TDM parameter "Data search filter > State" with "NM"
    And I use TDM parameter "Data search filter > TestCaseName" with "Home Mid-Term Evaluations - Add Discounts - NM"
    And I use TDM parameter "Sorting > DateTime" with "Descending"

    # Source step 0014: TBox Set Buffer | Module: TBox Set Buffer
    # Section: Precondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-36cf-f6e5-26343071e83a
    When I retrieve and retain the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber" as runtime value "Policy"
    When I retain hard-coded value "Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02" as runtime value "TCName"

  Scenario: Home Mid-Term Evaluations - Add Discounts - NM - PostValidation Day 02 using representative iteration New Mexico (NM)
    # Source step 0015: EU||Login | Module: EU||Login
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-e7e0-ff05-3f4674576186
    When I enter or select "AQ7314" in "Txt_Login ID_1"
    When I enter the RUNTIME-CONFIGURED value "ExpressPassword" in "Txt_Password_1"
    When I click "Lnk_LOGIN"

    # Source step 0016: EU||Home-Navigate to TransACT page | Module: EU||Home
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-6549-7e87-ed36e1cce28a
    When I enter the RUNTIME-DERIVED TDM value "Regression_Temp_Data.PolicyNumber" in "Txt_Search Text"
    When I click "Btn_Search"
    When I click "Lbl_Insured Name"
    When I click "Lnk_Policyholder_name"
    When I click "Lnk_Home"

    # Source step 0017: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0018: EU||TransACT(Home-Endorse)-Navigate to ViewPolicy page | Module: EU||TransACT(Home-Endorse)
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-05f5-b320-1ba33acaac86
    When I click "Btn_View Policy_Endorse"

    # Source step 0019: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0020: EU||Applicant-Navigate to Discounts page | Module: EU||Applicant
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-1c87-0618-e499872010b6
    When I click "Lnk__Discounts"

    # Source step 0021: TBox Wait | Module: TBox Wait
    # Section: Process | Reusable flow: zz Wait | Source XTestStep: 3a19dd55-d3cb-31ae-1220-d039e13dd35b
    When I wait "5000" milliseconds

    # Source step 0022: EU||Discounts(Home-Endorse)-Capture Auto-Home Discount on Day 02 | Module: EU||Discounts(Home-Endorse)
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-3a0f-5374-2cb95bb19a12
    Then I wait until "Lbl_Auto-Home Discount" is visible
    When I capture "Value" from "Txt_Auto-Home Discount" as runtime value "Auto-Home Discount Value Day02"
    Then "Lbl_Three-Line Discount" should exist

    # Source step 0023: Take Screenshot of the EU Discounts page | Module: TBox Take Screenshot
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-bd51-33ba-0861dcfa50be
    When I capture a "Desktop" screenshot at "\\\\fs1\\public\\Tosca\\PL DC Automation\\Screenshots\\Home\\{B[TCName]}_EU Discounts Page_{DATE[][][MM/dd/yyyy]}_{TIME}"

    # Source step 0024: Verifying that Auto-Home Discount is not dropped/removed on Day 02[value should be YES] | Module: TBox Partial Buffer
    # Section: Process | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-1497-ecf9-1507d4b30c14
    When I derive runtime buffer "Auto-Home Discount Value Day02" from "Yes"

    # Source step 0025: EU||Discounts-Log out of the Policy/EU | Module: EU||Discounts(Home-New Business)
    # Section: Postcondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-6f59-7272-01c591ca908d
    When I click "Btn_Log Out"

    # Source step 0026: CloseBrowser | Module: CloseBrowser
    # Section: Postcondition | Reusable flow: <none> | Source XTestStep: 3a19e1e5-3cbe-dab4-7829-9eaa976a2331
    When I close the active browser

# --------------------------------------------------------------------------------------------------
# SOURCE-DISABLED TOSCA ACTIONS — intentionally excluded from the executable scenario
# --------------------------------------------------------------------------------------------------
# 1. Source step 0009 "Enter Sign On Credentials" in module "EQ||Sign On" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - VERIFY "Txt_Username" with "True"
# 2. Source step 0010 "TBox Wait" in module "TBox Wait" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Duration" with "1000"
# 3. Source step 0011 "Maximize Window" in module "TBox Window Operation" was disabled. Reason: 05.06.25 14:50:33 [pa2096@dnanico1.aniconet.com]
#    - INPUT "Caption" with "*Sign On*"
#    - INPUT "Operation" with "Maximize"
#
# RECOVERY BEHAVIOR FROM TOSCA — automation support, not normal manual business flow
# Recovery scenario: Recovery Scenario - Take screenshot, EU log out and Close browser
# 1. Source recovery step 0001 TBox Take Screenshot of failure(during initial run) at TC level: I capture a "Desktop" screenshot at "\\\\fs1\\public\\Tosca\\PL DC Automation\\Screenshots\\Home\\{B[TCName]}_{DATE[][][MM/dd/yyyy]}_{TIME}"
# 2. Source recovery step 0002 EU||Discounts-Log out of the Policy/EU: I click "Btn_Log Out"
# 3. Source recovery step 0003 CloseBrowser: I close the active browser
# Recovery scenario: CleanUp Scenario - Take screenshot, EU log out and Close browser
# 4. Source recovery step 0004 TBox Take Screenshot of failure(during recovery run): I capture a "Desktop" screenshot at "\\\\fs1\\public\\Tosca\\PL DC Automation\\Screenshots\\Home\\{B[TCName]}_{DATE[][][MM/dd/yyyy]}_{TIME}"
# 5. Source recovery step 0005 EU||Discounts-Log out of the Policy/EU: I click "Btn_Log Out"
# 6. Source recovery step 0006 CloseBrowser: I close the active browser
