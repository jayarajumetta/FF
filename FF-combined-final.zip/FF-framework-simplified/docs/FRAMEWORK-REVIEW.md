# Framework review and changes

This revision starts from the previously merged SGS/customer framework. SGS remains the browser, hook, logging and evidence owner. The review covers core, hooks, configuration, clients, services, support models, tools, scripts, CI/CD and release packaging. Business POM workflows remain outside the redesign scope. A file-by-file disposition is recorded in `validation/file-review.json`.

## Decisions

| Area | Final decision and reason |
| --- | --- |
| Control intent | Removed the record and async-local step-history state. Page method names and the report’s current step supply diagnostics. Mechanical call-site edits remove intent arguments. |
| Locator recovery/cache | Removed both Duck Creek resolvers, their hints, generic frame fallback, process-wide locator caches, unused locator-spec construction and frame context. No replacement discovery layer was added. |
| Customer rescue | Removed `LocatorRescueService`, options, unused base-page rescue APIs and hook/config switches. Offline locator scanning/generation tools were also removed. |
| Action execution | `UiActions` reduced from 983 to 227 lines; component adapters from 423 to 118. Removed forced/DOM-click fallbacks, repeated fills, fuzzy ranked options, automatic Enter commit, key suppression, fixed sleeps and network-idle waits. |
| Layered data | Removed all three layered directories and manifests. All 1,044 scenario documents retain the values used by the old loader. Plain `fields` maps retain both field names and business aliases. Unused generation provenance is removed. |
| Existing data contracts | Retained data expressions, random patterns, conditions and `GetCanonicalField*` compatibility calls because existing business methods consume them. Historical document-share paths remain unchanged. |
| Screenshots | Full-page, unclipped page capture throughout core, checklist and Express-login failure paths. Fixed the missing `ScreenshotPath` assignment; unique failure names prevent overwriting earlier failed steps. |
| Browser selection | Explicit chrome/msedge/chromium selection, with environment overrides and positive timeout/viewport validation. No fallback that could misidentify browser coverage. Headless sessions use a deterministic viewport. |
| Browser lifecycle | One owner per scenario; callback-scoped popup waiting; evidence listeners cover new pages; context closes before video/trace/HAR publication. Logger disposal is idempotent and safe for late optional callbacks. |
| Hooks | Shared `ScenarioLifecycle` with three thin Reqnroll hook wrappers. Customer hooks only compose customer services, apply guards and export customer evidence. They do not start a second browser factory. |
| Retries | Kept the existing configurable whole-scenario NUnit retry, default zero, including WC Basic exclusion and per-attempt reports. Generator is one normal project dependency, not nested per-project shell builds. No pipeline retry layer. |
| Reports | Retained scenario JSON/HTML, consolidated HTML/XML/summary, NUnit attachments and optional evidence bundle. These are distinct consumers of the same scenario evidence. Reporting switches are honored; skipped/unknown counts stay distinct, an all-skipped run is SKIP, and the actual scenario outcome is set before attachment publication. |
| CI/CD | Standard build, source/unit validation, compiled artifact, pinned-build download, VSTest, report and artifact publication. Removed custom shard transport, temporary suite management, duplicated regression pipelines and classic release JSON. Existing Test Plan suite selection remains supported. |
| Forms Delta | Retained as a dedicated optional pipeline with the existing hash, branch, reviewed-change and package-write guards. Adapted paths to the combined repository. |
| Customer API/auth | POST helper sends once, with no header/body dumping; caller owns the response. Ping uses `IHttpClientFactory`, correct OAuth JSON wire names and disposed HTTP responses. |
| Customer forms helpers | Removed fixed 3-second waits and DOM clicks from shared dropdown helper. Missing requested selections now fail clearly. Forms errors fail by default instead of only logging. |
| Optional DataPool | Retained explicit standalone service and optional no-op client. Removed server autostart and bundled historical quote records. |
| Obsolete utilities | Removed generation-era schema gates and data-conversion scripts that assumed layered data; replaced with current source/binding/data checks. Kept the domain forms maintenance scripts and their tests. |

## UiActions method review

| Method | Behavior |
| --- | --- |
| `ClickAsync` | One ordinary Playwright click; no force, retry, frame probing or DOM click. |
| `FillAsync` | One native/component set. Text fields commit via blur to preserve the existing application contract. |
| `PressSequentiallyAsync` | Clear once, type once with caller-selected key delay. |
| `PressAsync` | Normalize existing key notation and execute the requested key/click; never suppress Enter/Tab. |
| `SmartSetAsync`, `SelectAsync` | Deterministic native/select/boolean/group adapters; exact requested dropdown option. |
| `ActivateTabAsync` | Exact tab role/name within supplied container. |
| `ClickDialogActionAsync` | Exact button role/name within supplied dialog. |
| `ToggleExpansionPanelAsync` | Read known expansion state, click only when necessary, assert resulting state. |
| `ClickGridCellAsync` | Exact cell text within supplied grid; no arbitrary first match. |
| `ExistsAsync` | Bounded optional visibility; only timeout becomes false. |
| `WaitAsync` | Required visible/hidden/detached/enabled/disabled wait; no warning-only success. |
| `WaitReadyBestEffortAsync` | Explicit optional readiness hint; timeout logged, invalid-selector errors propagate. |
| `VerifyAsync` | Retrying Playwright assertions, with preserved optional deferred failure collection. |
| `CaptureAsync` | Read appropriate input value or text without retries or locator substitution. |
| `ReviewRequiredAsync` | Retained diagnostic note API used by existing page methods. It is not an assertion or automatic repair. |
| Reporting wrapper | Records caller/method, operation and outcome. Does not dump field values into action telemetry. |
| `ApplicationLogin.SignInAsync` | Retains credential resolution and normal actions; password locator uses its accessible label rather than an implicit textbox role. |

## Customer capabilities reconciled

| Customer mechanism | Retained/adapted destination |
| --- | --- |
| All eight features / 104 expanded cases | EQ_BOP, EQ_SFP and EQ_PA under the EQ project; `@cs_import` scope |
| All 27 customer NUnit test files | `Imported/CS/Tests`; 424 nonbrowser cases retained and passing |
| Environment and Dev-state guards | Scoped imported hook policy; six QA DevOnly guard checks skip correctly |
| Per-scenario shared context/quote state | One customer context registered through scoped DI; quote-number file under scenario artifacts |
| Forms XML parsing and validation | Customer clients, parser, validation service and reviewed expected-form resources retained |
| Baseline qualification/delta and operational handoff | Forms tool chain, dedicated pipeline and hash/approval guards retained |
| Forms HTML, CSV/TRX and premium extraction | Customer report service and domain scripts retained; shared framework report remains authoritative for scenario outcome |
| RatePolicy safety and checklist outage mode | Retained; outage-only work cannot become a full-workflow pass |
| Optional request diagnostics | Retained read-only `RetryDiagnostics`; no action replay |
| OAuth/Ping integration | Retained with token property mapping and response/client lifecycle fixes |
| Browser/trace ownership and evidence | Adapted to SGS BrowserSession; customer duplicate browser factory/global DI plugin not reintroduced |
| Optional DataPool | Retained without automatic server startup; history is empty in a new package |

The source-to-final customer map is `validation/customer-capability-map.json`. Customer pipeline-contract tests were updated to check the new centralized regression pipeline and dedicated Forms Delta path; business assertions were not removed.

## Compatibility corrections and limits

- The BAP regression feature referenced 44 files at an obsolete flat path. These references now point at the existing `TestData/Scenarios/Basic` files. Scenario bodies, tags, parameters and case counts are otherwise preserved.
- The regression profile catalog now reads its actual `TestData/Scenarios/Regression/RegressionProfiles.json` location.
- Root entry files are now `InsuranceAutomation.sln` and `Framework.runsettings`. Build scripts no longer mutate runsettings.
- The forms JSON tooling loader now finds the combined EQ DLL in the central Release output folder.
- Existing POM methods may contain application-specific waits/retries and source warnings; the requested review excluded their broad redesign. Removing core recovery intentionally exposes a wrong, ambiguous or wrong-frame locator rather than making it pass through a different control. Live application smoke/regression execution is still required to find those cases.
- The supplied customer BOP primary-insured PoC step remains inconclusive, and the SFP RatePolicy expected-form baseline remains unpopulated. Those limitations predate this revision.
- Azure pipelines were parsed and their compiled package was exercised locally. Actual Azure permissions, agents, secret variables, browser installation and internal application access were not available for an Azure run.

## Validation evidence

See `validation/validation-summary.json` and the included build/test logs. The clean solution build and subsequent compilation passed. Remaining compiler warnings are in inherited POM/step-definition code; they are not suppressed globally. Source validation finds all 44 features, 806 cases and 48,599 expanded steps with zero syntax, undefined-binding, ambiguous-binding or missing-scenario-path errors.

Browser contract tests are supplied for actual Chrome and Edge. In this environment they stopped at launch because the branded browsers are not installed. Full-page option behavior is covered by an offline interface contract test; actual PNG dimensions require the supplied browser contract tests. No live application pass or guarantee of zero runtime regression is asserted.

## Standards used

- Playwright actionability and auto-waiting: https://playwright.dev/dotnet/docs/actionability
- Playwright browser channels: https://playwright.dev/dotnet/docs/browsers
- Full-page screenshots: https://playwright.dev/dotnet/docs/screenshots
- Navigation readiness: https://playwright.dev/dotnet/docs/api/class-page#page-goto
- Azure VSTest task: https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/vstest-v3
