@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1"
