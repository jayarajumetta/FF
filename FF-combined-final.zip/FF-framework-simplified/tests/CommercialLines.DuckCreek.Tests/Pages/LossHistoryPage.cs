using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class LossHistoryPage
{
    private readonly BrowserSession _browser;
    private readonly LossHistoryLocators _locators;
    private readonly UiActions _ui;

    public LossHistoryPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new LossHistoryLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAddAddlInterestAsync(string expected) =>
        _ui.WaitAsync(_locators.AddAddlInterest, expected);

    public Task ClickAddAddlInterestAsync() =>
        _ui.ClickAsync(_locators.AddAddlInterest);

    public Task WaitForAddlInterestsAsync(string expected) =>
        _ui.WaitAsync(_locators.AddlInterests, expected);

    public Task ClickAddlInterestsAsync() =>
        _ui.ClickAsync(_locators.AddlInterests);


    public Task WaitForAddlInterestsMainOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task ClickAddlInterestsMainOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForLossAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.LossAddress, expected);

    public Task EnterLossAddressAsync(string value) =>
        _ui.FillAsync(_locators.LossAddress, value);

    public Task PressLossAddressAsync(string key) =>
        _ui.PressAsync(_locators.LossAddress, key);

    public Task WaitForAssignLocationsAsync(string expected) =>
        _ui.WaitAsync(_locators.AssignLocations, expected);

    public Task ClickAssignLocationsAsync() =>
        _ui.ClickAsync(_locators.AssignLocations);

    public Task WaitForAssignmentScheduleForAsync(string expected) =>
        _ui.WaitAsync(_locators.OtherInterestPremisesSchedule, expected);

    public Task WaitForAssignmentScheduleForOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task ClickAssignmentScheduleForOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForDescriptionOfPropertyAsync(string expected) =>
        _ui.WaitAsync(_locators.DescriptionOfProperty, expected);

    public Task EnterDescriptionOfPropertyAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfProperty, value);

    public Task PressDescriptionOfPropertyAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfProperty, key);

    public Task WaitForFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.FirstName, expected);

    public Task EnterFirstNameAsync(string value) =>
        _ui.FillAsync(_locators.FirstName, value);

    public Task PressFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.FirstName, key);

    public Task WaitForInsuredTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.InsuredType, expected);

    public Task EnterInsuredTypeAsync(string value) =>
        _ui.FillAsync(_locators.InsuredType, value);

    public Task PressInsuredTypeAsync(string key) =>
        _ui.PressAsync(_locators.InsuredType, key);

    public Task WaitForLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.LastName, expected);

    public Task EnterLastNameAsync(string value) =>
        _ui.FillAsync(_locators.LastName, value);

    public Task PressLastNameAsync(string key) =>
        _ui.PressAsync(_locators.LastName, key);

    public Task WaitForLoanNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.LoanNumber, expected);

    public Task EnterLoanNumberAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.LoanNumber, value, 20);

    public Task PressLoanNumberAsync(string key) =>
        _ui.PressAsync(_locators.LoanNumber, key);

    public Task WaitForMIAsync(string expected) =>
        _ui.WaitAsync(_locators.MI, expected);

    public Task EnterMIAsync(string value) =>
        _ui.FillAsync(_locators.MI, value);

    public Task PressMIAsync(string key) =>
        _ui.PressAsync(_locators.MI, key);

    public Task WaitForNewAssignmentAsync(string expected) =>
        _ui.WaitAsync(_locators.NewAssignmentHeading, expected);

    public Task ClickNewAssignmentAsync() =>
        _ui.ClickAsync(_locators.NewAssignment);

    public Task WaitForOtherInterestPremisesDetailOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task ClickOtherInterestPremisesDetailOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForOtherInterestPremisesScheduleAsync(string expected) =>
        _ui.WaitAsync(_locators.OtherInterestPremisesSchedule, expected);

    public Task ClickOtherInterestPremisesScheduleOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForProvisionsApplicableAsync(string expected) =>
        _ui.WaitAsync(_locators.ProvisionsApplicable, expected);

    public Task EnterProvisionsApplicableAsync(string value) =>
        _ui.FillAsync(_locators.ProvisionsApplicable, value);

    public async Task<bool> IsProvisionsApplicableAvailableAsync() =>
        await _locators.ProvisionsApplicable.CountAsync() > 0;

    public Task PressProvisionsApplicableAsync(string key) =>
        _ui.PressAsync(_locators.ProvisionsApplicable, key);

    public Task WaitForTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.Type, expected);

    public Task EnterTypeAsync(string value) =>
        _ui.FillAsync(_locators.Type, value);

    public Task PressTypeAsync(string key) =>
        _ui.PressAsync(_locators.Type, key);

    public Task WaitForZipCodeAsync(string expected) =>
        _ui.WaitAsync(_locators.ZipCode, expected);

    public Task EnterZipCodeAsync(string value) =>
        _ui.FillAsync(_locators.ZipCode, value);

    public Task PressZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.ZipCode, key);


    public Task EnterLossAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LossAddress, value, delayMs);

    public Task EnterDescriptionOfPropertySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfProperty, value, delayMs);

    public Task EnterFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FirstName, value, delayMs);

    public Task EnterInsuredTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.InsuredType, value, delayMs);

    public Task EnterLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LastName, value, delayMs);

    public Task EnterLoanNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LoanNumber, value, delayMs);

    public Task EnterMISequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.MI, value, delayMs);

    public Task EnterProvisionsApplicableSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProvisionsApplicable, value, delayMs);

    public Task EnterTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Type, value, delayMs);

    public Task EnterZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ZipCode, value, delayMs);
}
