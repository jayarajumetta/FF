using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class PolicyWorkflowPage
{
    private readonly BrowserSession _browser;
    private readonly PolicyWorkflowLocators _locators;
    private readonly UiActions _ui;

    public PolicyWorkflowPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new PolicyWorkflowLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifyAJAXErrorCheckAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AJAXErrorCheck, expected, property);

    public Task WaitForAccountsReceivableHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task WaitForAddClientAsync(string expected) =>
        _ui.WaitAsync(_locators.AddClient, expected);

    public Task PressAddClientAsync(string key) =>
        _ui.PressAsync(_locators.AddClient, key);

    public Task ClickAddClientAsync() =>
        _ui.ClickAsync(_locators.AddClient);

    public Task EnterAggregateLimitAsync(string value) =>
        _ui.FillAsync(_locators.AggregateLimit, value);

    public Task PressAggregateLimitAsync(string key) =>
        _ui.PressAsync(_locators.AggregateLimit, key);

    public Task WaitForBusinessownersAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task ClickCPDetailAsync() =>
        _ui.ClickAsync(_locators.CPDetail);

    public Task WaitForCPPLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task VerifyCTStraightThroughLiabilityLimitTo1MAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CTStraightThroughLiabilityLimitTo1M, expected, property);

    public Task EnterLiabilityLimitAsync(string value) =>
        _ui.SmartSetAsync(_locators.LiabilityLimit, value);

    public Task WaitForCommercialAutoAsync(string expected) =>
        _ui.WaitAsync(_locators.CommercialAuto, expected);

    public Task EnterDedTypeAsync(string value) =>
        _ui.FillAsync(_locators.DedType, value);

    public Task PressDedTypeAsync(string key) =>
        _ui.PressAsync(_locators.DedType, key);

    public Task EnterDeductibleBasisAsync(string value) =>
        _ui.FillAsync(_locators.DeductibleBasis, value);

    public Task PressDeductibleBasisAsync(string key) =>
        _ui.PressAsync(_locators.DeductibleBasis, key);

    public Task WaitForDescriptionOfSpecifiedOperationAsync(string expected) =>
        _ui.WaitAsync(_locators.DescriptionOfSpecifiedOperation, expected);

    public Task VerifyDescriptionOfSpecifiedOperationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.DescriptionOfSpecifiedOperation, expected, property);

    public Task EnterDescriptionOfSpecifiedOperationAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfSpecifiedOperation, value);

    public Task PressDescriptionOfSpecifiedOperationAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfSpecifiedOperation, key);

    public Task EnterDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupAsync(string value) =>
        _ui.FillAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, value);

    public Task PressDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupAsync(string key) =>
        _ui.PressAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, key);

    public Task WaitForEmployersLiabAsync(string expected) =>
        _ui.WaitAsync(_locators.EmployersLiab, expected);

    public Task WaitForEndorsementHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterFireDamageAsync(string value) =>
        _ui.FillAsync(_locators.FireDamage, value);

    public Task WaitForGeneralLiabAsync(string expected) =>
        _ui.WaitAsync(_locators.GeneralLiab, expected);

    public Task EnterHasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverageAsync(string value) =>
        _ui.FillAsync(_locators.HasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverage, value);

    public Task PressHasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverageAsync(string key) =>
        _ui.PressAsync(_locators.HasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverage, key);

    public Task WaitForHomeownerSLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task WaitForOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task WaitUMLimitdsAsync(string expected) =>
        _ui.WaitAsync(_locators.UMLimits, expected);

    public Task ClickOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task EnterIFRAMEDuckCreekPolicyDescriptionOfOtherAsync(string value) =>
        _ui.FillAsync(_locators.IFRAMEDuckCreekPolicyDescriptionOfOther, value);

    public Task EnterDoesThisPolicyCoversAContractorExposureAsync(string value) =>
        _ui.FillAsync(_locators.DoesThisPolicyCoverContractorExposure, value);

    public Task EnterUMLimitAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UMLimit, value, delayMs);

    public Task EnterUMLimitsAsync(string value) =>
       _ui.FillAsync(_locators.UMLimits, value);

    public Task VerifyDoesThisPolicyCoversAContractorExposureAsync(string expected,string value) =>
        _ui.VerifyAsync(_locators.DoesThisPolicyCoverContractorExposure,expected, value);

    public Task<string> CaptureDoesThisPolicyCoversAContractorExposureAsync(string value = "") =>
        _ui.CaptureAsync(_locators.DoesThisPolicyCoverContractorExposure, value);

    public Task ClickIFRAMEDuckCreekPolicyOtherCheckBoxAsync() =>
        _ui.ClickAsync(_locators.IFRAMEDuckCreekPolicyOtherCheckBox);

    public Task ClickIMDetailAsync() =>
        _ui.ClickAsync(_locators.IMDetail);

    public Task ClickIncludeBusinessownersAsync() =>
        _ui.ClickAsync(_locators.IncludeBusinessowners);

    public Task ClickIncludeCommercialAutoAsync() =>
        _ui.ClickAsync(_locators.IncludeCommercialAuto);

    public Task ClickIncludeCommercialPackagePolicyLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeCommercialPackagePolicyLiability);

    public Task ClickIncludeEmployersLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeEmployersLiability);

    public Task ClickIncludeGeneralLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeGeneralLiability);

    public Task ClickIncludeHomeownerSLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeHomeownerSLiability);

    public Task ClickIncludePersonalAutoLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludePersonalAutoLiability);

    public Task ClickIncludeRentalOwnerSLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeRentalOwnerSLiability);

    public Task ClickIncludeSFP10LiabilityFarmAsync() =>
        _ui.ClickAsync(_locators.IncludeSFP10LiabilityFarm);

    public Task ClickIncludeWatercraftLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeWatercraftLiability);

    public Task VerifyIndividualTypeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IndividualType, expected, property);

    public Task EnterIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsAsync(string value) =>
        _ui.FillAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, value);

    public Task PressIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsAsync(string key) =>
        _ui.PressAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, key);

    public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task ClickLoggedInUserAsync() =>
        _ui.ClickAsync(_locators.LoggedInUser);

    public Task WaitForUserNameInitialAsync(string expected) =>
        _ui.WaitAsync(_locators.UserNameInitial, expected);

    public Task ClickUserNameInitialAsync() =>
        _ui.ClickAsync(_locators.UserNameInitial);

    public Task WaitForLogoutAsync(string expected) =>
        _ui.WaitAsync(_locators.Logout, expected);

    public Task ClickLogoutAsync() =>
        _ui.ClickAsync(_locators.Logout);

    public Task WaitForLogoutOkButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.LogoutOkButton, expected);

    public async Task ClickLogoutOkButtonAsync()
    {
        try
        {
            await _locators.LogoutOkButton.ClickAsync(new LocatorClickOptions { Timeout = 5000 });
        }
        catch (PlaywrightException)
        {
            // The OK click can trigger a page navigation/reload that destroys the
            // current execution context mid-click; treat that as success since the
            // dialog has already been dismissed by the click action itself.
        }

        await _browser.Page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
    }

    public async Task<bool> LogoutOkButtonIsVisibleAsync() =>
        await _locators.LogoutOkButton.CountAsync() > 0 && await _locators.LogoutOkButton.IsVisibleAsync();

    public Task EnterMedicalAsync(string value) =>
        _ui.FillAsync(_locators.Medical, value);

    public Task PressOKAsync(string key) =>
        _ui.PressAsync(_locators.OK, key);

    public Task EnterOccurenceLimitAsync(string value) =>
        _ui.FillAsync(_locators.OccurenceLimit, value);

    public Task PressOccurenceLimitAsync(string key) =>
        _ui.PressAsync(_locators.OccurenceLimit, key);

    public Task EnterOfFullTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfFullTimeEmployees, value);

    public Task PressOfFullTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfFullTimeEmployees, key);

    public Task EnterOfPartTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfPartTimeEmployees, value);

    public Task PressOfPartTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfPartTimeEmployees, key);

    public Task EnterOfSeasonalTemporaryEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfSeasonalTemporaryEmployees, value);

    public Task PressOfSeasonalTemporaryEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfSeasonalTemporaryEmployees, key);

    public Task EnterPersAdvInjAsync(string value) =>
        _ui.FillAsync(_locators.PersAdvInj, value);

    public Task WaitForPersonalAutoAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalAuto, expected);

    public Task WaitForPolicyCovgGLPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task WaitForPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovg, expected);

    public Task WaitForPolicyInfoHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterPremOpDedAsync(string value) =>
        _ui.FillAsync(_locators.PremOpDed, value);

    public Task PressPremOpDedAsync(string key) =>
        _ui.PressAsync(_locators.PremOpDed, key);

    public Task EnterPremOpPDDedAsync(string value) =>
        _ui.FillAsync(_locators.PremOpPDDed, value);

    public Task EnterProdBIDedAsync(string value) =>
        _ui.FillAsync(_locators.ProdBIDed, value);

    public Task PressProdBIDedAsync(string key) =>
        _ui.PressAsync(_locators.ProdBIDed, key);

    public Task EnterProdPDDedAsync(string value) =>
        _ui.FillAsync(_locators.ProdPDDed, value);

    public Task EnterProductsAggLimitAsync(string value) =>
        _ui.FillAsync(_locators.ProductsAggLimit, value);

    public Task VerifyPropertyOfOthersRatingGroupAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PropertyOfOthersRatingGroup, expected, property);

    public Task EnterPropertyOfOthersRatingGroupAsync(string value) =>
        _ui.FillAsync(_locators.PropertyOfOthersRatingGroup, value);

    public Task PressPropertyOfOthersRatingGroupAsync(string key) =>
        _ui.PressAsync(_locators.PropertyOfOthersRatingGroup, key);

    public Task WaitForQuickSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.QuickSearchButton, expected);

    public Task ClickQuickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.QuickSearchButton);

    public Task WaitForRentalOwnersLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task VerifyOKAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.OK, expected, property);

    public Task WaitForReturnToAdminAsync(string expected) =>
        _ui.WaitAsync(_locators.ReturnToAdmin, expected);

    public Task VerifyReturnToAdminAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ReturnToAdmin, expected, property);

    public Task ClickReturnToAdminAsync() =>
        _ui.ClickAsync(_locators.ReturnToAdmin);

    public Task ClickReturnToCPPAsync() =>
        _ui.ClickAsync(_locators.ReturnToCPP);

    public Task ClickRiskAccountsReceivableOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task ClickRiskBaileesCustomersOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task ClickRiskComputerSystemsOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForSFP10LiabilityFarmAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task VerifySaveForLaterAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SaveForLater, expected, property);

    public Task ClickSaveForLaterAsync() =>
        _ui.ClickAsync(_locators.SaveForLater);

    public Task WaitForSaveForLaterOKAsync(string expected) =>
        _ui.WaitAsync(_locators.SaveForLaterOK, expected);

    public Task ClickSaveForLaterOKAsync() =>
        _ui.ClickAsync(_locators.SaveForLaterOK);

    public Task WaitForSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchButton, expected);

    public Task ClickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.SearchButton);

    public Task WaitForSearchResultsInsuredNameColumnHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchResultsInsuredNameColumnHeader, expected);

    public Task ClickSearchResultInsuredNameLinkAsync() =>
        _ui.ClickAsync(_locators.SearchResultInsuredNameLink);

    public Task WaitForCommercialAutoQuoteLinkAsync(string expected) =>
        _ui.WaitAsync(_locators.CommercialAutoQuoteLink, expected);

    public Task ClickCommercialAutoQuoteLinkAsync() =>
        _ui.ClickAsync(_locators.CommercialAutoQuoteLink);

    public Task WaitForSearchMethodEGDescriptionPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchMethodEGDescriptionPolicy, expected);

    public Task EnterSearchMethodEGDescriptionPolicyAsync(string value) =>
        _ui.FillAsync(_locators.SearchMethodEGDescriptionPolicy, value);

    public Task PressSearchMethodEGDescriptionPolicyAsync(string key) =>
        _ui.PressAsync(_locators.SearchMethodEGDescriptionPolicy, key);

    public Task VerifyRiskComputerSystemsSearchResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.RiskComputerSystemsSearchResult, expected, property);

    public Task EnterRiskComputerSystemsSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskComputerSystemsSearchResult, value);

    public Task PressRiskComputerSystemsSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskComputerSystemsSearchResult, key);

    public Task VerifyRiskBaileesCustomersSearchResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.RiskBaileesCustomersSearchResult, expected, property);

    public Task EnterRiskBaileesCustomersSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersSearchResult, value);

    public Task PressRiskBaileesCustomersSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersSearchResult, key);

    public Task VerifyRiskAccountsReceivableSearchResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.RiskAccountsReceivableSearchResult, expected, property);

    public Task EnterRiskAccountsReceivableSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskAccountsReceivableSearchResult, value);

    public Task PressRiskAccountsReceivableSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskAccountsReceivableSearchResult, key);

    public Task WaitForSearchTextAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchText, expected);

    public Task EnterSearchTextAsync(string value) =>
        _ui.FillAsync(_locators.SearchText, value);

    public Task PressSearchTextAsync(string key) =>
        _ui.PressAsync(_locators.SearchText, key);

    public Task EnterRiskAccountsReceivableSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskAccountsReceivableSearchValue, value);

    public Task PressRiskAccountsReceivableSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskAccountsReceivableSearchValue, key);

    public Task EnterRiskComputerSystemsSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskComputerSystemsSearchValue, value);

    public Task PressRiskComputerSystemsSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskComputerSystemsSearchValue, key);

    public Task EnterRiskBaileesCustomersSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersSearchValue, value);

    public Task PressRiskBaileesCustomersSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersSearchValue, key);

    public Task VerifyShowMeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ShowMe, expected, property);

    public Task ClickShowMeAsync() =>
        _ui.ClickAsync(_locators.ShowMe);

    public Task<bool> IsShowMeVisibleAsync() => _ui.ExistsAsync(_locators.ShowMe);

    public Task SetSplitBIDedAsync(string value) =>
        _ui.SmartSetAsync(_locators.SplitBIDed, value);

    public Task PressSplitBIDedAsync(string key) =>
        _ui.PressAsync(_locators.SplitBIDed, key);

    public Task EnterSplitPDDedAsync(string value) =>
        _ui.FillAsync(_locators.SplitPDDed, value);

    public Task ClickStartAsync() =>
        _ui.ClickAsync(_locators.Start);

    public Task VerifyBrowserCommunicationHTTPStatusZeroAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.BrowserCommunicationHTTPStatusZero, expected, property);

    public Task VerifyValueAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Value, expected, property);

    public Task ClickValueAsync() =>
        _ui.ClickAsync(_locators.Value);

    public Task WaitForViewPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.ViewPolicy, expected);

    public Task PressViewPolicyAsync(string key) =>
        _ui.PressAsync(_locators.ViewPolicy, key);

    public Task ClickViewPolicyAsync() =>
        _ui.ClickAsync(_locators.ViewPolicy);

    public Task WaitForWatercraftLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);
    public Task<string> CaptureDescriptionOfSpecifiedOperationAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DescriptionOfSpecifiedOperation, property);


    public Task EnterAggregateLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AggregateLimit, value, delayMs);

    public Task EnterDedTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DedType, value, delayMs);

    public Task EnterDeductibleBasisSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DeductibleBasis, value, delayMs);

    public Task EnterDescriptionOfSpecifiedOperationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfSpecifiedOperation, value, delayMs);

    public Task EnterDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, value, delayMs);

    public Task EnterFireDamageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FireDamage, value, delayMs);

    public Task EnterHasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverage, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyDescriptionOfOtherSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyDescriptionOfOther, value, delayMs);

    public Task EnterIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, value, delayMs);

    public Task EnterMedicalSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Medical, value, delayMs);

    public Task EnterOccurenceLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OccurenceLimit, value, delayMs);

    public Task EnterOfFullTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfFullTimeEmployees, value, delayMs);

    public Task EnterOfPartTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfPartTimeEmployees, value, delayMs);

    public Task EnterOfSeasonalTemporaryEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfSeasonalTemporaryEmployees, value, delayMs);

    public Task EnterPersAdvInjSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PersAdvInj, value, delayMs);

    public Task EnterPremOpDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PremOpDed, value, delayMs);

    public Task EnterPremOpPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PremOpPDDed, value, delayMs);

    public Task EnterProdBIDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProdBIDed, value, delayMs);

    public Task EnterProdPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProdPDDed, value, delayMs);

    public Task EnterProductsAggLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProductsAggLimit, value, delayMs);

    public Task EnterPropertyOfOthersRatingGroupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PropertyOfOthersRatingGroup, value, delayMs);

    public Task EnterSearchMethodEGDescriptionPolicySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchMethodEGDescriptionPolicy, value, delayMs);

    public Task EnterRiskComputerSystemsSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskComputerSystemsSearchResult, value, delayMs);

    public Task EnterRiskBaileesCustomersSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersSearchResult, value, delayMs);

    public Task EnterRiskAccountsReceivableSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskAccountsReceivableSearchResult, value, delayMs);

    public Task EnterSearchTextSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchText, value, delayMs);

    public Task EnterRiskAccountsReceivableSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskAccountsReceivableSearchValue, value, delayMs);

    public Task EnterRiskComputerSystemsSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskComputerSystemsSearchValue, value, delayMs);

    public Task EnterRiskBaileesCustomersSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersSearchValue, value, delayMs);

    public Task EnterSplitPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SplitPDDed, value, delayMs);

    public Task ClickLocationAsync() =>
        _ui.ClickAsync(_locators.Location);

    public Task<bool> IsTerritoryVisibleAsync() => _ui.ExistsAsync(_locators.Territory);

    public Task EnterTerritoryAsync(string value) =>
        _ui.FillAsync(_locators.Territory, value);
}
