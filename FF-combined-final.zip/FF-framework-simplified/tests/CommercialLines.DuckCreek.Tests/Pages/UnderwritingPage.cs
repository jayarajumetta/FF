using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class UnderwritingPage
{
    private readonly BrowserSession _browser;
    private readonly UnderwritingLocators _locators;
    private readonly UiActions _ui;

    public UnderwritingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new UnderwritingLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAcceptAsync(string expected) =>
        _ui.WaitAsync(_locators.Accept, expected);

    public Task ClickAcceptAsync() =>
        _ui.ClickAsync(_locators.Accept);

    public Task WaitForUnderwritingInfoCommercialPropertyHistoryCommercialGeneralLiabilityHistoryAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task ClickUnderwritingInfoNavigationCommercialGeneralLiabilityHistoryAsync() =>
        _ui.ClickAsync(_locators.UnderwritingInfoNavigationCommercialGeneralLiabilityHistory);

    public Task ClickCommercialPropertyHistoryAsync() =>
        _ui.ClickAsync(_locators.CommercialPropertyHistory);

    public Task WaitForUnderwritingInfoGeneralUWQuestionsGeneralUWQuestionsAsync(string expected) =>
        _ui.WaitAsync(_locators.UnderwritingInfoGeneralUWQuestionsGeneralUWQuestions, expected);

    public Task ClickUnderwritingInfoNavigationGeneralUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.UnderwritingInfoNavigationGeneralUWQuestions);

    public Task WaitForInsuranceScoreAsync(string expected) =>
        _ui.WaitAsync(_locators.InsuranceScore, expected);

    public Task<bool> IsInsuranceScoreVisibleAsync() => _ui.ExistsAsync(_locators.InsuranceScore);

    public Task ClickInsuranceScoreAsync() =>
        _ui.ClickAsync(_locators.InsuranceScore);

    public Task ClickInsuranceScoreConsentAsync() =>
        _ui.ClickAsync(_locators.InsuranceScoreConsent);

    public Task EnterUnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrierAsync(string value) =>
        _ui.FillAsync(_locators.UnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrier, value);

    public Task PressUnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrierAsync(string key) =>
        _ui.PressAsync(_locators.UnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrier, key);

    public Task EnterUnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrierAsync(string value) =>
        _ui.FillAsync(_locators.UnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrier, value);

    public Task PressUnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrierAsync(string key) =>
        _ui.PressAsync(_locators.UnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrier, key);

    public Task EnterUnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrierAsync(string value) =>
        _ui.FillAsync(_locators.UnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrier, value);

    public Task PressUnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrierAsync(string key) =>
        _ui.PressAsync(_locators.UnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrier, key);

    public Task WaitForUnderwritingInfoOtherInsuranceHistoryOtherInsuranceHistoryAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task ClickUnderwritingInfoNavigationOtherInsuranceHistoryAsync() =>
        _ui.ClickAsync(_locators.UnderwritingInfoNavigationOtherInsuranceHistory);

    public Task VerifyReferenceNumberAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ReferenceNumber, expected, property);

    public Task VerifyTheInsuranceScoreServiceHasReturnedTheFollowingErrorCREDITVENDORUNREACHABLEPLEASEREPROCESSAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.TheInsuranceScoreServiceHasReturnedTheFollowingErrorCREDITVENDORUNREACHABLEPLEASEREPROCESS, expected, property);

    public Task ClickUpdateAnswersAsync() =>
        _ui.ClickAsync(_locators.UpdateAnswers);
    public Task EnterUnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UnderwritingInfoCommercialPropertyHistoryIsThereAPriorCarrier, value, delayMs);

    public Task EnterUnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UnderwritingInfoCommercialGeneralLiabilityHistoryIsThereAPriorCarrier, value, delayMs);

    public Task EnterUnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UnderwritingInfoOtherInsuranceHistoryIsThereAPriorCarrier, value, delayMs);
}
