using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class FormsPage
{
    private readonly BrowserSession _browser;
    private readonly FormsLocators _locators;
    private readonly UiActions _ui;

    public FormsPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new FormsLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAdditionalInterestsAsync(string expected) =>
        _ui.WaitAsync(_locators.AddlInterestsLink, expected);

    public Task ClickAdditionalInterestsAsync() =>
        _ui.ClickAsync(_locators.AddlInterestsLink);

    public Task WaitForAddlInterestsAsync(string expected) =>
        _ui.WaitAsync(_locators.AddlInterests, expected);

    public Task ClickBusinessownersAsync() =>
        _ui.ClickAsync(_locators.Businessowners);

    public Task WaitForBusinessownersHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.BusinessOwnerHeading, expected);

    public Task WaitForEffectiveDateAsync(string expected) =>
        _ui.WaitAsync(_locators.EffectiveDate, expected);

    public Task EnterEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task EnterLiquifiedGasAsync(string value) =>
        _ui.FillAsync(_locators.LiquifiedGas, value);

    public Task PressEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task VerifyEmployerSLiabilityCheckBoxAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EmployerSLiabilityCheckBox, expected, property);


    public Task VerifyYearBuilt1980Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.YearBuilt1980, expected, property);

    public Task EnterExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.ExpirationDate, value);

    public Task PressExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.ExpirationDate, key);

    public Task WaitForHomeownerSLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task PressHomeownerSLiabilityAsync(string key) =>
        _ui.PressAsync(_locators.PageTitle, key);

    public Task ClickHomeownerSLiabilityAsync() =>
    _locators.HomersLiability.EvaluateAsync("el => el.click()");

    public Task ClickImportPolicyDataButtonAsync() =>
        _ui.ClickAsync(_locators.ImportPolicyDataButton);

    public Task EnterLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.LiabilityLimit, value);

    public Task PressLiabilityLimitAsync(string key) =>
        _ui.PressAsync(_locators.LiabilityLimit, key);

    public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task EnterPDLimitAsync(string value) =>
        _ui.FillAsync(_locators.PDLimit, value);

    public Task EnterCommercialUMLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialUMLimit, value, delayMs);

    public Task PressCommercialUMLimitAsync(string key) =>
       _ui.PressAsync(_locators.CommercialUMLimit, key);

    public Task PressPDLimitAsync(string key) =>
        _ui.PressAsync(_locators.PDLimit, key);

    public Task WaitForPersonalAutoAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalAuto, expected);

    public Task PressPersonalAutoAsync(string key) =>
        _ui.PressAsync(_locators.PersonalAuto, key);

    public Task ClickPersonalAutoAsync() =>
        _ui.ClickAsync(_locators.PersonalAuto);

    public Task EnterPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.PolicyNumber, value);

    public Task<string> CapturePolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PolicyNumber, property);

    public Task PressPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.PolicyNumber, key);

    public Task EnterSessionIDAsync(string value) =>
        _ui.FillAsync(_locators.SessionID, value);

    public Task PressSessionIDAsync(string key) =>
        _ui.PressAsync(_locators.SessionID, key);

    public Task<bool> HasSessionIDAsync() =>
        _ui.ExistsAsync(_locators.SessionID);

    public Task VerifyStatusCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.StatusCode, expected, property);

    public Task<bool> HasStatusCodeAsync() =>
        _ui.ExistsAsync(_locators.StatusCode);

    public Task EnterTotalSubjectPremiumAsync(string value) =>
        _ui.FillAsync(_locators.TotalSubjectPremium, value);

    public Task PressTotalSubjectPremiumAsync(string key) =>
        _ui.PressAsync(_locators.TotalSubjectPremium, key);

    public Task<string> CaptureValueAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Value, property);

    public Task WaitForWatercraftLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task PressWatercraftLiabilityAsync(string key) =>
        _ui.PressAsync(_locators.PageTitle, key);

    public Task ClickWatercraftLiabilityAsync() =>
        _locators.WaterLiability.EvaluateAsync("el => el.click()");
    public Task EnterEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EffectiveDate, value, delayMs);

    public Task EnterExpirationDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExpirationDate, value, delayMs);

    public Task EnterLiabilityLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LiabilityLimit, value, delayMs);

    public Task EnterPDLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PDLimit, value, delayMs);

    public Task EnterPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyNumber, value, delayMs);

    public Task EnterSessionIDSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SessionID, value, delayMs);

    public Task EnterTotalSubjectPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalSubjectPremium, value, delayMs);
}
