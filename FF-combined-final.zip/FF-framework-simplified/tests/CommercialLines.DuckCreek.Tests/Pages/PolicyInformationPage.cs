using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class PolicyInformationPage
{
    private readonly BrowserSession _browser;
    private readonly PolicyInformationLocators _locators;
    private readonly UiActions _ui;

    public PolicyInformationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new PolicyInformationLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterCarrierAsync(string value) =>
        _ui.FillAsync(_locators.Carrier, value);

    public Task PressCarrierAsync(string key) =>
        _ui.PressAsync(_locators.Carrier, key);

    public Task WaitForClientAsync(string expected) =>
        _ui.WaitAsync(_locators.Client, expected);

    public Task WaitForDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.Detail, expected);

    public Task EnterEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task PressEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task ClickEnterPriorLossInformationAsync() =>
        _ui.ClickAsync(_locators.EnterPriorLossInformation);

    public Task EnterExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.ExpirationDate, value);

    public Task PressExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.ExpirationDate, key);

    public Task ClickInsuranceHistoryAsync() =>
        _ui.ClickAsync(_locators.InsuranceHistory);

    public Task WaitForIsThereAPriorCarrierAsync(string expected) =>
        _ui.WaitAsync(_locators.IsThereAPriorCarrier, expected);

    public Task EnterIsThereAPriorCarrierAsync(string value) =>
        _ui.FillAsync(_locators.IsThereAPriorCarrier, value);

    public Task PressIsThereAPriorCarrierAsync(string key) =>
        _ui.PressAsync(_locators.IsThereAPriorCarrier, key);

    public Task ClickIsThereAPriorCarrierAsync() =>
        _ui.ClickAsync(_locators.IsThereAPriorCarrier);

    public Task WaitForLossExperienceHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.LossExperienceHeading, expected);

    public Task EnterModificationFactorAsync(string value) =>
        _ui.FillAsync(_locators.ModificationFactor, value);

    public Task PressModificationFactorAsync(string key) =>
        _ui.PressAsync(_locators.ModificationFactor, key);

    public Task VerifyNoKnownLossesAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NoKnownLosses, expected, property);

    public Task SetNoKnownLossesAsync(string value) =>
        _ui.SmartSetAsync(_locators.NoKnownLosses, value);

    public Task PressNoKnownLossesAsync(string key) =>
        _ui.PressAsync(_locators.NoKnownLosses, key);

    public Task ClickNoKnownLossesAsync() =>
        _ui.ClickAsync(_locators.NoKnownLosses);

    public Task ClickOtherInsuranceHistoryOKAsync() =>
        _ui.ClickAsync(_locators.OtherInsuranceHistoryOK);

    public Task EnterPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.PolicyNumber, value);

    public Task PressPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.PolicyNumber, key);

    public Task EnterPolicyTypeAsync(string value) =>
        _ui.FillAsync(_locators.PolicyType, value);

    public Task PressPolicyTypeAsync(string key) =>
        _ui.PressAsync(_locators.PolicyType, key);

    public Task ClickReturnToQuoteAsync() =>
        _ui.ClickAsync(_locators.ReturnToQuote);

    public Task EnterTotalPremiumAsync(string value) =>
        _ui.FillAsync(_locators.TotalPremium, value);

    public Task PressTotalPremiumAsync(string key) =>
        _ui.PressAsync(_locators.TotalPremium, key);
    public Task EnterCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Carrier, value, delayMs);

    public Task EnterEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EffectiveDate, value, delayMs);

    public Task EnterExpirationDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExpirationDate, value, delayMs);

    public Task EnterIsThereAPriorCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsThereAPriorCarrier, value, delayMs);

    public Task EnterModificationFactorSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ModificationFactor, value, delayMs);

    public Task EnterPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyNumber, value, delayMs);

    public Task EnterPolicyTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyType, value, delayMs);

    public Task EnterTotalPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalPremium, value, delayMs);
}
