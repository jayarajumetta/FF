using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class SubmissionPage
{
    private readonly BrowserSession _browser;
    private readonly SubmissionLocators _locators;
    private readonly UiActions _ui;

    public SubmissionPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new SubmissionLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifyAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabs, expected, property);

    public Task ClickCompleteApplicationAsync() =>
        _ui.ClickAsync(_locators.CompleteApplication);

    public Task VerifyIsThisCoverageBoundAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IsThisCoverageBound, expected, property);

    public Task EnterIsThisCoverageBoundAsync(string value) =>
        _ui.FillAsync(_locators.IsThisCoverageBound, value);

    public Task PressIsThisCoverageBoundAsync(string key) =>
        _ui.PressAsync(_locators.IsThisCoverageBound, key);

    public Task<bool> IsThisCoverageBoundExistsAsync() =>
        _ui.ExistsAsync(_locators.IsThisCoverageBound);

    public Task EnterJavaScriptAsync(string value) =>
        _ui.FillAsync(_locators.JavaScript, value);

    public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task VerifyResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Result, expected, property);

    public Task WaitForStoplightWaitingWindowAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightWaitingWindow, expected);
    public Task WaitStoplightWaitingWindowCloseAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightWaitingWindowClose, expected);

    public Task VerifyStoplightWaitingWindowCloseAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.StoplightWaitingWindowClose, expected, property);

    public Task ClickStoplightWaitingWindowCloseAsync() =>
        _ui.ClickAsync(_locators.StoplightWaitingWindowClose);

    public Task VerifyStoplightWaitingWindowErrorAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.StoplightWaitingWindowError, expected, property);

    public Task ClickStoplightWaitingWindowFirstCloseButtonOnErrorAsync() =>
        _ui.ClickAsync(_locators.StoplightWaitingWindowClose);

    public Task EnterTitleAsync(string value) =>
        _ui.FillAsync(_locators.Title, value);

    public Task WaitForStoplightProcessingCompleteMessageAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightProcessingCompleteMessage, expected);

    public Task ClickStoplightWaitingWindowCloseButtonAsync() =>
        _ui.ClickAsync(_locators.StoplightWaitingWindowClose);
    public Task<string> CaptureResultAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Result, property);


    public Task EnterIsThisCoverageBoundSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsThisCoverageBound, value, delayMs);

    public Task EnterJavaScriptSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.JavaScript, value, delayMs);

    public Task EnterTitleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Title, value, delayMs);
}
