using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class CoveragesPage
{
    private readonly BrowserSession _browser;
    private readonly CoveragesLocators _locators;
    private readonly UiActions _ui;

    public CoveragesPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new CoveragesLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickAddCoverageFormAsync() =>
        _ui.ClickAsync(_locators.AddCoverageForm);

    public Task WaitForAddCoverageFormAsync(string expected) =>
        _ui.WaitAsync(_locators.AddCoverageForm, expected);

    public Task ClickAddEndorsementAsync() =>
        _ui.ClickAsync(_locators.AddEndorsement);

    public Task WaitForAwayFromPremisesDescAsync(string expected) =>
        _ui.WaitAsync(_locators.AwayFromPremisesDesc, expected);

    public Task EnterAwayFromPremisesDescAsync(string value) =>
        _ui.FillAsync(_locators.AwayFromPremisesDesc, value);

    public Task EnterAwayFromPremisesDescSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AwayFromPremisesDesc, value, delayMs);

    public Task PressAwayFromPremisesDescAsync(string key) =>
        _ui.PressAsync(_locators.AwayFromPremisesDesc, key);

    public Task WaitForAwayFromPremisesLmtAsync(string expected) =>
        _ui.WaitAsync(_locators.AwayFromPremisesLmt, expected);

    public Task EnterAwayFromPremisesLmtAsync(string value) =>
        _ui.FillAsync(_locators.AwayFromPremisesLmt, value);

    public Task EnterAwayFromPremisesLmtSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AwayFromPremisesLmt, value, delayMs);

    public Task PressAwayFromPremisesLmtAsync(string key) =>
        _ui.PressAsync(_locators.AwayFromPremisesLmt, key);

    public Task ClickPolicyCovgAccountsReceivableOKAsync() =>
        _ui.ClickAsync(_locators.PolicyCovgAccountsReceivableOK);

    public Task WaitForPolicyCovgAccountsReceivableOKAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgAccountsReceivableOK, expected);

    public Task ClickCPAsync() =>
        _ui.ClickAsync(_locators.CP);

    public Task WaitForCoinsuranceAsync(string expected) =>
        _ui.WaitAsync(_locators.Coinsurance, expected);

    public Task EnterCoinsuranceAsync(string value) =>
        _ui.FillAsync(_locators.Coinsurance, value);

    public Task PressCoinsuranceAsync(string key) =>
        _ui.PressAsync(_locators.Coinsurance, key);

    public Task WaitForCoverageFormToBeAddedAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormToBeAdded, expected);

    public Task EnterCoverageFormToBeAddedAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormToBeAdded, value);

    public Task PressCoverageFormToBeAddedAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormToBeAdded, key);

    public async Task EnterCoverageFormToBeAddedWithRetryAsync(string value, int maxAttempts = 3, int waitBeforeMs = 1000, int delayMs = 20)
    {
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await Task.Delay(waitBeforeMs);
            if (await _ui.ExistsAsync(_locators.CoverageFormToBeAdded))
            {
                await _ui.PressSequentiallyAsync(_locators.CoverageFormToBeAdded, value, delayMs);
                return;
            }
        }
        await _ui.PressSequentiallyAsync(_locators.CoverageFormToBeAdded, value, delayMs);
    }

    public Task WaitForDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.Description, expected);

    public Task EnterDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.Description, value);

    public Task<string> CaptureDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Description, property);

    public Task PressDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.Description, key);

    public Task WaitForDescriptionOfSpecifiedOperationAsync(string expected) =>
        _ui.WaitAsync(_locators.DescriptionOfSpecifiedOperation, expected);

    public Task VerifyDescriptionOfSpecifiedOperationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.DescriptionOfSpecifiedOperation, expected, property);

    public Task EnterDescriptionOfSpecifiedOperationAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfSpecifiedOperation, value);

    public Task PressDescriptionOfSpecifiedOperationAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfSpecifiedOperation, key);

    public Task ClickDetailAsync() =>
        _ui.ClickAsync(_locators.Detail);

    public Task Click0078DetailAsync() =>
      _ui.ClickAsync(_locators.FG0078Detail);






    public Task Click0062DetailAsync() =>
     _ui.ClickAsync(_locators.FG0062);

    public Task Click0069DetailAsync() =>
     _ui.ClickAsync(_locators.FG0069);

    public Task Click0072DetailAsync() =>
     _ui.ClickAsync(_locators.FG0072);

    public Task Click0063DetailAsync() =>
     _ui.ClickAsync(_locators.FG0063);

    public Task Click0074DetailAsync() =>
     _ui.ClickAsync(_locators.FG0074);

    public Task Click0077DetailAsync() =>
     _ui.ClickAsync(_locators.FG0077);

    public Task Click0071DetailAsync() =>
     _ui.ClickAsync(_locators.FG0071);

    public Task ClickFG0055DetailAsync() =>
        _ui.ClickAsync(_locators.FG0055Detail);

    public Task EnterEndorsementTypeAsync(string value) =>
        _ui.FillAsync(_locators.EndorsementType, value);

    public Task PressEndorsementTypeAsync(string key) =>
        _ui.PressAsync(_locators.EndorsementType, key);

    public Task ClickGLNavigationLinksEndorsementsAsync() =>
        _ui.ClickAsync(_locators.GLNavigationLinksEndorsements);

    public Task WaitForEndorsementsAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterEstimatedPremiumAsync(string value) =>
        _ui.FillAsync(_locators.EstimatedPremium, value);

    public Task VerifyFG0055TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FG0055TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsement, expected, property);

    public Task<bool> IsCG2151TableRowAmendmentOfLiquorLiabilityExclusionVisibleAsync() =>
        _ui.ExistsAsync(_locators.CG2151TableRowAmendmentOfLiquorLiabilityExclusion);

    public Task ClickCG2151DetailAsync() =>
        _ui.ClickAsync(_locators.CG2151Detail);

    public Task EnterCovEndorsementsDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CovEndorsementsDescription, value);

    public Task<bool> IsFG0059TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementNYVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0059TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementNY);

    public Task ClickFG0059DetailAsync() =>
        _ui.ClickAsync(_locators.FG0059Detail);

    public Task<bool> IsFG0063TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementMDVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0063TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementMD);

    public Task ClickFG0063DetailAsync() =>
        _ui.ClickAsync(_locators.FG0063Detail);

    public Task<bool> IsFG0062TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementPAVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0062TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementPA);

    public Task ClickFG0062DetailAsync() =>
        _ui.ClickAsync(_locators.FG0062Detail);

    public Task<bool> IsFG0069TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementORVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0069TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementOR);

    public Task ClickFG0069DetailAsync() =>
        _ui.ClickAsync(_locators.FG0069Detail);

    public Task<bool> IsFG0071TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementNHVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0071TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementNH);

    public Task ClickFG0071DetailAsync() =>
        _ui.ClickAsync(_locators.FG0071Detail);

    public Task<bool> IsFG0072TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementMEVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0072TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementME);

    public Task ClickFG0072DetailAsync() =>
        _ui.ClickAsync(_locators.FG0072Detail);

    public Task<bool> IsFG0074TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementCTVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0074TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementCT);

    public Task ClickFG0074DetailAsync() =>
        _ui.ClickAsync(_locators.FG0074Detail);

    public Task<bool> IsFG0077TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementVAVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0077TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementVA);

    public Task ClickFG0077DetailAsync() =>
        _ui.ClickAsync(_locators.FG0077Detail);

    public Task<bool> IsFG0078TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementVTVisibleAsync() =>
        _ui.ExistsAsync(_locators.FG0078TableRowEmploymentPracticesLiabilityInsuranceCoverageEndorsementVT);

    public Task ClickFG0078DetailAsync() =>
        _ui.ClickAsync(_locators.FG0078Detail);

    public Task VerifyFG0078TableRowEndorsementAsync(string expected, string property) =>
      _ui.VerifyAsync(_locators.FG0078Detail, expected, property);


    public Task VerifyFG0062TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0062, expected, property);

    public Task VerifyFG0069TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0069, expected, property);

    public Task VerifyFG0072TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0072, expected, property);

    public Task VerifyFG0063TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0063, expected, property);

    public Task VerifyFG0077TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0077, expected, property);

    public Task VerifyFG0071TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0071, expected, property);

    public Task VerifyCG2151TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.CG2151, expected, property);

    public Task VerifyFG0074TableRowEndorsementAsync(string expected, string property) =>
    _ui.VerifyAsync(_locators.FG0074, expected, property);



    public Task WaitForFGFormTableRowAsync(string expected) =>
        _ui.WaitAsync(_locators.FGFormTableRow, expected);

    public Task EnterFungusAsync(string value) =>
        _ui.FillAsync(_locators.Fungus, value);

    public Task PressFungusAsync(string key) =>
        _ui.PressAsync(_locators.Fungus, key);

    public Task ClickGLAsync() =>
        _ui.ClickAsync(_locators.GL);

    public Task EnterHasTheInsuredEverHadAClaimForEmploymentPracticesAsync(string value) =>
        _ui.FillAsync(_locators.HasTheInsuredEverHadAClaimForEmploymentPractices, value);

    public Task PressHasTheInsuredEverHadAClaimForEmploymentPracticesAsync(string key) =>
        _ui.PressAsync(_locators.HasTheInsuredEverHadAClaimForEmploymentPractices, key);

    public Task ClickIMAsync() =>
        _ui.ClickAsync(_locators.IM);

    public Task EnterLimitDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.LimitDeductible, value);

    public Task PressLimitDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.LimitDeductible, key);

    public Task EnterPolicyCoverageAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCoverage, value);

    public Task PressPolicyCoverageAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCoverage, key);

    public Task ClickIMNavigationLinksPolicyCovgAsync() =>
        _ui.ClickAsync(_locators.IMNavigationLinksPolicyCovg);

    public Task WaitForPolicyCovgMainPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task WaitForPolicyInfoHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterPropertyExtensionEndorsementsAsync(string value) =>
        _ui.FillAsync(_locators.PropertyExtensionEndorsements, value);

    public Task PressPropertyExtensionEndorsementsAsync(string key) =>
        _ui.PressAsync(_locators.PropertyExtensionEndorsements, key);

    public Task EnterTheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaintAsync(string value) =>
        _ui.FillAsync(_locators.TheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint, value);

    public Task PressTheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaintAsync(string key) =>
        _ui.PressAsync(_locators.TheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint, key);

    public Task EnterThirdPartyAsync(string value) =>
        _ui.FillAsync(_locators.ThirdParty, value);

    public Task PressThirdPartyAsync(string key) =>
        _ui.PressAsync(_locators.ThirdParty, key);

    public Task EnterUtilityServicesAsync(string value) =>
        _ui.FillAsync(_locators.UtilityServices, value);

    public Task PressUtilityServicesAsync(string key) =>
        _ui.PressAsync(_locators.UtilityServices, key);

    public Task<string> CaptureDescriptionOfSpecifiedOperationAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DescriptionOfSpecifiedOperation, property);


    public Task EnterCoinsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Coinsurance, value, delayMs);

    public Task EnterCoverageFormToBeAddedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormToBeAdded, value, delayMs);

    public Task EnterDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Description, value, delayMs);

    public Task EnterDescriptionOfSpecifiedOperationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfSpecifiedOperation, value, delayMs);

    public Task EnterEndorsementTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EndorsementType, value, delayMs);

    public Task EnterEstimatedPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EstimatedPremium, value, delayMs);

    public Task EnterFungusSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Fungus, value, delayMs);

    public Task EnterHasTheInsuredEverHadAClaimForEmploymentPracticesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HasTheInsuredEverHadAClaimForEmploymentPractices, value, delayMs);

    public Task EnterLimitDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LimitDeductible, value, delayMs);

    public Task EnterPolicyCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCoverage, value, delayMs);

    public Task EnterPropertyExtensionEndorsementsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PropertyExtensionEndorsements, value, delayMs);

    public Task EnterTheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaintSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TheInsuredAndAnyExecutiveOfficerOrOwnerHasKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint, value, delayMs);

    public Task EnterThirdPartySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ThirdParty, value, delayMs);

    public Task EnterUtilityServicesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UtilityServices, value, delayMs);
}
