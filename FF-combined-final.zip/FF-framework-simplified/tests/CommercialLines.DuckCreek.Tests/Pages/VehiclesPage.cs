using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class VehiclesPage
{
    private readonly BrowserSession _browser;
    private readonly VehiclesLocators _locators;
    private readonly UiActions _ui;

    public VehiclesPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new VehiclesLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterCarrierNameAsync(string value) =>
        _ui.FillAsync(_locators.CarrierName, value);

    public Task PressCarrierNameAsync(string key) =>
        _ui.PressAsync(_locators.CarrierName, key);

    public Task WaitForEffectiveDateAsync(string expected) =>
        _ui.WaitAsync(_locators.EffectiveDate, expected);

    public Task EnterEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task PressEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task EnterExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.ExpirationDate, value);

    public Task PressExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.ExpirationDate, key);

    public Task ClickIncludeMotorcycleLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeMotorcycleLiability);

    public Task ClickIncludeRecreationalVehicleLiabilityAsync() =>
        _ui.ClickAsync(_locators.IncludeRecreationalVehicleLiability);

    public Task EnterLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.LiabilityLimit, value);

    public Task PressLiabilityLimitAsync(string key) =>
        _ui.PressAsync(_locators.LiabilityLimit, key);

    public Task WaitForMotorcycleLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterPDLimitAsync(string value) =>
        _ui.FillAsync(_locators.PDLimit, value);

    public Task PressPDLimitAsync(string key) =>
        _ui.PressAsync(_locators.PDLimit, key);

    public Task WaitForPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovg, expected);

    public Task EnterPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.PolicyNumber, value);

    public Task PressPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.PolicyNumber, key);

    public Task WaitForRecreationalVehicleLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.RecreationalVehicleLiability, expected);

    public Task ClickRecreationalVehicleLiabilityAsync() =>
        _locators.RecreationalVehicleLiability.EvaluateAsync("el => el.click()");

    public Task WaitForRecreationalVehicleLiabilityHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterTotalSubjectPremiumAsync(string value) =>
        _ui.FillAsync(_locators.TotalSubjectPremium, value);

    public Task PressTotalSubjectPremiumAsync(string key) =>
        _ui.PressAsync(_locators.TotalSubjectPremium, key);


    public Task EnterCarrierNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CarrierName, value, delayMs);

    public Task EnterEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EffectiveDate, value, delayMs);

    public Task EnterExpirationDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExpirationDate, value, delayMs);

    public Task EnterLiabilityLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LiabilityLimit, value, delayMs);

    public Task EnterPDLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PDLimit, value, delayMs);

    public Task EnterPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyNumber, value, delayMs);

    public Task EnterTotalSubjectPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalSubjectPremium, value, delayMs);

    public Task EnterCommercialUMLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialUMLimit, value, delayMs);

    public Task PressCommercialUMLimitAsync(string key) =>
        _ui.PressAsync(_locators.CommercialUMLimit, key);
}
