using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class ProposalPage
{
    private readonly BrowserSession _browser;
    private readonly ProposalLocators _locators;
    private readonly UiActions _ui;

    public ProposalPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new ProposalLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task PressEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task<string> CaptureEffectiveDateAsync(string property = "") =>
        _ui.CaptureAsync(_locators.EffectiveDate, property);

    public Task ClickNewQuoteAsync() =>
        _ui.ClickAsync(_locators.NewQuote);

    public Task EnterProductAsync(string value) =>
        _ui.FillAsync(_locators.Product, value);
    public Task EnterProducerAsync(string value) =>
        _ui.FillAsync(_locators.Producer, value);

    public async Task EnterProducerSequentiallyAsync(string value, int delayMs = 20)
    {
        await _ui.PressSequentiallyAsync(_locators.Producer, value, delayMs);
    }
    public Task PressProductAsync(string key) =>
        _ui.PressAsync(_locators.Product, key);

    public Task PressProducerAsync(string key) =>
        _ui.PressAsync(_locators.Producer, key);

    public Task WaitForStartAsync(string expected) =>
        _ui.WaitAsync(_locators.Start, expected);

    public Task ClickStartAsync() =>
        _ui.ClickAsync(_locators.Start);


    public Task EnterEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EffectiveDate, value, delayMs);

    public async Task EnterProductSequentiallyAsync(string value, int delayMs = 20)
    {
        await _ui.PressSequentiallyAsync(_locators.Product, value, delayMs);
    }
}
