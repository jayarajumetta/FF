using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class PricingPage
{
    private readonly BrowserSession _browser;
    private readonly PricingLocators _locators;
    private readonly UiActions _ui;

    public PricingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new PricingLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifyEstimatedPremiumAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EstimatedPremium, expected, property);

    public Task VerifyFullTermPremiumAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FullTermPremium, expected, property);

    public Task WaitForFullTermPremiumAsync(string expected) =>
        _ui.WaitAsync(_locators.FullTermPremium, expected);

    public Task EnterWCEstimatedPremiumAsync(string value) =>
       _ui.FillAsync(_locators.EstimatedPremium, value);


    public Task EnterJavaScriptAsync(string value) =>
        _ui.FillAsync(_locators.JavaScript, value);

    public Task VerifyPremiumAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Premium, expected, property);


    public Task ClickPolicyFormAsync() =>
       _ui.ClickAsync(_locators.PolicyForms);

    public Task VerifyPremiumChangeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PremiumChange, expected, property);

    public Task VerifyPremiumWrittenAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PremiumWritten, expected, property);

    public Task VerifyPriorPremiumAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PriorPremium, expected, property);

    public Task VerifyResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Result, expected, property);

    public Task EnterTitleAsync(string value) =>
        _ui.FillAsync(_locators.Title, value);

    public Task<string> CaptureResultAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Result, property);


    public Task EnterJavaScriptSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.JavaScript, value, delayMs);

    public Task EnterTitleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Title, value, delayMs);
}
