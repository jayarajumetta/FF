using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class DiscountsPage
{
    private readonly BrowserSession _browser;
    private readonly DiscountsLocators _locators;
    private readonly UiActions _ui;

    public DiscountsPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new DiscountsLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterAccountCreditAsync(string value) =>
        _ui.FillAsync(_locators.AccountCredit, value);

    public Task PressAccountCreditAsync(string key) =>
        _ui.PressAsync(_locators.AccountCredit, key);

    public Task WaitForBAPSpecificFieldsOKAsync(string expected) =>
        _ui.WaitAsync(_locators.BAPSpecificFieldsOK, expected);

    public Task VerifyBAPSpecificFieldsOKAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.BAPSpecificFieldsOK, expected, property);

    public Task ClickBAPSpecificFieldsOKAsync() =>
        _ui.ClickAsync(_locators.BAPSpecificFieldsOK);

    public Task EnterNAICSCodeSearchResultsAsync(string value) =>
        _ui.FillAsync(_locators.NAICSCodeSearchResults, value);

    public Task PressNAICSCodeSearchResultsAsync(string key) =>
        _ui.PressAsync(_locators.NAICSCodeSearchResults, key);

    public Task EnterNAICSCodeSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.NAICSCodeSearchValue, value);

    public Task PressNAICSCodeSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.NAICSCodeSearchValue, key);
    public Task EnterAccountCreditSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AccountCredit, value, delayMs);

    public Task EnterNAICSCodeSearchResultsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NAICSCodeSearchResults, value, delayMs);

    public Task EnterNAICSCodeSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NAICSCodeSearchValue, value, delayMs);
}
