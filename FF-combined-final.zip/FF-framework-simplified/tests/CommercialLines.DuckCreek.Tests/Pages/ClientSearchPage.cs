using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLDC.Pages.Locators;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class ClientSearchPage
{
    private readonly BrowserSession _browser;
    private readonly ClientSearchLocators _locators;
    private readonly UiActions _ui;

    public ClientSearchPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new ClientSearchLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickAddNamedInsuredIndividualAsync() =>
        _ui.ClickAsync(_locators.AddNamedInsuredIndividual);

    public async Task CheckIsClientDataCurrentAsync()
    {
        if (await _locators.IsClientDataCurrent.CountAsync() > 0 && await _locators.IsClientDataCurrent.IsVisibleAsync())
        {
            await _ui.ClickAsync(_locators.IsClientDataCurrent);
            if (await _locators.OK.CountAsync() > 0 && await _locators.OK.IsVisibleAsync())
            {
                await _ui.ClickAsync(_locators.OK);
            }
        }

    }

    public Task WaitForAdditionalInsuredFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalInsuredFirstName, expected);

    public Task EnterAdditionalInsuredFirstNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredFirstName, value);

    public Task PressAdditionalInsuredFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredFirstName, key);

    public Task WaitForAdditionalInsuredLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalInsuredLastName, expected);

    public Task EnterAdditionalInsuredLastNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredLastName, value);

    public Task EnterAdditionalInsuredLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredLastName, value, delayMs);

    public Task PressAdditionalInsuredLastNameAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredLastName, key);

    public Task EnterAdditionalInsuredMiddleNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredMiddleName, value);

    public Task PressAdditionalInsuredMiddleNameAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredMiddleName, key);

    public Task WaitForAdditionalNamedInsuredAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalNamedInsured, expected);

    public Task ClickAdditionalNamedInsuredAsync() =>
        _ui.ClickAsync(_locators.AdditionalNamedInsured);

    public Task WaitForAdditionalNamedInsuredHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalNamedInsuredHeading, expected);

    public Task WaitForAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.Address, expected);

    public Task EnterAddressAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.Address, value);

    public Task<string> CaptureAddressAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Address, property);

    public Task PressAddressAsync(string key) =>
        _ui.PressAsync(_locators.Address, key);

    public Task WaitForAdditionalInsuredIndividualAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalInsuredIndividualAddress, expected);

    public Task EnterAdditionalInsuredIndividualAddressAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualAddress, value);

    public Task PressAdditionalInsuredIndividualAddressAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredIndividualAddress, key);

    public Task PressAddressLineTwoAsync(string key) =>
        _ui.PressAsync(_locators.AddressLineTwo, key);

    public Task WaitForBusinessNameAsync(string expected) =>
        _ui.WaitAsync(_locators.BusinessName, expected);

    public Task EnterBusinessNameAsync(string value) =>
        _ui.FillAsync(_locators.BusinessName, value);

    public Task<string> CaptureBusinessNameAsync(string property = "") =>
        _ui.CaptureAsync(_locators.BusinessName, property);

    public Task PressBusinessNameAsync(string key) =>
        _ui.PressAsync(_locators.BusinessName, key);

    public Task WaitForCityAsync(string expected) =>
        _ui.WaitAsync(_locators.City, expected);

    public Task EnterCityAsync(string value) =>
        _ui.FillAsync(_locators.City, value);

    public Task<string> CaptureCityAsync(string property = "") =>
        _ui.CaptureAsync(_locators.City, property);

    public Task PressCityAsync(string key) =>
        _ui.PressAsync(_locators.City, key);

    public Task WaitForAddClientAsync(string expected) =>
        _ui.WaitAsync(_locators.AddClient, expected);

    public Task VerifyAddClientAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AddClient, expected, property);

    public Task ClickAddClientAsync() =>
        _ui.ClickAsync(_locators.AddClient);

    public Task ClickClientSearchAsync() =>
        _ui.ClickAsync(_locators.ClientSearch);

    public Task WaitForClientSearchAsync(string expected) =>
        _ui.WaitAsync(_locators.ClientSearch, expected);

    public Task ClickCompleteAsync() =>
        _ui.ClickAsync(_locators.Complete);

    public Task EnterDOBAsync(string value) =>
        _ui.FillAsync(_locators.DOB, value);

    public Task PressDOBAsync(string key) =>
        _ui.PressAsync(_locators.DOB, key);

    public Task WaitForAddAssociatedClientDateOfBirthAsync(string expected) =>
        _ui.WaitAsync(_locators.AddAssociatedClientDateOfBirth, expected);

    public Task EnterAddAssociatedClientDateOfBirthAsync(string value) =>
        _ui.FillAsync(_locators.AddAssociatedClientDateOfBirth, value);

    public Task<string> CaptureAddAssociatedClientDateOfBirthAsync(string property = "") =>
        _ui.CaptureAsync(_locators.AddAssociatedClientDateOfBirth, property);

    public Task PressAddAssociatedClientDateOfBirthAsync(string key) =>
        _ui.PressAsync(_locators.AddAssociatedClientDateOfBirth, key);

    public Task EnterAdditionalInsuredIndividualDateOfBirthAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualDateOfBirth, value);

    public Task PressAdditionalInsuredIndividualDateOfBirthAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredIndividualDateOfBirth, key);

    public Task ClickAddAssociatedClientDetailAsync() =>
        _ui.ClickAsync(_locators.AddAssociatedClientDetail);

    public Task ClickAdditionalInsuredIndividualDetailAsync() =>
        _ui.ClickAsync(_locators.AdditionalInsuredIndividualDetail);

    public Task WaitForNamedInsuredIndividualEnterSSNAsync(string expected) =>
        _ui.WaitAsync(_locators.NamedInsuredIndividualEnterSSN, expected);

    public Task PressNamedInsuredIndividualEnterSSNAsync(string key) =>
        _ui.PressAsync(_locators.NamedInsuredIndividualEnterSSN, key);

    public Task ClickNamedInsuredIndividualEnterSSNAsync() =>
        _ui.ClickAsync(_locators.NamedInsuredIndividualEnterSSN);

    public Task<string> CaptureNamedInsuredIndividualEnterSSNAsync(string property = "") =>
        _ui.CaptureAsync(_locators.NamedInsuredIndividualEnterSSN, property);

    public Task WaitForAddAssociatedClientEnterSSNAsync(string expected) =>
        _ui.WaitAsync(_locators.AddAssociatedClientEnterSSN, expected);

    public Task PressAddAssociatedClientEnterSSNAsync(string key) =>
        _ui.PressAsync(_locators.AddAssociatedClientEnterSSN, key);

    public Task ClickAddAssociatedClientEnterSSNAsync() =>
        _ui.ClickAsync(_locators.AddAssociatedClientEnterSSN);

    public Task EnterAddAssociatedClientEnterSSNAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AddAssociatedClientEnterSSN, value);

    public Task<string> CaptureAddAssociatedClientEnterSSNAsync(string property = "") =>
        _ui.CaptureAsync(_locators.AddAssociatedClientEnterSSN, property);

    public Task WaitForEntityTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.EntityType, expected);

    public Task EnterEntityTypeAsync(string value) =>
        _ui.FillAsync(_locators.EntityType, value);

    public Task<string> CaptureEntityTypeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.EntityType, property);

    public Task PressEntityTypeAsync(string key) =>
        _ui.PressAsync(_locators.EntityType, key);

    public Task WaitForFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.FirstName, expected);

    public Task EnterFirstNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.FirstName, value);//_ui.FillAsync(_locators.FirstName, value);

    public Task<string> CaptureFirstNameAsync(string property = "") =>
        _ui.CaptureAsync(_locators.FirstName, property);

    public Task PressFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.FirstName, key);

    public Task WaitForGenderAsync(string expected) =>
        _ui.WaitAsync(_locators.Gender, expected);

    public Task EnterGenderAsync(string value) =>
        _ui.FillAsync(_locators.Gender, value);

    public Task<string> CaptureGenderAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Gender, property);

    public Task PressGenderAsync(string key) =>
        _ui.PressAsync(_locators.Gender, key);

    public async Task ClickOKAsync()
    {
        //if (await _locators.OK.CountAsync() > 0 && await _locators.OK.IsVisibleAsync())
        //{
        //    await _ui.ClickAsync(_locators.OK);
        //    return;
        //}

        await _ui.ClickAsync(_locators.OK);
    }

    public async Task ClickOKWithRetryAsync(int maxAttempts = 3, int waitBeforeMs = 1000)
    {
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await Task.Delay(waitBeforeMs);
            if (await _ui.ExistsAsync(_locators.OK))
            {
                await ClickOKAsync();
                return;
            }
        }
        await ClickOKAsync();
    }

    public Task WaitForIndividualTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.IndividualType, expected);

    public Task EnterIndividualTypeAsync(string value) =>
        _ui.FillAsync(_locators.IndividualType, value);

    public Task PressIndividualTypeAsync(string key) =>
        _ui.PressAsync(_locators.IndividualType, key);

    public Task WaitForInsuredEMailAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.InsuredEMailAddress, expected);

    public Task EnterInsuredEMailAddressAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.InsuredEMailAddress, value);

    public Task<string> CaptureInsuredEMailAddressAsync(string property = "") =>
        _ui.CaptureAsync(_locators.InsuredEMailAddress, property);

    public Task PressInsuredEMailAddressAsync(string key) =>
        _ui.PressAsync(_locators.InsuredEMailAddress, key);

    public Task WaitForInsuredTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.InsuredType, expected);

    public Task EnterInsuredTypeAsync(string value) =>
        _ui.FillAsync(_locators.InsuredType, value);

    public Task<string> CaptureInsuredTypeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.InsuredType, property);

    public Task PressInsuredTypeAsync(string key) =>
        _ui.PressAsync(_locators.InsuredType, key);

    public Task EnterJavaScriptAsync(string value) =>
        _ui.FillAsync(_locators.JavaScript, value);

    public Task PressLastNameAsync(string key) =>
        _ui.PressAsync(_locators.LastName, key);

    public Task WaitForLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.LastName, expected);

    public Task WaitForMiddleNameAsync(string expected) =>
        _ui.WaitAsync(_locators.MiddleName, expected);

    public Task EnterMiddleNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.MiddleName, value);

    public Task<string> CaptureMiddleNameAsync(string property = "") =>
        _ui.CaptureAsync(_locators.MiddleName, property);

    public Task PressMiddleNameAsync(string key) =>
        _ui.PressAsync(_locators.MiddleName, key);

    public Task WaitForNameOfAuditContactAsync(string expected) =>
        _ui.WaitAsync(_locators.NameOfAuditContact, expected);

    public Task EnterNameOfAuditContactAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NameOfAuditContact, value);

    public Task PressNameOfAuditContactAsync(string key) =>
        _ui.PressAsync(_locators.NameOfAuditContact, key);

    public Task ClickNameOfAuditContactAsync() =>
        _ui.ClickAsync(_locators.NameOfAuditContact);

    public Task WaitForNameOfInspectionContactAsync(string expected) =>
        _ui.WaitAsync(_locators.NameOfInspectionContact, expected);

    public Task EnterNameOfInspectionContactAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NameOfInspectionContact, value);

    public Task<string> CaptureNameOfInspectionContactAsync(string property = "") =>
        _ui.CaptureAsync(_locators.NameOfInspectionContact, property);

    public Task PressNameOfInspectionContactAsync(string key) =>
        _ui.PressAsync(_locators.NameOfInspectionContact, key);

    public Task ClickNameOfInspectionContactAsync() =>
        _ui.ClickAsync(_locators.NameOfInspectionContact);

    public Task WaitForOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);
    public Task ClickOrderSSNAsync() =>
        _ui.ClickAsync(_locators.OrderSSN);

    public Task WaitForOrderSSNAsync(string expected) =>
        _ui.WaitAsync(_locators.OrderSSN, expected);

    public Task WaitForPleaseVerifySSNAsync(string expected) =>
        _ui.WaitAsync(_locators.PleaseVerifySSN, expected);

    public Task WaitForQuickQuoteAsync(string expected) =>
        _ui.WaitAsync(_locators.QuickQuote, expected);

    public Task SetQuickQuoteAsync(string value) =>
        _ui.SmartSetAsync(_locators.QuickQuote, value);

    public Task VerifyResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Result, expected, property);

    public Task WaitForReturnToClientAsync(string expected) =>
        _ui.WaitAsync(_locators.ReturnToClient, expected);

    public Task ClickReturnToClientAsync() =>
        _ui.ClickAsync(_locators.ReturnToClient);

    public Task WaitForSSNWasNotReturnedAsync(string expected) =>
        _ui.WaitAsync(_locators.SSNWasNotReturned, expected);

    public Task VerifySearchResultsDuckCreekPolicyFirstCheckboxAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SearchResultsDuckCreekPolicyFirstCheckbox, expected, property);

    public Task WaitForSocialSecurityAsync(string expected) =>
        _ui.WaitAsync(_locators.VerifySocialSecurity, expected);

    public Task VerifySocialSecurityAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.VerifySocialSecurity, expected, property);

    public Task WaitForStateAsync(string expected) =>
        _ui.WaitAsync(_locators.State, expected);

    public Task EnterStateAsync(string value) =>
        _ui.FillAsync(_locators.State, value);

    public Task<string> CaptureStateAsync(string property = "") =>
        _ui.CaptureAsync(_locators.State, property);

    public Task PressStateAsync(string key) =>
        _ui.PressAsync(_locators.State, key);

    public Task EnterTitleAsync(string value) =>
        _ui.FillAsync(_locators.Title, value);

    public Task WaitForUnderwritingInfoAsync(string expected) =>
        _ui.WaitAsync(_locators.UnderwritingInfo, expected);

    public Task WaitForVerifyAsync(string expected) =>
        _ui.WaitAsync(_locators.Verify, expected);

    public Task ClickVerifyAsync() =>
        _ui.ClickAsync(_locators.Verify);

    public Task VerifyVerifyAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Verify, expected, property);

    public Task WaitForWebsiteAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.WebsiteAddress, expected);

    public Task<bool> HasVerifyAsync() =>
        _ui.ExistsAsync(_locators.Verify);

    public Task EnterWebsiteAddressAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.WebsiteAddress, value);

    public Task<string> CaptureWebsiteAddressAsync(string property = "") =>
        _ui.CaptureAsync(_locators.WebsiteAddress, property);

    public Task PressWebsiteAddressAsync(string key) =>
        _ui.PressAsync(_locators.WebsiteAddress, key);

    public Task VerifyYearsInBusinessAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.YearsInBusiness, expected, property);

    public Task<bool> HasYearsInBusinessAsync() =>
        _ui.ExistsAsync(_locators.YearsInBusiness);

    public Task<bool> ExistsYearsInBusinessAsync() =>
        _ui.ExistsAsync(_locators.YearsInBusiness);

    public Task EnterYearsInBusinessAsync(string value) =>
        _ui.FillAsync(_locators.YearsInBusiness, value);


    public async Task<bool> IsYearOfBuisnessAvailableAsync() =>
     await _locators.YearsInBusiness.CountAsync() > 0;

    public Task<string> CaptureYearsInBusinessAsync(string property = "") =>
        _ui.CaptureAsync(_locators.YearsInBusiness, property);

    public Task PressYearsInBusinessAsync(string key) =>
        _ui.PressAsync(_locators.YearsInBusiness, key);

    public Task VerifyNamedInsuredZipCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NamedInsuredZipCode, expected, property);

    public Task WaitForNamedInsuredZipCodeAsync(string expected) =>
        _ui.WaitAsync(_locators.NamedInsuredZipCode, expected);

    public Task EnterNamedInsuredZipCodeAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NamedInsuredZipCode, value);

    public Task<string> CaptureNamedInsuredZipCodeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.NamedInsuredZipCode, property);

    public Task PressNamedInsuredZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.NamedInsuredZipCode, key);

    public Task EnterAdditionalInsuredIndividualZipCodeAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualZipCode, value);

    public Task PressAdditionalInsuredIndividualZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInsuredIndividualZipCode, key);

    public Task EnterLastNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.LastName, value);

    public Task<string> CaptureLastNameAsync(string property = "") =>
        _ui.CaptureAsync(_locators.LastName, property);

    public Task EnterNamedInsuredIndividualEnterSSNAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NamedInsuredIndividualEnterSSN, value, 30);


    public Task WaitForPrimaryPhoneAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryPhone, expected);

    public Task EnterPrimaryPhoneAsync(string value) =>
        _ui.FillAsync(_locators.PrimaryPhone, value);

    public Task PressPrimaryPhoneAsync(string key) =>
        _ui.PressAsync(_locators.PrimaryPhone, key);

    public Task<string> CapturePrimaryPhoneAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PrimaryPhone, property);

    public Task WaitForFEINAsync(string expected) =>
        _ui.WaitAsync(_locators.FEIN, expected);

    public Task EnterFEINAsync(string value) =>
        _ui.FillAsync(_locators.FEIN, value);

    public Task PressFEINAsync(string key) =>
        _ui.PressAsync(_locators.FEIN, key);

    public Task<string> CaptureFEINAsync(string property = "") =>
        _ui.CaptureAsync(_locators.FEIN, property);

    public Task WaitForAuditTelephoneAsync(string expected) =>
        _ui.WaitAsync(_locators.AuditTelephone, expected);

    public Task EnterAuditTelephoneAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AuditTelephone, value);

    public Task WaitForInspectionTelephoneAsync(string expected) =>
        _ui.WaitAsync(_locators.InspectionTelephone, expected);

    public Task EnterInspectionTelephoneAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.InspectionTelephone, value);

    public Task PressInspectionTelephoneAsync(string key) =>
        _ui.PressAsync(_locators.InspectionTelephone, key);

    public Task<string> CaptureInspectionTelephoneAsync(string property = "") =>
        _ui.CaptureAsync(_locators.InspectionTelephone, property);


    public Task EnterAdditionalInsuredFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredFirstName, value, delayMs);

    public Task EnterAdditionalInsuredMiddleNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredMiddleName, value, delayMs);

    public Task EnterAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Address, value, delayMs);

    public Task EnterAdditionalInsuredIndividualAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualAddress, value, delayMs);

    public Task EnterBusinessNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessName, value, delayMs);

    public Task EnterCitySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.City, value, delayMs);

    public Task EnterDOBSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DOB, value, delayMs);

    public Task EnterAddAssociatedClientDateOfBirthSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddAssociatedClientDateOfBirth, value, delayMs);

    public Task EnterAdditionalInsuredIndividualDateOfBirthSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualDateOfBirth, value, delayMs);

    public Task EnterAddAssociatedClientEnterSSNSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddAssociatedClientEnterSSN, value, delayMs);

    public Task EnterEntityTypeSequentiallyAsync(string value, int delayMs = 50) =>
        _ui.PressSequentiallyAsync(_locators.EntityType, value, delayMs);

    public async Task EnterEntityTypeSequentiallyWithRetryAsync(string value, int maxAttempts = 3, int waitBeforeMs = 500, int delayMs = 50)
    {
        var expected = value ?? string.Empty;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await _ui.PressSequentiallyAsync(_locators.EntityType, expected, delayMs);
            await Task.Delay(waitBeforeMs);

            var actual = await CaptureEntityTypeAsync("value");
            if (!string.IsNullOrWhiteSpace(actual) && actual.Contains(expected, StringComparison.OrdinalIgnoreCase))
            {
                return;
            }
        }
    }

    public Task EnterFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FirstName, value, delayMs);

    public Task EnterGenderSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Gender, value, delayMs);

    public Task EnterIndividualTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IndividualType, value, delayMs);

    public Task EnterInsuredEMailAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.InsuredEMailAddress, value, delayMs);

    public Task EnterInsuredTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.InsuredType, value, delayMs);

    public Task EnterJavaScriptSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.JavaScript, value, delayMs);

    public Task EnterMiddleNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.MiddleName, value, delayMs);

    public Task EnterNameOfAuditContactSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NameOfAuditContact, value, delayMs);

    public Task EnterNameOfInspectionContactSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NameOfInspectionContact, value, delayMs);

    public Task EnterStateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.State, value, delayMs);

    public Task EnterTitleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Title, value, delayMs);

    public Task EnterWebsiteAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WebsiteAddress, value, delayMs);

    public Task EnterYearsInBusinessSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.YearsInBusiness, value, delayMs);

    public Task EnterNamedInsuredZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NamedInsuredZipCode, value, delayMs);

    public Task EnterAdditionalInsuredIndividualZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalInsuredIndividualZipCode, value, delayMs);

    public Task EnterLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LastName, value, delayMs);

    public Task EnterNamedInsuredIndividualEnterSSNSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NamedInsuredIndividualEnterSSN, value, delayMs);

    public Task EnterPrimaryPhoneSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PrimaryPhone, value, delayMs);

    public Task EnterFEINSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FEIN, value, delayMs);

    public Task EnterAuditTelephoneSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AuditTelephone, value, delayMs);

    public Task EnterInspectionTelephoneSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.InspectionTelephone, value, delayMs);

    public async Task EnterInsuredAndEntityTypeAsync(string insuredType, string entityType)
    {
        await _ui.FillAsync(_locators.InsuredType, insuredType);
        await _ui.WaitReadyBestEffortAsync(_locators.EntityType, 2500);
        await _ui.FillAsync(_locators.EntityType, entityType);
    }

}
