using InsuranceAutomation.CLDC.Pages.Locators;
using InsuranceAutomation.CLDC.Runtime;
using InsuranceAutomation.Core;
using Microsoft.Playwright;
using System.Transactions;
namespace InsuranceAutomation.CLDC.Pages;
public sealed class RegressionTransactionPage
{
    private readonly BrowserSession _browser; private readonly UiActions _ui; private readonly RegressionTransactionLocators _locators;
    public RegressionTransactionPage(BrowserSession browser, UiActions ui) { _browser=browser; _ui=ui; _locators=new(browser.Page); }
    public async Task WaitForTransACTAsync() => await _locators.PageTitle.WaitForAsync(new() { State=WaitForSelectorState.Visible, Timeout=60000 });
    public async Task<string> CapturePolicyNumberAsync()
    {
        if (await _locators.PolicyNumber.CountAsync()==0) return string.Empty;
        return (await _locators.PolicyNumber.InputValueAsync().ConfigureAwait(false)).Trim();
    }
    public async Task SelectTransactionTypeAsync(string transactionType)
    {
        await WaitForTransACTAsync();
        await _ui.SmartSetAsync(_locators.TransactionType, transactionType);
        await _ui.PressAsync(_locators.TransactionType, "Tab");
        await _ui.ClickAsync(_locators.Go);

    }
    public async Task ClickOkIfVisibleAsync()
    {
        if (await _locators.OK.CountAsync()>0 && await _locators.OK.IsVisibleAsync())
        {
            await _ui.ClickAsync(_locators.OK);
        }
    }
    public async Task EnterEffectiveDateAndReasonAsync(string effectiveDate, string reason)
    {
        if (await _locators.EffectiveDate.CountAsync()>0 && !string.IsNullOrWhiteSpace(effectiveDate))
        {
            await _ui.PressSequentiallyAsync(_locators.EffectiveDate, effectiveDate);
            await _ui.PressAsync(_locators.EffectiveDate, "Tab");
        }
        if (await _locators.Reason.CountAsync()>0 && !string.IsNullOrWhiteSpace(reason))
        {
            await _ui.PressSequentiallyAsync(_locators.Reason, reason);
            await _ui.PressAsync(_locators.Reason, "Tab");
        }

        if (await _locators.LocationQuestion.CountAsync()>0 && await _locators.LocationQuestion.IsVisibleAsync())
        {
            await EnterLocationQuestionAsync("No");
        }

        if (await _locators.OK.CountAsync()>0) await _ui.ClickAsync(_locators.OK);
        await _browser.Page.WaitForTimeoutAsync(750);
    }
    public async Task EnterLocationQuestionAsync(string value)
    {
        if (await _locators.LocationQuestion.CountAsync()>0)
        {
            await _ui.SmartSetAsync(_locators.LocationQuestion, value);
            await _ui.PressAsync(_locators.LocationQuestion, "Tab");
        }
    }
    public async Task EnterReasonAsOtherWithDetailAsync(string reasonDetail)
    {
        if (await _locators.Reason.CountAsync()>0)
        {
            await _ui.PressSequentiallyAsync(_locators.Reason, "Other");
            await _ui.PressAsync(_locators.Reason, "Tab");
        }
        await _browser.Page.WaitForTimeoutAsync(5000);
        if (await _locators.ReasonDetail.CountAsync()>0 && !string.IsNullOrWhiteSpace(reasonDetail))
        {
            try
            {
                await _locators.ReasonDetail.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 15000 });
            }
            catch (TimeoutException)
            {
                // Fall through to the fill call below, which will no-op if still not visible.
            }
            await _ui.FillAsync(_locators.ReasonDetail, reasonDetail);
            await _ui.PressAsync(_locators.ReasonDetail, "Tab");
        }
        if (await _locators.OK.CountAsync()>0) await _ui.ClickAsync(_locators.OK);
        await _browser.Page.WaitForTimeoutAsync(5000);
    }
    public async Task StartAsync(RegressionTransactionProfile profile, string effectiveDate)
    {
        await WaitForTransACTAsync();
        await _ui.SmartSetAsync(_locators.TransactionType, profile.Transaction);
        await _ui.ClickAsync(_locators.Go);
        if (await _locators.EffectiveDate.CountAsync()>0 && !string.IsNullOrWhiteSpace(profile.DateRule))
        {
            await _ui.FillAsync(_locators.EffectiveDate, RegressionDateRules.Resolve(effectiveDate, profile.DateRule));
            await _ui.PressAsync(_locators.EffectiveDate, "Tab");
        }
        if (await _locators.Reason.CountAsync()>0 && !string.IsNullOrWhiteSpace(profile.Reason))
        {
            await _ui.SmartSetAsync(_locators.Reason, profile.Reason);
            await _ui.PressAsync(_locators.Reason, "Tab");
        }
        if (await _locators.ReasonDetail.CountAsync()>0 && !string.IsNullOrWhiteSpace(profile.ReasonDetail))
            await _ui.FillAsync(_locators.ReasonDetail, profile.ReasonDetail);
        if (profile.RollToRenewal.HasValue && await _locators.RollToRenewal.CountAsync()>0)
            await _ui.SmartSetAsync(_locators.RollToRenewal, profile.RollToRenewal.Value ? "True" : "False");
        if (await _locators.OK.CountAsync()>0) await _ui.ClickAsync(_locators.OK);
        await _browser.Page.WaitForTimeoutAsync(750);
    }
    public async Task OpenPolicyForEditAsync()
    {
        if (await _locators.EditPolicy.CountAsync()>0) await _ui.ClickAsync(_locators.EditPolicy);
    }
    public async Task VerifyChargeAsync(string expected)
    {
        if (string.IsNullOrWhiteSpace(expected)) return;
        await Microsoft.Playwright.Assertions.Expect(_locators.TransactionGrid).ToContainTextAsync(expected, new() { Timeout=30000 });
    }
    public async Task VerifyPacketAsync(string transactionType, string packetType)
    {
        if (!string.IsNullOrWhiteSpace(transactionType)) await Microsoft.Playwright.Assertions.Expect(_locators.TransactionGrid).ToContainTextAsync(transactionType.Replace("*", string.Empty), new(){Timeout=30000});
        if (!string.IsNullOrWhiteSpace(packetType)) await Microsoft.Playwright.Assertions.Expect(_browser.Page.Locator("body")).ToContainTextAsync(packetType, new(){Timeout=30000});
    }
    public async Task VerifyRateTypeAsync(string rateType)
    {
        if (!string.IsNullOrWhiteSpace(rateType)) await Microsoft.Playwright.Assertions.Expect(_locators.TransactionGrid).ToContainTextAsync(rateType, new(){Timeout=30000});
    }
    public async Task VerifyOffsetAsync(string transactionType) => await Microsoft.Playwright.Assertions.Expect(_locators.TransactionGrid).ToContainTextAsync(transactionType, new(){Timeout=30000});
    public async Task VerifyDuplicateIdOutputAsync()
    {
        if (await _locators.ViewPolicyDetails.CountAsync()>0) await _ui.ClickAsync(_locators.ViewPolicyDetails);
        await _locators.AttachmentsGrid.WaitForAsync(new(){State=WaitForSelectorState.Visible,Timeout=30000});
        await Microsoft.Playwright.Assertions.Expect(_locators.AttachmentsGrid).ToContainTextAsync("Duplicate", new(){Timeout=30000});
        if (await _locators.ReturnToTransACT.CountAsync()>0) await _ui.ClickAsync(_locators.ReturnToTransACT);
    }
}
