using InsuranceAutomation.CLDC.Pages.Locators;
using InsuranceAutomation.Core;
using Microsoft.Playwright;
using Newtonsoft.Json.Linq;

namespace InsuranceAutomation.CLDC.Pages;

public sealed class NavigationPage
{
    private readonly BrowserSession _browser;
    private readonly NavigationLocators _locators;
    private readonly UiActions _ui;

    public NavigationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new NavigationLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterAVCostNewAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AVCostNew, value);

    public Task PressAVCostNewAsync(string key) =>
        _ui.PressAsync(_locators.AVCostNew, key);

    public async Task<bool> IsAVCostNewVisibleAsync() =>
        await _locators.AVCostNew.First.IsVisibleAsync();

    public Task EnterAWhatIsThePublicProtectionClassRatingAsync(string value) =>
        _ui.FillAsync(_locators.AWhatIsThePublicProtectionClassRating, value);

    public Task EnterFarmLiabilityCoverage10000000Async(string value) =>
        _ui.FillAsync(_locators.farmliabilityCoverageof1000000, value);

    public Task PressAWhatIsThePublicProtectionClassRatingAsync(string key) =>
        _ui.PressAsync(_locators.AWhatIsThePublicProtectionClassRating, key);

    public Task VerifyAcceptUMAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AcceptUM, expected, property);

    public Task WaitForAccountsReceivableHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskAccountsReceivableSearchResult, expected);

    public Task ClickAccountsReceivableUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.AccountsReceivableUWQuestions);

    public Task ClickAddAsync() =>
        _ui.ClickAsync(_locators.Add);

    public Task ClickAddAddlInterestAsync() =>
        _ui.ClickAsync(_locators.AddAddlInterest);

    public Task WaitForAddBuildingAsync(string expected) =>
        _ui.WaitAsync(_locators.AddBuilding, expected);

    public Task ClickAddBuildingAsync() =>
        _ui.ClickAsync(_locators.AddBuilding);

    public Task ClickRiskAccountsReceivableAddAsync() =>
        _ui.ClickAsync(_locators.RiskAccountsReceivableAdd);

    public Task WaitForRiskAccountsReceivableAddAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskAccountsReceivableAdd, expected);

    public Task WaitForAddClassAsync(string expected) =>
        _ui.WaitAsync(_locators.AddClass, expected);

    public Task ClickAddClassAsync() =>
        _ui.ClickAsync(_locators.AddClass);

    public Task<bool> IsTerritoryVisibleAsync() =>
        _ui.ExistsAsync(_locators.Territory);

    public Task EnterTerritoryAsync(string value) =>
        _ui.FillAsync(_locators.Territory, value);

    public Task WaitForAddClassCodeAsync(string expected) =>
        _ui.WaitAsync(_locators.AddClassCode, expected);

    public Task ClickAddClassCodeAsync() =>
        _ui.ClickAsync(_locators.AddClassCode);

    public Task ClickAlcoholOrFreedrugspaceAsync() =>
        _ui.ClickAsync(_locators.AlcoholOrDrugFreespce);

    public Task WaitForOKAsync2(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task WaitForRiskPageVisibleAsync() =>
        _ui.WaitAsync(_locators.RiskPageTitle, "Exists");

    public Task WaitForEndorsementsPageVisibleAsync() =>
        _ui.WaitAsync(_locators.EndorsementsPageTitle, "Exists");

    public async Task<bool> IsOKVisibleAsync()
    {
        if (await _locators.PopupOK.First.IsVisibleAsync())
        {
            return true;
        }

        return await _locators.OK.First.IsVisibleAsync();
    }

    public async Task ClickOKAsync()
    {
        // The OK button sometimes renders inside a nested Duck Creek popup window iframe
        // (iframe[id^='dctPopup_dctPopupWindow']) rather than the top document. Wait (bounded)
        // for whichever one actually appears and click it directly via DOM, rather than always
        // falling back to _ui.ClickAsync on the top-document locator, which carries its own long
        // internal actionability timeout and times out hard when OK only exists in the popup frame.
        const int maxAttempts = 3;
        var popupOk = _locators.PopupOK;
        var topDocOk = _locators.OK;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            // Any Playwright wait/click performed here (including the ones inside DomClickAsync)
            // can throw if the popup frame detaches or becomes stale between the visibility probe
            // and the click (a known Duck Creek popup race). That must not bubble out of this
            // method uncaught - treat it as a failed attempt and retry instead of failing the step.
            bool clicked;
            try
            {
                var popupVisible = await WaitForVisibleAsync(popupOk, 4000);
                if (popupVisible)
                {
                    await ComponentAwareControlActions.DomClickAsync(popupOk);
                    clicked = true;
                }
                else
                {
                    var topDocVisible = await WaitForVisibleAsync(topDocOk, 4000);
                    if (topDocVisible)
                    {
                        await ComponentAwareControlActions.DomClickAsync(topDocOk);
                        clicked = true;
                    }
                    else
                    {
                        clicked = false;
                    }
                }
            }
            catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
            {
                clicked = false;
            }

            if (!clicked)
            {
                // Neither locator showed up this attempt (or the click attempt faulted); give the
                // page a beat and retry.
                continue;
            }

            // Give the page a moment to process the click/dismiss the dialog before re-checking.

            // The click frequently closes/dismisses the popup entirely, detaching its iframe from the
            // DOM. Re-querying a locator scoped to an already-detached frame throws (e.g. "Frame was
            // detached"), which would otherwise surface as a false failure even though the click worked.
            bool stillVisible;
            try
            {
                stillVisible = await popupOk.First.IsVisibleAsync() || await topDocOk.First.IsVisibleAsync();
            }
            catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
            {
                stillVisible = false;
            }

            if (!stillVisible)
            {
                return;
            }
        }
    }

    private static async Task<bool> WaitForVisibleAsync(ILocator locator, int timeoutMs)
    {
        try
        {
            await locator.First.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = timeoutMs });
            return true;
        }
        catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
        {
            return false;
        }
    }

    public Task WaitForOptionAPopupOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OptionAPopupOK, expected);

    public Task ClickOptionAPopupOKAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.OptionAPopupOK);

    public Task ClickSafetyCommoditiesAsync() =>
        _ui.ClickAsync(_locators.safetyCommodities);

    public Task ClickAddCoverageFormAsync() =>
        _ui.ClickAsync(_locators.AddCoverageForm);

    public Task ClickAddDriverAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.AddDriver);

    public Task EnterAddDriverNameAsync(string value) =>
        _ui.FillAsync(_locators.AddDriverName, value);

    public async Task<bool> IsAddDriverNameVisibleAsync() =>
        await _locators.AddDriverName.First.IsVisibleAsync();

    public Task WaitForAddDriverNameVisibleAsync() =>
        _locators.AddDriverName.First.WaitForAsync(new() { State = WaitForSelectorState.Visible });

    public Task PressAddDriverNameAsync(string key) =>
        _ui.PressAsync(_locators.AddDriverName, key);

    public Task ClickEndorsementMainAddEndorsementAsync() =>
        _ui.ClickAsync(_locators.AddEndorsement);

    public Task ClickCU2118DeleteAsync() =>
        _ui.ClickAsync(_locators.Cu2118Delete);

    public Task<bool> IsCU2118DeletePresentAsync() =>
        _ui.ExistsAsync(_locators.Cu2118Delete);

    public Task ClickBadilyJustingAsync() =>
       _ui.ClickAsync(_locators.BodilyInjury);

    public Task ClickPropertDamageAsync() =>
       _ui.ClickAsync(_locators.PropertyDamange);

    public Task ClickPersonalAdvertisingAsync() =>
       _ui.ClickAsync(_locators.PersonalAdvertising);

    public Task WaitForEndorsementMainAddEndorsementAsync(string expected) =>
        _ui.WaitAsync(_locators.AddEndorsement, expected);

    public Task ClickEndorsementsAddEndorsementAsync() =>
        _ui.ClickAsync(_locators.AddEndorsement);

    public Task ClickAddExcludedOfficerInformationAsync() =>
        _ui.ClickAsync(_locators.AddExcludedOfficerInformation);

    public Task ClickAddExcludedOthersInformationAsync() =>
        _ui.ClickAsync(_locators.AddExcludedOthersInformation);

    public Task WaitForAddGroupAsync(string expected) =>
        _ui.WaitAsync(_locators.AddGroup, expected);

    public Task ClickAddGroupAsync() =>
        _ui.ClickAsync(_locators.AddGroup);

    public Task ClickAddNotesRemarksAsync() =>
        _ui.ClickAsync(_locators.AddNotesRemarks);

    public async Task ClickAddOptionAAsync()
    {
        // Add Option A sometimes renders inside a nested Duck Creek popup window iframe
        // (iframe[id^='dctPopup_dctPopupWindow']) rather than the top document. Probing the
        // popup frame first with a short timeout avoids burning the full element-ready timeout
        // on the wrong (top-document) locator when the popup variant is what's actually shown.
        var popupButton = _locators.AddOptionAPopup;
        try
        {
            await popupButton.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 2000 });
            await ComponentAwareControlActions.DomClickAsync(popupButton);
            return;
        }
        catch (Exception ex) when (ex is PlaywrightException or TimeoutException) { }

        await _ui.ClickAsync(_locators.AddOptionA);
    }

    public Task ClickAddOtherInterestAsync() =>
        _ui.ClickAsync(_locators.AddOtherInterest);

    public Task WaitForAddOtherInterestVisibleAsync() =>
        _locators.AddOtherInterest.WaitForAsync(new() { State = WaitForSelectorState.Visible });

    public Task ClickAddOthersInformationAsync() =>
        _ui.ClickAsync(_locators.AddOthersInformation);

    public Task ClickAddPartnerInformationAsync() =>
        _ui.ClickAsync(_locators.AddPartnerInformation);

    public Task ClickAddPremisesAsync() =>
        _ui.ClickAsync(_locators.AddPremises);

    public Task ClickAddPriorCarrierAsync() =>
        _ui.ClickAsync(_locators.AddPriorCarrier);

    public Task ClickAddRiskAtThisLocationAsync() =>
        _ui.ClickAsync(_locators.AddRiskAtThisLocation);

    public Task ClickAddSoleProprietorInformationAsync() =>
        _ui.ClickAsync(_locators.AddSoleProprietorInformation);

    public Task ClickAddThirdPartyAsync() =>
        _ui.ClickAsync(_locators.AddThirdParty);

    public Task ClickAdditionalInterestsAsync() =>
        _ui.ClickAsync(_locators.AdditionalInterestsLink);

    public Task EnterAdditionalOtherInterestAddressAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestAddress, value);

    public Task EnterAdditionalOtherInterestZipCodeAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestZipCode, value);


    public Task PressAdditionalOtherInterestAddressAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalOtherInterestAddress, key);

    public Task WaitForAdditionalOtherInterestInputFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalOtherInterestInputFirstName, expected);

    public Task EnterAdditionalOtherInterestInputFirstNameAsync(string value) =>
        _ui.FillAsync(_locators.AdditionalOtherInterestInputFirstName, value);

    public Task PressAdditionalOtherInterestInputFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalOtherInterestInputFirstName, key);

    public Task WaitForAdditionalOtherInterestInputLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalOtherInterestInputLastName, expected);

    public Task WaitForAdditionalInterestsScheduleAddlInterestsAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTop, expected);

    public Task VerifyAdditionalInterestsScheduleAddlInterestsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PageTop, expected, property);

    public Task WaitForSignsHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task ClickGLNavigationLinksAddlInterestsAsync() =>
        _ui.ClickAsync(_locators.GLNavigationLinksAddlInterests);

    public Task EnterAddressAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.Address, value);

    public Task<string> CaptureAddressAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Address, property);

    public Task PressAddressAsync(string key) =>
        _ui.PressAsync(_locators.Address, key);

    public Task EnterCG2935AddLInsuredStateOrPoliticalPermitsAddressAsync(string value) =>
        _ui.FillAsync(_locators.AdditionalOtherInterestAddress, value);

    public Task PressCG2935AddLInsuredStateOrPoliticalPermitsAddressAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalOtherInterestAddress, key);

    public Task EnterGLOCPRiskAddressAsync(string value) =>
        _ui.FillAsync(_locators.GLOCPRiskAddress, value);

    public Task PressGLOCPRiskAddressAsync(string key) =>
        _ui.PressAsync(_locators.GLOCPRiskAddress, key);

    public Task WaitForLocationAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.LocationAddress, expected);

    public Task WaitForAddressStreetCityStateZipAsync(string expected) =>
        _ui.WaitAsync(_locators.AddressStreetCityStateZip, expected);

    public Task EnterAddressStreetCityStateZipAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddressStreetCityStateZip, value, delayMs);

    public Task<string> CaptureAddressStreetCityStateZipAsync(string property = "") =>
        _ui.CaptureAsync(_locators.AddressStreetCityStateZip, property);

    public Task PressAddressStreetCityStateZipAsync(string key) =>
        _ui.PressAsync(_locators.AddressStreetCityStateZip, key);

    public Task EnterAggregateLimitAsync(string value) =>
        _ui.FillAsync(_locators.IFRAMEDuckCreekPolicyAggregateLimit, value);

    public async Task<bool> IsAggregateLimitVisibleAsync() =>
        await IsAnyVisibleAsync(_locators.IFRAMEDuckCreekPolicyAggregateLimit);


    public Task EnterGLOCPAggregateLimitAsync(string value) =>
      _ui.FillAsync(_locators.GLOCPAggregateLimit, value);





    public Task PressAggregateLimitAsync(string key) =>
        _ui.PressAsync(_locators.AggregateLimit, key);

    public Task EnterAnnualGrossReceiptsAsync(string value) =>
        _ui.FillAsync(_locators.AnnualGrossReceipts, value);

    public Task PressAnnualGrossReceiptsAsync(string key) =>
        _ui.PressAsync(_locators.AnnualGrossReceipts, key);

    public Task EnterAnyPersonalAutoPolicyListingNameInsuredAsync(string value) =>
        _ui.FillAsync(_locators.AnyPersonalAutoPolicyListingNameInsured, value);

    public Task PressAnyPersonalAutoPolicyListingNameInsuredAsync(string key) =>
        _ui.PressAsync(_locators.AnyPersonalAutoPolicyListingNameInsured, key);

    public Task WaitForAnyVehicleCoveredRegisteredInNotPrimaryStateAsync(string expected) =>
        _ui.WaitAsync(_locators.AnyVehicleCoveredRegisteredInNotPrimaryState, expected);

    public Task EnterAnyVehicleCoveredRegisteredInNotPrimaryStateAsync(string value) =>
        _ui.FillAsync(_locators.AnyVehicleCoveredRegisteredInNotPrimaryState, value);

    public Task PressAnyVehicleCoveredRegisteredInNotPrimaryStateAsync(string key) =>
        _ui.PressAsync(_locators.AnyVehicleCoveredRegisteredInNotPrimaryState, key);

    public Task EnterAreAnySignsOffPremisesOrNotAttachedToBuildingAsync(string value) =>
        _ui.FillAsync(_locators.AreAnySignsOffPremisesOrNotAttachedToBuilding, value);

    public Task<string> CaptureAreAnySignsOffPremisesOrNotAttachedToBuildingAsync(string property = "") =>
        _ui.CaptureAsync(_locators.AreAnySignsOffPremisesOrNotAttachedToBuilding, property);

    public Task PressAreAnySignsOffPremisesOrNotAttachedToBuildingAsync(string key) =>
        _ui.PressAsync(_locators.AreAnySignsOffPremisesOrNotAttachedToBuilding, key);

    public Task WaitForArePhysicalsRequiredAfterOffersOfEmploymentAreMadeAsync(string expected) =>
        _ui.WaitAsync(_locators.ArePhysicalsRequiredAfterOffersOfEmploymentAreMade, expected);

    public Task WaitForAreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.AreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicy, expected);

    public Task EnterAreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicyAsync(string value) =>
        _ui.FillAsync(_locators.AreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicy, value);

    public Task PressAreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicyAsync(string key) =>
        _ui.PressAsync(_locators.AreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicy, key);

    public Task EnterAreThereAnyOfficersThatShouldBeExcludedAsync(string value) =>
        _ui.FillAsync(_locators.AreThereAnyOfficersThatShouldBeExcluded, value);

    public Task PressAreThereAnyOfficersThatShouldBeExcludedAsync(string key) =>
        _ui.PressAsync(_locators.AreThereAnyOfficersThatShouldBeExcluded, key);

    public Task WaitForAssignLocationAsync(string expected) =>
        _ui.WaitAsync(_locators.AssignLocation, expected);

    public Task ClickAssignLocationAsync() =>
        _ui.ClickAsync(_locators.AssignLocation);

    public Task WaitForAssignLocationsAsync(string expected) =>
        _ui.WaitAsync(_locators.AssignLocations, expected);

    public Task ClickAssignLocationsAsync() =>
        _ui.ClickAsync(_locators.AssignLocations);

    public Task EnterAudioVisualAsync(string value) =>
        _ui.SmartSetAsync(_locators.AudioVisual, value);

    public Task PressAudioVisualAsync(string key) =>
        _ui.PressAsync(_locators.AudioVisual, key);

    public async Task<bool> IsAudioVisualVisibleAsync() =>
        await _locators.AudioVisual.First.IsVisibleAsync();

    public Task EnterAvailableClassificationsAsync(string value) =>
        _ui.FillAsync(_locators.AvailableClassifications, value);

    public Task PressAvailableClassificationsAsync(string key) =>
        _ui.PressAsync(_locators.AvailableClassifications, key);

    public Task EnterAverageNumberOfDaysServiceAsync(string value) =>
        _ui.FillAsync(_locators.AverageNumberOfDaysService, value);

    public Task PressAverageNumberOfDaysServiceAsync(string key) =>
        _ui.PressAsync(_locators.AverageNumberOfDaysService, key);

    public Task EnterAverageNumberOfWorkingDaysAsync(string value) =>
        _ui.FillAsync(_locators.AverageNumberOfWorkingDays, value);

    public Task PressAverageNumberOfWorkingDaysAsync(string key) =>
        _ui.PressAsync(_locators.AverageNumberOfWorkingDays, key);

    public Task EnterAverageServiceChargeAsync(string value) =>
        _ui.FillAsync(_locators.AverageServiceCharge, value);

    public Task PressAverageServiceChargeAsync(string key) =>
        _ui.PressAsync(_locators.AverageServiceCharge, key);

    public Task EnterAverageValuePerOrderAsync(string value) =>
        _ui.FillAsync(_locators.AverageValuePerOrder, value);

    public Task PressAverageValuePerOrderAsync(string key) =>
        _ui.PressAsync(_locators.AverageValuePerOrder, key);

    public Task EnterBAreThereAnyPrivateProtectionImprovementsAsync(string value) =>
        _ui.FillAsync(_locators.BAreThereAnyPrivateProtectionImprovements, value);

    public Task PressBAreThereAnyPrivateProtectionImprovementsAsync(string key) =>
        _ui.PressAsync(_locators.BAreThereAnyPrivateProtectionImprovements, key);

    public Task WaitForBG2SymbolAsync(string expected) =>
        _ui.WaitAsync(_locators.BG2Symbol, expected);

    public Task EnterBG2SymbolAsync(string value) =>
        _ui.FillAsync(_locators.BG2Symbol, value);

    public Task PressBG2SymbolAsync(string key) =>
        _ui.PressAsync(_locators.BG2Symbol, key);

    public Task WaitForBG2SymbolPrefixAsync(string expected) =>
        _ui.WaitAsync(_locators.BG2SymbolPrefix, expected);

    public Task EnterBG2SymbolPrefixAsync(string value) =>
        _ui.FillAsync(_locators.BG2SymbolPrefix, value);

    public Task PressBG2SymbolPrefixAsync(string key) =>
        _ui.PressAsync(_locators.BG2SymbolPrefix, key);

    public Task ClickBaileesCustomerUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.BaileesCustomerUWQuestions);

    public Task WaitForBaileesCustomersHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.BaileesCustomersHeading, expected);

    public Task WaitForBillTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.BillType, expected);

    public Task EnterBillTypeAsync(string value) =>
        _ui.FillAsync(_locators.BillType, value);

    public Task PressBillTypeAsync(string key) =>
        _ui.PressAsync(_locators.BillType, key);

    public Task ClickNavigationBillingAsync() =>
        _ui.ClickAsync(_locators.NavigationBillingLink);

    public Task WaitForBillingAsync(string expected) =>
        _ui.WaitAsync(_locators.Billing, expected);

    public Task EnterBodyStyleAsync(string value) =>
        _ui.FillAsync(_locators.BodyStyle, value);

    public async Task<bool> IsBodyStyleVisibleAsync() =>
        await _locators.BodyStyle.First.IsVisibleAsync();

    public Task PressBodyStyleAsync(string key) =>
        _ui.PressAsync(_locators.BodyStyle, key);

    public Task WaitForBoomDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.BoomDeductible, expected);

    public Task EnterBoomDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.BoomDeductible, value);

    public Task PressBoomDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.BoomDeductible, key);

    public Task WaitForBorrowingHiringOrLeasingWithinYearAsync(string expected) =>
        _ui.WaitAsync(_locators.BorrowingHiringOrLeasingWithinYear, expected);

    public Task EnterBorrowingHiringOrLeasingWithinYearAsync(string value) =>
        _ui.FillAsync(_locators.BorrowingHiringOrLeasingWithinYear, value);

    public Task PressBorrowingHiringOrLeasingWithinYearAsync(string key) =>
        _ui.PressAsync(_locators.BorrowingHiringOrLeasingWithinYear, key);

    public Task WaitForBuildingAsync(string expected) =>
        _ui.WaitAsync(_locators.Building, expected);

    public Task ClickBuildingAsync() =>
        _ui.ClickAsync(_locators.Building);

    public Task WaitForBuildingLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingLimit, expected);

    public Task EnterBuildingLimitAsync(string value) =>
        _ui.FillAsync(_locators.BuildingLimit, value);

    public Task PressBuildingLimitAsync(string key) =>
        _ui.PressAsync(_locators.BuildingLimit, key);

    public Task WaitForBuildingRatingGroupAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskInputRatingGroupID, expected);

    public Task EnterBuildingRatingGroupAsync(string value) =>
        _ui.FillAsync(_locators.RiskInputRatingGroupID, value);

    public Task PressBuildingRatingGroupAsync(string key) =>
        _ui.PressAsync(_locators.RiskInputRatingGroupID, key);

    public Task<string> CaptureBuildingRatingGroupAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskInputRatingGroupID, property);

    public async Task<bool> IsBuildingRatingGroupVisibleAsync() =>
        await _locators.RiskInputRatingGroupID.First.IsVisibleAsync();

    public Task EnterBusinessInterruptionDescriptionOfScheduledPropertyAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.BusinessInterruptionDescriptionOfScheduledProperty, value);

    public Task PressBusinessInterruptionDescriptionOfScheduledPropertyAsync(string key) =>
        _ui.PressAsync(_locators.BusinessInterruptionDescriptionOfScheduledProperty, key);

    public Task WaitForOptionAAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTop, expected);

    public Task EnterBusinessInterruptionEndorsementAsync(string value) =>
        _ui.FillAsync(_locators.BusinessInterruptionEndorsement, value);

    public Task PressBusinessInterruptionEndorsementAsync(string key) =>
        _ui.PressAsync(_locators.BusinessInterruptionEndorsement, key);

    public Task WaitForBusinessInterruptionDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.BusinessInterruptionDetail, expected);

    public Task ClickBusinessInterruptionDetailAsync() =>
        _ui.ClickAsync(_locators.BusinessInterruptionDetail);

    public Task WaitForBusinessInterruptionLimitOfInsuranceAsync(string expected) =>
        _ui.WaitAsync(_locators.BusinessInterruptionLimitOfInsurance, expected);

    public Task EnterBusinessInterruptionLimitOfInsuranceAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.BusinessInterruptionLimitOfInsurance, value);

    public Task PressBusinessInterruptionLimitOfInsuranceAsync(string key) =>
        _ui.PressAsync(_locators.BusinessInterruptionLimitOfInsurance, key);

    public Task WaitForCA2325LeasedWorkersCoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.CA2325LeasedWorkersCoverage, expected);

    public Task EnterCA9940ContractProvisionsAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.CA9940ContractProvisions, value);

    public async Task<bool> IsCA9940ContractProvisionsVisibleAsync() =>
        await _locators.CA9940ContractProvisions.First.IsVisibleAsync();

    public Task WaitForCA9940ContractProvisionsVisibleAsync() =>
        _locators.CA9940ContractProvisions.First.WaitForAsync(new() { State = WaitForSelectorState.Visible });

    public Task PressCA9940ContractProvisionsAsync(string key) =>
        ComponentAwareControlActions.DomPressAsync(_locators.CA9940ContractProvisions, key);

    public Task EnterCA9940MakeAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9940Make, value);

    public async Task<bool> IsCA9940MakeVisibleAsync() =>
        await _locators.CA9940Make.IsVisibleAsync();

    public Task WaitForCA9940MakeVisibleAsync() =>
        _locators.CA9940Make.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task PressCA9940MakeAsync(string key) =>
        _ui.PressAsync(_locators.CA9940Make, key);

    public Task EnterCA9940ModelAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9940Model, value);

    public async Task<bool> IsCA9940ModelVisibleAsync() =>
        await _locators.CA9940Model.IsVisibleAsync();

    public Task WaitForCA9940ModelVisibleAsync() =>
        _locators.CA9940Model.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task PressCA9940ModelAsync(string key) =>
        _ui.PressAsync(_locators.CA9940Model, key);

    public Task EnterCA9940VINAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9940VIN, value);

    public async Task<bool> IsCA9940VINVisibleAsync() =>
        await _locators.CA9940VIN.IsVisibleAsync();

    public Task WaitForCA9940VINVisibleAsync() =>
        _locators.CA9940VIN.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task PressCA9940VINAsync(string key) =>
        _ui.PressAsync(_locators.CA9940VIN, key);

    public Task EnterCA9940YearAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9940Year, value);

    public async Task<bool> IsCA9940YearVisibleAsync() =>
        await _locators.CA9940Year.IsVisibleAsync();

    public Task WaitForCA9940YearVisibleAsync() =>
        _locators.CA9940Year.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task PressCA9940YearAsync(string key) =>
        _ui.PressAsync(_locators.CA9940Year, key);

    public Task EnterCA9948ClassesOfCommoditiesTransportedAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.CA9948ClassesOfCommoditiesTransported, value);

    public async Task<bool> IsCA9948ClassesOfCommoditiesTransportedVisibleAsync() =>
        await _locators.CA9948ClassesOfCommoditiesTransported.First.IsVisibleAsync();

    public Task WaitForCA9948ClassesOfCommoditiesTransportedVisibleAsync() =>
        _locators.CA9948ClassesOfCommoditiesTransported.First.WaitForAsync(new() { State = WaitForSelectorState.Visible });

    public Task PressCA9948ClassesOfCommoditiesTransportedAsync(string key) =>
        ComponentAwareControlActions.DomPressAsync(_locators.CA9948ClassesOfCommoditiesTransported, key);

    public Task ClickExcludeUndergroundPropertyDamageHazardAsync() =>
        _ui.ClickAsync(_locators.ExcludeUndergroundPropertyDamageHazard);

    public Task ClickCGLAsync() =>
        _ui.ClickAsync(_locators.CGL);

    public Task EnterCGLLimitsAsync(string value) =>
        _ui.FillAsync(_locators.CGLLimits, value);

    public Task<string> CaptureCGLLimitsAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CGLLimits, property);

    public Task PressCGLLimitsAsync(string key) =>
        _ui.PressAsync(_locators.CGLLimits, key);

    public Task WaitForCPPLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.CPPLiability, expected);

    public Task PressCPPLiabilityAsync(string key) =>
        _ui.PressAsync(_locators.PageTitle, key);

    public Task ClickCPPLiabilityAsync() =>
        _ui.ClickAsync(_locators.CPPLiability);

    public Task EnterCWhatIsTheDistanceInFeetToTheNearestHydrantAsync(string value) =>
        _ui.FillAsync(_locators.CWhatIsTheDistanceInFeetToTheNearestHydrant, value);

    public Task PressCWhatIsTheDistanceInFeetToTheNearestHydrantAsync(string key) =>
        _ui.PressAsync(_locators.CWhatIsTheDistanceInFeetToTheNearestHydrant, key);

    public Task ClickCallISOAsync() =>
        _ui.ClickAsync(_locators.CallISO);

    public Task WaitForCarrierAsync(string expected) =>
        _ui.WaitAsync(_locators.Carrier, expected);

    public Task EnterCarrierAsync(string value) =>
        _ui.FillAsync(_locators.Carrier, value);

    public Task<string> CaptureCarrierAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Carrier, property);

    public Task PressCarrierAsync(string key) =>
        _ui.PressAsync(_locators.Carrier, key);

    public Task WaitForCauseOfLossAsync(string expected) =>
        _ui.WaitAsync(_locators.CauseOfLoss, expected);

    public Task EnterCauseOfLossAsync(string value) =>
        _ui.FillAsync(_locators.CauseOfLoss, value);

    public Task PressCauseOfLossAsync(string key) =>
        _ui.PressAsync(_locators.CauseOfLoss, key);

    public Task EnterCityAsync(string value) =>
        _ui.FillAsync(_locators.City, value);

    public Task PressCityAsync(string key) =>
        _ui.PressAsync(_locators.City, key);

    public Task EnterClassCodeAsync(string value) =>
        _ui.FillAsync(_locators.ClassCode, value);

    public Task PressClassCodeAsync(string key) =>
        _ui.PressAsync(_locators.ClassCode, key);

    public Task WaitForClassCodeFrameAsync(string expected) =>
        _ui.WaitAsync(_locators.ClassCodeFrame, expected);

    public Task EnterClassCodeFrameClassCodeWindowAsync(string value) =>
        _ui.FillAsync(_locators.ClassCodeFrameClassCodeWindow, value);

    public Task WaitForClassificationOfRiskAsync(string expected) =>
        _ui.WaitAsync(_locators.ClassificationOfRisk, expected);

    public Task EnterClassificationOfRiskAsync(string value) =>
        _ui.FillAsync(_locators.ClassificationOfRisk, value);

    public Task<bool> IsClassificationOfRiskVisibleAsync() => _ui.ExistsAsync(_locators.ClassificationOfRisk);

    public Task PressClassificationOfRiskAsync(string key) =>
        _ui.PressAsync(_locators.ClassificationOfRisk, key);

    public Task WaitForClickAddEndorsementAsync(string expected) =>
        _ui.WaitAsync(_locators.AddEndorsement, expected);

    public Task ClickClickAddEndorsementAsync() =>
        _ui.ClickAsync(_locators.AddEndorsement);

    public Task WaitForClickAddExcludedDriverAsync(string expected) =>
        expected == "Visible"
            ? _locators.ClickAddExcludedDriver.WaitForAsync(new() { State = WaitForSelectorState.Visible })
            : _ui.WaitAsync(_locators.ClickAddExcludedDriver, expected);

    public Task ClickClickAddExcludedDriverAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.ClickAddExcludedDriver);

    public Task WaitForAddClientAsync(string expected) =>
        _ui.WaitAsync(_locators.AddClient, expected);

    public Task VerifyAddClientAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AddClient, expected, property);

    public Task EnterAddClientAsync(string value) =>
        _ui.FillAsync(_locators.AddClient, value);

    public Task ClickAddClientAsync() =>
        _ui.ClickAsync(_locators.AddClient);

    public Task ClickClientLinkAsync() =>
        _ui.ClickAsync(_locators.ClientLink);

    public Task WaitForClientLinkAsync(string expected) =>
        _ui.WaitAsync(_locators.ClientLink, expected);

    public async Task<bool> IsClientLinkVisibleAsync() =>
        await _locators.ClientLink.CountAsync() > 0 && await _locators.ClientLink.IsVisibleAsync();

    public Task ClickHomeLinkAsync() =>
        _ui.ClickAsync(_locators.HomeLink);

    public Task WaitForHomeLinkAsync(string expected) =>
        _ui.WaitAsync(_locators.HomeLink, expected);

    public Task WaitForClientPageTitleAsync(string expected) =>
        _ui.WaitAsync(_locators.ClientPageTitle, expected);

    public Task WaitForPolicyCovgComputerSystemsCoinsuranceAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgComputerSystemsCoinsurance, expected);

    public Task EnterPolicyCovgComputerSystemsCoinsuranceAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgComputerSystemsCoinsurance, value);

    public Task PressPolicyCovgComputerSystemsCoinsuranceAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgComputerSystemsCoinsurance, key);

    public Task WaitForRatingGroupsCoinsuranceAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroupsCoinsurance, expected);

    public Task EnterRatingGroupsCoinsuranceAsync(string value) =>
        _ui.FillAsync(_locators.RatingGroupsCoinsurance, value);

    public Task PressRatingGroupsCoinsuranceAsync(string key) =>
        _ui.PressAsync(_locators.RatingGroupsCoinsurance, key);

    public Task WaitForPolicyCovgContractorsEquipmentCoinsuranceAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgContractorsEquipmentCoinsurance, expected);

    public Task EnterPolicyCovgContractorsEquipmentCoinsuranceAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgContractorsEquipmentCoinsurance, value);

    public Task PressPolicyCovgContractorsEquipmentCoinsuranceAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgContractorsEquipmentCoinsurance, key);

    public Task ClickCollisionAsync() =>
        _ui.ClickAsync(_locators.Collision);

    public Task VerifyCollisionCoverageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CollisionCoverage, expected, property);

    public Task EnterCollisionCoverageAsync(string value) =>
        _ui.FillAsync(_locators.CollisionCoverage, value);

    public async Task<bool> IsCollisionCoverageVisibleAsync() =>
        await _locators.CollisionCoverage.First.IsVisibleAsync();

    public Task PressCollisionCoverageAsync(string key) =>
        _ui.PressAsync(_locators.CollisionCoverage, key);

    public Task EnterCollisionCoverageDeductibleAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.CollisionCoverageDeductible, value);

    public async Task<bool> IsCollisionCoverageDeductibleVisibleAsync() =>
        await _locators.CollisionCoverageDeductible.First.IsVisibleAsync();

    public Task EnterAutoLoanCoverageAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.AutoLoanCoverage, value);

    public async Task<bool> IsAutoLoanCoverageVisibleAsync() =>
        await _locators.AutoLoanCoverage.First.IsVisibleAsync();

    public Task PressAutoLoanCoverageAsync(string key) =>
        _ui.PressAsync(_locators.AutoLoanCoverage, key);

    public Task WaitForCollisionDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.CollisionDeductible, expected);

    public Task EnterHiredAutoCollisionDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCollisionDeductible, value);

    public Task PressHiredAutoCollisionDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCollisionDeductible, key);

    public Task EnterHiredAutoCollisionDeductibleWithDriverAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCollisionDeductibleWithDriver, value);

    public Task PressHiredAutoCollisionDeductibleWithDriverAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCollisionDeductibleWithDriver, key);

    public Task ClickStateDetailsHiredAutoPDWithoutDriverIfAnyAsync() =>
        _ui.ClickAsync(_locators.StateDetailsHiredAutoPDWithoutDriverIfAny);

    public Task ClickStateDetailsHiredAutoPhysicalDamageWithDriverIfAnyAsync() =>
        _ui.ClickAsync(_locators.StateDetailsHiredAutoPhysicalDamageWithDriverIfAny);

    public Task ClickCommercialAutoAsync() =>
        _ui.ClickAsync(_locators.CommercialAuto); // 

    public Task WaitForCommercialAutoDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.CommericialAutoDetailHeading, expected);

    public Task ClickCommonNavigationLinksNextAsync() =>
        _ui.ClickAsync(_locators.CommonNavigationLinksNext);

    public Task EnterCompanyNameAsync(string value) =>
        _ui.FillAsync(_locators.CompanyName, value);

    public Task PressCompanyNameAsync(string key) =>
        _ui.PressAsync(_locators.CompanyName, key);

    public Task ClickComprehensiveAsync() =>
        _ui.ClickAsync(_locators.Comprehensive);

    public Task EnterComputerEquipmentAsync(string value) =>
        _ui.FillAsync(_locators.ComputerEquipment, value);

    public Task PressComputerEquipmentAsync(string key) =>
        _ui.PressAsync(_locators.ComputerEquipment, key);

    public Task ClickComputerSystemsUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.ComputerSystemsUWQuestions);

    public Task WaitForBuildingDetailConstructionAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingDetailConstruction, expected);

    public Task EnterBuildingDetailConstructionAsync(string value) =>
        _ui.FillAsync(_locators.BuildingDetailConstruction, value);

    public Task PressBuildingDetailConstructionAsync(string key) =>
        _ui.PressAsync(_locators.BuildingDetailConstruction, key);

    public Task EnterRiskBaileesCustomersConstructionAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersConstruction, value);

    public Task PressRiskBaileesCustomersConstructionAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersConstruction, key);

    public Task EnterConstructionCodeAsync(string value) =>
        _ui.FillAsync(_locators.ConstructionCode, value);

    public Task PressConstructionCodeAsync(string key) =>
        _ui.PressAsync(_locators.ConstructionCode, key);

    public Task WaitForRiskAccountsReceivableConstructionAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskAccountsReceivableConstruction, expected);

    public Task EnterRiskAccountsReceivableConstructionAsync(string value) =>
        _ui.FillAsync(_locators.RiskAccountsReceivableConstruction, value);

    public Task<bool> IsRiskAccountsReceivableConstructionVisibleAsync() => _ui.ExistsAsync(_locators.RiskAccountsReceivableConstruction);

    public Task PressRiskAccountsReceivableConstructionAsync(string key) =>
        _ui.PressAsync(_locators.RiskAccountsReceivableConstruction, key);

    public Task ClickContractorsEquipmentUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.ContractorsEquipmentUWQuestions);

    public Task WaitForCoverageBeginDateAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageBeginDate, expected);

    public Task EnterCoverageEndDateAsync(string value) =>
        _ui.FillAsync(_locators.CoverageEndDate, value);

    public Task PressCoverageEndDateAsync(string key) =>
        _ui.PressAsync(_locators.CoverageEndDate, key);

    public Task WaitForPolicyCovgGLCoverageFormAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgGLCoverageForm, expected);

    private static async Task<bool> IsAnyVisibleAsync(ILocator locator)
    {
        var count = await locator.CountAsync();
        for (var i = 0; i < count; i++)
        {
            if (await locator.Nth(i).IsVisibleAsync())
            {
                return true;
            }
        }

        return false;
    }

    public async Task<bool> IsPolicyCovgGLCoverageFormVisibleAsync() =>
        await IsAnyVisibleAsync(_locators.PolicyCovgGLCoverageForm);

    public Task EnterPolicyCovgGLCoverageFormAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgGLCoverageForm, value);

    public Task PressPolicyCovgGLCoverageFormAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgGLCoverageForm, key);

    public Task VerifyPolicyCovgSignsCoverageFormAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PolicyCovgSignsCoverageForm, expected, property);

    public Task WaitForRiskMainCoverageFormAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskMainCoverageForm, expected);

    public Task EnterRiskMainCoverageFormAsync(string value) =>
        _ui.FillAsync(_locators.RiskMainCoverageForm, value);

    public Task PressRiskMainCoverageFormAsync(string key) =>
        _ui.PressAsync(_locators.RiskMainCoverageForm, key);

    public Task WaitForPolicyCovgComputerSystemsCoverageFormDisplayAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgComputerSystemsCoverageFormDisplay, expected);

    public Task WaitForPolicyCovgBaileesCutomersCoverageFormDisplayAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgBaileesCutomersCoverageFormDisplay, expected);

    public Task WaitForPolicyCovgMotorTruckCargoCoverageFormDisplayAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgMotorTruckCargoCoverageFormDisplay, expected);

    public Task WaitForPolicyCovgSignsCoverageFormDisplayAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgSignsCoverageFormDisplay, expected);

    public Task WaitForPolicyCovgContractorsEquipmentCoverageFormDisplayAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgContractorsEquipmentCoverageFormDisplay, expected);

    public Task WaitForCoverageFormToBeAddedAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormToBeAdded, expected);

    public Task EnterCoverageFormToBeAddedAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormToBeAdded, value);

    public Task PressCoverageFormToBeAddedAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormToBeAdded, key);

    public Task WaitForCoverageTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageType, expected);

    public Task EnterCoverageTypeAsync(string value) =>
        _ui.FillAsync(_locators.CoverageType, value);

    public Task PressCoverageTypeAsync(string key) =>
        _ui.PressAsync(_locators.CoverageType, key);

    public Task WaitForCoveredPropertyConsistingPrincipallyOfAsync(string expected) =>
        _ui.WaitAsync(_locators.CoveredPropertyConsistingPrincipallyOf, expected);

    public Task EnterCoveredPropertyConsistingPrincipallyOfAsync(string value) =>
        _ui.FillAsync(_locators.CoveredPropertyConsistingPrincipallyOf, value);

    public Task PressCoveredPropertyConsistingPrincipallyOfAsync(string key) =>
        _ui.PressAsync(_locators.CoveredPropertyConsistingPrincipallyOf, key);

    public Task WaitForCreateValuationAsync(string expected) =>
        _ui.WaitAsync(_locators.CreateValuation, expected);

    public Task ClickCreateValuationAsync() =>
        _ui.ClickAsync(_locators.CreateValuation);

    public Task EnterDWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentAsync(string value) =>
        _ui.FillAsync(_locators.DWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, value);

    public Task PressDWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentAsync(string key) =>
        _ui.PressAsync(_locators.DWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, key);

    public Task EnterDataAndMediaAsync(string value) =>
        _ui.FillAsync(_locators.DataAndMedia, value);

    public Task PressDataAndMediaAsync(string key) =>
        _ui.PressAsync(_locators.DataAndMedia, key);

    public Task WaitForDateOfBirthAsync(string expected) =>
        _ui.WaitAsync(_locators.DateOfBirth, expected);

    public Task EnterDateOfBirthAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.DateOfBirth, value);

    public Task PressDateOfBirthAsync(string key) =>
        _ui.PressAsync(_locators.DateOfBirth, key);

    public Task WaitForDateOfHireAsync(string expected) =>
        _ui.WaitAsync(_locators.DateOfHire, expected);

    public Task EnterDateOfHireAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.DateOfHire, value);

    public Task PressDateOfHireAsync(string key) =>
        _ui.PressAsync(_locators.DateOfHire, key);

    public Task WaitForDebrisRemovalAdditionalAsync(string expected) =>
        _ui.WaitAsync(_locators.DebrisRemovalAdditional, expected);

    public Task EnterDebrisRemovalAdditionalAsync(string value) =>
        _ui.FillAsync(_locators.DebrisRemovalAdditional, value);

    public async Task<bool> IsDebrisRemovalAdditionalAsync() =>
        await _locators.DebrisRemovalAdditional.CountAsync() > 0;

    public Task PressDebrisRemovalAdditionalAsync(string key) =>
        _ui.PressAsync(_locators.DebrisRemovalAdditional, key);

    public Task SetDebrisRemovalAdditionalAsync(string value) =>
        _ui.SmartSetAsync(_locators.DebrisRemovalAdditional, value);

    public Task WaitForDebrisRemovalAdditionalLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.DebrisRemovalAdditionalLimit, expected);

    public Task EnterDebrisRemovalAdditionalLimitAsync(string value) =>
        _ui.FillAsync(_locators.DebrisRemovalAdditionalLimit, value);

    public async Task<bool> IsDebrisRemovalAdditionalLimitAsync() =>
        await _locators.DebrisRemovalAdditionalLimit.CountAsync() > 0;
    public Task SetDebrisRemovalAdditionalLimitAsync(string value) =>
        _ui.SmartSetAsync(_locators.DebrisRemovalAdditionalLimit, value);

    public Task PressDebrisRemovalAdditionalLimitAsync(string key) =>
        _ui.PressAsync(_locators.DebrisRemovalAdditionalLimit, key);

    public Task EnterDedTypeAsync(string value) =>
        _ui.FillAsync(_locators.DedType, value);

    public Task PressDedTypeAsync(string key) =>
        _ui.PressAsync(_locators.DedType, key);

    public Task EnterDedicatedLineAsync(string value) =>
        _ui.FillAsync(_locators.DedicatedLine, value);

    public Task PressDedicatedLineAsync(string key) =>
        _ui.PressAsync(_locators.DedicatedLine, key);

    public Task WaitForRatingGroupsDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroupsDeductible, expected);

    public Task EnterRatingGroupsDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.RatingGroupsDeductible, value);

    public Task PressRatingGroupsDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.RatingGroupsDeductible, key);

    public Task EnterEndorsementIF0002WaterborneEquipmentDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.EndorsementIF0002WaterborneEquipmentDeductible, value);

    public Task PressEndorsementIF0002WaterborneEquipmentDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.EndorsementIF0002WaterborneEquipmentDeductible, key);

    public Task WaitForPolicyCovgMotorTruckCargoDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgMotorTruckCargoDeductible, expected);

    public Task EnterPolicyCovgMotorTruckCargoDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgMotorTruckCargoDeductible, value);

    public Task PressPolicyCovgMotorTruckCargoDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgMotorTruckCargoDeductible, key);

    public Task EnterRiskBaileesCustomersDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersDeductible, value);

    public Task PressRiskBaileesCustomersDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersDeductible, key);

    public Task WaitForBuildingDetailDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingDetailDeductible, expected);

    public Task EnterBuildingDetailDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.BuildingDetailDeductible, value);

    public Task PressBuildingDetailDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.BuildingDetailDeductible, key);

    public Task EnterDeductibleBasisAsync(string value) =>
        _ui.FillAsync(_locators.DeductibleBasis, value);

    public Task PressDeductibleBasisAsync(string key) =>
        _ui.PressAsync(_locators.DeductibleBasis, key);

    public Task WaitForPolicyCovgContractorsEquipmentDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgContractorsEquipmentDeductible, expected);

    public Task EnterPolicyCovgContractorsEquipmentDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgContractorsEquipmentDeductible, value);

    public Task PressPolicyCovgContractorsEquipmentDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgContractorsEquipmentDeductible, key);

    public Task WaitForPolicyCovgComputerSystemsDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgComputerSystemsDeductible, expected);

    public Task EnterPolicyCovgComputerSystemsDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgComputerSystemsDeductible, value);

    public Task PressPolicyCovgComputerSystemsDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgComputerSystemsDeductible, key);

    public Task WaitForBuildingDetailDeductibleIncreasedTheftAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingDetailDeductibleIncreasedTheft, expected);

    public Task EnterBuildingDetailDeductibleIncreasedTheftAsync(string value) =>
        _ui.FillAsync(_locators.BuildingDetailDeductibleIncreasedTheft, value);

    public Task PressBuildingDetailDeductibleIncreasedTheftAsync(string key) =>
        _ui.PressAsync(_locators.BuildingDetailDeductibleIncreasedTheft, key);

    public Task WaitForRatingGroupsDeductibleIncreasedTheftAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroupsDeductibleIncreasedTheft, expected);

    public Task EnterRatingGroupsDeductibleIncreasedTheftAsync(string value) =>
        _ui.FillAsync(_locators.RatingGroupsDeductibleIncreasedTheft, value);

    public Task PressRatingGroupsDeductibleIncreasedTheftAsync(string key) =>
        _ui.PressAsync(_locators.RatingGroupsDeductibleIncreasedTheft, key);

    public Task WaitForBuildingDetailDeductibleWindHailAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingDetailDeductibleWindHail, expected);

    public Task EnterBuildingDetailDeductibleWindHailAsync(string value) =>
        _ui.FillAsync(_locators.BuildingDetailDeductibleWindHail, value);

    public Task PressBuildingDetailDeductibleWindHailAsync(string key) =>
        _ui.PressAsync(_locators.BuildingDetailDeductibleWindHail, key);

    public Task WaitForRatingGroupsDeductibleWindHailAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroupsDeductibleWindHail, expected);

    public Task EnterRatingGroupsDeductibleWindHailAsync(string value) =>
        _ui.FillAsync(_locators.RatingGroupsDeductibleWindHail, value);

    public Task PressRatingGroupsDeductibleWindHailAsync(string key) =>
        _ui.PressAsync(_locators.RatingGroupsDeductibleWindHail, key);

    public Task EnterDefaultExpModTypeAsync(string value) =>
        _ui.FillAsync(_locators.DefaultExpModType, value);

    public Task PressDefaultExpModTypeAsync(string key) =>
        _ui.PressAsync(_locators.DefaultExpModType, key);

    public Task<string> CaptureDefaultExperienceModAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DefaultExperienceMod, property);

    public Task EnterDescribeAllHoldHarmlessAgreementsAndPleaseProvideACopyAsync(string value) =>
        _ui.FillAsync(_locators.DescribeAllHoldHarmlessAgreementsAndPleaseProvideACopy, value);

    public Task PressDescribeAllHoldHarmlessAgreementsAndPleaseProvideACopyAsync(string key) =>
        _ui.PressAsync(_locators.DescribeAllHoldHarmlessAgreementsAndPleaseProvideACopy, key);

    public Task WaitForPolicyCovgContractorsEquipmentDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormDescription, expected);

    public Task EnterPolicyCovgContractorsEquipmentDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormDescription, value);

    public Task<string> CapturePolicyCovgContractorsEquipmentDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CoverageFormDescription, property);

    public Task PressPolicyCovgContractorsEquipmentDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormDescription, key);

    public Task WaitForPolicyCovgBaileesCutomersDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormDescription, expected);

    public Task EnterPolicyCovgBaileesCutomersDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormDescription, value);

    public Task<string> CapturePolicyCovgBaileesCutomersDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CoverageFormDescription, property);

    public Task PressPolicyCovgBaileesCutomersDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormDescription, key);

    public Task WaitForPolicyCovgComputerSystemsDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormDescription, expected);

    public Task EnterPolicyCovgComputerSystemsDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormDescription, value);

    public Task<string> CapturePolicyCovgComputerSystemsDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CoverageFormDescription, property);

    public Task PressPolicyCovgComputerSystemsDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormDescription, key);

    public Task WaitForRatingGroupsDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroupsDescription, expected);

    public Task EnterRatingGroupsDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.RatingGroupsDescription, value);

    public Task PressRatingGroupsDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.RatingGroupsDescription, key);

    public Task WaitForPolicyCovgSignsDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormDescription, expected);

    public Task EnterPolicyCovgSignsDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormDescription, value);

    public Task<string> CapturePolicyCovgSignsDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CoverageFormDescription, property);

    public Task PressPolicyCovgSignsDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormDescription, key);

    public Task WaitForPolicyCovgMotorTruckCargoDescriptionAsync(string expected) =>
        _ui.WaitAsync(_locators.CoverageFormDescription, expected);

    public Task EnterPolicyCovgMotorTruckCargoDescriptionAsync(string value) =>
        _ui.FillAsync(_locators.CoverageFormDescription, value);

    public Task<string> CapturePolicyCovgMotorTruckCargoDescriptionAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CoverageFormDescription, property);

    public Task PressPolicyCovgMotorTruckCargoDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.CoverageFormDescription, key);

    public Task EnterDescriptionOfBusinessActivitesAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfBusinessActivites, value);

    public Task PressDescriptionOfBusinessActivitesAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfBusinessActivites, key);

    public Task EnterDescriptionOfOperationSAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfOperationS, value);

    public Task PressDescriptionOfOperationSAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfOperationS, key);

    public Task EnterDescriptionOfOperationsAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfSpecifiedOperation, value);

    public Task PressDescriptionOfOperationsAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfOperations, key);

    public Task WaitForDescriptionOfSpecifiedOperationAsync(string expected) =>
        _ui.WaitAsync(_locators.DescriptionOfSpecifiedOperation, expected);

    public Task WaitFostimatedPremiumAsync(string expected) =>
        _ui.WaitAsync(_locators.EstimatedPremium, expected);

    public Task EnterEstimatedPremiumsAsync(string value) =>
        _ui.FillAsync(_locators.EstimatedPremium, value);

    public Task VerifyDescriptionOfSpecifiedOperationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.DescriptionOfSpecifiedOperation, expected, property);

    public Task EnterDescriptionOfSpecifiedOperationAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfSpecifiedOperation, value);

    public async Task<bool> IsEstimatedPremiumAvailableAsync() =>
        await _locators.EstimatedPremium.CountAsync() > 0;


    public async Task<bool> IsInsuranceScoreAvailableAsync() =>
        await _locators.InsuranceScoreConsent.CountAsync() > 0;

    public async Task<bool> IsPropertyLocated2miles() =>
       await _locators.PropertLocated2Miles.CountAsync() > 0;





    public Task EnterPropertyunder2MilesAsync(string value) =>
    _ui.FillAsync(_locators.PropertLocated2Miles, value);


    public Task EnterEstimatedPremiumAsync(string value) =>
        _ui.FillAsync(_locators.EstimatedPremium, value);
    public Task ClickInsuranceScoreConsentAsync() =>
    _ui.ClickAsync(_locators.InsuranceScoreConsent);

    public Task ClickInsuranceScoreAsync() =>
     _ui.ClickAsync(_locators.InsuranceScoreConsent);

    public Task PressDescriptionOfSpecifiedOperationAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfSpecifiedOperation, key);

    public Task ClickDesignatedWorkplacesExclusionOKAsync() =>
        _ui.ClickAsync(_locators.DesignatedWorkplacesExclusionOK);

    public Task WaitForUnderwritingInfoOtherInsuranceHistoryDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.Select, expected);

    public Task WaitForLocationDetailClickAsync(string expected) =>
        _ui.WaitAsync(_locators.LocationDetail, expected);

    public Task ClickLocationDetailAsync() =>
        _ui.ClickAsync(_locators.LocationDetail);

    public Task ClickPrivatePassengerVehicleDetailAsync() =>
        _ui.ClickAsync(_locators.PrivatePassengerVehicleDetail);

    public Task ClickTruckVehicleDetailAsync() =>
        _ui.ClickAsync(_locators.TruckVehicleDetail);

    public Task ClickTruckTractorVehicleDetailAsync() =>
        _ui.ClickAsync(_locators.TruckTractorVehicleDetail);

    public Task ClickSemitrailerVehicleDetailAsync() =>
        _ui.ClickAsync(_locators.SemitrailerVehicleDetail);

    public Task ClickBuildingDetailAsync() =>
    _ui.ClickAsync(_locators.AssignBuildingDetails);

    public Task WaitForLocationDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task WaitForDoYouHaveACDLLicenseAsync(string expected) =>
        _ui.WaitAsync(_locators.DoYouHaveACDLLicense, expected);

    public Task<bool> DoYouHaveACDLLicenseExistsAsync() =>
        _ui.ExistsAsync(_locators.DoYouHaveACDLLicense);

    public Task EnterDoYouHaveACDLLicenseAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.DoYouHaveACDLLicense, value);

    public Task PressDoYouHaveACDLLicenseAsync(string key) =>
        _ui.PressAsync(_locators.DoYouHaveACDLLicense, key);

    public Task EnterDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupAsync(string value) =>
        _ui.FillAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, value);

    public Task PressDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupAsync(string key) =>
        _ui.PressAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, key);

    public Task EnterDoesTheApplicantWishToCoverAnySignsInsideTheirPremisesAsync(string value) =>
        _ui.FillAsync(_locators.DoesTheApplicantWishToCoverAnySignsInsideTheirPremises, value);

    public Task<string> CaptureDoesTheApplicantWishToCoverAnySignsInsideTheirPremisesAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DoesTheApplicantWishToCoverAnySignsInsideTheirPremises, property);

    public Task PressDoesTheApplicantWishToCoverAnySignsInsideTheirPremisesAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheApplicantWishToCoverAnySignsInsideTheirPremises, key);

    public Task EnterDoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirementAsync(string value) =>
        _ui.FillAsync(_locators.DoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirement, value);

    public Task PressDoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirementAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirement, key);

    public Task EnterDoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofsAsync(string value) =>
        _ui.FillAsync(_locators.DoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofs, value);

    public Task PressDoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofsAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofs, key);

    public Task EnterDoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicyAsync(string value) =>
        _ui.FillAsync(_locators.DoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicy, value);

    public Task PressDoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicyAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicy, key);

    public Task ClickDriveOtherCarAsync() =>
        _ui.ClickAsync(_locators.DriveOtherCar);

    public Task ClickDriverScheduleAsync() =>
        _ui.ClickAsync(_locators.DriverSchedule);

    public Task VerifyDriversLicenseNumberAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.DriversLicenseNumber, expected, property);

    public Task WaitForDriversLicenseNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.DriversLicenseNumber, expected);

    public Task EnterDriversLicenseNumberAsync(string value) =>
        _ui.FillAsync(_locators.DriversLicenseNumber, value);

    public Task PressDriversLicenseNumberAsync(string key) =>
        _ui.PressAsync(_locators.DriversLicenseNumber, key);

    public Task EnterDryCleaningAsync(string value) =>
        _ui.FillAsync(_locators.DryCleaning, value);

    public Task PressDryCleaningAsync(string key) =>
        _ui.PressAsync(_locators.DryCleaning, key);

    public Task WaitForDuplicatedRecordsAsync(string expected) =>
        _ui.WaitAsync(_locators.DuplicatedRecords, expected);

    public Task EnterDuplicatedRecordsAsync(string value) =>
        _ui.FillAsync(_locators.DuplicatedRecords, value);

    public Task<bool> IsDuplicatedRecordsVisibleAsync() => _ui.ExistsAsync(_locators.DuplicatedRecords);

    public Task PressDuplicatedRecordsAsync(string key) =>
        _ui.PressAsync(_locators.DuplicatedRecords, key);

    public Task EnterEAreNoSmokingRulesPostedAndEnforcedAsync(string value) =>
        _ui.FillAsync(_locators.EAreNoSmokingRulesPostedAndEnforced, value);

    public Task PressEAreNoSmokingRulesPostedAndEnforcedAsync(string key) =>
        _ui.PressAsync(_locators.EAreNoSmokingRulesPostedAndEnforced, key);

    public Task EnterEMailAsync(string value) =>
        _ui.FillAsync(_locators.EMail, value);

    public Task EnterEarthquakeAsync(string value) =>
        _ui.FillAsync(_locators.Earthquake, value);

    public Task PressEarthquakeAsync(string key) =>
        _ui.PressAsync(_locators.Earthquake, key);

    public Task WaitForEasyPayAsync(string expected) =>
        _ui.WaitAsync(_locators.EasyPay, expected);

    public Task EnterEasyPayAsync(string value) =>
        _ui.FillAsync(_locators.EasyPay, value);

    public Task PressEasyPayAsync(string key) =>
        _ui.PressAsync(_locators.EasyPay, key);

    public Task WaitForCommercialAutoEffectiveDateAsync(string expected) =>
        _ui.WaitAsync(_locators.CommercialAutoEffectiveDate, expected);

    public Task EnterCommercialAutoEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.CommercialAutoEffectiveDate, value);

    public Task EnterLiquifiedGasAsync(string value) =>
        _ui.FillAsync(_locators.LiquifiedGas, value);

    public Task<string> CaptureCommercialAutoEffectiveDateAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CommercialAutoEffectiveDate, property);

    public Task EnterCommercialAutoExpirynDateAsync(string value) =>
        _ui.FillAsync(_locators.CommercialAutoExpiryDateDate, value);

    public Task PressCommercialAutoEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.CommercialAutoEffectiveDate, key);

    public Task WaitForBusinessownersEffectiveDateAsync(string expected) =>
        _ui.WaitAsync(_locators.BusinessownersEffectiveDate, expected);

    public Task EnterBusinessownersEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.BusinessownersEffectiveDate, value);

    public Task PressBusinessownersEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.BusinessownersEffectiveDate, key);

    public Task EnterPolicyInfoRequiredAndOptionalFieldsEffectiveDateAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.PolicyInfoRequiredAndOptionalFieldsEffectiveDate, value);

    public Task PressPolicyInfoRequiredAndOptionalFieldsEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.PolicyInfoRequiredAndOptionalFieldsEffectiveDate, key);

    public Task WaitForEligibleForEnhancedWindRatingProgramAsync(string expected) =>
        _ui.WaitAsync(_locators.EligibleForEnhancedWindRatingProgram, expected);

    public Task EnterEligibleForEnhancedWindRatingProgramAsync(string value) =>
        _ui.FillAsync(_locators.EligibleForEnhancedWindRatingProgram, value);

    public Task PressEligibleForEnhancedWindRatingProgramAsync(string key) =>
        _ui.PressAsync(_locators.EligibleForEnhancedWindRatingProgram, key);

    public Task ClickEmployeeHiredAutosCheckBoxAsync() =>
        _ui.ClickAsync(_locators.EmployeeHiredAutosCheckBox);

    public Task WaitForEmployersLiabAsync(string expected) =>
        _ui.WaitAsync(_locators.EmployersLiab, expected);

    public Task PressEmployersLiabAsync(string key) =>
        _ui.PressAsync(_locators.EmployersLiab, key);

    public Task ClickEmployersLiabAsync() =>
        _ui.ClickAsync(_locators.EmployersLiab);

    public Task ClickEndorsementAsync() =>
        _ui.ClickAsync(_locators.Endorsement);

    public Task WaitForEndorsementHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task VerifyFirstEndorsementScheduleRowAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FirstEndorsementScheduleRow, expected, property);

    public Task VerifyFirstEndorsementTableRowAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FirstEndorsementTableRow, expected, property);

    public Task VerifySecondEndorsementTableRowAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SecondEndorsementTableRow, expected, property);

    public Task VerifyCA2394EndorsementFormNameAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CA2394EndorsementFormName, expected, property);

    public async Task<bool> IsCA2394EndorsementFormNameVisibleAsync() =>
        await _locators.CA2394EndorsementFormName.IsVisibleAsync();

    public Task EnterCG2401NonBindingArbitrationEndorsementTypeAsync(string value) =>
        _ui.FillAsync(_locators.CoverageEndorsementType, value);


    public Task EnterDescriptionOfActivitiesAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfActivities, value);







    public Task PressCG2401NonBindingArbitrationEndorsementTypeAsync(string key) =>
        _ui.PressAsync(_locators.CoverageEndorsementType, key);

    public Task WaitForBAPEndorsementsEndorsementTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.LineEndorsementType, expected);

    public Task EnterBAPEndorsementsEndorsementTypeAsync(string value) =>
        _ui.FillAsync(_locators.LineEndorsementType, value);

    public Task PressBAPEndorsementsEndorsementTypeAsync(string key) =>
        _ui.PressAsync(_locators.LineEndorsementType, key);

    public Task ClickBAPEndorsementsEndorsementTypeAsync() =>
        _ui.ClickAsync(_locators.LineEndorsementType);

    public Task EnterEndorsementsPartnersOfficersAndOthersExclusionEndorsementTypeAsync(string value) =>
        _ui.FillAsync(_locators.CoverageEndorsementType, value);

    public Task PressEndorsementsPartnersOfficersAndOthersExclusionEndorsementTypeAsync(string key) =>
        _ui.PressAsync(_locators.CoverageEndorsementType, key);

    public Task ClickGLNavigationLinksEndorsementsAsync() =>
        _ui.ClickAsync(_locators.GLNavigationLinksEndorsements);

    public Task WaitForEndorsementsAsync(string expected) =>
        _ui.WaitAsync(_locators.Endorsements, expected);

    public Task WaitForWCNavigationLinksEndorsementsAsync(string expected) =>
        _ui.WaitAsync(_locators.WCNavigationLinksEndorsements, expected);

    public Task PressWCNavigationLinksEndorsementsAsync(string key) =>
        _ui.PressAsync(_locators.WCNavigationLinksEndorsements, key);

    public Task EnterEndrosmentType(string value) =>
       _ui.FillAsync(_locators.EndrosmentType, value);

    public Task EnterEndrosmentOfficeThatShouldBeExcludedType(string value) =>
    _ui.FillAsync(_locators.OfficeThatShouldBeExcluded, value);

    public Task ClickAddEndorsementsAsync() =>
       _ui.ClickAsync(_locators.AddEndorsements);

    public Task ClickWCNavigationLinksEndorsementsAsync() =>
        _ui.ClickAsync(_locators.WCNavigationLinksEndorsements);

    public Task VerifySignsHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PageTitle, expected, property);

    public Task EnterEngineSizeCcAsync(string value) =>
        _ui.FillAsync(_locators.EngineSizeCc, value);

    public async Task<bool> IsEngineSizeCcVisibleAsync() =>
        await _locators.EngineSizeCc.First.IsVisibleAsync();

    public Task PressEngineSizeCcAsync(string key) =>
        _ui.PressAsync(_locators.EngineSizeCc, key);

    public Task WaitForEntityInfoFrameAsync(string expected) =>
        _ui.WaitAsync(_locators.EntityInfoFrame, expected);

    public Task ClickEntityScheduleAsync() =>
        _ui.ClickAsync(_locators.EntitySchedule);

    public Task EnterEstimatedHighestValueAsync(string value) =>
        _ui.FillAsync(_locators.EstimatedHighestValue, value);

    public Task PressEstimatedHighestValueAsync(string key) =>
        _ui.PressAsync(_locators.EstimatedHighestValue, key);

    public Task WaitForEstimatorTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.EstimatorType, expected);

    public Task EnterEstimatorTypeAsync(string value) =>
        _ui.FillAsync(_locators.EstimatorType, value);

    public Task SetEstimatorTypeAsync(string value) =>
        _ui.SmartSetAsync(_locators.EstimatorType, value);

    public Task PressEstimatorTypeAsync(string key) =>
        _ui.PressAsync(_locators.EstimatorType, key);

    public Task ClickExcessLiabilityIfAnyAsync() =>
        _ui.ClickAsync(_locators.ExcessLiabilityIfAny);

    public Task SetExcludeCollapseHazardAsync(string value) =>
        _ui.SmartSetAsync(_locators.ExcludeCollapseHazard, value);

    public Task PressExcludeCollapseHazardAsync(string key) =>
        _ui.PressAsync(_locators.ExcludeCollapseHazard, key);

    public Task SetExcludeExplosionHazardAsync(string value) =>
        _ui.SmartSetAsync(_locators.ExcludeExplosionHazard, value);

    public Task PressExcludeExplosionHazardAsync(string key) =>
        _ui.PressAsync(_locators.ExcludeExplosionHazard, key);

    public Task SetExcludeUndergroundPropertyDamageHazardAsync(string value) =>
        _ui.SmartSetAsync(_locators.ExcludeUndergroundPropertyDamageHazard, value);

    public Task PressExcludeUndergroundPropertyDamageHazardAsync(string key) =>
        _ui.PressAsync(_locators.ExcludeUndergroundPropertyDamageHazard, key);

    public Task WaitForExcludedLiabilityConfidentialInformationAsync(string expected) =>
        _ui.WaitAsync(_locators.ExcludedLiabilityConfidentialInformation, expected);

    public Task VerifyExcludedLiabilityConfidentialInformationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ExcludedLiabilityConfidentialInformation, expected, property);

    public Task<string> CaptureExcludedLiabilityConfidentialInformationAsync(string property = "") =>
        _ui.CaptureAsync(_locators.ExcludedLiabilityConfidentialInformation, property);

    public Task EnterExcludedLiabilityConfidentialInformationAsync(string value) =>
        _ui.FillAsync(_locators.ExcludedLiabilityConfidentialInformation, value);

    public Task PressExcludedLiabilityConfidentialInformationAsync(string key) =>
        _ui.PressAsync(_locators.ExcludedLiabilityConfidentialInformation, key);

    public Task EnterExperienceModTypeAsync(string value) =>
        _ui.FillAsync(_locators.ExperienceModType, value);

    public Task PressExperienceModTypeAsync(string key) =>
        _ui.PressAsync(_locators.ExperienceModType, key);

    public Task EnterExperienceRatedAsync(string value) =>
        _ui.FillAsync(_locators.ExperienceRated, value);

    public Task PressExperienceRatedAsync(string key) =>
        _ui.PressAsync(_locators.ExperienceRated, key);

    public Task EnterExperienceRatingOptionsAsync(string value) =>
        _ui.FillAsync(_locators.ExperienceRatingOptions, value);

    public Task PressExperienceRatingOptionsAsync(string key) =>
        _ui.PressAsync(_locators.ExperienceRatingOptions, key);

    public Task EnterGeneralLiabilityExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.GeneralLiabilityExpirationDate, value);

    public Task<string> CaptureGeneralLiabilityExpirationDateAsync(string property = "") =>
        _ui.CaptureAsync(_locators.GeneralLiabilityExpirationDate, property);

    public Task PressGeneralLiabilityExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.GeneralLiabilityExpirationDate, key);

    public Task EnterBusinessownersExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.BusinessownersExpirationDate, value);

    public Task PressBusinessownersExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.BusinessownersExpirationDate, key);

    public Task EnterExposureAsync(string value) =>
        _ui.FillAsync(_locators.Exposure, value);

    public Task PressExposureAsync(string key) =>
        _ui.PressAsync(_locators.Exposure, key);

    public Task EnterExtendedEmployeeCoverageAsync(string value) =>
        _ui.FillAsync(_locators.ExtendedEmployeeCoverage, value);

    public Task PressExtendedEmployeeCoverageAsync(string key) =>
        _ui.PressAsync(_locators.ExtendedEmployeeCoverage, key);

    public Task WaitForExtraExpenseAsync(string expected) =>
        _ui.WaitAsync(_locators.ExtraExpense, expected);

    public Task EnterExtraExpenseAsync(string value) =>
        _ui.FillAsync(_locators.ExtraExpense, value);

    public Task PressExtraExpenseAsync(string key) =>
        _ui.PressAsync(_locators.ExtraExpense, key);

    public Task VerifyFeetFromHydrantAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FeetFromHydrant, expected, property);

    public Task EnterFeetFromHydrantAsync(string value) =>
        _ui.FillAsync(_locators.FeetFromHydrant, value);

    public Task PressFeetFromHydrantAsync(string key) =>
        _ui.PressAsync(_locators.FeetFromHydrant, key);

    public Task EnterFireDamageAsync(string value) =>
        _ui.FillAsync(_locators.FireDamage, value);

    public Task PressFireDamageAsync(string key) =>
        _ui.PressAsync(_locators.FireDamage, key);

    public Task EnterStateDetailsDriveOtherCarFirstNameAsync(string value) =>
        _ui.FillAsync(_locators.StateDetailsDriveOtherCarFirstName, value);

    public Task PressStateDetailsDriveOtherCarFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.StateDetailsDriveOtherCarFirstName, key);

    public Task WaitForFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.FirstName, expected);

    public Task EnterFirstNameAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.FirstName, value);

    public Task PressFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.FirstName, key);

    public Task EnterGCWAsync(string value) =>
        _ui.FillAsync(_locators.GCW, value);

    public async Task<bool> IsGCWVisibleAsync() =>
        await _locators.GCW.First.IsVisibleAsync();

    public Task PressGCWAsync(string key) =>
        _ui.PressAsync(_locators.GCW, key);

    public Task ClickGLDetailAsync() =>
        _ui.ClickAsync(_locators.GLDetail);

    public Task ClickGLUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.GLUWQuestions);

    public Task WaitForGeneralLiabAsync(string expected) =>
        _ui.WaitAsync(_locators.GeneralLiab, expected);

    public Task PressGeneralLiabAsync(string key) =>
        _ui.PressAsync(_locators.GeneralLiab, key);

    public Task ClickGeneralLiabAsync() =>
        _ui.ClickAsync(_locators.GeneralLiab);

    public Task WaitForGeneralLiabilityInformationAsync(string expected) =>
        _ui.WaitAsync(_locators.GeneralLiabilityHeader, expected);

    public Task ClickGeneralLiabilityInformationAsync() =>
        _ui.ClickAsync(_locators.ProductsOrCompletedOps);

    public Task WaitForGeneralUWQuestionsAsync(string expected) =>
        _ui.WaitAsync(_locators.GeneralUWQuestions, expected);

    public Task WaitForGetCalculatedValueAsync(string expected) =>
        _ui.WaitAsync(_locators.GetCalculatedValue, expected);

    public Task ClickGetCalculatedValueAsync() =>
        _ui.ClickAsync(_locators.GetCalculatedValue);

    public Task WaitForGroupClassAsync(string expected) =>
        _ui.WaitAsync(_locators.GroupClass, expected);

    public Task EnterGroupClassAsync(string value) =>
        _ui.FillAsync(_locators.GroupClass, value);

    public Task PressGroupClassAsync(string key) =>
        _ui.PressAsync(_locators.GroupClass, key);

    public Task VerifyHasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiringAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.HasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiring, expected, property);

    public async Task<bool> IsHasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiringVisibleAsync() =>
        await _locators.HasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiring.First.IsVisibleAsync();

    public Task EnterHasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiringAsync(string value) =>
        _ui.FillAsync(_locators.HasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiring, value);

    public Task PressHasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiringAsync(string key) =>
        _ui.PressAsync(_locators.HasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiring, key);

    public Task WaitForHaveYouHadAnyLiabilityLossesInTheLast5YearsOnAnyPrimaryOrExcessPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.HaveYouHadAnyLiabilityLossesInTheLast5YearsOnAnyPrimaryOrExcessPolicy, expected);

    public Task EnterHiredAutoCA2001AddressAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCA2001Address, value);

    public Task PressHiredAutoCA2001AddressAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCA2001Address, key);

    public Task ClickHiredAutoCA2001OKAsync() =>
        _ui.ClickAsync(_locators.HiredAutoCA2001OK);

    public Task EnterHiredAutoCA2001FirstNameAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCA2001FirstName, value);

    public Task PressHiredAutoCA2001FirstNameAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCA2001FirstName, key);

    public Task EnterHiredAutoCA2001LastNameAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCA2001LastName, value);

    public Task PressHiredAutoCA2001LastNameAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCA2001LastName, key);

    public Task EnterHiredAutoCA2001ZipCodeAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoCA2001ZipCode, value);

    public Task PressHiredAutoCA2001ZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoCA2001ZipCode, key);

    public Task VerifyHiredAutoExtAddlInsuredAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.HiredAutoExtAddlInsured, expected, property);

    public Task EnterHiredAutoExtAddlInsuredAsync(string value) =>
        _ui.FillAsync(_locators.HiredAutoExtAddlInsured, value);

    public Task PressHiredAutoExtAddlInsuredAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoExtAddlInsured, key);

    public Task WaitForHiredAutoOKAsync(string expected) =>
        _ui.WaitAsync(_locators.HiredAutoOK, expected);

    public Task EnterHiredAutoOKAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoOK, value);

    public Task PressHiredAutoOKAsync(string key) =>
        _ui.PressAsync(_locators.HiredAutoOK, key);

    public Task ClickHiredAutoLiabilityAsync() =>
        _ui.ClickAsync(_locators.HiredAutoLiability);

    public Task EnterCostOfHirePrimaryAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.CostOfHirePrimary, value);

    public async Task<bool> IsCostOfHirePrimaryVisibleAsync() =>
        await _locators.CostOfHirePrimary.First.IsVisibleAsync();

    public Task EnterCostOfHireExcessAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.CostOfHireExcess, value);

    public async Task<bool> IsCostOfHireExcessVisibleAsync() =>
        await _locators.CostOfHireExcess.First.IsVisibleAsync();

    public Task EnterCostOfHirePhysicalDamageAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.CostOfHirePhysicalDamage, value);

    public async Task<bool> IsCostOfHirePhysicalDamageVisibleAsync() =>
        await _locators.CostOfHirePhysicalDamage.First.IsVisibleAsync();

    public Task EnterCostOfHireWithDriverAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.CostOfHireWithDriver, value);

    public async Task<bool> IsCostOfHireWithDriverVisibleAsync() =>
        await _locators.CostOfHireWithDriver.First.IsVisibleAsync();

    public Task ClickHiredAutoOKAsync() =>
        _ui.ClickAsync(_locators.HiredAutoOK);

    public Task ClickHiredAutoPhysicalDamageWithDriverAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.HiredAutoPhysicalDamageWithDriver);

    public Task ClickHiredAutoPhysicalDamageWithoutDriverAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.HiredAutoPhysicalDamageWithoutDriver.First);

    public Task WaitForHiredEquipmentAsync(string expected) =>
        _ui.WaitAsync(_locators.HiredEquipment, expected);

    public Task EnterHiredEquipmentAsync(string value) =>
        _ui.FillAsync(_locators.HiredEquipment, value);

    public Task PressHiredEquipmentAsync(string key) =>
        _ui.PressAsync(_locators.HiredEquipment, key);

    public Task EnterHowOftenIsDataBackedUpAsync(string value) =>
        _ui.FillAsync(_locators.HowOftenIsDataBackedUp, value);

    public Task PressHowOftenIsDataBackedUpAsync(string key) =>
        _ui.PressAsync(_locators.HowOftenIsDataBackedUp, key);

    public Task WaitForAdditionalInterestsScheduleIFRAMEAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalInterestsScheduleIFRAME, expected);

    public Task VerifyAdditionalInterestsScheduleIFRAMEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AdditionalInterestsScheduleIFRAME, expected, property);

    public Task WaitForDriverDetailIFRAMEAsync(string expected) =>
        _ui.WaitAsync(_locators.DriverDetailIFRAME, expected);

    public Task WaitForDriverDetailPageTitleAsync(string expected) =>
        _ui.WaitAsync(_locators.DriverDetailPageTitle, expected);

    public Task WaitForDriverSchedulePageTitleAsync(string expected) =>
        _ui.WaitAsync(_locators.DriverSchedulePageTitle, expected);

    public Task WaitForRiskSchedulePageTitleAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskSchedulePageTitle, expected);


    public Task EnterIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationSAsync(string value) => 
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationS, value);

    public Task PressIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationSAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationS, key);

    public Task EnterIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremisesAsync(string value) =>
        _ui.FillAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremises, value);

    public Task PressIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremisesAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremises, key);

    public Task EnterIFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivitiesAsync(string value) =>
        _ui.FillAsync(_locators.IFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivities, value);

    public Task EnterIFRAMEDuckCreekPolicyWADescriptionOfPremisesOrActivitiesAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionSOfDesignatedPremises, value);

    public Task PressIFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivitiesAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivities, key);

    public Task EnterIFRAMEDuckCreekPolicyExcludedDriverAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyExcludedDriver, value);

    public Task PressIFRAMEDuckCreekPolicyExcludedDriverAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyExcludedDriver, key);

    public Task EnterIFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalSAsync(string value) =>
        _ui.FillAsync(_locators.IFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalS, value);

    public Task PressIFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalSAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalS, key);

    public Task WaitForIFRAMEDuckCreekPolicyVehicleAssociationAsync(string expected) =>
        _ui.WaitAsync(_locators.IFRAMEDuckCreekPolicyVehicleAssociation, expected);

    public Task PressIFRAMEDuckCreekPolicyVehicleAssociationAsync(string key) =>
        _ui.PressAsync(_locators.IFRAMEDuckCreekPolicyVehicleAssociation, key);

    public Task ClickIFRAMEDuckCreekPolicyVehicleAssociationAsync() =>
        _ui.ClickAsync(_locators.IFRAMEDuckCreekPolicyVehicleAssociation);

    public async Task<bool> IsIFRAMEDuckCreekPolicyVehicleAssociationVisibleAsync() =>
        await _locators.IFRAMEDuckCreekPolicyVehicleAssociation.First.IsVisibleAsync();

    // Opens the Vehicle Association dropdown directly in the popup iframe (no background-page
    // probing) and selects the second rendered option, since the first option is always the
    // "(Select)" placeholder and the second option is the actual first real vehicle entry.
    public async Task SelectFirstIFRAMEDuckCreekPolicyVehicleAssociationOptionAsync()
    {
        var input = _locators.IFRAMEDuckCreekPolicyVehicleAssociation;
        await ComponentAwareControlActions.DomClickAsync(input);

        var firstOption = _locators.IFRAMEDuckCreekPolicyVehicleAssociationFirstOption;
        var secondOption = _locators.IFRAMEDuckCreekPolicyVehicleAssociationSecondOption;
        try
        {
            await firstOption.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 3000 });
        }
        catch (TimeoutException)
        {
            // Dropdown list did not open from the click alone; force it open via keyboard.
            await input.First.PressAsync("ArrowDown");
            await firstOption.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 5000 });
        }

        await ComponentAwareControlActions.DomClickAsync(secondOption);
        await input.First.PressAsync("Tab");
    }

    public Task WaitForBAPEndorsementsIFRAMEAsync(string expected) =>
        _ui.WaitAsync(_locators.BAPEndorsementsIFRAME, expected);

    public Task VerifyBAPEndorsementsIFRAMEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.BAPEndorsementsIFRAME, expected, property);

    public Task EnterIfYesDescribeAsync(string value) =>
        _ui.FillAsync(_locators.IfYesDescribe, value);

    public Task PressIfYesDescribeAsync(string key) =>
        _ui.PressAsync(_locators.IfYesDescribe, key);

    public Task EnterIfYesExplainAsync(string value) =>
        _ui.FillAsync(_locators.IfYesExplain, value);

    public Task PressIfYesExplainAsync(string key) =>
        _ui.PressAsync(_locators.IfYesExplain, key);

    public Task ClickImportPolicyDataAsync() =>
        _ui.ClickAsync(_locators.ImportPolicyData);

    public Task ClickImportPolicyDataButtonAsync() =>
        _ui.ClickAsync(_locators.ImportPolicyData);

    public Task WaitForIncreasedPollutantCleanupAsync(string expected) =>
        _ui.WaitAsync(_locators.IncreasedPollutantCleanup, expected);

    public Task EnterIncreasedPollutantCleanupAsync(string value) =>
        _ui.FillAsync(_locators.IncreasedPollutantCleanup, value);

    public async Task<bool> IsIncreasedPollutantCleanupAsync() =>
        await _locators.IncreasedPollutantCleanup.CountAsync() > 0;
    public Task SetIncreasedPollutantCleanupAsync(string value) =>
        _ui.SmartSetAsync(_locators.IncreasedPollutantCleanup, value);

    public Task PressIncreasedPollutantCleanupAsync(string key) =>
        _ui.PressAsync(_locators.IncreasedPollutantCleanup, key);

    public Task EnterIndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocatedAsync(string value) =>
        _ui.FillAsync(_locators.IndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocated, value);

    public Task PressIndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocatedAsync(string key) =>
        _ui.PressAsync(_locators.IndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocated, key);

    public Task ClickInsuranceHistoryAsync() =>
        _ui.ClickAsync(_locators.InsuranceHistory);

    public Task WaitForInsuredTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.InsuredType, expected);

    public Task WaitForInterestAsync(string expected) =>
        _ui.WaitAsync(_locators.Interest, expected);

    public Task EnterInterestAsync(string value) =>
        _ui.FillAsync(_locators.Interest, value);

    public Task PressInterestAsync(string key) =>
        _ui.PressAsync(_locators.Interest, key);

    public Task WaitForIntrastateRiskIDAsync(string expected) =>
        _ui.WaitAsync(_locators.IntrastateRiskID, expected);

    public Task WaitForIsTheBuildingCooledAsync(string expected) =>
        _ui.WaitAsync(_locators.IsTheBuildingCooled, expected);

    public Task EnterIsTheBuildingCooledAsync(string value) =>
        _ui.FillAsync(_locators.IsTheBuildingCooled, value);

    public Task PressIsTheBuildingCooledAsync(string key) =>
        _ui.PressAsync(_locators.IsTheBuildingCooled, key);

    public Task WaitForIsTheBuildingHeatedWithASolidFuelHeatingDeviceAsync(string expected) =>
        _ui.WaitAsync(_locators.IsTheBuildingHeatedWithASolidFuelHeatingDevice, expected);

    public Task EnterIsTheBuildingHeatedWithASolidFuelHeatingDeviceAsync(string value) =>
        _ui.FillAsync(_locators.IsTheBuildingHeatedWithASolidFuelHeatingDevice, value);

    public Task PressIsTheBuildingHeatedWithASolidFuelHeatingDeviceAsync(string key) =>
        _ui.PressAsync(_locators.IsTheBuildingHeatedWithASolidFuelHeatingDevice, key);

    public Task EnterIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsAsync(string value) =>
        _ui.FillAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, value);

    public Task PressIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsAsync(string key) =>
        _ui.PressAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, key);

    public Task WaitForIsThereAPriorCarrierAsync(string expected) =>
        _ui.WaitAsync(_locators.IsThereAPriorCarrier, expected);

    public Task EnterIsThereAPriorCarrierAsync(string value) =>
        _ui.FillAsync(_locators.IsThereAPriorCarrier, value);

    public Task PressIsThereAPriorCarrierAsync(string key) =>
        _ui.PressAsync(_locators.IsThereAPriorCarrier, key);

    public Task EnterIsThisCoverageBoundAsync(string value) =>
        _ui.FillAsync(_locators.IsThisCoverageBound, value);

    public Task PressIsThisCoverageBoundAsync(string key) =>
        _ui.PressAsync(_locators.IsThisCoverageBound, key);

    public Task<bool> IsThisCoverageBoundExistsAsync() =>
        _ui.ExistsAsync(_locators.IsThisCoverageBound);

    public Task<bool> OrderAuditExistsAsync() =>
        _ui.ExistsAsync(_locators.OrderAudit);

    public Task VerifyIsThisPolicyBeingFullyCancelledAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IsThisPolicyBeingFullyCancelled, expected, property);

    public Task VerifyIsThisVehicleUsedInSnowPlowOperationsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IsThisVehicleUsedInSnowPlowOperations, expected, property);

    public Task EnterIsThisVehicleUsedInSnowPlowOperationsAsync(string value) =>
        _ui.FillAsync(_locators.IsThisVehicleUsedInSnowPlowOperations, value);

    public async Task<bool> IsThisVehicleUsedInSnowPlowOperationsVisibleAsync() =>
        await _locators.IsThisVehicleUsedInSnowPlowOperations.First.IsVisibleAsync();

    public Task PressIsThisVehicleUsedInSnowPlowOperationsAsync(string key) =>
        _ui.PressAsync(_locators.IsThisVehicleUsedInSnowPlowOperations, key);

    public Task EnterJavaScriptAsync(string value) =>
        _ui.FillAsync(_locators.JavaScript, value);

    public Task WaitForLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.LastName, expected);

    public Task EnterLastNameAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.LastName, value);

    public Task PressLastNameAsync(string key) =>
        _ui.PressAsync(_locators.LastName, key);

    public Task EnterStateDetailsDriveOtherCarLastNameAsync(string value) =>
        _ui.FillAsync(_locators.StateDetailsDriveOtherCarLastName, value);

    public Task PressStateDetailsDriveOtherCarLastNameAsync(string key) =>
        _ui.PressAsync(_locators.StateDetailsDriveOtherCarLastName, key);

    public Task EnterLaundryAsync(string value) =>
        _ui.FillAsync(_locators.Laundry, value);

    public Task PressLaundryAsync(string key) =>
        _ui.PressAsync(_locators.Laundry, key);

    public Task EnterLetteringAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.Lettering, value, 20);

    public Task<string> CaptureLetteringAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Lettering, property);

    public Task<string> CaptureRiskTypeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskType, property);

    public Task PressLetteringAsync(string key) =>
        _ui.PressAsync(_locators.Lettering, key);

    public Task EnterCommercialAutoLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.CommercialAutoLiabilityLimit, value);

    public Task<string> CaptureCommercialAutoLiabilityLimitAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CommercialAutoLiabilityLimit, property);

    public Task PressCommercialAutoLiabilityLimitAsync(string key) =>
        _ui.PressAsync(_locators.CommercialAutoLiabilityLimit, key);

    public Task EnterSFP10LiabilityFarmLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.SFP10LiabilityFarmLiabilityLimit, value);

    public Task EnterRiskDefaultsLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.RiskDefaultsLiabilityLimit, value);

    public Task<string> CaptureRiskDefaultsLiabilityLimitAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskDefaultsLiabilityLimit, property);

    public Task PressRiskDefaultsLiabilityLimitAsync(string key) =>
        _ui.PressAsync(_locators.RiskDefaultsLiabilityLimit, key);

    public Task EnterRiskDefaultsIncomeLossBenefitsAsync(string value) =>
        _ui.FillAsync(_locators.RiskDefaultsIncomeLossBenefits, value);

    public Task<string> CaptureRiskDefaultsIncomeLossBenefitsAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskDefaultsIncomeLossBenefits, property);

    public Task PressRiskDefaultsIncomeLossBenefitsAsync(string key) =>
        _ui.PressAsync(_locators.RiskDefaultsIncomeLossBenefits, key);

    public Task EnterRiskDefaultsTowingAsync(string value) =>
        _ui.FillAsync(_locators.RiskDefaultsTowing, value);

    public Task<string> CaptureRiskDefaultsTowingAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskDefaultsTowing, property);

    public Task PressRiskDefaultsTowingAsync(string key) =>
        _ui.PressAsync(_locators.RiskDefaultsTowing, key);

    public Task<string> CaptureSFP10LiabilityFarmLiabilityLimitAsync(string property = "") =>
        _ui.CaptureAsync(_locators.SFP10LiabilityFarmLiabilityLimit, property);

    public Task PressSFP10LiabilityFarmLiabilityLimitAsync(string key) =>
        _ui.PressAsync(_locators.SFP10LiabilityFarmLiabilityLimit, key);

    public Task WaitForPolicyCovgBaileesPropertyAwayFromYourPremisesLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgBaileesPropertyAwayFromYourPremisesLimit, expected);

    public Task EnterPolicyCovgBaileesPropertyAwayFromYourPremisesLimitAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgBaileesPropertyAwayFromYourPremisesLimit, value);

    public Task PressPolicyCovgBaileesPropertyAwayFromYourPremisesLimitAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgBaileesPropertyAwayFromYourPremisesLimit, key);

    public Task EnterEndorsementIF0002WaterborneEquipmentLimitAsync(string value) =>
        _ui.FillAsync(_locators.EndorsementIF0002WaterborneEquipmentLimit, value);

    public Task PressEndorsementIF0002WaterborneEquipmentLimitAsync(string key) =>
        _ui.PressAsync(_locators.EndorsementIF0002WaterborneEquipmentLimit, key);

    public Task EnterRiskBaileesCustomersLimitAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersLimit, value);

    public Task PressRiskBaileesCustomersLimitAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersLimit, key);

    public Task EnterLimitOfInsuranceAsync(string value) =>
        _ui.FillAsync(_locators.LimitOfInsurance, value);

    public Task PressLimitOfInsuranceAsync(string key) =>
        _ui.PressAsync(_locators.LimitOfInsurance, key);

    public Task EnterLineConditionerAsync(string value) =>
        _ui.FillAsync(_locators.LineConditioner, value);

    public Task PressLineConditionerAsync(string key) =>
        _ui.PressAsync(_locators.LineConditioner, key);

    public Task EnterListAllPoliciesWithAmericanNationalAsync(string value) =>
        _ui.FillAsync(_locators.ListAllPoliciesWithAmericanNational, value);

    public Task PressListAllPoliciesWithAmericanNationalAsync(string key) =>
        _ui.PressAsync(_locators.ListAllPoliciesWithAmericanNational, key);

    public Task WaitForLoadingMessageAsync(string expected) =>
        _ui.WaitAsync(_locators.LoadingMessage, expected);

    public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task EnterLoanLeaseGapAsync(string value) =>
        _ui.FillAsync(_locators.LoanLeaseGap, value);

    public async Task<bool> IsLoanLeaseGapVisibleAsync() =>
        await _locators.LoanLeaseGap.First.IsVisibleAsync();

    public Task PressLoanLeaseGapAsync(string key) =>
        _ui.PressAsync(_locators.LoanLeaseGap, key);

    public Task WaitForLocationAsync(string expected) =>
        _ui.WaitAsync(_locators.Location, expected);


    public Task ClickWCNavigationLinksLocationAsync() =>
        _ui.ClickAsync(_locators.WCNavigationLinksLocation);

    public Task WaitForWCNavigationLinksLocationAsync(string expected) =>
        _ui.WaitAsync(_locators.WCNavigationLinksLocation, expected);

    public Task WaitForLocationAssignmentAsync(string expected) =>
        _ui.WaitAsync(_locators.LocationAssignment, expected);

    public Task WaitForLocationIDAsync(string expected) =>
        _ui.WaitAsync(_locators.LocationID, expected);

    public Task VerifyLocationIDAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LocationID, expected, property);

    public Task EnterLocationIDAsync(string value) =>
        _ui.FillAsync(_locators.LocationID, value);

    public Task PressLocationIDAsync(string key) =>
        _ui.PressAsync(_locators.LocationID, key);

    public Task ClickLocationIDAsync() =>
        _ui.ClickAsync(_locators.LocationID);

    public Task EnterLocationOfCoveredOperationsAsync(string value) =>
        _ui.FillAsync(_locators.LocationOfCoveredOperations, value);

    public Task PressLocationOfCoveredOperationsAsync(string key) =>
        _ui.PressAsync(_locators.LocationOfCoveredOperations, key);

    public Task ClickLossExperienceAsync() =>
        _ui.ClickAsync(_locators.LossOfExperience);

    public Task WaitForLossExperienceHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.LossExperience, expected);

    public Task EnterMakeAsync(string value) =>
        _ui.FillAsync(_locators.Make, value);

    public Task PressMakeAsync(string key) =>
        _ui.PressAsync(_locators.Make, key);

    public Task WaitForMaritalStatusAsync(string expected) =>
        _ui.WaitAsync(_locators.MaritalStatus, expected);

    public Task EnterMaritalStatusAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.MaritalStatus, value);

    public Task PressMaritalStatusAsync(string key) =>
        _ui.PressAsync(_locators.MaritalStatus, key);

    public Task EnterMedicalAsync(string value) =>
        _ui.FillAsync(_locators.Medical, value);

    public Task PressMedicalAsync(string key) =>
        _ui.PressAsync(_locators.Medical, key);

    public Task EnterMeritRatingAsync(string value) =>
        _ui.FillAsync(_locators.MeritRating, value);

    public Task EnterMilesFromFireDepartmentAsync(string value) =>
        _ui.FillAsync(_locators.MilesFromFireDepartment, value);

    public Task PressMilesFromFireDepartmentAsync(string key) =>
        _ui.PressAsync(_locators.MilesFromFireDepartment, key);

    public Task WaitForMiscItemsBlanketCoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.MiscItemsBlanketCoverage, expected);


    public Task EnterMeritRatingSelectionAsync(string value) =>
       _ui.FillAsync(_locators.MeritRatingSelection, value);


    public Task EnterMiscItemsBlanketCoverageAsync(string value) =>
        _ui.FillAsync(_locators.MiscItemsBlanketCoverage, value);

    public Task PressMiscItemsBlanketCoverageAsync(string key) =>
        _ui.PressAsync(_locators.MiscItemsBlanketCoverage, key);

    public Task EnterModelAsync(string value) =>
        _ui.FillAsync(_locators.Model, value);

    public Task PressModelAsync(string key) =>
        _ui.PressAsync(_locators.Model, key);

    public Task EnterModificationFactorAsync(string value) =>
        _ui.FillAsync(_locators.ModificationFactor, value);

    public Task<string> CaptureModificationFactorAsync(string property = "") =>
        _ui.CaptureAsync(_locators.ModificationFactor, property);

    public Task PressModificationFactorAsync(string key) =>
        _ui.PressAsync(_locators.ModificationFactor, key);

    public Task ClickMotorTruckCargoUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.MotorTruckCargoUWQuestions);

    public Task WaitForMotorcycleLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task PressMotorcycleLiabilityAsync(string key) =>
        _ui.PressAsync(_locators.PageTitle, key);

    public Task ClickMotorcycleLiabilityAsync() =>
        _locators.MotorCycleLiability.EvaluateAsync("el => el.click()");

    public Task EnterN10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarmsAsync(string value) =>
        _ui.FillAsync(_locators.N10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarms, value);

    public Task PressN10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarmsAsync(string key) =>
        _ui.PressAsync(_locators.N10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarms, key);

    public Task EnterN10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheftAsync(string value) =>
        _ui.FillAsync(_locators.N10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheft, value);

    public Task PressN10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheftAsync(string key) =>
        _ui.PressAsync(_locators.N10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheft, key);

    public Task EnterN11AreDriversMVRsAndTripLogsMaintainedAsync(string value) =>
        _ui.FillAsync(_locators.N11AreDriversMVRsAndTripLogsMaintained, value);

    public Task PressN11AreDriversMVRsAndTripLogsMaintainedAsync(string key) =>
        _ui.PressAsync(_locators.N11AreDriversMVRsAndTripLogsMaintained, key);

    public Task EnterN11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransitAsync(string value) =>
        _ui.FillAsync(_locators.N11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransit, value);

    public Task PressN11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransitAsync(string key) =>
        _ui.PressAsync(_locators.N11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransit, key);

    public Task EnterN12AreDriversMVRsReviewedOnARegularBasisAndMaintainedAsync(string value) =>
        _ui.FillAsync(_locators.N12AreDriversMVRsReviewedOnARegularBasisAndMaintained, value);

    public Task PressN12AreDriversMVRsReviewedOnARegularBasisAndMaintainedAsync(string key) =>
        _ui.PressAsync(_locators.N12AreDriversMVRsReviewedOnARegularBasisAndMaintained, key);

    public Task EnterN12HowOftenAreTheseLogsReviewedOrUpdatedAsync(string value) =>
        _ui.FillAsync(_locators.N12HowOftenAreTheseLogsReviewedOrUpdated, value);

    public Task PressN12HowOftenAreTheseLogsReviewedOrUpdatedAsync(string key) =>
        _ui.PressAsync(_locators.N12HowOftenAreTheseLogsReviewedOrUpdated, key);

    public Task EnterN13LiveAnimalInTransitCoverageAsync(string value) =>
        _ui.FillAsync(_locators.N13LiveAnimalInTransitCoverage, value);

    public Task PressN13LiveAnimalInTransitCoverageAsync(string key) =>
        _ui.PressAsync(_locators.N13LiveAnimalInTransitCoverage, key);

    public Task EnterN13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicleAsync(string value) =>
        _ui.FillAsync(_locators.N13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicle, value);

    public Task PressN13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicleAsync(string key) =>
        _ui.PressAsync(_locators.N13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicle, key);

    public Task EnterN14LegalLiabilityCoverageAsync(string value) =>
        _ui.FillAsync(_locators.N14LegalLiabilityCoverage, value);

    public Task PressN14LegalLiabilityCoverageAsync(string key) =>
        _ui.PressAsync(_locators.N14LegalLiabilityCoverage, key);

    public Task EnterN14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorageAsync(string value) =>
        _ui.FillAsync(_locators.N14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorage, value);

    public Task PressN14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorageAsync(string key) =>
        _ui.PressAsync(_locators.N14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorage, key);

    public Task EnterN15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheftAsync(string value) =>
        _ui.FillAsync(_locators.N15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheft, value);

    public Task PressN15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheftAsync(string key) =>
        _ui.PressAsync(_locators.N15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheft, key);

    public Task EnterN16DoesTheRiskUseReleaseFormsAsync(string value) =>
        _ui.FillAsync(_locators.N16DoesTheRiskUseReleaseForms, value);

    public Task PressN16DoesTheRiskUseReleaseFormsAsync(string key) =>
        _ui.PressAsync(_locators.N16DoesTheRiskUseReleaseForms, key);

    public Task EnterN1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipmentAsync(string value) =>
        _ui.FillAsync(_locators.N1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipment, value);

    public Task PressN1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipmentAsync(string key) =>
        _ui.PressAsync(_locators.N1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipment, key);

    public Task EnterN2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremisesAsync(string value) =>
        _ui.FillAsync(_locators.N2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremises, value);

    public Task PressN2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremisesAsync(string key) =>
        _ui.PressAsync(_locators.N2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremises, key);

    public Task EnterN2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommoditiesAsync(string value) =>
        _ui.FillAsync(_locators.N2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommodities, value);

    public Task PressN2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommoditiesAsync(string key) =>
        _ui.PressAsync(_locators.N2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommodities, key);

    public Task EnterN2ndClassCategoryAsync(string value) =>
        _ui.FillAsync(_locators.N2ndClassCategory, value);

    public async Task<bool> IsN2ndClassCategoryVisibleAsync() =>
        await _locators.N2ndClassCategory.First.IsVisibleAsync();

    public Task PressN2ndClassCategoryAsync(string key) =>
        _ui.PressAsync(_locators.N2ndClassCategory, key);

    public Task EnterN2ndClassCodeAsync(string value) =>
        _ui.FillAsync(_locators.N2ndClassCode, value);

    public async Task<bool> IsN2ndClassCodeVisibleAsync() =>
        await _locators.N2ndClassCode.First.IsVisibleAsync();

    public Task PressN2ndClassCodeAsync(string key) =>
        _ui.PressAsync(_locators.N2ndClassCode, key);

    public Task EnterN3DoesTheApplicantHaulForOthersAsync(string value) =>
        _ui.FillAsync(_locators.N3DoesTheApplicantHaulForOthers, value);

    public Task PressN3DoesTheApplicantHaulForOthersAsync(string key) =>
        _ui.PressAsync(_locators.N3DoesTheApplicantHaulForOthers, key);

    public Task EnterN3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepairAsync(string value) =>
        _ui.FillAsync(_locators.N3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepair, value);

    public Task PressN3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepairAsync(string key) =>
        _ui.PressAsync(_locators.N3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepair, key);

    public Task EnterN4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdatedAsync(string value) =>
        _ui.FillAsync(_locators.N4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdated, value);

    public Task PressN4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdatedAsync(string key) =>
        _ui.PressAsync(_locators.N4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdated, key);

    public Task EnterN4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailerAsync(string value) =>
        _ui.FillAsync(_locators.N4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailer, value);

    public Task PressN4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailerAsync(string key) =>
        _ui.PressAsync(_locators.N4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailer, key);

    public Task EnterN5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintainedAsync(string value) =>
        _ui.FillAsync(_locators.N5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintained, value);

    public Task PressN5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintainedAsync(string key) =>
        _ui.PressAsync(_locators.N5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintained, key);

    public Task WaitForN5DeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.N5Deductible, expected);

    public Task EnterN5DeductibleAsync(string value) =>
        _ui.FillAsync(_locators.N5Deductible, value);

    public Task PressN5DeductibleAsync(string key) =>
        _ui.PressAsync(_locators.N5Deductible, key);

    public Task EnterN5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttachedAsync(string value) =>
        _ui.FillAsync(_locators.N5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttached, value);

    public Task PressN5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttachedAsync(string key) =>
        _ui.PressAsync(_locators.N5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttached, key);

    public Task EnterN6AreAllStorageAreasLockedAtAllTimesWhenUnoccupiedAsync(string value) =>
        _ui.FillAsync(_locators.N6AreAllStorageAreasLockedAtAllTimesWhenUnoccupied, value);

    public Task PressN6AreAllStorageAreasLockedAtAllTimesWhenUnoccupiedAsync(string key) =>
        _ui.PressAsync(_locators.N6AreAllStorageAreasLockedAtAllTimesWhenUnoccupied, key);

    public Task EnterN6DoesTheApplicantPullDoubleOrTripleTrailersAsync(string value) =>
        _ui.FillAsync(_locators.N6DoesTheApplicantPullDoubleOrTripleTrailers, value);

    public Task PressN6DoesTheApplicantPullDoubleOrTripleTrailersAsync(string key) =>
        _ui.PressAsync(_locators.N6DoesTheApplicantPullDoubleOrTripleTrailers, key);

    public Task EnterN7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremisesAsync(string value) =>
        _ui.FillAsync(_locators.N7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremises, value);

    public Task PressN7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremisesAsync(string key) =>
        _ui.PressAsync(_locators.N7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremises, key);

    public Task EnterN7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattendedAsync(string value) =>
        _ui.FillAsync(_locators.N7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattended, value);

    public Task PressN7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattendedAsync(string key) =>
        _ui.PressAsync(_locators.N7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattended, key);

    public Task EnterN8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperateAsync(string value) =>
        _ui.FillAsync(_locators.N8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperate, value);

    public Task PressN8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperateAsync(string key) =>
        _ui.PressAsync(_locators.N8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperate, key);

    public Task EnterN9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommoditiesAsync(string value) =>
        _ui.FillAsync(_locators.N9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommodities, value);

    public Task PressN9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommoditiesAsync(string key) =>
        _ui.PressAsync(_locators.N9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommodities, key);

    public Task EnterN9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystemAsync(string value) =>
        _ui.FillAsync(_locators.N9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystem, value);

    public Task PressN9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystemAsync(string key) =>
        _ui.PressAsync(_locators.N9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystem, key);

    public Task WaitForNAICSCodeSearchValueAsync(string expected) =>
        _ui.WaitAsync(_locators.NAICSCodeSearchValue, expected);

    public Task EnterNAICSCodeSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.NAICSCodeSearchValue, value);

    public Task PressNAICSCodeSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.NAICSCodeSearchValue, key);

    public Task ClickNAICSCodeSearchValueAsync() =>
        _ui.ClickAsync(_locators.NAICSCodeSearchValue);

    public Task EnterNameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServicesAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServices, value);

    public Task PressNameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServicesAsync(string key) =>
        _ui.PressAsync(_locators.NameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServices, key);

    public Task EnterNamesAsync(string value) =>
        _ui.FillAsync(_locators.Names, value);

    public Task PressNamesAsync(string key) =>
        _ui.PressAsync(_locators.Names, key);

    public Task WaitForNoKnownLossesAsync(string expected) =>
        _ui.WaitAsync(_locators.NoKnownLosses, expected);

    public Task SetNoKnownLossesAsync(string value) =>
        _ui.SmartSetAsync(_locators.NoKnownLosses, value);

    public Task PressNoKnownLossesAsync(string key) =>
        _ui.PressAsync(_locators.NoKnownLosses, key);

    public Task ClickNoKnownLossesAsync() =>
        _ui.ClickAsync(_locators.NoKnownLosses);

    public Task EnterNonOwnedAutoAsync(string value) =>
        _ui.FillAsync(_locators.NonOwnedAuto, value);

    public Task PressNonOwnedAutoAsync(string key) =>
        _ui.PressAsync(_locators.NonOwnedAuto, key);

    public Task ClickNotepadAsync() =>
        _ui.ClickAsync(_locators.NotepadLink);

    public Task WaitForNotepadHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.Notepad, expected);

    public Task EnterNumberOfEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfEmployees, value);

    public Task PressNumberOfEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfEmployees, key);

    public Task EnterNumberOfFullTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfFullTimeEmployees, value);

    public Task PressNumberOfFullTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfFullTimeEmployees, key);

    public Task EnterNumberOfPartTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfPartTimeEmployees, value);

    public Task PressNumberOfPartTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfPartTimeEmployees, key);

    public Task WaitForNumberOfVehiclesAsync(string expected) =>
        _ui.WaitAsync(_locators.NumberOfVehicles, expected);

    public Task EnterNumberOfVehiclesAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.NumberOfVehicles, value);

    public Task PressNumberOfVehiclesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfVehicles, key);

    public Task ClickOCPAsync() =>
        _ui.ClickAsync(_locators.OCP);

    public async Task WaitForOKAsync(string expected)
    {
        // Mirrors ClickOKAsync: the OK button sometimes renders inside a nested Duck Creek popup
        // window iframe (iframe[id^='dctPopup_dctPopupWindow']) rather than the top document.
        // Probing the popup frame first avoids burning the full element-ready timeout on the
        // wrong (top-document) locator when the popup variant is what's actually shown.
        if (expected == "Exists")
        {
            var popupOk = _locators.OptionAPopupOK;
            var deadline = Environment.TickCount64 + 8000;
            while (Environment.TickCount64 < deadline)
            {
                try
                {
                    await popupOk.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 1000 });
                    return;
                }
                catch (Exception ex) when (ex is PlaywrightException or TimeoutException) { }
            }
        }

        await _ui.WaitAsync(_locators.OK, expected);
    }

    public Task WaitForOKClassCodeAsync(string expected) =>
        _ui.WaitAsync(_locators.OKClassCode, expected);

    public Task VerifyOKClassCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.OKClassCode, expected, property);

    public Task ClickOKClassCodeAsync() =>
        _ui.ClickAsync(_locators.OKClassCode);

    public Task ClickOKDetailsAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task PressOKFirstAsync(string key) =>
        _ui.PressAsync(_locators.OK, key);

    public Task ClickOKFirstAsync() =>
        _ui.ClickAsync(_locators.OKFirst);

    public Task WaitForOKSecondAsync(string expected) =>
        _ui.WaitAsync(_locators.OKFirst, expected);

    public Task EnterOTCCausesOfLossAsync(string value) =>
        _ui.FillAsync(_locators.OTCCausesOfLoss, value);

    public async Task<bool> IsOTCCausesOfLossVisibleAsync() =>
        await _locators.OTCCausesOfLoss.First.IsVisibleAsync();

    public Task PressOTCCausesOfLossAsync(string key) =>
        _ui.PressAsync(_locators.OTCCausesOfLoss, key);

    public Task EnterStateDetailsHiredAutoPDWithoutDriverOTCDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.StateDetailsHiredAutoPDWithoutDriverOTCDeductible, value);

    public Task PressStateDetailsHiredAutoPDWithoutDriverOTCDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.StateDetailsHiredAutoPDWithoutDriverOTCDeductible, key);

    public Task EnterStateDetailsHiredAutoPhysicalDamageWithDriverOTCDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.StateDetailsHiredAutoPhysicalDamageWithDriverOTCDeductible, value);

    public Task PressStateDetailsHiredAutoPhysicalDamageWithDriverOTCDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.StateDetailsHiredAutoPhysicalDamageWithDriverOTCDeductible, key);

    public Task WaitForStateDetailsDriveOtherCarOTCDeductibleAsync(string expected) =>
        _ui.WaitAsync(_locators.StateDetailsDriveOtherCarOTCDeductible, expected);

    public Task ClickStateDetailsHiredAutoPDWithoutDriverIfAnyFieldAsync() =>
        _ui.ClickAsync(_locators.StateDetailsHiredAutoPDWithoutDriverIfAnyField);

    public Task ClickStateDetailsHiredAutoPhysicalDamageWithDriverIfAnyFieldAsync() =>
        ComponentAwareControlActions.DomClickAsync(_locators.StateDetailsHiredAutoPhysicalDamageWithDriverIfAnyField.First);

    public Task WaitForOccupancyTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.OccupancyType, expected);

    public Task EnterOccupancyTypeAsync(string value) =>
        _ui.FillAsync(_locators.OccupancyType, value);

    public Task EnterOccupancyTypeOverrideAsync(string value) =>
       _ui.FillAsync(_locators.OccupancyTypeOverride, value);


    public async Task<bool> IsOccupancyTypeOverrideAsync() =>
        await _locators.OccupancyTypeOverride.CountAsync() > 0;


    public async Task<bool> IsOccupancyTypeAsync() =>
  await _locators.OccupancyType.CountAsync() > 0;



    public async Task<bool> IsRatingGroupAsync() =>
       await _locators.RatingGroupsDeductible.CountAsync() > 0;

    public async Task<bool> IsRatingGroupDeductableAsync() =>
        await _locators.RatingGroupsDeductibleIncreasedTheft.CountAsync() > 0;

    public async Task<bool> IsRatingGroupDeductableblackhail() =>
        await _locators.RatingGroupsDeductibleWindHail.CountAsync() > 0;






    public async Task<bool> IsCauseOfLossAsync() =>
          await _locators.CauseOfLoss.CountAsync() > 0;






    public Task PressOccupancyTypeAsync(string key) =>
        _ui.PressAsync(_locators.OccupancyType, key);

    public Task WaitForOccupiedAsync(string expected) =>
        _ui.WaitAsync(_locators.Occupied, expected);

    public Task EnterOccupiedAsync(string value) =>
        _ui.FillAsync(_locators.Occupied, value);

    public async Task<bool> IsOccupiedAsync() =>
        await _locators.Occupied.CountAsync() > 0;
    public Task SetOccupiedAsync(string value) =>
        _ui.SmartSetAsync(_locators.Occupied, value);

    public Task PressOccupiedAsync(string key) =>
        _ui.PressAsync(_locators.Occupied, key);

    public Task EnterOccurenceLimitAsync(string value) =>
        _ui.FillAsync(_locators.OccurenceLimit, value);

    public async Task<bool> IsOccurenceLimitVisibleAsync() =>
        await IsAnyVisibleAsync(_locators.OccurenceLimit);

    public Task PressOccurenceLimitAsync(string key) =>
        _ui.PressAsync(_locators.OccurenceLimit, key);

    public Task WaitForOfEmployeesAsync(string expected) =>
        _ui.WaitAsync(_locators.OfEmployees, expected);

    public Task EnterOfEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfEmployees, value);

    public Task PressOfEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfEmployees, key);

    public Task EnterOfFullTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfFullTimeEmployees, value);

    public async Task<bool> IsOfFullTimeEmployeesAvailableAsync() =>
        await _locators.OfFullTimeEmployees.CountAsync() > 0;

    public Task PressOfFullTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfFullTimeEmployees, key);

    public Task EnterOfPartTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfPartTimeEmployees, value);

    public async Task<bool> IsOfPartTimeEmployeesAvailableAsync() =>
        await _locators.OfPartTimeEmployees.CountAsync() > 0;

    public Task PressOfPartTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfPartTimeEmployees, key);

    public Task EnterOfPartnersAsync(string value) =>
        _ui.FillAsync(_locators.OfPartners, value);

    public Task PressOfPartnersAsync(string key) =>
        _ui.PressAsync(_locators.OfPartners, key);

    public Task EnterOfSeasonalTemporaryEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.OfSeasonalTemporaryEmployees, value);

    public async Task<bool> IsOfSeasonalTemporaryEmployeesAvailableAsync() =>
        await _locators.OfSeasonalTemporaryEmployees.CountAsync() > 0;

    public Task PressOfSeasonalTemporaryEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.OfSeasonalTemporaryEmployees, key);

    public Task EnterOfficersAsync(string value) =>
        _ui.FillAsync(_locators.Officers, value);

    public Task PressOfficersAsync(string key) =>
        _ui.PressAsync(_locators.Officers, key);

    public Task EnterOfficersPositionHeldAsync(string value) =>
        _ui.FillAsync(_locators.OfficersPositionHeld, value);

    public Task PressOfficersPositionHeldAsync(string key) =>
        _ui.PressAsync(_locators.OfficersPositionHeld, key);

    public Task ClickOptionACheckBoxAsync() =>
        _ui.ClickAsync(_locators.OptionACheckBox);

    public Task WaitForOptionAScheduleButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.OptionAScheduleButton, expected);

    public Task ClickOptionAScheduleButtonAsync() =>
        _ui.ClickAsync(_locators.OptionAScheduleButton);

    public Task VerifyOrderAuditAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.OrderAudit, expected, property);

    public Task EnterOrderAuditAsync(string value) =>
        _ui.FillAsync(_locators.OrderAudit, value);

    public Task PressOrderAuditAsync(string key) =>
        _ui.PressAsync(_locators.OrderAudit, key);

    public Task EnterOriginalCostNewAsync(string value) =>
        _ui.FillAsync(_locators.RiskVehicleInputValueEstimate, value);

    public async Task<bool> IsOriginalCostNewVisibleAsync() =>
        await _locators.RiskVehicleInputValueEstimate.First.IsVisibleAsync();

    public Task PressOriginalCostNewAsync(string key) =>
        _ui.PressAsync(_locators.RiskVehicleInputValueEstimate, key);

    public Task EnterVehicleValueEstimateAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.RiskVehicleInputValueEstimate, value);

    public async Task<bool> IsVehicleValueEstimateVisibleAsync() =>
        await _locators.RiskVehicleInputValueEstimate.First.IsVisibleAsync();

    public Task EnterOthersAsync(string value) =>
        _ui.FillAsync(_locators.Others, value);

    public Task PressOthersAsync(string key) =>
        _ui.PressAsync(_locators.Others, key);

    public Task EnterPartnersAsync(string value) =>
        _ui.FillAsync(_locators.Partners, value);

    public Task PressPartnersAsync(string key) =>
        _ui.PressAsync(_locators.Partners, key);

    public Task WaitForPayPlanAsync(string expected) =>
        _ui.WaitAsync(_locators.PayPlan, expected);

    public Task EnterPayPlanAsync(string value) =>
        _ui.FillAsync(_locators.PayPlan, value);

    public Task PressPayPlanAsync(string key) =>
        _ui.PressAsync(_locators.PayPlan, key);

    public Task VerifyPendingRateChangeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PendingRateChange, expected, property);

    public Task WaitForPerVehicleLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.PerVehicleLimit, expected);

    public Task EnterPerVehicleLimitAsync(string value) =>
        _ui.FillAsync(_locators.PerVehicleLimit, value);

    public Task PressPerVehicleLimitAsync(string key) =>
        _ui.PressAsync(_locators.PerVehicleLimit, key);


    public Task PressAlcoholOrFreedrugspaceAsync(string key) =>
      _ui.PressAsync(_locators.AlcoholOrDrugFreespce, key);

    public Task EnterPersAdvInjAsync(string value) =>
        _ui.FillAsync(_locators.PersAdvInj, value);

    public Task PressPersAdvInjAsync(string key) =>
        _ui.PressAsync(_locators.PersAdvInj, key);

    public Task WaitForPersonalPortableComputersAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalPortableComputers, expected);

    public Task EnterPersonalPortableComputersAsync(string value) =>
        _ui.FillAsync(_locators.PersonalPortableComputers, value);

    public Task PressPersonalPortableComputersAsync(string key) =>
        _ui.PressAsync(_locators.PersonalPortableComputers, key);

    public Task WaitForPersonalPropertyLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalPropertyLimit, expected);

    public Task EnterPersonalPropertyLimitAsync(string value) =>
        _ui.FillAsync(_locators.PersonalPropertyLimit, value);

    public Task PressPersonalPropertyLimitAsync(string key) =>
        _ui.PressAsync(_locators.PersonalPropertyLimit, key);

    public Task WaitForPersonalPropertyRatingGroupAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalPropertyRatingGroupID, expected);

    public Task EnterPersonalPropertyRatingGroupAsync(string value) =>
        _ui.FillAsync(_locators.PersonalPropertyRatingGroupID, value);

    public Task PressPersonalPropertyRatingGroupAsync(string key) =>
        _ui.PressAsync(_locators.PersonalPropertyRatingGroupID, key);





    public Task<string> CaptureRatingGroupsDeductibleAsync(string property = "") =>

   _ui.CaptureAsync(_locators.RatingGroupsDeductibleIncreasedTheft, property);



    public Task<string> CaptureDeductableGroupAsync(string property = "") =>

   _ui.CaptureAsync(_locators.RatingGroupsDeductible, property);


    public Task<string> CapturePersonalPropertyRatingGroupAsync(string property = "") =>

    _ui.CaptureAsync(_locators.RiskInputRatingGroupID, property);

    public async Task<bool> IsPersonalPropertyRatingGroupVisibleAsync() =>
        await _locators.RiskInputRatingGroupID.First.IsVisibleAsync();
    public Task EnterPersonalPropertyGroupAsync(string value) =>
       _ui.FillAsync(_locators.RiskInputRatingGroupID, value);


    public Task<string> CapturePropertyOfOthersRatingGroupAsync(string property = "") =>

   _ui.CaptureAsync(_locators.PersonalPropertyRatingGroupID, property);

    public async Task<bool> IsPersonalPropertyRatingVisibleAsync() =>
        await _locators.RiskInputRatingGroupID.First.IsVisibleAsync();

    public async Task<bool> IsPersonalPropertyVisibleAsync() =>
        await _locators.PersonalPropertyLimit.First.IsVisibleAsync();


    public Task WaitForPierOrWharfAsync(string expected) =>
        _ui.WaitAsync(_locators.PierOrWharf, expected);

    public Task EnterPierOrWharfAsync(string value) =>
        _ui.FillAsync(_locators.PierOrWharf, value);

    public async Task<bool> IsPierOrWharfAsync() =>
        await _locators.PierOrWharf.CountAsync() > 0;

    public Task SetPierOrWharfAsync(string value) =>
        _ui.SmartSetAsync(_locators.PierOrWharf, value);

    public Task PressPierOrWharfAsync(string key) =>
        _ui.PressAsync(_locators.PierOrWharf, key);

    public Task WaitForPierOrWharfCOLOptionsAsync(string expected) =>
        _ui.WaitAsync(_locators.PierOrWharfCOLOptions, expected);

    public Task EnterPierOrWharfCOLOptionsAsync(string value) =>
        _ui.FillAsync(_locators.PierOrWharfCOLOptions, value);

    public async Task<bool> IsPierOrWharfCOLOptionsAsync() =>
        await _locators.PierOrWharfCOLOptions.CountAsync() > 0;
    public Task SetPierOrWharfCOLOptionsAsync(string value) =>
        _ui.SmartSetAsync(_locators.PierOrWharfCOLOptions, value);

    public Task PressPierOrWharfCOLOptionsAsync(string key) =>
        _ui.PressAsync(_locators.PierOrWharfCOLOptions, key);

    public Task WaitForPierOrWharfCauseOfLossAsync(string expected) =>
        _ui.WaitAsync(_locators.PierOrWharfCauseOfLoss, expected);

    public Task EnterPierOrWharfCauseOfLossAsync(string value) =>
        _ui.FillAsync(_locators.PierOrWharfCauseOfLoss, value);

    public async Task<bool> IsPierOrWharfCauseOfLossAsync() =>
        await _locators.PierOrWharfCauseOfLoss.CountAsync() > 0;
    public Task SetPierOrWharfCauseOfLossAsync(string value) =>
        _ui.SmartSetAsync(_locators.PierOrWharfCauseOfLoss, value);

    public Task PressPierOrWharfCauseOfLossAsync(string key) =>
        _ui.PressAsync(_locators.PierOrWharfCauseOfLoss, key);

    public Task WaitForPierOrWharfConstructionAsync(string expected) =>
        _ui.WaitAsync(_locators.PierOrWharfConstruction, expected);

    public Task EnterPierOrWharfConstructionAsync(string value) =>
        _ui.FillAsync(_locators.PierOrWharfConstruction, value);

    public async Task<bool> IsPierOrWharfConstructionAsync() =>
        await _locators.PierOrWharfConstruction.CountAsync() > 0;
    public Task SetPierOrWharfConstructionAsync(string value) =>
        _ui.SmartSetAsync(_locators.PierOrWharfConstruction, value);

    public Task PressPierOrWharfConstructionAsync(string key) =>
        _ui.PressAsync(_locators.PierOrWharfConstruction, key);

    public Task EnterPleaseProvideWebsiteAddressEsAsync(string value) =>
        _ui.FillAsync(_locators.PleaseProvideWebsiteAddressEs, value);

    public Task ClickPolicyCovgerageAsync() =>
        _ui.ClickAsync(_locators.PolicyCovgerage);

    public Task WaitForPolicyCovgGLPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgerage, expected);

    public Task ClickIMNavigationLinksPolicyCovgAsync() =>
        _ui.ClickAsync(_locators.PolicyCovgerage);

    public Task WaitForPolicyCovgMainPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovg, expected);

    public Task WaitForPolicyCovgAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovg, expected);

    public Task WaitForPolicyCovgerageAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgerage, expected);

    public Task EnterPolicyHolderNameAsync(string value) =>
        _ui.FillAsync(_locators.PolicyHolderName, value);

    public Task PressPolicyHolderNameAsync(string key) =>
        _ui.PressAsync(_locators.PolicyHolderName, key);

    public Task WaitForNamedInsuredInformationHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.NamedInsuredInformationHeading, expected);

    public Task ClickPolicyInfoAsync() =>
        _ui.ClickAsync(_locators.PolicyInfo);

    public Task WaitForPolicyInfoAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyInfo, expected);

    public Task WaitForPolicyInfoHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.PageTitle, expected);

    public Task EnterCommercialAutoPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.CommercialAutoPolicyNumber, value);

    public Task<string> CaptureCommercialAutoPolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CommercialAutoPolicyNumber, property);

    public Task PressCommercialAutoPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.CommercialAutoPolicyNumber, key);

    public Task EnterBusinessownersPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.BusinessownersPolicyNumber, value);

    public Task<string> CaptureBusinessownersPolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.BusinessownersPolicyNumber, property);

    public Task EnterCPPLiabPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.CPPLiabilityPolicyNumber, value);

    public Task PressCPPLiabPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.CPPLiabilityPolicyNumber, key);

    public Task<string> CaptureCPPLiabPolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.CPPLiabilityPolicyNumber, property);

    public Task PressBusinessownersPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.BusinessownersPolicyNumber, key);

    public Task EnterGeneralLiabilityPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.GeneralLiabilityPolicyNumber, value);

    public Task<string> CaptureGeneralLiabilityPolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.GeneralLiabilityPolicyNumber, property);

    public Task EnterSFPiabilityPolicyNumberAsync(string value) =>
        _ui.FillAsync(_locators.GeneralLiabilityPolicyNumber, value);

    public Task PressGeneralLiabilityPolicyNumberAsync(string key) =>
        _ui.PressAsync(_locators.GeneralLiabilityPolicyNumber, key);

    public Task EnterPolicyTypeAsync(string value) =>
        _ui.FillAsync(_locators.PolicyType, value);

    public Task<string> CapturePolicyTypeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PolicyType, property);

    public Task PressPolicyTypeAsync(string key) =>
        _ui.PressAsync(_locators.PolicyType, key);

    public Task EnterPowerSuppressorVoltageRegulatorAsync(string value) =>
        _ui.FillAsync(_locators.PowerSuppressorVoltageRegulator, value);

    public Task PressPowerSuppressorVoltageRegulatorAsync(string key) =>
        _ui.PressAsync(_locators.PowerSuppressorVoltageRegulator, key);

    public Task EnterPremOpDedAsync(string value) =>
        _ui.FillAsync(_locators.PremOpDed, value);

    public Task PressPremOpDedAsync(string key) =>
        _ui.PressAsync(_locators.PremOpDed, key);

    public Task EnterPremOpPDDedAsync(string value) =>
        _ui.FillAsync(_locators.PremOpPDDed, value);

    public Task WaitForPremisesTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.PremisesType, expected);

    public Task EnterPremisesTypeAsync(string value) =>
        _ui.FillAsync(_locators.PremisesType, value);

    public Task EnterPremisesCredit(string value) =>
        _ui.FillAsync(_locators.PremisesCreditOrDebit, value);


    public Task EnterPremisesComments(string value) =>
        _ui.FillAsync(_locators.PremisesComments, value);

    public Task EnterClassificationPecularities(string value) =>
        _ui.FillAsync(_locators.ClassificationPecularities, value);

    public Task EnterClassificationPecularitiesComments(string value) =>
        _ui.FillAsync(_locators.ClassificationPecularitiesComments, value);

    public Task EnterMedicalFacilities(string value) =>
        _ui.FillAsync(_locators.MedicalFacilities, value);

    public Task EnterMedicalFacilitiesComments(string value) =>
        _ui.FillAsync(_locators.MedicalFacilitiesComments, value);

    public Task EnterExtraordinarySafetyPrograms(string value) =>
        _ui.FillAsync(_locators.ExtraordinarySafetyPrograms, value);

    public Task EnterExtraordinarySafetyProgramsComments(string value) =>
        _ui.FillAsync(_locators.ExtraordinarySafetyProgramsComments, value);




    public Task EnterSafetyDevices(string value) =>
        _ui.FillAsync(_locators.safetyDevices, value);



    public Task EnterEmployerSafetyDevices(string value) =>
        _ui.FillAsync(_locators.EmployersafetyPolicy, value);



    public Task EnterEmployerSafetyDevicesComments(string value) =>
        _ui.FillAsync(_locators.EmployersafetyPolicyComments, value);



    public Task EnterSafetyDevicesComments(string value) =>
        _ui.FillAsync(_locators.SafetyDevicesComments, value);

    public Task EnterEmployeesSelection(string value) =>
        _ui.FillAsync(_locators.employeesSelection, value);

    public Task EnterEmployeeselectionComments(string value) =>
        _ui.FillAsync(_locators.EmployeeselectionComments, value);

    public Task EnterManagementSafetyOrganizationStateInput(string value) =>
        _ui.FillAsync(_locators.ManagementSafetyOrganizationStateInput, value);

    public Task EnterManagementSafetyOrganizationStateInputComments(string value) =>
        _ui.FillAsync(_locators.ManagementSafetyOrganizationStateInputComments, value);

    public Task EnterManagementCooperationWithInsuranceCarrierStateInput(string value) =>
        _ui.FillAsync(_locators.ManagementCooperationWithInsuranceCarrierStateInput, value);

    public Task EnterManagementCooperationWithInsuranceCarrierStateInputComments(string value) =>
        _ui.FillAsync(_locators.ManagementCooperationWithInsuranceCarrierStateInputComments, value);

    public Task EnterPolicyExpensesStateInput(string value) =>
        _ui.FillAsync(_locators.PolicyExpensesStateInput, value);

    public Task EnterPolicyExpensesStateInputComments(string value) =>
        _ui.FillAsync(_locators.PolicyExpensesStateInputComments, value);

    public Task EnterOtherFactorsStateInput(string value) =>
        _ui.FillAsync(_locators.OtherFactorsStateInput, value);

    public Task EnterOtherFactorsStateInputComments(string value) =>
        _ui.FillAsync(_locators.OtherFactorsStateInputComments, value);

    public Task<bool> IsPremisesTypeVisibleAsync() => _ui.ExistsAsync(_locators.PremisesType);

    public Task PressPremisesTypeAsync(string key) =>
        _ui.PressAsync(_locators.PremisesType, key);

    public Task WaitForPremiumVisibleAsync(int timeoutMs = 30000) =>
        _ui.WaitReadyBestEffortAsync(_locators.Premium, timeoutMs);

    public Task VerifyPremiumAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Premium, expected, property);

    public Task ClickPricingAsync() =>
        _ui.ClickAsync(_locators.PricingLink);


    public Task ClickWorksheetAsync() =>
        _ui.ClickAsync(_locators.Worksheet);

    public Task WaitForPricingDetailAsync(string expected) =>
        _ui.WaitAsync(_locators.PricingDetail, expected);

    public Task ClickPricingDetailAsync() =>
        _ui.ClickAsync(_locators.PricingDetail);

    public Task ClickPricingDetailOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForPricingAsync(string expected) =>
        _ui.WaitAsync(_locators.PricingLink, expected);

    public Task WaitForPricingHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.PricingHeading, expected);

    public Task ClickPrimaryLiabilityIfAnyAsync() =>
        _ui.ClickAsync(_locators.PrimaryLiabilityIfAny);

    public Task WaitForPrimaryLocationStateAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryLocationState, expected);

    public Task VerifyPrimaryLocationStateAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PrimaryLocationState, expected, property);

    public Task WaitForPrimaryRatingStateAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryRatingState, expected);

    public Task EnterPrimaryRatingStateAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.PrimaryRatingState, value);

    public Task<string> CapturePrimaryRatingStateAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PrimaryRatingState, property);

    public Task PressprimaryRatingStateAsync(string key) =>
        _ui.PressAsync(_locators.PrimaryRatingState, key);

    public Task SelectKansasStateAsync(string value) =>
        _ui.SelectAsync(_locators.PrimaryRatingStateKansas, value);

    public Task PressPrimaryRatingStateAsync(string key) =>
        _ui.PressAsync(_locators.PrimaryRatingState, key);

    public Task ClickPrimaryRatingStateAsync() =>
        _ui.ClickAsync(_locators.PrimaryRatingStateDropDown);

    public Task WaitForPrimaryRatingStateKansasAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryRatingStateKansas, expected);

    public Task ClickPrimaryRatingStateKansasAsync() =>
        _ui.ClickAsync(_locators.PrimaryRatingStateKansas);

    public Task VerifyPriorAmericanNationalPolicyAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PriorAmericanNationalPolicy, expected, property);

    public Task EnterProdBIDedAsync(string value) =>
        _ui.FillAsync(_locators.ProdBIDed, value);

    public Task PressProdBIDedAsync(string key) =>
        _ui.PressAsync(_locators.ProdBIDed, key);

    public Task EnterProdPDDedAsync(string value) =>
        _ui.FillAsync(_locators.ProdPDDed, value);

    public Task EnterProduceCarriedAsync(string value) =>
        _ui.FillAsync(_locators.ProduceCarried, value);

    public Task PressProduceCarriedAsync(string key) =>
        _ui.PressAsync(_locators.ProduceCarried, key);

    public Task EnterProductsAggLimitAsync(string value) =>
        _ui.FillAsync(_locators.ProductsAggLimit, value);

    public async Task<bool> IsProductsAggLimitVisibleAsync() =>
        await IsAnyVisibleAsync(_locators.ProductsAggLimit);

    public Task PressProductsAggLimitAsync(string key) =>
        _ui.PressAsync(_locators.ProductsAggLimit, key);

    public Task VerifyProductsCompletedOperationsAggregateLimitAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ProductsCompletedOperationsAggregateLimit, expected, property);

    public Task<string> CaptuteProductsCompletedOperationsAggregateLimitAsync(string property = "") =>
        _ui.CaptureAsync(_locators.ProductsCompletedOperationsAggregateLimit, property);

    public Task EnterProductsCompletedOperationsAggregateLimitAsync(string value) =>
        _ui.FillAsync(_locators.ProductsCompletedOperationsAggregateLimit, value);

    public Task PressProductsCompletedOperationsAggregateLimitAsync(string key) =>
        _ui.PressAsync(_locators.ProductsCompletedOperationsAggregateLimit, key);

    public Task ClickProductsCompletedOpsButtonAsync() =>
        _ui.ClickAsync(_locators.ProductsCompletedOpsButton);

    public Task ClickWineryQuestionnaireAsync() =>
        _ui.ClickAsync(_locators.WineryQuestionnaire);

    public async Task ClickWineryQuestionnaireWithRetryAsync(int maxAttempts = 3, int waitBeforeMs = 1000)
    {
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await Task.Delay(waitBeforeMs);
            if (await _ui.ExistsAsync(_locators.WineryQuestionnaire))
            {
                await ClickWineryQuestionnaireAsync();
                return;
            }
        }
        await ClickWineryQuestionnaireAsync();
    }

    public Task EnterPercentOfRetailWineSalesOtherThanRestaurantAsync(string value) =>
        _ui.FillAsync(_locators.PercentOfRetailWineSalesOtherThanRestaurant, value);

    public Task EnterPercentOfRetailWineSalesDirectToConsumerAsync(string value) =>
        _ui.FillAsync(_locators.PercentOfRetailWineSalesDirectToConsumer, value);

    public Task EnterWhatPercentOfRetailSalesIsDerivedFromOtherSalesAsync(string value) =>
        _ui.FillAsync(_locators.WhatPercentOfRetailSalesIsDerivedFromOtherSales, value);

    public Task SetDoYouHaveABanquetHallThatIsRentedToOthersAsync(string value) =>
        _ui.SmartSetAsync(_locators.DoYouHaveABanquetHallThatIsRentedToOthers, value);

    public Task SetDoYouPerformOnOrOffPremisesCateringAsync(string value) =>
        _ui.SmartSetAsync(_locators.DoYouPerformOnOrOffPremisesCatering, value);

    public Task SetGuestLodgingForPublicAsync(string value) =>
        _ui.SmartSetAsync(_locators.GuestLodgingForPublic, value);

    public Task SetLifeSafetyControlsAsync(string value) =>
        _ui.SmartSetAsync(_locators.LifeSafetyControls, value);

    public Task SetSwimmingPoolOrBeachesAsync(string value) =>
        _ui.SmartSetAsync(_locators.SwimmingPoolOrBeaches, value);

    public Task SetGuestActivitiesAsync(string value) =>
        _ui.SmartSetAsync(_locators.GuestActivities, value);

    public Task SetSpecialEventsAsync(string value) =>
        _ui.SmartSetAsync(_locators.SpecialEvents, value);

    public Task SetBottleWineForOthersAsync(string value) =>
        _ui.SmartSetAsync(_locators.BottleWineForOthers, value);

    public Task SetStoredWineForOthersAsync(string value) =>
        _ui.SmartSetAsync(_locators.StoredWineForOthers, value);

    public Task SetBeerOrAleManufacturedAsync(string value) =>
        _ui.SmartSetAsync(_locators.BeerOrAleManufactured, value);

    public Task SetHardManufacturedAsync(string value) =>
        _ui.SmartSetAsync(_locators.HardManufactured, value);

    public Task SetOwnHerbicidesPesticidesFertilizersAsync(string value) =>
        _ui.SmartSetAsync(_locators.OwnHerbicidesPesticidesFertilizers, value);

    public Task SetOthersHerbicidesPesticidesFertilizersAsync(string value) =>
        _ui.SmartSetAsync(_locators.OthersHerbicidesPesticidesFertilizers, value);

    public Task SetAircraftConductedApplicationsAsync(string value) =>
        _ui.SmartSetAsync(_locators.AircraftConductedApplications, value);

    public Task SetAlcoholBeverageInterventionAsync(string value) =>
        _ui.SmartSetAsync(_locators.AlcoholBeverageIntervention, value);

    public Task SetCitedForLiquorControlAsync(string value) =>
        _ui.SmartSetAsync(_locators.CitedForLiquorControl, value);

    public Task SetCateringBanquetAllowAlcoholAsync(string value) =>
        _ui.SmartSetAsync(_locators.CateringBanquetAllowAlcohol, value);

    public Task SetCertificateOfInsurancefForLiquorLiabilityAsync(string value) =>
        _ui.SmartSetAsync(_locators.CertificateOfInsurancefForLiquorLiability, value);

    public Task SetEmplyesAlcoholBeverageInterventionTrainingAsync(string value) =>
        _ui.SmartSetAsync(_locators.EmplyesAlcoholBeverageInterventionTraining, value);

    public Task EnterNumberOfShipmentAnnualAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfShipmentAnnual, value);

    public Task EnterAverageValueEachShipmentAsync(string value) =>
        _ui.FillAsync(_locators.AverageValueEachShipment, value);

    public Task EnterAverageDistanceShippedAsync(string value) =>
        _ui.FillAsync(_locators.AverageDistanceShipped, value);

    public Task SetTransportWineForOthersAsync(string value) =>
        _ui.SmartSetAsync(_locators.TransportWineForOthers, value);

    public Task SetSuppliersDependentToProduceWineAsync(string value) =>
        _ui.SmartSetAsync(_locators.SuppliersDependentToProduceWine, value);

    public Task WaitForPropertyAsync(string expected) =>
        _ui.WaitAsync(_locators.Property, expected);

    public Task ClickPropertyAsync() =>
        _ui.ClickAsync(_locators.Property);

    public Task ClickPropertyAwayFromYourPremisesScheduleAsync() =>
        _ui.ClickAsync(_locators.PropertyAwayFromYourPremisesSchedule);

    public Task WaitForPolicyCovgComputerSystemsPropertyInTransitAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgComputerSystemsPropertyInTransit, expected);

    public Task EnterPolicyCovgComputerSystemsPropertyInTransitAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgComputerSystemsPropertyInTransit, value);

    public Task PressPolicyCovgComputerSystemsPropertyInTransitAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgComputerSystemsPropertyInTransit, key);

    public Task WaitForPolicyCovgBaileesCutomersPropertyInTransitAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyCovgBaileesCutomersPropertyInTransit, expected);

    public Task EnterPolicyCovgBaileesCutomersPropertyInTransitAsync(string value) =>
        _ui.FillAsync(_locators.PolicyCovgBaileesCutomersPropertyInTransit, value);

    public Task PressPolicyCovgBaileesCutomersPropertyInTransitAsync(string key) =>
        _ui.PressAsync(_locators.PolicyCovgBaileesCutomersPropertyInTransit, key);

    public Task WaitForPropertyOfOthersLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.PropertyOfOthersLimit, expected);

    public Task EnterPropertyOfOthersLimitAsync(string value) =>
        _ui.FillAsync(_locators.PropertyOfOthersLimit, value);

    public Task PressPropertyOfOthersLimitAsync(string key) =>
        _ui.PressAsync(_locators.PropertyOfOthersLimit, key);

    public Task WaitForPropertyOfOthersRatingGroupAsync(string expected) =>
        _ui.WaitAsync(_locators.PropertyOfOthersRatingGroupID, expected);

    public Task EnterPropertyOfOthersRatingGroupAsync(string value) =>
        _ui.FillAsync(_locators.PropertyOfOthersRatingGroupID, value);

    public Task PressPropertyOfOthersRatingGroupAsync(string key) =>
        _ui.PressAsync(_locators.PropertyOfOthersRatingGroupID, key);

    public async Task<bool> IsPropertyOfOthersRatingGroupVisibleAsync() =>
        await _locators.PropertyOfOthersRatingGroupID.First.IsVisibleAsync();

    public Task ClickPropertyUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.PropertyUWQuestions);

    public Task WaitForProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWestAsync(string expected) =>
        _ui.WaitAsync(_locators.ProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWest, expected);

    public Task EnterProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWestAsync(string value) =>
        _ui.FillAsync(_locators.ProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWest, value);

    public Task PressProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWestAsync(string key) =>
        _ui.PressAsync(_locators.ProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWest, key);

    public Task EnterProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMediaAsync(string value) =>
        _ui.FillAsync(_locators.ProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMedia, value);

    public Task PressProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMediaAsync(string key) =>
        _ui.PressAsync(_locators.ProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMedia, key);

    public Task WaitForRatingGroupsAsync(string expected) =>
        _ui.WaitAsync(_locators.RatingGroups, expected);

    public Task ClickRatingGroupsAsync() =>
        _ui.ClickAsync(_locators.RatingGroups);

    public Task WaitForRentalOwnersLiabilityAsync(string expected) =>
        _ui.WaitAsync(_locators.RentalOwnersLiability, expected);

    public Task PressRentalOwnersLiabilityAsync(string key) =>
        _ui.PressAsync(_locators.PageTitle, key);

    public Task ClickRentalOwnersLiabilityAsync() =>
        _locators.RentalOwnersLiability.EvaluateAsync("el => el.click()");

    public Task WaitForRentalReimbursementAsync(string expected) =>
        _ui.WaitAsync(_locators.RentalReimbursement, expected);

    public Task EnterRentalReimbursementAsync(string value) =>
        _ui.FillAsync(_locators.RentalReimbursement, value);

    public Task PressRentalReimbursementAsync(string key) =>
        _ui.PressAsync(_locators.RentalReimbursement, key);

    public Task WaitForRentedEquipmentExpenseAsync(string expected) =>
        _ui.WaitAsync(_locators.RentedEquipmentExpense, expected);

    public Task EnterRentedEquipmentExpenseAsync(string value) =>
        _ui.FillAsync(_locators.RentedEquipmentExpense, value);

    public Task PressRentedEquipmentExpenseAsync(string key) =>
        _ui.PressAsync(_locators.RentedEquipmentExpense, key);

    public Task EnterRequestedUmbrellaLimitAsync(string value) =>
        _ui.FillAsync(_locators.RequestedUmbrellaLimit, value);

    public Task EnterIndustryCodeAsync(string value) =>
        _ui.FillAsync(_locators.IndustryCode, value);

    public Task PressRequestedUmbrellaLimitAsync(string key) =>
        _ui.PressAsync(_locators.RequestedUmbrellaLimit, key);

    public Task VerifyResultAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Result, expected, property);

    public Task VerifyYearBuilt1980Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.YearBuilt1980, expected, property);

    public Task WaitForYearBuilt1980Async(string expected) =>
        _ui.WaitAsync(_locators.YearBuilt1980, expected);

    public Task EnterEnterYearInBuilt1980Async(string value) =>
        _ui.FillAsync(_locators.YearBuilt1980, value);

    public Task EnterLiveStockMeatAsync(string value) =>
        _ui.FillAsync(_locators.LiveStockMeat, value);

    public Task ClickReturnToQuoteAsync() =>
        _ui.ClickAsync(_locators.ReturnToQuote);

    public Task ClickRiskAsync() =>
        _ui.ClickAsync(_locators.Risk);

    public Task WaitForRiskAsync(string expected) =>
        _ui.WaitAsync(_locators.Risk, expected);

    public Task ClickRiskAccountsReceivableOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForRiskAccountsReceivableOKAsync(string expected) =>
        _ui.WaitAsync(_locators.OK, expected);

    public Task ClickRiskBaileesCustomersOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task ClickRiskComputerSystemsOKAsync() =>
        _ui.ClickAsync(_locators.OK);

    public Task WaitForRiskScheduleAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskSchedule, expected);

    public Task ClickRiskScheduleAsync() =>
        _ui.ClickAsync(_locators.RiskSchedule);

    public Task WaitForRiskTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.RiskType, expected);

    public Task EnterRiskTypeAsync(string value) =>
        _ui.FillAsync(_locators.RiskType, value);

    public Task PressRiskTypeAsync(string key) =>
        _ui.PressAsync(_locators.RiskType, key);

    public Task WaitForRoofTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.RoofType, expected);

    public Task EnterRoofTypeAsync(string value) =>
        _ui.FillAsync(_locators.RoofType, value);

    public Task PressRoofTypeAsync(string key) =>
        _ui.PressAsync(_locators.RoofType, key);

    public Task ClickSFP10LiabilityFarmAsync() =>
        _ui.ClickAsync(_locators.SFP10LiabilityFarm);

    public Task ClickSaveForLaterAsync() =>
        _ui.ClickAsync(_locators.SaveForLater);

    public Task WaitForScheduledCoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.ScheduledCoverage, expected);

    public Task EnterScheduledCoverageAsync(string value) =>
        _ui.FillAsync(_locators.ScheduledCoverage, value);

    public Task PressScheduledCoverageAsync(string key) =>
        _ui.PressAsync(_locators.ScheduledCoverage, key);

    public Task EnterRiskComputerSystemsSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskComputerSystemsSearchResult, value);

    public Task PressRiskComputerSystemsSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskComputerSystemsSearchResult, key);

    public Task EnterRiskBaileesCustomersSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersSearchResult, value);

    public Task PressRiskBaileesCustomersSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersSearchResult, key);

    public Task EnterRiskAccountsReceivableSearchResultAsync(string value) =>
        _ui.FillAsync(_locators.RiskAccountsReceivableSearchResult, value);

    public Task<string> CaptureRiskAccountsReceivableSearchResultAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskAccountsReceivableSearchResult, property);

    public Task WaitForRiskAccountsReceivableSearchResultAsync(string expected) => _ui.WaitAsync(_locators.RiskAccountsReceivableSearchResult, expected);

    public Task PressRiskAccountsReceivableSearchResultAsync(string key) =>
        _ui.PressAsync(_locators.RiskAccountsReceivableSearchResult, key);

    public Task WaitForSearchResultsAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchResults, expected);

    public Task EnterSearchResultsAsync(string value) =>
        _ui.FillAsync(_locators.SearchResults, value);

    public async Task<bool> IsSearchResultsAsync() =>
        await _locators.SearchResults.CountAsync() > 0;

    public Task PressSearchResultsAsync(string key) =>
        _ui.PressAsync(_locators.SearchResults, key);

    public Task WaitForSearchValueAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchValue, expected);

    public Task EnterSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.SearchValue, value);

    public Task PressSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.SearchValue, key);

    public Task WaitForPropertyAddClassSearchValueAsync(string expected) =>
        _ui.WaitAsync(_locators.PropertyAddClassSearchValue, expected);

    public Task EnterPropertyAddClassSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.PropertyAddClassSearchValue, value);

    public async Task<bool> IsPropertyAddClassSearchValueAsync() =>
        await _locators.PropertyAddClassSearchValue.CountAsync() > 0;

    public Task PressPropertyAddClassSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.PropertyAddClassSearchValue, key);

    public Task EnterRiskAccountsReceivableSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskAccountsReceivableSearchValue, value);

    public Task<string> CaptureRiskAccountsReceivableSearchValueAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskAccountsReceivableSearchValue, property);

    public Task WaitForRiskAccountsReceivableSearchValueAsync(string expected) => _ui.WaitAsync(_locators.RiskAccountsReceivableSearchValue, expected);

    public Task PressRiskAccountsReceivableSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskAccountsReceivableSearchValue, key);

    public Task EnterRiskComputerSystemsSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskComputerSystemsSearchValue, value);

    public Task<string> CaptureRiskComputerSystemsSearchValueAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskComputerSystemsSearchValue, property);

    public Task PressRiskComputerSystemsSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskComputerSystemsSearchValue, key);

    public Task EnterRiskBaileesCustomersSearchValueAsync(string value) =>
        _ui.FillAsync(_locators.RiskBaileesCustomersSearchValue, value);

    public Task<string> CaptureRiskBaileesCustomersSearchValueAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskBaileesCustomersSearchValue, property);

    public Task PressRiskBaileesCustomersSearchValueAsync(string key) =>
        _ui.PressAsync(_locators.RiskBaileesCustomersSearchValue, key);

    public Task EnterSeasonalProduceTrailersAsync(string value) =>
        _ui.FillAsync(_locators.SeasonalProduceTrailers, value);

    public Task PressSeasonalProduceTrailersAsync(string key) =>
        _ui.PressAsync(_locators.SeasonalProduceTrailers, key);

    public Task ClickSelectAsync() =>
        _ui.ClickAsync(_locators.Select);

    public Task VerifySelectAppropriateCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SelectAppropriateCode, expected, property);

    public Task EnterSelectAppropriateCodeAsync(string value) =>
        _ui.FillAsync(_locators.SelectAppropriateCode, value);

    public Task PressSelectAppropriateCodeAsync(string key) =>
        _ui.PressAsync(_locators.SelectAppropriateCode, key);

    public Task VerifySelectClassCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SelectClassCode, expected, property);

    public Task EnterSelectClassCodeAsync(string value) =>
        _ui.FillAsync(_locators.SelectClassCode, value);

    public Task PressSelectClassCodeAsync(string key) =>
        _ui.PressAsync(_locators.SelectClassCode, key);

    public Task WaitForSelectEndorsementAsync(string expected) =>
        _ui.WaitAsync(_locators.LineEndorsementType, expected);

    public Task VerifySelectEndorsementAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LineEndorsementType, expected, property);

    public Task EnterSelectEndorsementAsync(string value) =>
        _ui.FillAsync(_locators.LineEndorsementType, value);

    public Task PressSelectEndorsementAsync(string key) =>
        _ui.PressAsync(_locators.LineEndorsementType, key);

    public Task ClickSelectNAICSCodeAsync() =>
        _ui.ClickAsync(_locators.SelectNAICSCode);

    public Task ClickSelectPPCAsync() =>
        _ui.ClickAsync(_locators.SelectPPC);

    public Task WaitForSexAsync(string expected) =>
        _ui.WaitAsync(_locators.Sex, expected);

    public Task EnterSexAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.Sex, value);

    public Task PressSexAsync(string key) =>
        _ui.PressAsync(_locators.Sex, key);

    public Task WaitForShowAllLocationsAsync(string expected) =>
        _ui.WaitAsync(_locators.ShowAllLocations, expected);

    public Task EnterSignLocationAsync(string value) =>
        _ui.FillAsync(_locators.SignLocation, value);

    public Task<string> CaptureSignLocationAsync(string property = "") =>
        _ui.CaptureAsync(_locators.SignLocation, property);

    public Task PressSignLocationAsync(string key) =>
        _ui.PressAsync(_locators.SignLocation, key);

    public Task ClickSignsUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.SignsUWQuestions);

    public Task EnterSmallDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.SmallDeductible, value);


    public Task EnterSmallDeductibleSelectionAsync(string value) =>
       _ui.FillAsync(_locators.SmallDeductableSection, value);



    public Task EnterLLinestateDeductibleSelectionAsync(string value) =>
      _ui.FillAsync(_locators.LineStateTermInput, value);



    public Task EnterSmallDeductibleSelectioncreditdeductableAsync(string value) =>
     _ui.FillAsync(_locators.SmallDeductibleCreditDeductible, value);



    public Task EnterSmallDeductibleSelectioncreditAsync(string value) =>
     _ui.FillAsync(_locators.SmallDeductibleCredit, value);


    public Task PressSmallDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.SmallDeductible, key);

    public Task EnterSoleProprietorsAsync(string value) =>
        _ui.FillAsync(_locators.SoleProprietors, value);

    public Task PressSoleProprietorsAsync(string key) =>
        _ui.PressAsync(_locators.SoleProprietors, key);

    public Task ClickSpecificUnderwritingQuestionsAsync() =>
        _ui.ClickAsync(_locators.SpecificUnderwritingQuestions);

    public async Task ClickSpecificUnderwritingQuestionsWithRetryAsync(int maxAttempts = 3, int waitBeforeMs = 1000)
    {
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await Task.Delay(waitBeforeMs);
            if (await _ui.ExistsAsync(_locators.SpecificUnderwritingQuestions))
            {
                await ClickSpecificUnderwritingQuestionsAsync();
                return;
            }
        }
        await ClickSpecificUnderwritingQuestionsAsync();
    }

    public Task SetSplitBIDedAsync(string value) =>
        _ui.SmartSetAsync(_locators.SplitBIDed, value);

    public Task PressSplitBIDedAsync(string key) =>
        _ui.PressAsync(_locators.SplitBIDed, key);

    public Task EnterSplitPDDedAsync(string value) =>
        _ui.FillAsync(_locators.SplitPDDed, value);

    public Task WaitForSquareFeetAsync(string expected) =>
        _ui.WaitAsync(_locators.SquareFeet, expected);

    public Task EnterSquareFeetAsync(string value) =>
        _ui.FillAsync(_locators.SquareFeet, value);

    public Task PressSquareFeetAsync(string key) =>
        _ui.PressAsync(_locators.SquareFeet, key);

    public Task EnterPolicyHolderStateAsync(string value) =>
        _ui.FillAsync(_locators.PolicyHolderState, value);

    public Task PressPolicyHolderStateAsync(string key) =>
        _ui.PressAsync(_locators.PolicyHolderState, key);

    public Task WaitForStateAsync(string expected) =>
        _ui.WaitAsync(_locators.State, expected);

    public Task EnterEndorsementsDesignatedWorkplacesExclusionStateAsync(string value) =>
        _ui.FillAsync(_locators.EndorsementsDesignatedWorkplacesExclusionState, value);

    public Task PressEndorsementsDesignatedWorkplacesExclusionStateAsync(string key) =>
        _ui.PressAsync(_locators.EndorsementsDesignatedWorkplacesExclusionState, key);

    public Task WaitForStateDetailsAsync(string expected) =>
        _ui.WaitAsync(_locators.StateDetails, expected);
    public Task ClickStateDetailsAsync() =>
        _ui.ClickAsync(_locators.StateDetails);

    public Task WaitForSelectAsync(string expected) =>
        _ui.WaitAsync(_locators.Select, expected);

    public Task WaitForStateLicensedAsync(string expected) =>
        _ui.WaitAsync(_locators.StateLicensed, expected);

    public Task EnterStateLicensedAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.StateLicensed, value);

    public Task PressStateLicensedAsync(string key) =>
        _ui.PressAsync(_locators.StateLicensed, key);

    public Task EnterStateOrPoliticalSubdivisionAsync(string value) =>
        _ui.FillAsync(_locators.StateOrPoliticalSubdivision, value);

    public Task PressStateOrPoliticalSubdivisionAsync(string key) =>
        _ui.PressAsync(_locators.StateOrPoliticalSubdivision, key);

    public async Task<bool> IsAdditionalOtherInterestBusinessNameVisibleAsync() =>
        await _locators.AdditionalOtherInterestBusinessName.First.IsVisibleAsync();

    public Task EnterAdditionalOtherInterestBusinessNameAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestBusinessName, value);

    public Task EnterAdditionalOtherInterestFirstNameAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestInputFirstName, value);

    public Task EnterAdditionalOtherInterestLastNameAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestInputLastName, value);

    public Task EnterStatedAmountAsync(string value) =>
        _ui.FillAsync(_locators.RiskVehicleInputValueEstimate, value);

    public async Task<bool> IsStatedAmountVisibleAsync() =>
        await _locators.RiskVehicleInputValueEstimate.First.IsVisibleAsync();

    public Task PressStatedAmountAsync(string key) =>
        _ui.PressAsync(_locators.RiskVehicleInputValueEstimate, key);

    public Task EnterSpecialOrMobileEquipmentGroupTypeAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.SpecialOrMobileEquipmentGroupType, value);

    public Task WaitForSpecialOrMobileEquipmentGroupTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.SpecialOrMobileEquipmentGroupType, expected);

    public async Task EnterPublicGroupTypeAsync(string value)
    {
        await _ui.PressSequentiallyAsync(_locators.PublicGroupType, value);
        await _ui.PressAsync(_locators.PublicGroupType, "Tab");
    }

    public Task WaitForPublicGroupTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.PublicGroupType, expected);

    public async Task EnterPublicTypeAsync(string value)
    {
        await _ui.PressSequentiallyAsync(_locators.PublicType, value);
        await _ui.PressAsync(_locators.PublicType, "Tab");
    }

    public async Task<string> GetPublicTypeValueAsync() =>
        (await _locators.PublicType.InputValueAsync())?.Trim() ?? string.Empty;

    public Task WaitForPublicTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.PublicType, expected);

    public Task EnterAcceptLiabilityCoverageAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AcceptLiabilityCoverage, value);

    public Task WaitForAcceptLiabilityCoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.AcceptLiabilityCoverage, expected);

    public Task WaitForStoplightMessageTotalSubjectPremiumAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightMessageTotalSubjectPremium, expected);

    public Task EnterStorageLimitAsync(string value) =>
        _ui.FillAsync(_locators.StorageLimit, value);

    public Task PressStorageLimitAsync(string key) =>
        _ui.PressAsync(_locators.StorageLimit, key);

    public Task WaitForStoriesAsync(string expected) =>
        _ui.WaitAsync(_locators.Stories, expected);

    public Task EnterStoriesAsync(string value) =>
        _ui.FillAsync(_locators.Stories, value);

    public Task PressStoriesAsync(string key) =>
        _ui.PressAsync(_locators.Stories, key);

    public Task WaitForSubmissionAsync(string expected) =>
        _ui.WaitAsync(_locators.SubmissionLink, expected);

    public Task PressSubmissionAsync(string key) =>
        _ui.PressAsync(_locators.SubmissionLink, key);

    public Task ClickSubmissionAsync() =>
        _ui.ClickAsync(_locators.SubmissionLink);

    public Task WaitForCompleteApplicationAsync(string expected) =>
        _ui.WaitAsync(_locators.CompleteApplication, expected);

    public Task ClickCompleteApplicationAsync() =>
        _ui.ClickAsync(_locators.CompleteApplication);

    public Task WaitForStoplightWaitingResultsAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightWaitingResults, expected);

    public Task ClickStoplightCloseButtonAsync() =>
        _ui.ClickAsync(_locators.StoplightCloseButton);

    public Task WaitForSubmissionHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.Submission, expected);

    public Task VerifySubmissionHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PageTop, expected, property);

    public Task EnterTapesCoverageAsync(string value) =>
        _ui.FillAsync(_locators.TapesCoverage, value);

    public Task PressTapesCoverageAsync(string key) =>
        _ui.PressAsync(_locators.TapesCoverage, key);

    public async Task<bool> IsTapesCoverageVisibleAsync() =>
        await _locators.TapesCoverage.First.IsVisibleAsync();

    public Task EnterTextBoxAsync(string value) =>
        _ui.FillAsync(_locators.TextBox, value);

    public Task PressTextBoxAsync(string key) =>
      _ui.PressAsync(_locators.TextBox, key);

    public Task<string> CaptureTextBoxAsync(string property = "") =>
        _ui.CaptureAsync(_locators.TextBox, property);

    public Task WaitForThirdPartyDesigneeAsync(string expected) =>
        _ui.WaitAsync(_locators.ThirdPartyDesignee, expected);

    public Task ClickThirdPartyDesigneeAsync() =>
        _ui.ClickAsync(_locators.ThirdPartyDesignee);

    public Task EnterTitleAsync(string value) =>
        _ui.FillAsync(_locators.Title, value);

    public Task WaitForToolsAndClothingBelongingToYourEmployeesAsync(string expected) =>
        _ui.WaitAsync(_locators.ToolsAndClothingBelongingToYourEmployees, expected);

    public Task EnterToolsAndClothingBelongingToYourEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.ToolsAndClothingBelongingToYourEmployees, value);

    public Task PressToolsAndClothingBelongingToYourEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.ToolsAndClothingBelongingToYourEmployees, key);

    public Task EnterTotalCostOfWorkAsync(string value) =>
        _ui.FillAsync(_locators.TotalCostOfWork, value);

    public Task PressTotalCostOfWorkAsync(string key) =>
        _ui.PressAsync(_locators.TotalCostOfWork, key);

    public Task EnterTotalPayrollEstimatedAsync(string value) =>
        _ui.FillAsync(_locators.TotalPayrollEstimated, value);

    public Task PressTotalPayrollEstimatedAsync(string key) =>
        _ui.PressAsync(_locators.TotalPayrollEstimated, key);

    public Task EnterTotalPremiumAsync(string value) =>
        _ui.FillAsync(_locators.TotalPremium, value);

    public Task<string> CaptureTotalPremiumAsync(string property = "") =>
        _ui.CaptureAsync(_locators.TotalPremium, property);

    public Task PressTotalPremiumAsync(string key) =>
        _ui.PressAsync(_locators.TotalPremium, key);

    public Task EnterGeneralLiabilityTotalSubjectPremiumAsync(string value) =>
        _ui.FillAsync(_locators.GeneralLiabilityTotalSubjectPremium, value);

    public Task<string> CaptureGeneralLiabilityTotalSubjectPremiumAsync(string property = "") =>
        _ui.CaptureAsync(_locators.GeneralLiabilityTotalSubjectPremium, property);

    public Task PressGeneralLiabilityTotalSubjectPremiumAsync(string key) =>
        _ui.PressAsync(_locators.GeneralLiabilityTotalSubjectPremium, key);

    public Task EnterBusinessownersTotalSubjectPremiumAsync(string value) =>
        _ui.FillAsync(_locators.BusinessownersTotalSubjectPremium, value);

    public Task<string> CaptureBusinessownersTotalSubjectPremiumAsync(string property = "") =>
        _ui.CaptureAsync(_locators.BusinessownersTotalSubjectPremium, property);

    public Task PressBusinessownersTotalSubjectPremiumAsync(string key) =>
        _ui.PressAsync(_locators.BusinessownersTotalSubjectPremium, key);

    public Task EnterTowingAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.Towing, value);

    public async Task<bool> IsTowingVisibleAsync() =>
        await _locators.Towing.First.IsVisibleAsync();

    public Task PressTowingAsync(string key) =>
        _ui.PressAsync(_locators.Towing, key);

    public Task EnterVehicleRentalReimbursementAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.VehicleRentalReimbursement, value);

    public async Task<bool> IsVehicleRentalReimbursementVisibleAsync() =>
        await _locators.VehicleRentalReimbursement.First.IsVisibleAsync();

    public Task PressVehicleRentalReimbursementAsync(string key) =>
        _ui.PressAsync(_locators.VehicleRentalReimbursement, key);

    public Task EnterTrailerInterchangeCollisionDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.TrailerInterchangeCollisionDeductible, value);

    public Task PressTrailerInterchangeCollisionDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.TrailerInterchangeCollisionDeductible, key);

    public Task EnterTrailerInterchangeCompDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.TrailerInterchangeCompDeductible, value);

    public Task PressTrailerInterchangeCompDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.TrailerInterchangeCompDeductible, key);

    public Task EnterTrailerInterchangeEnterDaysInsuredAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.TrailerInterchangeEnterDaysInsured, value);

    public Task PressTrailerInterchangeEnterDaysInsuredAsync(string key) =>
        _ui.PressAsync(_locators.TrailerInterchangeEnterDaysInsured, key);

    public async Task<bool> IsTrailerInterchangeEnterDaysInsuredVisibleAsync() =>
        await _locators.TrailerInterchangeEnterDaysInsured.IsVisibleAsync();

    public Task WaitForTrailerInterchangeEnterDaysInsuredVisibleAsync() =>
        _locators.TrailerInterchangeEnterDaysInsured.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task EnterTrailerInterchangeEnterOfTrailersAsync(string value) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.TrailerInterchangeEnterOfTrailers, value);

    public Task PressTrailerInterchangeEnterOfTrailersAsync(string key) =>
        _ui.PressAsync(_locators.TrailerInterchangeEnterOfTrailers, key);

    public async Task<bool> IsTrailerInterchangeEnterOfTrailersVisibleAsync() =>
        await _locators.TrailerInterchangeEnterOfTrailers.IsVisibleAsync();

    public Task WaitForTrailerInterchangeEnterOfTrailersVisibleAsync() =>
        _locators.TrailerInterchangeEnterOfTrailers.WaitForAsync(new() { State = Microsoft.Playwright.WaitForSelectorState.Visible });

    public Task EnterFG0013AutomaticAdditionalInsuredSpecificRelationshipTypeAsync(string value) =>
        _ui.FillAsync(_locators.AdditionalOtherInterestType, value);

    public Task PressFG0013AutomaticAdditionalInsuredSpecificRelationshipTypeAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalOtherInterestType, key);

    public Task EnterEndorsementMainTypeAsync(string value) =>
        _ui.FillAsync(_locators.EndorsementMainType, value);

    public Task PressEndorsementMainTypeAsync(string key) =>
        _ui.PressAsync(_locators.EndorsementMainType, key);

    public Task EnterGLOCPRiskTypeAsync(string value) =>
        _ui.FillAsync(_locators.GLOCPRiskType, value);

    public Task PressGLOCPRiskTypeAsync(string key) =>
        _ui.PressAsync(_locators.GLOCPRiskType, key);

    public Task EnterCG2007AddLInsuredEngineersArchitectsTypeAsync(string value) =>
        _ui.FillAsync(_locators.AdditionalOtherInterestType, value);

    public Task PressCG2007AddLInsuredEngineersArchitectsTypeAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalOtherInterestType, key);

    public Task EnterRiskSignsTypeAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.RiskSignsType, value, 20);

    public Task<string> CaptureRiskSignsTypeAsync(string property = "") =>
        _ui.CaptureAsync(_locators.RiskSignsType, property);

    public Task PressRiskSignsTypeAsync(string key) =>
        _ui.PressAsync(_locators.RiskSignsType, key);

    public Task WaitForCG2007AddLInsuredEngineersArchitectsTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalOtherInterestType, expected);

    public Task ClickCG2007AddLInsuredEngineersArchitectsTypeAsync() =>
        _ui.ClickAsync(_locators.AdditionalOtherInterestType);

    public Task VerifyCG2007AddLInsuredEngineersArchitectsTypeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AdditionalOtherInterestType, expected, property);

    public Task WaitForTypeOfContractorAsync(string expected) =>
        _ui.WaitAsync(_locators.TypeOfContractor, expected);

    public Task EnterTypeOfContractorAsync(string value) =>
        _ui.FillAsync(_locators.TypeOfContractor, value);

    public Task PressTypeOfContractorAsync(string key) =>
        _ui.PressAsync(_locators.TypeOfContractor, key);

    public Task EnterTypeOfEquipmentAsync(string value) =>
        _ui.FillAsync(_locators.TypeOfEquipment, value);

    public Task PressTypeOfEquipmentAsync(string key) =>
        _ui.PressAsync(_locators.TypeOfEquipment, key);

    public Task WaitForTypeOfInterestAsync(string expected) =>
        _ui.WaitAsync(_locators.AdditionalOtherInterestType, expected);

    public Task EnterTypeOfInterestAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.AdditionalOtherInterestType, value);

    public Task PressTypeOfInterestAsync(string key) =>
        ComponentAwareControlActions.DomPressAsync(_locators.AdditionalOtherInterestType, key);

    public Task EnterTypeOfLicenseAsync(string value) =>
        _ui.FillAsync(_locators.TypeOfLicense, value);

    public Task PressTypeOfLicenseAsync(string key) =>
        _ui.PressAsync(_locators.TypeOfLicense, key);

    public Task EnterUMBILimitAsync(string value) =>
        _ui.FillAsync(_locators.UMBILimit, value);

    public Task PressUMBILimitAsync(string key) =>
        _ui.PressAsync(_locators.UMBILimit, key);

    public Task EnterUMPDLimitAsync(string value) =>
        _ui.FillAsync(_locators.UMPDLimit, value);

    public async Task<bool> IsUMPDLimitVisibleAsync() =>
        await _locators.UMPDLimit.First.IsVisibleAsync();

    public Task PressUMPDLimitAsync(string key) =>
        _ui.PressAsync(_locators.UMPDLimit, key);

    public Task EnterUIMCSLLimitAsync(string value) =>
        _ui.FillAsync(_locators.UIMCSLLimit, value);

    public async Task<bool> IsUIMCSLLimitVisibleAsync() =>
        await _locators.UIMCSLLimit.First.IsVisibleAsync();

    public Task PressUIMCSLLimitAsync(string key) =>
        _ui.PressAsync(_locators.UIMCSLLimit, key);

    public Task EnterPIPWaiverAsync(string value) =>
        _ui.FillAsync(_locators.PIPWaiver, value);

    public async Task<bool> IsPIPWaiverVisibleAsync() =>
        await _locators.PIPWaiver.First.IsVisibleAsync();

    public Task PressPIPWaiverAsync(string key) =>
        _ui.PressAsync(_locators.PIPWaiver, key);

    public Task EnterPIPLimitAsync(string value) =>
        _ui.FillAsync(_locators.PIPLimit, value);

    public async Task<bool> IsPIPLimitVisibleAsync() =>
        await _locators.PIPLimit.First.IsVisibleAsync();

    public Task PressPIPLimitAsync(string key) =>
        _ui.PressAsync(_locators.PIPLimit, key);

    public Task EnterPIPAdditionalCombinationLimitAsync(string value) =>
        _ui.FillAsync(_locators.PIPAdditionalCombinationLimit, value);

    public async Task<bool> IsPIPAdditionalCombinationLimitVisibleAsync() =>
        await _locators.PIPAdditionalCombinationLimit.First.IsVisibleAsync();

    public Task PressPIPAdditionalCombinationLimitAsync(string key) =>
        _ui.PressAsync(_locators.PIPAdditionalCombinationLimit, key);

    public Task EnterPIPExtraordinaryMedicalLimitAsync(string value) =>
        _ui.FillAsync(_locators.PIPExtraordinaryMedicalLimit, value);

    public async Task<bool> IsPIPExtraordinaryMedicalLimitVisibleAsync() =>
        await _locators.PIPExtraordinaryMedicalLimit.First.IsVisibleAsync();

    public Task PressPIPExtraordinaryMedicalLimitAsync(string key) =>
        _ui.PressAsync(_locators.PIPExtraordinaryMedicalLimit, key);

    public Task EnterPIPAdditionalLimitAsync(string value) =>
        _ui.FillAsync(_locators.PIPAdditionalLimit, value);

    public async Task<bool> IsPIPAdditionalLimitVisibleAsync() =>
        await _locators.PIPAdditionalLimit.First.IsVisibleAsync();

    public Task PressPIPAdditionalLimitAsync(string key) =>
        _ui.PressAsync(_locators.PIPAdditionalLimit, key);

    public Task EnterPIPDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.PIPDeductible, value);

    public async Task<bool> IsPIPDeductibleVisibleAsync() =>
        await _locators.PIPDeductible.First.IsVisibleAsync();

    public Task PressPIPDeductibleAsync(string key) =>
        _ui.PressAsync(_locators.PIPDeductible, key);

    public Task EnterPIPAdditionalAccidentalDeathLimitAsync(string value) =>
        _ui.FillAsync(_locators.PIPAdditionalAccidentalDeathLimit, value);

    public async Task<bool> IsPIPAdditionalAccidentalDeathLimitVisibleAsync() =>
        await _locators.PIPAdditionalAccidentalDeathLimit.First.IsVisibleAsync();

    public Task PressPIPAdditionalAccidentalDeathLimitAsync(string key) =>
        _ui.PressAsync(_locators.PIPAdditionalAccidentalDeathLimit, key);

    public Task EnterBroadenedPIPAsync(string value) =>
        _ui.FillAsync(_locators.BroadenedPIP, value);

    public async Task<bool> IsBroadenedPIPVisibleAsync() =>
        await _locators.BroadenedPIP.First.IsVisibleAsync();

    public Task PressBroadenedPIPAsync(string key) =>
        _ui.PressAsync(_locators.BroadenedPIP, key);

    public Task EnterBroadenedPIPFirstNameAsync(string value) =>
        _ui.FillAsync(_locators.BroadenedPIPFirstName, value);

    public async Task<bool> IsBroadenedPIPFirstNameVisibleAsync() =>
        await _locators.BroadenedPIPFirstName.First.IsVisibleAsync();

    public Task EnterBroadenedPIPLastNameAsync(string value) =>
        _ui.FillAsync(_locators.BroadenedPIPLastName, value);

    public async Task<bool> IsBroadenedPIPLastNameVisibleAsync() =>
        await _locators.BroadenedPIPLastName.First.IsVisibleAsync();

    public Task EnterUMTypeDefaultSelectionsAsync(string value) =>
        _ui.FillAsync(_locators.UMTypeDefaultSelections, value);

    public Task PressUMTypeDefaultSelectionsAsync(string key) =>
        _ui.PressAsync(_locators.UMTypeDefaultSelections, key);

    public Task VerifyOKAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.OK, expected, property);

    public Task ClickUWQuestionsAsync() =>
        _ui.ClickAsync(_locators.UWQuestionsLink);

    public Task PressUWQuestionsUmbrellaAsync(string key) =>
        _ui.PressAsync(_locators.UMQuestionsUmbrella, key);

    public Task ClickUWQuestionsUmbrellaAsync() =>
        _ui.ClickAsync(_locators.UMQuestionsUmbrella);

    public Task ClickUWQuestionsWorkersCompAsync() =>
        _ui.ClickAsync(_locators.UWQuestionsWorkersComp);

    public Task VerifyUmbrellaLimitAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.UmbrellaLimit, expected, property);

    public Task<string> CaptureUmbrellaLimitAsync(string property = "") =>
        _ui.CaptureAsync(_locators.UmbrellaLimit, property);

    public Task EnterUmbrellaLimitAsync(string value) =>
        _ui.FillAsync(_locators.UmbrellaLimit, value);

    public Task PressUmbrellaLimitAsync(string key) =>
        _ui.PressAsync(_locators.UmbrellaLimit, key);

    public Task ClickUnderwritingInfoAsync() =>
        _ui.ClickAsync(_locators.UnderwritingInfo);

    public Task EnterUninterruptiblePowerSourceAsync(string value) =>
        _ui.FillAsync(_locators.UninterruptiblePowerSource, value);

    public Task PressUninterruptiblePowerSourceAsync(string key) =>
        _ui.PressAsync(_locators.UninterruptiblePowerSource, key);

    public Task WaitForUnnamedPremisesAsync(string expected) =>
        _ui.WaitAsync(_locators.UnnamedPremises, expected);

    public Task EnterUnnamedPremisesAsync(string value) =>
        _ui.FillAsync(_locators.UnnamedPremises, value);

    public Task PressUnnamedPremisesAsync(string key) =>
        _ui.PressAsync(_locators.UnnamedPremises, key);

    public Task WaitForUnnamedTerminalsLimitAsync(string expected) =>
        _ui.WaitAsync(_locators.UnnamedTerminalsLimit, expected);

    public Task EnterUnnamedTerminalsLimitAsync(string value) =>
        _ui.FillAsync(_locators.UnnamedTerminalsLimit, value);

    public Task<bool> IsUnnamedTerminalsLimitVisibleAsync() => _ui.ExistsAsync(_locators.UnnamedTerminalsLimit);

    public Task PressUnnamedTerminalsLimitAsync(string key) =>
        _ui.PressAsync(_locators.UnnamedTerminalsLimit, key);

    public Task ClickSpecificUnderwritingQuestionsContractorsEquipmentUpdateAnswersAsync() =>
        _ui.ClickAsync(_locators.UpdateAnswers);

    public Task PressUWQuestionsUmbrellaUpdateAnswersAsync(string key) =>
        _ui.PressAsync(_locators.UpdateAnswers, key);

    public Task ClickUWQuestionsUmbrellaUpdateAnswersAsync() =>
        _ui.ClickAsync(_locators.UpdateAnswers);

    public Task WaitForUWQuestionsUmbrellaUpdateAnswersAsync(string expected) =>
        _ui.WaitAsync(_locators.UpdateAnswers, expected);

    public Task WaitForUWQuestionHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.UWVHeader, expected);

    public Task PressPropertyUWQuestionsUpdateAnswersAsync(string key) =>
        _ui.PressAsync(_locators.UpdateAnswers, key);

    public Task ClickPropertyUWQuestionsUpdateAnswersAsync() =>
        _ui.ClickAsync(_locators.UpdateAnswers);

    public Task PressUpdateAnswersButtonAsync(string key) =>
        _ui.PressAsync(_locators.UpdateAnswers, key);

    public Task ClickUpdateAnswersButtonAsync() =>
        _ui.ClickAsync(_locators.UpdateAnswers);

    public Task EnterUsedAsShowroomAsync(string value) =>
        _ui.FillAsync(_locators.UsedAsShowroom, value);

    public async Task<bool> IsUsedAsShowroomVisibleAsync() =>
        await _locators.UsedAsShowroom.First.IsVisibleAsync();

    public Task PressUsedAsShowroomAsync(string key) =>
        _ui.PressAsync(_locators.UsedAsShowroom, key);

    public Task WaitForVINAsync(string expected) =>
        _ui.WaitAsync(_locators.VIN, expected);

    public Task EnterVINAsync(string value) =>
        _ui.FillAsync(_locators.VIN, value);

    public Task PressVINAsync(string key) =>
        _ui.PressAsync(_locators.VIN, key);

    public Task WaitForVacancyPermitAsync(string expected) =>
        _ui.WaitAsync(_locators.VacancyPermit, expected);

    public Task EnterVacancyPermitAsync(string value) =>
        _ui.FillAsync(_locators.VacancyPermit, value);

    public async Task<bool> IsVacancyPermitAsync() =>
        await _locators.VacancyPermit.CountAsync() > 0;
    public Task SetVacancyPermitAsync(string value) =>
        _ui.SmartSetAsync(_locators.VacancyPermit, value);

    public Task PressVacancyPermitAsync(string key) =>
        _ui.PressAsync(_locators.VacancyPermit, key);

    public Task WaitForVacantBuildingAsync(string expected) =>
        _ui.WaitAsync(_locators.VacantBuilding, expected);

    public Task EnterVacantBuildingAsync(string value) =>
        _ui.FillAsync(_locators.VacantBuilding, value);

    public async Task<bool> IsVacantBuildingAsync() =>
        await _locators.VacantBuilding.CountAsync() > 0;
    public Task SetVacantBuildingAsync(string value) =>
        _ui.SmartSetAsync(_locators.VacantBuilding, value);

    public Task PressVacantBuildingAsync(string key) =>
        _ui.PressAsync(_locators.VacantBuilding, key);

    public Task WaitForValuationAsync(string expected) =>
        _ui.WaitAsync(_locators.Valuation, expected);

    public Task EnterValuationAsync(string value) =>
        _ui.FillAsync(_locators.Valuation, value);

    public Task PressValuationAsync(string key) =>
        _ui.PressAsync(_locators.Valuation, key);

    public Task WaitForValuationTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.ValuationType, expected);

    public Task EnterValuationTypeAsync(string value) =>
        _ui.FillAsync(_locators.ValuationType, value);

    public Task SetValuationTypeAsync(string value) =>
        _ui.SmartSetAsync(_locators.ValuationType, value);

    public Task PressValuationTypeAsync(string key) =>
        _ui.PressAsync(_locators.ValuationType, key);

    public Task EnterValueBasisAsync(string value) =>
        _ui.FillAsync(_locators.ValueBasis, value);

    public async Task<bool> IsValueBasisVisibleAsync() =>
        await _locators.ValueBasis.First.IsVisibleAsync();

    public Task PressValueBasisAsync(string key) =>
        _ui.PressAsync(_locators.ValueBasis, key);

    public Task EnterVehicleInformationAsync(string value) =>
        _ui.FillAsync(_locators.VehicleInformation, value);

    public Task PressVehicleInformationAsync(string key) =>
        _ui.PressAsync(_locators.VehicleInformation, key);

    public Task VerifyVehicleSchedule1VehAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.VehicleSchedule1Veh, expected, property);

    public Task WaitForVehicleTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.VehicleType, expected);

    public Task VerifyVehicleTypeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.VehicleType, expected, property);

    public Task EnterVehicleTypeAsync(string value) =>
        _ui.FillAsync(_locators.VehicleType, value);

    public Task PressVehicleTypeAsync(string key) =>
        _ui.PressAsync(_locators.VehicleType, key);

    public Task WaitForVirusHarmfulCodeOrSimilarInstructionAsync(string expected) =>
        _ui.WaitAsync(_locators.VirusHarmfulCodeOrSimilarInstruction, expected);

    public Task EnterVirusHarmfulCodeOrSimilarInstructionAsync(string value) =>
        _ui.FillAsync(_locators.VirusHarmfulCodeOrSimilarInstruction, value);

    public Task PressVirusHarmfulCodeOrSimilarInstructionAsync(string key) =>
        _ui.PressAsync(_locators.VirusHarmfulCodeOrSimilarInstruction, key);

    public Task ClickVolunteerHiredAutosCheckBoxAsync() =>
        _ui.ClickAsync(_locators.VolunteerHiredAutosCheckBox);

    public Task ClickWCScheduleAsync() =>
        _ui.ClickAsync(_locators.WCSchedule);

    public Task VerifyWaitonPricingHeadingAndFillOutRequiredFieldsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.WaitonPricingHeadingAndFillOutRequiredFields, expected, property);

    public Task EnterWaiverOfSubrogationAsync(string value) =>
        _ui.FillAsync(_locators.WaiverOfSubrogation, value);

    public Task PressWaiverOfSubrogationAsync(string key) =>
        _ui.PressAsync(_locators.WaiverOfSubrogation, key);

    public Task<bool> IsWaiverOfSubrogationExposureVisibleAsync() =>
        _ui.ExistsAsync(_locators.WaiverOfSubrogationExposure);

    public Task EnterWaiverOfSubrogationExposureAsync(string value) =>
        _ui.FillAsync(_locators.WaiverOfSubrogationExposure, value);

    public Task PressWaiverOfSubrogationExposureAsync(string key) =>
        _ui.PressAsync(_locators.WaiverOfSubrogationExposure, key);

    public Task EnterWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.WereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90Days, value);

    public Task EnterWorkplaceSafetyRiskManagementAsync(string value) =>
        _ui.FillAsync(_locators.WorkplaceSafetyRiskManagement, value);

    public Task EnterWCEstimatedPremiumAsync(string value) =>
       _ui.FillAsync(_locators.EstimatedPremium, value);



    public Task Hastheapplicantbeeninbusinessforatleast3yearswithcontinuousWorkersCompensationCoverage(string key) =>

        _ui.FillAsync(_locators.Hastheapplicantbeeninbusinessforatleast3yearswithcontinuousWorkersCompensationCoverage, key);

    public Task PressWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysAsync(string key) =>
        _ui.PressAsync(_locators.WereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90Days, key);

    public Task<string> CaptureWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysAsync(string property = "") =>
        _ui.CaptureAsync(_locators.WereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90Days, property);

    public Task EnterWhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecuredAsync(string value) =>
        _ui.FillAsync(_locators.WhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecured, value);

    public Task PressWhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecuredAsync(string key) =>
        _ui.PressAsync(_locators.WhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecured, key);

    public Task EnterWhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorageAsync(string value) =>
        _ui.FillAsync(_locators.WhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorage, value);

    public Task PressWhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorageAsync(string key) =>
        _ui.PressAsync(_locators.WhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorage, key);

    public Task EnterWhatIsTheConstructionOfEachSignAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsTheConstructionOfEachSign, value);

    public Task<string> CaptureWhatIsTheConstructionOfEachSignAsync(string property = "") =>
        _ui.CaptureAsync(_locators.WhatIsTheConstructionOfEachSign, property);

    public Task PressWhatIsTheConstructionOfEachSignAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsTheConstructionOfEachSign, key);

    public Task EnterWhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStoredAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStored, value);

    public Task<string> CaptureWhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStoredAsync(string property = "") =>
        _ui.CaptureAsync(_locators.WhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStored, property);

    public Task PressWhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStoredAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStored, key);

    public Task EnterWhatIsTheDistanceInFeetToTheNearestFireHydrantAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsTheDistanceInFeetToTheNearestFireHydrant, value);

    public Task PressWhatIsTheDistanceInFeetToTheNearestFireHydrantAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsTheDistanceInFeetToTheNearestFireHydrant, key);

    public Task EnterWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, value);

    public Task PressWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, key);

    public Task VerifyWhatIsThePrimaryReasonThisNewPolicyIsBeingRewrittenWithFarmFamilyAmericanNationalAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.WhatIsThePrimaryReasonThisNewPolicyIsBeingRewrittenWithFarmFamilyAmericanNational, expected, property);

    public Task EnterWhatIsTheProcedureForTransportingTheComputerEquipmentAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsTheProcedureForTransportingTheComputerEquipment, value);

    public Task PressWhatIsTheProcedureForTransportingTheComputerEquipmentAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsTheProcedureForTransportingTheComputerEquipment, key);

    public Task EnterWhatIsThePublicProtectionClassRatingAsync(string value) =>
        _ui.FillAsync(_locators.WhatIsThePublicProtectionClassRating, value);

    public Task PressWhatIsThePublicProtectionClassRatingAsync(string key) =>
        _ui.PressAsync(_locators.WhatIsThePublicProtectionClassRating, key);

    public Task EnterWhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheftAsync(string value) =>
        _ui.FillAsync(_locators.WhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheft, value);

    public Task<string> CaptureWhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheftAsync(string property = "") =>
        _ui.CaptureAsync(_locators.WhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheft, property);

    public Task PressWhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheftAsync(string key) =>
        _ui.PressAsync(_locators.WhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheft, key);

    public Task EnterWhichFormAreYouCompletingAsync(string value) =>
        _ui.FillAsync(_locators.WhichFormAreYouCompleting, value);

    public Task PressWhichFormAreYouCompletingAsync(string key) =>
        _ui.PressAsync(_locators.WhichFormAreYouCompleting, key);

    public Task EnterWhyIsThisCoverageDesiredAsync(string value) =>
        _ui.FillAsync(_locators.WhyIsThisCoverageDesired, value);

    public Task PressWhyIsThisCoverageDesiredAsync(string key) =>
        _ui.PressAsync(_locators.WhyIsThisCoverageDesired, key);

    public Task EnterYearAsync(string value) =>
        _ui.FillAsync(_locators.Year, value);

    public Task PressYearAsync(string key) =>
        _ui.PressAsync(_locators.Year, key);

    public Task WaitForYearBuiltAsync(string expected) =>
        _ui.WaitAsync(_locators.YearBuilt, expected);

    public Task EnterYearBuiltAsync(string value) =>
        _ui.FillAsync(_locators.YearBuilt, value);

    public Task PressYearBuiltAsync(string key) =>
        _ui.PressAsync(_locators.YearBuilt, key);

    public Task WaitForYearLicensedAsync(string expected) =>
        _ui.WaitAsync(_locators.YearLicensed, expected);

    public Task EnterYearLicensedAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.YearLicensed, value);

    public Task PressYearLicensedAsync(string key) =>
        _ui.PressAsync(_locators.YearLicensed, key);

    public Task EnterYearsInBusinessAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.YearsInBusiness, value);


    public Task EnterPrimaryStateAsync(string value) =>
      _ui.FillAsync(_locators.PrimaryLocationState, value);


    public async Task<bool> IsPrimaryLocationAvailableAsync() =>
     await _locators.PrimaryLocationState.CountAsync() > 0;

    public Task PressYearsInBusinessAsync(string key) =>
        _ui.PressAsync(_locators.YearsInBusiness, key);

    public Task EnterLocationZipCodeAsync(string value) =>
        ComponentAwareControlActions.DomFillAsync(_locators.LocationZipCode, value);

    public Task PressLocationZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.LocationZipCode, key);

    public Task EnterThirdPartyDesigneeZipCodeAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeZipCode, value);

    public Task PressThirdPartyDesigneeZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.ThirdPartyDesigneeZipCode, key);

    public Task WaitForThirdPartyDesigneeFirstNameAsync(string expected) =>
        _ui.WaitAsync(_locators.ThirdPartyDesigneeFirstName, expected);

    public Task EnterThirdPartyDesigneeFirstNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeFirstName, value);

    public Task WaitForThirdPartyDesigneeLastNameAsync(string expected) =>
        _ui.WaitAsync(_locators.ThirdPartyDesigneeLastName, expected);

    public Task EnterThirdPartyDesigneeLastNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeLastName, value);

    public Task EnterThirdPartyDesigneeAddressAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeAddress, value);

    public async Task<bool> IsThirdPartyDesigneeBusinessNameVisibleAsync() =>
        await _locators.ThirdPartyDesigneeBusinessName.First.IsVisibleAsync();

    public Task EnterThirdPartyDesigneeBusinessNameAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeBusinessName, value);

    public Task EnterGLOCPRiskZipCodeAsync(string value) =>
        _ui.FillAsync(_locators.GLOCPRiskZipCode, value);

    public Task PressGLOCPRiskZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.GLOCPRiskZipCode, key);

    public Task VerifyLocationZipCodeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LocationZipCode, expected, property);

    public Task<string> CaptureDescriptionOfSpecifiedOperationAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DescriptionOfSpecifiedOperation, property);

    public Task<string> CaptureVehicleSchedule1VehAsync(string property = "") =>
        _ui.CaptureAsync(_locators.VehicleSchedule1Veh, property);

    public Task EnterAdditionalOtherInterestInputLastNameAsync(string value) =>
        _ui.FillAsync(_locators.AdditionalOtherInterestInputLastName, value);

    public Task EnterEntityInfoFrameEntityInfoWindowFaxAsync(string value) =>
        _ui.FillAsync(_locators.EntityInfoFrameEntityInfoWindowFax, value);

    public Task EnterEntityInfoFrameEntityInfoWindowBureauNumberAsync(string value) =>
        _ui.FillAsync(_locators.EntityInfoFrameEntityInfoWindowBureauNumber, value);

    public Task EnterEntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefaultAsync(string value) =>
        _ui.FillAsync(_locators.EntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefault, value);



    public Task EnterTaxpayerIdAsync(string value) =>
    _ui.FillAsync(_locators.TaxpayerId, value);

    public Task EnterAVCostNewSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AVCostNew, value, delayMs);

    public Task EnterAWhatIsThePublicProtectionClassRatingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AWhatIsThePublicProtectionClassRating, value, delayMs);

    public Task EnterAddDriverNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddDriverName, value, delayMs);

    public Task EnterAdditionalOtherInterestAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestAddress, value, delayMs);

    public Task EnterAdditionalOtherInterestInputFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestInputFirstName, value, delayMs);

    public Task EnterAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Address, value, delayMs);

    public Task EnterCG2935AddLInsuredStateOrPoliticalPermitsAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestAddress, value, delayMs);

    public Task EnterGLOCPRiskAddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GLOCPRiskAddress, value, delayMs);

    public Task EnterAddressStreetCityStateZipSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddressStreetCityStateZip, value, delayMs);

    public Task EnterAggregateLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AggregateLimit, value, delayMs);

    public Task EnterAnnualGrossReceiptsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AnnualGrossReceipts, value, delayMs);

    public Task EnterAnyPersonalAutoPolicyListingNameInsuredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AnyPersonalAutoPolicyListingNameInsured, value, delayMs);

    public Task EnterAnyVehicleCoveredRegisteredInNotPrimaryStateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AnyVehicleCoveredRegisteredInNotPrimaryState, value, delayMs);

    public Task EnterAreAnySignsOffPremisesOrNotAttachedToBuildingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AreAnySignsOffPremisesOrNotAttachedToBuilding, value, delayMs);

    public Task EnterAreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AreThereAnyCommercialVehiclesOwnedByTheApplicantNotInsuredOnThePolicy, value, delayMs);

    public Task EnterAreThereAnyOfficersThatShouldBeExcludedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AreThereAnyOfficersThatShouldBeExcluded, value, delayMs);

    public Task EnterAudioVisualSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AudioVisual, value, delayMs);

    public Task EnterAvailableClassificationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AvailableClassifications, value, delayMs);

    public Task EnterAverageNumberOfDaysServiceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AverageNumberOfDaysService, value, delayMs);

    public Task EnterAverageNumberOfWorkingDaysSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AverageNumberOfWorkingDays, value, delayMs);

    public Task EnterAverageServiceChargeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AverageServiceCharge, value, delayMs);

    public Task EnterAverageValuePerOrderSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AverageValuePerOrder, value, delayMs);

    public Task EnterBAreThereAnyPrivateProtectionImprovementsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BAreThereAnyPrivateProtectionImprovements, value, delayMs);

    public Task EnterBG2SymbolSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BG2Symbol, value, delayMs);

    public Task EnterBG2SymbolPrefixSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BG2SymbolPrefix, value, delayMs);

    public Task EnterBillTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BillType, value, delayMs);

    public Task EnterBodyStyleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BodyStyle, value, delayMs);

    public Task EnterBoomDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BoomDeductible, value, delayMs);

    public Task EnterBorrowingHiringOrLeasingWithinYearSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BorrowingHiringOrLeasingWithinYear, value, delayMs);

    public Task EnterBuildingLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BuildingLimit, value, delayMs);

    public Task EnterBuildingRatingGroupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskInputRatingGroupID, value, delayMs);

    public Task EnterBusinessInterruptionDescriptionOfScheduledPropertySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessInterruptionDescriptionOfScheduledProperty, value, delayMs);

    public Task EnterBusinessInterruptionEndorsementSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessInterruptionEndorsement, value, delayMs);

    public Task EnterBusinessInterruptionLimitOfInsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessInterruptionLimitOfInsurance, value, delayMs);

    public Task EnterCA9940ContractProvisionsSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9940ContractProvisions, value, delayMs);

    public Task EnterCA9940MakeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CA9940Make, value, delayMs);

    public Task EnterCA9940ModelSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CA9940Model, value, delayMs);

    public Task EnterCA9940VINSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CA9940VIN, value, delayMs);

    public Task EnterCA9940YearSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CA9940Year, value, delayMs);

    public Task EnterCA9948ClassesOfCommoditiesTransportedSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.CA9948ClassesOfCommoditiesTransported, value, delayMs);

    public Task EnterCGLLimitsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CGLLimits, value, delayMs);

    public Task EnterCWhatIsTheDistanceInFeetToTheNearestHydrantSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CWhatIsTheDistanceInFeetToTheNearestHydrant, value, delayMs);

    public Task EnterCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Carrier, value, delayMs);

    public Task EnterCauseOfLossSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CauseOfLoss, value, delayMs);

    public Task EnterCitySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.City, value, delayMs);

    public Task EnterClassCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ClassCode, value, delayMs);

    public Task EnterClassCodeFrameClassCodeWindowSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ClassCodeFrameClassCodeWindow, value, delayMs);

    public Task EnterClassificationOfRiskSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ClassificationOfRisk, value, delayMs);

    public Task EnterAddClientSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AddClient, value, delayMs);

    public Task EnterPolicyCovgComputerSystemsCoinsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgComputerSystemsCoinsurance, value, delayMs);

    public Task EnterRatingGroupsCoinsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RatingGroupsCoinsurance, value, delayMs);

    public Task EnterPolicyCovgContractorsEquipmentCoinsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgContractorsEquipmentCoinsurance, value, delayMs);

    public Task EnterCollisionCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CollisionCoverage, value, delayMs);

    public Task EnterHiredAutoCollisionDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoCollisionDeductible, value, delayMs);

    public Task EnterCompanyNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CompanyName, value, delayMs);

    public Task EnterComputerEquipmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ComputerEquipment, value, delayMs);

    public Task EnterBuildingDetailConstructionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BuildingDetailConstruction, value, delayMs);

    public Task EnterRiskBaileesCustomersConstructionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersConstruction, value, delayMs);

    public Task EnterConstructionCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ConstructionCode, value, delayMs);

    public Task EnterRiskAccountsReceivableConstructionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskAccountsReceivableConstruction, value, delayMs);

    public Task EnterCoverageEndDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageEndDate, value, delayMs);

    public Task EnterPolicyCovgGLCoverageFormSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgGLCoverageForm, value, delayMs);

    public Task EnterRiskMainCoverageFormSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskMainCoverageForm, value, delayMs);

    public Task EnterCoverageFormToBeAddedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormToBeAdded, value, delayMs);

    public Task EnterCoverageTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageType, value, delayMs);

    public Task EnterCoveredPropertyConsistingPrincipallyOfSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoveredPropertyConsistingPrincipallyOf, value, delayMs);

    public Task EnterDWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, value, delayMs);

    public Task EnterDataAndMediaSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DataAndMedia, value, delayMs);

    public Task EnterDateOfBirthSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.DateOfBirth, value, delayMs);

    public Task EnterDateOfHireSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.DateOfHire, value, delayMs);

    public Task EnterDebrisRemovalAdditionalSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DebrisRemovalAdditional, value, delayMs);

    public Task EnterDebrisRemovalAdditionalLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DebrisRemovalAdditionalLimit, value, delayMs);

    public Task EnterDedTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DedType, value, delayMs);

    public Task EnterDedicatedLineSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DedicatedLine, value, delayMs);

    public Task EnterRatingGroupsDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RatingGroupsDeductible, value, delayMs);

    public Task EnterEndorsementIF0002WaterborneEquipmentDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EndorsementIF0002WaterborneEquipmentDeductible, value, delayMs);

    public Task EnterPolicyCovgMotorTruckCargoDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgMotorTruckCargoDeductible, value, delayMs);

    public Task EnterRiskBaileesCustomersDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersDeductible, value, delayMs);

    public Task EnterBuildingDetailDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BuildingDetailDeductible, value, delayMs);

    public Task EnterDeductibleBasisSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DeductibleBasis, value, delayMs);

    public Task EnterPolicyCovgContractorsEquipmentDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgContractorsEquipmentDeductible, value, delayMs);

    public Task EnterPolicyCovgComputerSystemsDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgComputerSystemsDeductible, value, delayMs);

    public Task EnterBuildingDetailDeductibleIncreasedTheftSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BuildingDetailDeductibleIncreasedTheft, value, delayMs);

    public Task EnterRatingGroupsDeductibleIncreasedTheftSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RatingGroupsDeductibleIncreasedTheft, value, delayMs);

    public Task EnterBuildingDetailDeductibleWindHailSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BuildingDetailDeductibleWindHail, value, delayMs);

    public Task EnterRatingGroupsDeductibleWindHailSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RatingGroupsDeductibleWindHail, value, delayMs);

    public Task EnterDefaultExpModTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DefaultExpModType, value, delayMs);

    public Task EnterDescribeAllHoldHarmlessAgreementsAndPleaseProvideACopySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescribeAllHoldHarmlessAgreementsAndPleaseProvideACopy, value, delayMs);

    public Task EnterPolicyCovgContractorsEquipmentDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormDescription, value, delayMs);

    public Task EnterPolicyCovgBaileesCutomersDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormDescription, value, delayMs);

    public Task EnterPolicyCovgComputerSystemsDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormDescription, value, delayMs);

    public Task EnterRatingGroupsDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RatingGroupsDescription, value, delayMs);

    public Task EnterPolicyCovgSignsDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormDescription, value, delayMs);

    public Task EnterPolicyCovgMotorTruckCargoDescriptionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageFormDescription, value, delayMs);

    public Task EnterDescriptionOfBusinessActivitesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfBusinessActivites, value, delayMs);

    public Task EnterDescriptionOfOperationSSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfOperationS, value, delayMs);

    public Task EnterDescriptionOfOperationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfOperations, value, delayMs);

    public Task EnterDescriptionOfSpecifiedOperationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionOfSpecifiedOperation, value, delayMs);

    public Task EnterDoYouHaveACDLLicenseSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.DoYouHaveACDLLicense, value, delayMs);

    public Task EnterDoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesAnyRiskGeneratePowerOtherThanPrivateWindmillsOrEmergencyBackup, value, delayMs);

    public Task EnterDoesTheApplicantWishToCoverAnySignsInsideTheirPremisesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesTheApplicantWishToCoverAnySignsInsideTheirPremises, value, delayMs);

    public Task EnterDoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirementSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesTheInsuredApplicantRequestAdditionalInsuredStatusWithoutAWrittenContractRequirement, value, delayMs);

    public Task EnterDoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesTheInsuredEnterIntoContractsInvolvingCommercialSnowRemovalIncludingSnowRemovalFromResidentialRoofs, value, delayMs);

    public Task EnterDoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DoesTheInsuredEverEnterIntoContractsForTasksNotContemplatedInTheCurrentLiabilityClassificationsOnThePolicy, value, delayMs);

    public Task EnterDryCleaningSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DryCleaning, value, delayMs);

    public Task EnterDuplicatedRecordsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DuplicatedRecords, value, delayMs);

    public Task EnterEAreNoSmokingRulesPostedAndEnforcedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EAreNoSmokingRulesPostedAndEnforced, value, delayMs);

    public Task EnterEMailSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EMail, value, delayMs);

    public Task EnterEarthquakeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Earthquake, value, delayMs);

    public Task EnterEasyPaySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EasyPay, value, delayMs);

    public Task EnterCommercialAutoEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialAutoEffectiveDate, value, delayMs);

    public Task EnterBusinessownersEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessownersEffectiveDate, value, delayMs);

    public Task EnterPolicyInfoRequiredAndOptionalFieldsEffectiveDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyInfoRequiredAndOptionalFieldsEffectiveDate, value, delayMs);

    public Task EnterEligibleForEnhancedWindRatingProgramSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EligibleForEnhancedWindRatingProgram, value, delayMs);

    public Task EnterCG2401NonBindingArbitrationEndorsementTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageEndorsementType, value, delayMs);

    public Task EnterBAPEndorsementsEndorsementTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LineEndorsementType, value, delayMs);

    public Task EnterEndorsementsPartnersOfficersAndOthersExclusionEndorsementTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CoverageEndorsementType, value, delayMs);

    public Task EnterEngineSizeCcSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EngineSizeCc, value, delayMs);

    public Task EnterEstimatedHighestValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EstimatedHighestValue, value, delayMs);

    public Task EnterEstimatorTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EstimatorType, value, delayMs);

    public Task EnterExcludedLiabilityConfidentialInformationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExcludedLiabilityConfidentialInformation, value, delayMs);

    public Task EnterExperienceModTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExperienceModType, value, delayMs);

    public Task EnterExperienceRatedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExperienceRated, value, delayMs);

    public Task EnterExperienceRatingOptionsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExperienceRatingOptions, value, delayMs);

    public Task EnterGeneralLiabilityExpirationDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GeneralLiabilityExpirationDate, value, delayMs);

    public Task EnterBusinessownersExpirationDateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessownersExpirationDate, value, delayMs);

    public Task EnterExposureSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Exposure, value, delayMs);

    public Task EnterExtendedEmployeeCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExtendedEmployeeCoverage, value, delayMs);

    public Task EnterExtraExpenseSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ExtraExpense, value, delayMs);

    public Task EnterFeetFromHydrantSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FeetFromHydrant, value, delayMs);

    public Task EnterFireDamageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.FireDamage, value, delayMs);

    public Task EnterStateDetailsDriveOtherCarFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.StateDetailsDriveOtherCarFirstName, value, delayMs);

    public Task EnterFirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.FirstName, value, delayMs);

    public Task EnterGCWSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GCW, value, delayMs);

    public Task EnterGroupClassSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GroupClass, value, delayMs);

    public Task EnterHasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiringSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HasAnyApplicantBeenConvictedOfAFelonyOrBeenInvolvedInAnyIncidentsOrClaimsRelatingToSexualAbuseOrMolestationAllegationsDiscriminationArsonFraudBriberyOrNegligentHiring, value, delayMs);

    public Task EnterHiredAutoCA2001AddressSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoCA2001Address, value, delayMs);

    public Task EnterHiredAutoCA2001FirstNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoCA2001FirstName, value, delayMs);

    public Task EnterHiredAutoCA2001LastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoCA2001LastName, value, delayMs);

    public Task EnterHiredAutoCA2001ZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoCA2001ZipCode, value, delayMs);

    public Task EnterHiredAutoExtAddlInsuredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoExtAddlInsured, value, delayMs);

    public Task EnterHiredAutoOKSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredAutoOK, value, delayMs);

    public Task EnterHiredEquipmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HiredEquipment, value, delayMs);

    public Task EnterHowOftenIsDataBackedUpSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.HowOftenIsDataBackedUp, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationSSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedFarmLocationS, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremisesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyAddressEsOrDescriptionSOfDesignatedPremises, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivitiesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyDescriptionOfPremisesOrActivities, value, delayMs);
    public Task EnterIFRAMEAggregateLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyAggregateLimit, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyExcludedDriverSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyExcludedDriver, value, delayMs);

    public Task EnterIFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalSSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IFRAMEDuckCreekPolicyNameSOrDescriptionSOfDesignatedAnimalS, value, delayMs);

    public Task EnterIfYesDescribeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IfYesDescribe, value, delayMs);

    public Task EnterIfYesExplainSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IfYesExplain, value, delayMs);

    public Task EnterIncreasedPollutantCleanupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IncreasedPollutantCleanup, value, delayMs);

    public Task EnterIndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocatedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IndicateTheBuildingSAgeTypeOfConstructionAndProtectionClassAndOtherTenantsInTheBuildingSWhereTheComputerEquipmentIsLocated, value, delayMs);

    public Task EnterInterestSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Interest, value, delayMs);

    public Task EnterIsTheBuildingCooledSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsTheBuildingCooled, value, delayMs);

    public Task EnterIsTheBuildingHeatedWithASolidFuelHeatingDeviceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsTheBuildingHeatedWithASolidFuelHeatingDevice, value, delayMs);

    public Task EnterIsTheInsuredEngagedInAnySnowOrIceRemovalOperationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsTheInsuredEngagedInAnySnowOrIceRemovalOperations, value, delayMs);

    public Task EnterIsThereAPriorCarrierSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsThereAPriorCarrier, value, delayMs);

    public Task EnterIsThisCoverageBoundSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsThisCoverageBound, value, delayMs);

    public Task EnterIsThisVehicleUsedInSnowPlowOperationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.IsThisVehicleUsedInSnowPlowOperations, value, delayMs);

    public Task EnterJavaScriptSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.JavaScript, value, delayMs);

    public Task EnterLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.LastName, value, delayMs);

    public Task EnterStateDetailsDriveOtherCarLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.StateDetailsDriveOtherCarLastName, value, delayMs);

    public Task EnterLaundrySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Laundry, value, delayMs);

    public Task EnterLetteringSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Lettering, value, delayMs);

    public Task EnterCommercialAutoLiabilityLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialAutoLiabilityLimit, value, delayMs);

    public Task EnterCommercialUMLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialUMLimit, value, delayMs);

    public Task PressCommercialUMLimitAsync(string key) =>
       _ui.PressAsync(_locators.CommercialUMLimit, key);

    public Task EnterSFP10LiabilityFarmLiabilityLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SFP10LiabilityFarmLiabilityLimit, value, delayMs);

    public Task EnterPolicyCovgBaileesPropertyAwayFromYourPremisesLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgBaileesPropertyAwayFromYourPremisesLimit, value, delayMs);

    public Task EnterEndorsementIF0002WaterborneEquipmentLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EndorsementIF0002WaterborneEquipmentLimit, value, delayMs);

    public Task EnterRiskBaileesCustomersLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersLimit, value, delayMs);

    public Task EnterLimitOfInsuranceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LimitOfInsurance, value, delayMs);

    public Task EnterLineConditionerSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LineConditioner, value, delayMs);

    public Task EnterListAllPoliciesWithAmericanNationalSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ListAllPoliciesWithAmericanNational, value, delayMs);

    public Task EnterLoanLeaseGapSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LoanLeaseGap, value, delayMs);

    public Task EnterLocationIDSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LocationID, value, delayMs);

    public Task EnterLocationOfCoveredOperationsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LocationOfCoveredOperations, value, delayMs);

    public Task EnterMakeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Make, value, delayMs);

    public Task EnterMaritalStatusSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.MaritalStatus, value, delayMs);

    public Task EnterMedicalSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Medical, value, delayMs);

    public Task EnterMeritRatingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.MeritRating, value, delayMs);

    public Task EnterMilesFromFireDepartmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.MilesFromFireDepartment, value, delayMs);

    public Task EnterMiscItemsBlanketCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.MiscItemsBlanketCoverage, value, delayMs);

    public Task EnterModelSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Model, value, delayMs);

    public Task EnterModificationFactorSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ModificationFactor, value, delayMs);

    public Task EnterN10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarmsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N10AreThePremisesEquippedWithARecognizedApprovedCentralStationFireAlarmFireExtinguishersOrSmokeAlarms, value, delayMs);

    public Task EnterN10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheftSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N10HowAreTheGoodsBeingTransportedProtectedFromDamageAndTheft, value, delayMs);

    public Task EnterN11AreDriversMVRsAndTripLogsMaintainedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N11AreDriversMVRsAndTripLogsMaintained, value, delayMs);

    public Task EnterN11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N11WhatIsTheProcedureForTransportingPropertyIncludeTheTransitMethodsUsedAndTheProtectionClassProvidedWhileInTransit, value, delayMs);

    public Task EnterN12AreDriversMVRsReviewedOnARegularBasisAndMaintainedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N12AreDriversMVRsReviewedOnARegularBasisAndMaintained, value, delayMs);

    public Task EnterN12HowOftenAreTheseLogsReviewedOrUpdatedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N12HowOftenAreTheseLogsReviewedOrUpdated, value, delayMs);

    public Task EnterN13LiveAnimalInTransitCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N13LiveAnimalInTransitCoverage, value, delayMs);

    public Task EnterN13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N13WhatTypesOfVehiclesDoYouOperateAndWhatProtectiveDevicesAreOnEachVehicle, value, delayMs);

    public Task EnterN14LegalLiabilityCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N14LegalLiabilityCoverage, value, delayMs);

    public Task EnterN14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N14WhatIsYourProcedureForProtectingSmallItemsFromBreakageOrDisappearanceWhileInStorage, value, delayMs);

    public Task EnterN15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheftSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N15WhatMeasuresDoesTheInsuredTakeToProtectCustomerSPropertyAgainstTheft, value, delayMs);

    public Task EnterN16DoesTheRiskUseReleaseFormsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N16DoesTheRiskUseReleaseForms, value, delayMs);

    public Task EnterN1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N1WhatAreTheDistancesTheShipmentsWillTravelAndTheTimeRequiredToCompleteTheShipment, value, delayMs);

    public Task EnterN2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremisesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N2IndicateTheAgeTypeOfConstructionAndProtectionClassOfThePremises, value, delayMs);

    public Task EnterN2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommoditiesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N2WhatAreTheTypesAndAgesOfTheVehiclesTrailersUsedToTransportYourCommodities, value, delayMs);

    public Task EnterN2ndClassCategorySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N2ndClassCategory, value, delayMs);

    public Task EnterN2ndClassCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N2ndClassCode, value, delayMs);

    public Task EnterN3DoesTheApplicantHaulForOthersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N3DoesTheApplicantHaulForOthers, value, delayMs);

    public Task EnterN3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepairSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N3WhatIsThePercentageOfAnnualGrossReceiptsDerivedFromServiceOrRepair, value, delayMs);

    public Task EnterN4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdatedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N4WhatMethodDoYouUseForKeepingRecordsOfPropertyInYourCareAndHowOftenAreTheRecordsUpdated, value, delayMs);

    public Task EnterN4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailerSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N4WhatProtectiveDevicesAreInstalledOnEachVehicleOrTrailer, value, delayMs);

    public Task EnterN5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintainedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N5AreRecognizedApprovedCentralStationBurglarAlarmsInstalledAndMaintained, value, delayMs);

    public Task EnterN5DeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N5Deductible, value, delayMs);

    public Task EnterN5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttachedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N5DoAnyVehiclesHaveSpecialEquipmentMountedOrAttached, value, delayMs);

    public Task EnterN6AreAllStorageAreasLockedAtAllTimesWhenUnoccupiedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N6AreAllStorageAreasLockedAtAllTimesWhenUnoccupied, value, delayMs);

    public Task EnterN6DoesTheApplicantPullDoubleOrTripleTrailersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N6DoesTheApplicantPullDoubleOrTripleTrailers, value, delayMs);

    public Task EnterN7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremisesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N7AreThereAnyHazardousOrFlammableMaterialsUsedOrStoredOnThePremises, value, delayMs);

    public Task EnterN7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattendedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N7DoesTheApplicantLeaveTheTruckWindowsDoorsAndCompartmentsClosedAndLockedWhenUnattended, value, delayMs);

    public Task EnterN8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N8DoYouProvideScheduledMaintenanceForTheVehiclesAndTrailersYouOperate, value, delayMs);

    public Task EnterN9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommoditiesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N9AreTheEmployeesThatPackLoadAndUnloadTrainedInProperHandlingOfTheCommodities, value, delayMs);

    public Task EnterN9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystemSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.N9AreThePremisesOrAnyPortionOfThePremisesEquippedWithASprinklerSystem, value, delayMs);

    public Task EnterNAICSCodeSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NAICSCodeSearchValue, value, delayMs);

    public Task EnterNameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServicesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NameSOrDescriptionSAndDateSOfDesignatedActivitiesOrServices, value, delayMs);

    public Task EnterNamesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Names, value, delayMs);

    public Task EnterNonOwnedAutoSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NonOwnedAuto, value, delayMs);

    public Task EnterNumberOfEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NumberOfEmployees, value, delayMs);

    public Task EnterNumberOfFullTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NumberOfFullTimeEmployees, value, delayMs);

    public Task EnterNumberOfPartTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NumberOfPartTimeEmployees, value, delayMs);

    public Task EnterNumberOfVehiclesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.NumberOfVehicles, value, delayMs);

    public Task EnterOTCCausesOfLossSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OTCCausesOfLoss, value, delayMs);

    public Task EnterStateDetailsHiredAutoPDWithoutDriverOTCDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.StateDetailsHiredAutoPDWithoutDriverOTCDeductible, value, delayMs);

    public Task EnterOccupancyTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OccupancyType, value, delayMs);

    public Task EnterOccupiedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Occupied, value, delayMs);

    public Task EnterOccurenceLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OccurenceLimit, value, delayMs);

    public Task EnterOfEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfEmployees, value, delayMs);

    public Task EnterOfFullTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfFullTimeEmployees, value, delayMs);

    public Task EnterOfPartTimeEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfPartTimeEmployees, value, delayMs);

    public Task EnterOfPartnersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfPartners, value, delayMs);

    public Task EnterOfSeasonalTemporaryEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfSeasonalTemporaryEmployees, value, delayMs);

    public Task EnterOfficersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Officers, value, delayMs);

    public Task EnterOfficersPositionHeldSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OfficersPositionHeld, value, delayMs);

    public Task EnterOrderAuditSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.OrderAudit, value, delayMs);

    public Task EnterOriginalCostNewSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskVehicleInputValueEstimate, value, delayMs);

    public Task EnterOthersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Others, value, delayMs);

    public Task EnterPartnersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Partners, value, delayMs);

    public Task EnterPayPlanSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PayPlan, value, delayMs);

    public Task EnterPerVehicleLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PerVehicleLimit, value, delayMs);

    public Task EnterPersAdvInjSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PersAdvInj, value, delayMs);

    public Task EnterPersonalPortableComputersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PersonalPortableComputers, value, delayMs);

    public Task EnterPersonalPropertyLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PersonalPropertyLimit, value, delayMs);

    public Task EnterPersonalPropertyRatingGroupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskInputRatingGroupID, value, delayMs);

    public Task EnterPierOrWharfSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PierOrWharf, value, delayMs);

    public Task EnterPierOrWharfCOLOptionsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PierOrWharfCOLOptions, value, delayMs);

    public Task EnterPierOrWharfCauseOfLossSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PierOrWharfCauseOfLoss, value, delayMs);

    public Task EnterPierOrWharfConstructionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PierOrWharfConstruction, value, delayMs);

    public Task EnterPleaseProvideWebsiteAddressEsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PleaseProvideWebsiteAddressEs, value, delayMs);

    public Task EnterPolicyHolderNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyHolderName, value, delayMs);

    public Task EnterCommercialAutoPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CommercialAutoPolicyNumber, value, delayMs);

    public Task EnterUMBLimitAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UMBILimit, value, delayMs);

    

    public Task EnterBusinessownersPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessownersPolicyNumber, value, delayMs);

    public Task EnterCPPLiabPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.CPPLiabilityPolicyNumber, value, delayMs);

    public Task EnterGeneralLiabilityPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GeneralLiabilityPolicyNumber, value, delayMs);

    public Task EnterSFPiabilityPolicyNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GeneralLiabilityPolicyNumber, value, delayMs);

    public Task EnterPolicyTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyType, value, delayMs);

    public Task EnterPowerSuppressorVoltageRegulatorSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PowerSuppressorVoltageRegulator, value, delayMs);

    public Task EnterPremOpDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PremOpDed, value, delayMs);

    public Task EnterPremOpPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PremOpPDDed, value, delayMs);

    public Task EnterPremisesTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PremisesType, value, delayMs);

    public Task EnterPrimaryRatingStateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PrimaryRatingState, value, delayMs);

    public Task EnterProdBIDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProdBIDed, value, delayMs);

    public Task EnterProdPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProdPDDed, value, delayMs);

    public Task EnterProduceCarriedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProduceCarried, value, delayMs);

    public Task EnterProductsAggLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProductsAggLimit, value, delayMs);

    public Task EnterProductsCompletedOperationsAggregateLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProductsCompletedOperationsAggregateLimit, value, delayMs);

    public Task EnterPolicyCovgComputerSystemsPropertyInTransitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgComputerSystemsPropertyInTransit, value, delayMs);

    public Task EnterPolicyCovgBaileesCutomersPropertyInTransitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyCovgBaileesCutomersPropertyInTransit, value, delayMs);

    public Task EnterPropertyOfOthersLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PropertyOfOthersLimit, value, delayMs);

    public Task EnterPropertyOfOthersRatingGroupSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskInputRatingGroupID, value, delayMs);

    public Task EnterProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWestSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProvideAListOfSurroundingExposureOtherOccupanciesWithin100FtIncludingNorthEastSouthAndWest, value, delayMs);

    public Task EnterProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMediaSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ProvideInformationRegardingAntivirusMethodsAndCopyrightProtectionOfDataAndMedia, value, delayMs);

    public Task EnterRentalReimbursementSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RentalReimbursement, value, delayMs);

    public Task EnterRentedEquipmentExpenseSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RentedEquipmentExpense, value, delayMs);

    public Task EnterRequestedUmbrellaLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RequestedUmbrellaLimit, value, delayMs);

    public Task EnterRiskTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskType, value, delayMs);

    public Task EnterRoofTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RoofType, value, delayMs);

    public Task EnterScheduledCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ScheduledCoverage, value, delayMs);

    public Task EnterRiskComputerSystemsSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskComputerSystemsSearchResult, value, delayMs);

    public Task EnterRiskBaileesCustomersSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersSearchResult, value, delayMs);

    public Task EnterRiskAccountsReceivableSearchResultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskAccountsReceivableSearchResult, value, delayMs);

    public Task EnterSearchResultsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchResults, value, delayMs);

    public Task EnterSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchValue, value, delayMs);

    public Task EnterPropertyAddClassSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PropertyAddClassSearchValue, value, delayMs);

    public Task EnterRiskAccountsReceivableSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskAccountsReceivableSearchValue, value, delayMs);

    public Task EnterRiskComputerSystemsSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskComputerSystemsSearchValue, value, delayMs);

    public Task EnterRiskBaileesCustomersSearchValueSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskBaileesCustomersSearchValue, value, delayMs);

    public Task EnterSeasonalProduceTrailersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SeasonalProduceTrailers, value, delayMs);

    public Task EnterSelectAppropriateCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SelectAppropriateCode, value, delayMs);

    public Task EnterSelectClassCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SelectClassCode, value, delayMs);

    public Task EnterSelectEndorsementSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LineEndorsementType, value, delayMs);

    public Task EnterSDescriptionLocationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.DescriptionLocation, value, delayMs);

    public Task EnterSexSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.Sex, value, delayMs);

    public Task EnterSignLocationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SignLocation, value, delayMs);

    public Task EnterSmallDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SmallDeductible, value, delayMs);

    public Task EnterSoleProprietorsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SoleProprietors, value, delayMs);

    public Task EnterSplitPDDedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SplitPDDed, value, delayMs);

    public Task EnterSquareFeetSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SquareFeet, value, delayMs);

    public Task EnterPolicyHolderStateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.PolicyHolderState, value, delayMs);

    public Task EnterEndorsementsDesignatedWorkplacesExclusionStateSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EndorsementsDesignatedWorkplacesExclusionState, value, delayMs);

    public Task EnterStateLicensedSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.StateLicensed, value, delayMs);

    public Task EnterStateOrPoliticalSubdivisionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.StateOrPoliticalSubdivision, value, delayMs);

    public Task EnterStatedAmountSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskVehicleInputValueEstimate, value, delayMs);

    public Task EnterStorageLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.StorageLimit, value, delayMs);

    public Task EnterStoriesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Stories, value, delayMs);

    public Task EnterTapesCoverageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TapesCoverage, value, delayMs);

    public Task EnterTextBoxSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TextBox, value, delayMs);

    public Task EnterTitleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Title, value, delayMs);

    public Task EnterToolsAndClothingBelongingToYourEmployeesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ToolsAndClothingBelongingToYourEmployees, value, delayMs);

    public Task EnterTotalCostOfWorkSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalCostOfWork, value, delayMs);

    public Task EnterTotalPayrollEstimatedSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalPayrollEstimated, value, delayMs);

    public Task EnterTotalPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TotalPremium, value, delayMs);

    public Task EnterGeneralLiabilityTotalSubjectPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GeneralLiabilityTotalSubjectPremium, value, delayMs);

    public Task EnterBusinessownersTotalSubjectPremiumSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.BusinessownersTotalSubjectPremium, value, delayMs);

    public Task EnterTowingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Towing, value, delayMs);

    public Task EnterTrailerInterchangeCollisionDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TrailerInterchangeCollisionDeductible, value, delayMs);

    public Task EnterTrailerInterchangeCompDeductibleSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TrailerInterchangeCompDeductible, value, delayMs);

    public Task EnterTrailerInterchangeEnterDaysInsuredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TrailerInterchangeEnterDaysInsured, value, delayMs);

    public Task EnterTrailerInterchangeEnterOfTrailersSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TrailerInterchangeEnterOfTrailers, value, delayMs);

    public Task EnterFG0013AutomaticAdditionalInsuredSpecificRelationshipTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestType, value, delayMs);

    public Task EnterEndorsementMainTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EndorsementMainType, value, delayMs);

    public Task EnterGLOCPRiskTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GLOCPRiskType, value, delayMs);

    public Task EnterCG2007AddLInsuredEngineersArchitectsTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestType, value, delayMs);

    public Task EnterRiskSignsTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.RiskSignsType, value, delayMs);

    public Task EnterTypeOfContractorSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TypeOfContractor, value, delayMs);

    public Task EnterTypeOfEquipmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TypeOfEquipment, value, delayMs);

    public Task EnterTypeOfInterestSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.AdditionalOtherInterestType, value, delayMs);

    public Task EnterTypeOfLicenseSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.TypeOfLicense, value, delayMs);

    public Task EnterUMBILimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UMBILimit, value, delayMs);

    public Task EnterUMTypeDefaultSelectionsSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UMTypeDefaultSelections, value, delayMs);

    public Task EnterUmbrellaLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UmbrellaLimit, value, delayMs);

    public Task EnterUninterruptiblePowerSourceSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UninterruptiblePowerSource, value, delayMs);

    public Task EnterUnnamedPremisesSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UnnamedPremises, value, delayMs);

    public Task EnterUnnamedTerminalsLimitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UnnamedTerminalsLimit, value, delayMs);

    public Task EnterUsedAsShowroomSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.UsedAsShowroom, value, delayMs);

    public Task EnterVINSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VIN, value, delayMs);

    public Task EnterVacancyPermitSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VacancyPermit, value, delayMs);

    public Task EnterVacantBuildingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VacantBuilding, value, delayMs);

    public Task EnterValuationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Valuation, value, delayMs);

    public Task EnterValuationTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ValuationType, value, delayMs);

    public Task EnterValueBasisSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ValueBasis, value, delayMs);

    public Task EnterVehicleInformationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VehicleInformation, value, delayMs);

    public Task EnterVehicleTypeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VehicleType, value, delayMs);

    public Task EnterVirusHarmfulCodeOrSimilarInstructionSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.VirusHarmfulCodeOrSimilarInstruction, value, delayMs);

    public Task EnterWaiverOfSubrogationSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WaiverOfSubrogation, value, delayMs);

    public Task EnterWaiverOfSubrogationExposureSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WaiverOfSubrogationExposure, value, delayMs);

    public Task EnterWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90Days, value, delayMs);

    public Task EnterWhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecuredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatAreTheProceduresAndMethodsForKeepingTheEDPAreasSecured, value, delayMs);

    public Task EnterWhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorageSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatAreTheProceduresAndScheduleForBackingUpTheMediaAndDataAndTheirStorage, value, delayMs);

    public Task EnterWhatIsTheConstructionOfEachSignSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsTheConstructionOfEachSign, value, delayMs);

    public Task EnterWhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStoredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsTheConstructionOfThePremisesWhereTheReceivablesAreStored, value, delayMs);

    public Task EnterWhatIsTheDistanceInFeetToTheNearestFireHydrantSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsTheDistanceInFeetToTheNearestFireHydrant, value, delayMs);

    public Task EnterWhatIsTheDistanceInMilesToTheNearestRespondingFireDepartmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsTheDistanceInMilesToTheNearestRespondingFireDepartment, value, delayMs);

    public Task EnterWhatIsTheProcedureForTransportingTheComputerEquipmentSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsTheProcedureForTransportingTheComputerEquipment, value, delayMs);

    public Task EnterWhatIsThePublicProtectionClassRatingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatIsThePublicProtectionClassRating, value, delayMs);

    public Task EnterWhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheftSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhatSafeguardsAreInPlaceForReceivablesToProtectAgainstDamageOrTheft, value, delayMs);

    public Task EnterWhichFormAreYouCompletingSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhichFormAreYouCompleting, value, delayMs);

    public Task EnterWhyIsThisCoverageDesiredSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.WhyIsThisCoverageDesired, value, delayMs);

    public Task EnterYearSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.Year, value, delayMs);

    public Task EnterYearBuiltSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.YearBuilt, value, delayMs);

    public Task EnterYearLicensedSequentiallyAsync(string value, int delayMs = 20) =>
        ComponentAwareControlActions.DomPressSequentiallyAsync(_locators.YearLicensed, value, delayMs);

    public Task EnterYearsInBusinessSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.YearsInBusiness, value, delayMs);

    public Task EnterLocationZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.LocationZipCode, value, delayMs);

    public Task EnterThirdPartyDesigneeZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.ThirdPartyDesigneeZipCode, value, delayMs);

    public Task EnterGLOCPRiskZipCodeSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.GLOCPRiskZipCode, value, delayMs);

    public Task EnterAdditionalOtherInterestInputLastNameSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.AdditionalOtherInterestInputLastName, value, delayMs);

    public Task EnterEntityInfoFrameEntityInfoWindowFaxSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EntityInfoFrameEntityInfoWindowFax, value, delayMs);

    public Task EnterEntityInfoFrameEntityInfoWindowBureauNumberSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EntityInfoFrameEntityInfoWindowBureauNumber, value, delayMs);

    public Task EnterEntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefaultSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.EntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefault, value, delayMs);
}
