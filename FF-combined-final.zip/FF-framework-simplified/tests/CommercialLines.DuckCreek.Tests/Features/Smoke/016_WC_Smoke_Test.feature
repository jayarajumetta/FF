@CLDC @WC @smoke_test @wc_smoke_test @cldc_smoke_test

Feature: WC Smoke Test
  As a Commercial Lines Duck Creek policy processing user
  I want to complete the WC Smoke Test workflow
  So that the business transaction is executed with source-traceable data and verification

Background: Prepare Commercial Lines Duck Creek for policy processing
	Given I open a browser session
Scenario Outline: WC Smoke Test - <stateCode>
	Given test data "<dataFile>" and external data "<externalDataFile>" are loaded
	And I open the configured Commercial Lines Duck Creek application
	And I sign in to Commercial Lines Duck Creek using configured credentials
	And I start a new quote
	And I enter business client information
	And I add a new Associated Client - Business Owner Type - Click Add Client
	And I complete the Associated Client Info
	And I complete required policy information
	And I complete WC Specific Fields
	And I run insurance score
	And I navigate to Policy Info and Verify Desc
	And I click on QA button to logout
	And I open the configured Commercial Lines Duck Creek application
	And I sign in to Commercial Lines Duck Creek using configured credentials
	And I search for the quote description using quick search

Examples:
	| stateCode | dataFile                                           | stateVariant | stateName      | externalDataFile                    |
	| AL        | TestData/Scenarios/Smoke/016_wc_smoke_test_al.json | AL           | Alabama        | TestData/ExternalDataOverrides.json |
	| AR        | TestData/Scenarios/Smoke/016_wc_smoke_test_ar.json | AR           | Arkansas       | TestData/ExternalDataOverrides.json |
	| AZ        | TestData/Scenarios/Smoke/016_wc_smoke_test_az.json | AZ           | Arizona        | TestData/ExternalDataOverrides.json |
	| CT        | TestData/Scenarios/Smoke/016_wc_smoke_test_ct.json | CT           | Connecticut    | TestData/ExternalDataOverrides.json |
	| CO        | TestData/Scenarios/Smoke/016_wc_smoke_test_co.json | CO           | Colorado       | TestData/ExternalDataOverrides.json |
	#| DE        | TestData/Scenarios/Smoke/016_wc_smoke_test_de.json | DE           | Delaware       | TestData/ExternalDataOverrides.json |
	#| IA        | TestData/Scenarios/Smoke/016_wc_smoke_test_ia.json | IA           | Iowa           | TestData/ExternalDataOverrides.json |
	#| ID        | TestData/Scenarios/Smoke/016_wc_smoke_test_id.json | ID           | Idaho          | TestData/ExternalDataOverrides.json |
	#| IL        | TestData/Scenarios/Smoke/016_wc_smoke_test_il.json | IL           | Illinois       | TestData/ExternalDataOverrides.json |
	#| IN        | TestData/Scenarios/Smoke/016_wc_smoke_test_in.json | IN           | Indiana        | TestData/ExternalDataOverrides.json |
	#| KS        | TestData/Scenarios/Smoke/016_wc_smoke_test_ks.json | KS           | Kansas         | TestData/ExternalDataOverrides.json |
	#| KY        | TestData/Scenarios/Smoke/016_wc_smoke_test_ky.json | KY           | Kentucky       | TestData/ExternalDataOverrides.json |
	#| MA        | TestData/Scenarios/Smoke/016_wc_smoke_test_ma.json | MA           | Massachusetts  | TestData/ExternalDataOverrides.json |
	#| MD        | TestData/Scenarios/Smoke/016_wc_smoke_test_md.json | MD           | Maryland       | TestData/ExternalDataOverrides.json |
	#| MN        | TestData/Scenarios/Smoke/016_wc_smoke_test_mn.json | MN           | Minnesota      | TestData/ExternalDataOverrides.json |
	#| MO        | TestData/Scenarios/Smoke/016_wc_smoke_test_mo.json | MO           | Missouri       | TestData/ExternalDataOverrides.json |
	#| MS        | TestData/Scenarios/Smoke/016_wc_smoke_test_ms.json | MS           | Mississippi    | TestData/ExternalDataOverrides.json |
	#| MT        | TestData/Scenarios/Smoke/016_wc_smoke_test_mt.json | MT           | Montana        | TestData/ExternalDataOverrides.json |
	#| NE        | TestData/Scenarios/Smoke/016_wc_smoke_test_ne.json | NE           | Nebraska       | TestData/ExternalDataOverrides.json |
	#| NH        | TestData/Scenarios/Smoke/016_wc_smoke_test_nh.json | NH           | New Hampshire  | TestData/ExternalDataOverrides.json |
	#| NJ        | TestData/Scenarios/Smoke/016_wc_smoke_test_nj.json | NJ           | New Jersey     | TestData/ExternalDataOverrides.json |
	#| NM        | TestData/Scenarios/Smoke/016_wc_smoke_test_nm.json | NM           | New Mexico     | TestData/ExternalDataOverrides.json |
	#| NV        | TestData/Scenarios/Smoke/016_wc_smoke_test_nv.json | NV           | Nevada         | TestData/ExternalDataOverrides.json |
	#| NY        | TestData/Scenarios/Smoke/016_wc_smoke_test_ny.json | NY           | New York       | TestData/ExternalDataOverrides.json |
	#| OK        | TestData/Scenarios/Smoke/016_wc_smoke_test_ok.json | OK           | Oklahoma       | TestData/ExternalDataOverrides.json |
	#| PA        | TestData/Scenarios/Smoke/016_wc_smoke_test_pa.json | PA           | Pennsylvania   | TestData/ExternalDataOverrides.json |
	#| RI        | TestData/Scenarios/Smoke/016_wc_smoke_test_ri.json | RI           | Rhode Island   | TestData/ExternalDataOverrides.json |
	#| SC        | TestData/Scenarios/Smoke/016_wc_smoke_test_sc.json | SC           | South Carolina | TestData/ExternalDataOverrides.json |
	#| SD        | TestData/Scenarios/Smoke/016_wc_smoke_test_sd.json | SD           | South Dakota   | TestData/ExternalDataOverrides.json |
	#| TN        | TestData/Scenarios/Smoke/016_wc_smoke_test_tn.json | TN           | Tennessee      | TestData/ExternalDataOverrides.json |
	#| UT        | TestData/Scenarios/Smoke/016_wc_smoke_test_ut.json | UT           | Utah           | TestData/ExternalDataOverrides.json |
	#| VA        | TestData/Scenarios/Smoke/016_wc_smoke_test_va.json | VA           | Virginia       | TestData/ExternalDataOverrides.json |
	#| VT        | TestData/Scenarios/Smoke/016_wc_smoke_test_vt.json | VT           | Vermont        | TestData/ExternalDataOverrides.json |
	#| WV        | TestData/Scenarios/Smoke/016_wc_smoke_test_wv.json | WV           | West Virginia  | TestData/ExternalDataOverrides.json |
