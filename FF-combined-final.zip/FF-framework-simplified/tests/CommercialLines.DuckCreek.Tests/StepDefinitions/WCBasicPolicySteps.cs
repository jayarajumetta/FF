using InsuranceAutomation.CLDC.Pages;
using InsuranceAutomation.Core;
using Microsoft.Playwright;
using Microsoft.VisualBasic;
using NUnit.Framework;
using Reqnroll;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace InsuranceAutomation.CLDC.StepDefinitions;

[Binding, Scope(Feature = "WC Basic Policy")]
public sealed class WCBasicPolicySteps
{
    private readonly ScenarioContext _scenario;
    public WCBasicPolicySteps(ScenarioContext scenario) => _scenario = scenario;




    [Given(@"^I start a new quote$")]
    [When(@"^I start a new quote$")]
    [Then(@"^I start a new quote$")]
    public async Task StartANewQuoteAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new ProposalPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickNewQuoteAsync();
        await page.EnterEffectiveDateAsync(data.Resolve("{{data:effective_date_43}}"));
        await page.EnterProductAsync(data.Resolve("{{data:product_45}}"));
        await page.EnterProducerAsync(data.Resolve("{{data:producer_46}}"));
        await page.WaitForStartAsync("Visible");
        await page.ClickStartAsync();

    }






    [Given(@"^I enter business client information$")]
    [When(@"^I enter business client information$")]
    [Then(@"^I enter business client information$")]
    public async Task EnterBusinessClientInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();
        data.GenerateRandom("PrimaryPhone_0041", "[0-9]{10}");
        data.GenerateRandom("FEIN_0044", "486[0-9]{6}");
        data.GenerateRandom("AuditTelephone_0045", "[0-9]{10}");
        data.GenerateRandom("InspectionTelephone_0045", "[0-9]{10}");

        var page = new ClientSearchPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());


        await page.WaitForQuickQuoteAsync("Exists");
        await page.SetQuickQuoteAsync(data.Resolve("{{data:quick_quote_2}}"));
        await page.WaitForUnderwritingInfoAsync("Exists");
        await page.EnterInsuredTypeAsync(data.Resolve("{{data:insured_type_4}}"));
        await page.EnterEntityTypeAsync(data.Resolve("{{data:entity_type_8}}"));
        await page.WaitForBusinessNameAsync("Visible");
        await page.EnterBusinessNameAsync(data.Resolve("{{data:business_name_7}}"));
        await page.EnterPrimaryPhoneAsync(data.Resolve("{{runtime:PrimaryPhone_0041}}"));
        await page.EnterNamedInsuredZipCodeAsync(data.Resolve("{{data:zipcode_11}}"));
        await page.EnterAddressAsync(data.Resolve("{{data:address1_12}}"));
        await page.VerifyYearsInBusinessAsync("Exists", "");
        await page.EnterYearsInBusinessAsync(data.Resolve("{{data:years_in_business_14}}"));
        await page.EnterFEINAsync(data.Resolve("{{runtime:FEIN_0044}}"));
        await page.EnterNameOfAuditContactAsync(data.Resolve("{{data:name_of_audit_contact_16}}"));
        await page.EnterAuditTelephoneAsync(data.Resolve("{{runtime:AuditTelephone_0045}}"));
        await page.EnterNameOfInspectionContactAsync(data.Resolve("{{data:name_of_inspection_contact_18}}"));
        await page.EnterInspectionTelephoneAsync(data.Resolve("{{runtime:InspectionTelephone_0045}}"));
        await page.EnterInsuredEMailAddressAsync(data.Resolve("{{data:insured_e_mail_address_20}}"));
        await page.EnterWebsiteAddressAsync(data.Resolve("{{data:website_address_21}}"));
        await page.VerifyNamedInsuredZipCodeAsync("[0-9]{5}-[0-9]{4}", "Regex:value");

    }

    [Given(@"^I add a new Associated Client \- Business Owner Type \- Click Add Client$")]
    [When(@"^I add a new Associated Client \- Business Owner Type \- Click Add Client$")]
    [Then(@"^I add a new Associated Client \- Business Owner Type \- Click Add Client$")]
    public async Task AddANewAssociatedClientBusinessOwnerTypeClickAddClientAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PolicyWorkflowPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.WaitForAddClientAsync("Exists");
        await page.ClickAddClientAsync();
        await page.VerifyIndividualTypeAsync("Absent", "");

    }

    [Given(@"^I complete aJAX Error Check$")]
    [When(@"^I complete aJAX Error Check$")]
    [Then(@"^I complete aJAX Error Check$")]
    public async Task CompleteAJAXErrorCheckAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PolicyWorkflowPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.VerifyAJAXErrorCheckAsync("Exists", "");

    }

    [Given(@"^I complete required billing information$")]
    [When(@"^I complete required billing information$")]
    [Then(@"^I complete required billing information$")]
    public async Task CompleteRequiredBillingInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        //await page.ClickNavigationBillingAsync();
        //await page.WaitForBillingAsync("Exists");
        //await page.EnterBillTypeAsync(data.Resolve("{{data:bill_type_37}}"));
        //await page.WaitForBillTypeAsync("Equal");
        //await page.EnterPayPlanAsync(data.Resolve("{{data:pay_plan_40}}"));
        //await page.WaitForPayPlanAsync("Equal");
        //await page.WaitForEasyPayAsync("Exists");
        //await page.EnterEasyPayAsync(data.Resolve("{{data:easy_pay_44}}"));

    }

    [Given(@"^I complete the Associated Client Info$")]
    [When(@"^I complete the Associated Client Info$")]
    [Then(@"^I complete the Associated Client Info$")]
    public async Task CompleteTheAssociatedClientInfoAsync()
    {
        var data = _scenario.Get<ScenarioData>();
        data.GenerateRandom("MiddleName_0057", "^[a-z]{1}$");
        data.GenerateRandom("LastName_0057", "^[a-z]{7}$");
        data.GenerateRandom("FirstName_0057", "^[a-z]{4}$");

        var page = new ClientSearchPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.EnterIndividualTypeAsync(data.Resolve("{{data:wc_add_associated_client_individual_type}}"));
        await page.WaitForPleaseVerifySSNAsync("Exists");
        await page.EnterFirstNameAsync(data.Resolve("{{data:wc_add_associated_client_first_name}}"));
        await page.EnterMiddleNameAsync(data.Resolve("{{runtime:MiddleName_0057}}"));
        await page.EnterLastNameAsync(data.Resolve("{{runtime:LastName_0057}}"));
        await page.EnterAddAssociatedClientDateOfBirthAsync(data.Resolve("{{data:dateofbirth_52}}"));
        await page.EnterAddressAsync(data.Resolve("{{data:addclientAddress_1}}"));
        await page.EnterCityAsync(data.Resolve("{{data:city_54}}"));
        await page.EnterStateAsync(data.Resolve("{{data:AddClientState_49}}"));
        await page.EnterNamedInsuredZipCodeAsync(data.Resolve("{{data:AddClientZipcode_48}}"));
        await page.EnterGenderAsync(data.Resolve("{{data:gender_57}}"));
        await page.WaitForClientSearchAsync("Exists");
        await page.ClickClientSearchAsync();
        //await page.EnterFirstNameAsync(data.Resolve("{{runtime:FirstName_0057}}"));
        //await page.VerifySearchResultsDuckCreekPolicyFirstCheckboxAsync("Absent", "");
        await page.ClickOKAsync();
        await page.ClickOrderSSNAsync();
        await page.PressAddAssociatedClientEnterSSNAsync("Enter");
        await page.EnterAddAssociatedClientEnterSSNAsync(data.Resolve("{{data:wc_add_associated_client_ssn}}"));
        await page.ClickVerifyAsync();
        await page.VerifyVerifyAsync("Absent", "");
        await page.ClickCompleteAsync();
        //await page.ClickAddAssociatedClientDetailAsync();
        //await page.WaitForAddAssociatedClientEnterSSNAsync("Exists");
        //await page.ClickVerifyAsync();
        //await page.WaitForPleaseVerifySSNAsync("Absent");
        //await page.ClickCompleteAsync();
        //await page.WaitForAddAssociatedClientEnterSSNAsync("Exists");
        //await page.ClickVerifyAsync();
        //await page.WaitForPleaseVerifySSNAsync("Absent");
        //await page.ClickCompleteAsync();
        await page.WaitForClientSearchAsync("Exists");
        await page.ClickClientSearchAsync();

        await page.WaitForOKAsync("Exists");
        await page.ClickOKAsync();
        await page.WaitForClientSearchAsync("Absent");

    }

    [Given(@"^I navigate to Underwriting Info Screen$")]
    [When(@"^I navigate to Underwriting Info Screen$")]
    [Then(@"^I navigate to Underwriting Info Screen$")]
    public async Task NavigateToUnderwritingInfoScreenAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickUnderwritingInfoAsync();
        //await page.WaitForIsThereAPriorCarrierAsync("Exists");
        await page.EnterIsThereAPriorCarrierAsync(data.Resolve("{{data:is_there_a_prior_carrier_85}}"));
        await page.WaitForCarrierAsync("Exists");
        await page.EnterCarrierAsync(data.Resolve("{{data:wc_prior_carrier_name}}"));
        await page.EnterGeneralLiabilityPolicyNumberAsync(data.Resolve("{{data:wc_general_liability_policy_number}}"));
        await page.EnterPolicyTypeAsync(data.Resolve("{{data:wc_policy_type}}"));
        await page.EnterCommercialAutoEffectiveDateAsync(data.Resolve("{DATE[][-2y][MM'/'dd'/'yyyy]}"));
        await page.EnterGeneralLiabilityExpirationDateAsync(data.Resolve("{DATE[][][MM'/'dd'/'yyyy]}"));
        await page.EnterModificationFactorAsync(data.Resolve("{{data:modificationfactor_92}}"));
        await page.EnterTotalPremiumAsync(data.Resolve("{{data:total_premium_93}}"));
        await page.ClickOKAsync();
        //await page.WaitForUnderwritingInfoOtherInsuranceHistoryDetailAsync("Exists");
        await page.ClickLossExperienceAsync();
        //await page.WaitForNoKnownLossesAsync("Exists");
        //await page.SetNoKnownLossesAsync(data.Resolve("{{data:no_known_losses_98}}"));
        await page.ClickReturnToQuoteAsync();
        //await page.EnterTitleAsync(data.Resolve("{{data:title_100}}"));
        //await page.EnterJavaScriptAsync(data.Resolve("{{data:javascript_101}}"));
        //await page.VerifyResultAsync(data.Resolve("{{data:expected_result_value_102}}"), "value");

    }





    [Given(@"^I complete required policy information$")]
    [When(@"^I complete required policy information$")]
    [Then(@"^I complete required policy information$")]
    public async Task CompleteRequiredPolicyInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickPolicyInfoAsync();
        //await page.WaitForPolicyInfoHeaderAsync("Exists");
        await page.EnterPolicyInfoRequiredAndOptionalFieldsEffectiveDateAsync(data.Resolve("{{data:effectivedate_106}}"));
        await page.EnterWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysAsync(data.Resolve("{{data:were_the_exposures_insured_on_this_policy_previously_insured_for_this_client_on_another_farm_family_american_national_policy_within_the_last_90_days_109}}"));


        //await page.EnterWereTheExposuresInsuredOnThisPolicyPreviouslyInsuredForThisClientOnAnotherFarmFamilyAmericanNationalPolicyWithinTheLast90DaysSequentiallyAsync("{{data:were_the_exposures_insured_on_this_policy_previously_insured_for_this_client_on_another_farm_family_american_national_policy_within_the_last_90_days_113}}"));
        await page.VerifyPriorAmericanNationalPolicyAsync("Absent", "");
        await page.VerifyWhatIsThePrimaryReasonThisNewPolicyIsBeingRewrittenWithFarmFamilyAmericanNationalAsync("Absent", "");
        await page.VerifyIsThisPolicyBeingFullyCancelledAsync("Absent", "");
        //await page.WaitForPolicyInfoHeaderAsync("Visible");
        await page.WaitForDescriptionOfSpecifiedOperationAsync("Visible");
        await page.EnterDescriptionOfSpecifiedOperationAsync(data.BuildQuoteDescription());

        if (data.Condition("State ==\"VT\" || State ==\"NY\" || State == \"PA\" || State == \"MD\""))
        {
            await page.EnterWorkplaceSafetyRiskManagementAsync(data.Resolve("{{data:were_the_exposures_insured_on_this_policy_previously_insured_for_this_client_on_another_farm_family_american_national_policy_within_the_last_90_days_113}}"));

        }



        data.Set("QuoteDescription", await page.CaptureDescriptionOfSpecifiedOperationAsync("value"));

    }

    [Given(@"^I complete WC Specific Fields$")]
    [When(@"^I complete WC Specific Fields$")]
    [Then(@"^I complete WC Specific Fields$")]
    public async Task CompleteWCSpecificFieldsAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PolicyWorkflowPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.EnterHasTheApplicantBeenInBusinessForAtLeast3YearsWithContinuousWorkersCompensationCoverageAsync(data.Resolve("{{data:has_the_applicant_been_in_business_for_at_least_3_years_with_continuous_workers_compensation_coverage_123}}"));

    }

    [Given(@"^I complete Estimated premium$")]
    [When(@"^I complete Estimated premium$")]
    [Then(@"^I complete Estimated premium$")]
    public async Task CompleteEstimatedPremiumAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PricingPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        if (data.Condition("'Estimated Premium' == NULL"))
        {
            await page.VerifyEstimatedPremiumAsync("Absent", "");
        }

        if (data.Condition("State == \"NY\"")){

            await page.EnterWCEstimatedPremiumAsync(data.Resolve("{{data:wc_estimated_premium}}"));

                }

    }

    [Given(@"^I complete coverage Information$")]
    [When(@"^I complete coverage Information$")]
    [Then(@"^I complete coverage Information$")]
    public async Task CompleteCoverageInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickPolicyCovgerageAsync();


        if (await page.IsPrimaryLocationAvailableAsync())
        {
            await page.WaitForPrimaryLocationStateAsync("Exists");
            await page.EnterPrimaryStateAsync(data.Resolve("{{data:PrimaryLocationstate_53}}"));

        }


        //await page.VerifyPrimaryLocationStateAsync("(?i)^Alabama$", "Regex:value");
        //await page.EnterExperienceRatedAsync(data.Resolve("{{data:experience_rated_128}}"));

    }

    [Given(@"^I complete Address 1$")]
    [When(@"^I complete Address 1$")]
    [Then(@"^I complete Address 1$")]
    public async Task CompleteAddress1Async()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickWCNavigationLinksLocationAsync();
        //await page.WaitForLocationAddressAsync("Exists");
        await page.VerifyLocationZipCodeAsync("[0-9]{5}-[0-9]{4}", "Regex:value");
        await page.ClickOKAsync();

    }

    [Given(@"^I complete rating Information$")]
    [When(@"^I complete rating Information$")]
    [Then(@"^I complete rating Information$")]
    public async Task CompleteRatingInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickStateDetailsAsync();
        await page.WaitForIntrastateRiskIDAsync("Exists");

    }

    [Given(@"^I add Class Codes$")]
    [When(@"^I add Class Codes$")]
    [Then(@"^I add Class Codes$")]
    public async Task AddClassCodesAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickWCScheduleAsync();
        await page.WaitForAddClassCodeAsync("Exists");
        await page.ClickAddClassCodeAsync();
        await page.VerifyOKClassCodeAsync("Absent", "");
        await page.WaitForSearchValueAsync("Exists");
        await page.EnterSearchValueAsync(data.Resolve("{{data:class_code_frame_class_code_window_searchvalue_141}}"));
        await page.EnterSelectClassCodeAsync(data.Resolve("{{data:class_code_frame_class_code_window_select_class_code_143}}"));
        await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
        await page.VerifySelectClassCodeAsync(data.Resolve("{{data:expected_class_code_frame_class_code_window_select_class_code_value_146}}"), "value");
        await page.WaitForOKClassCodeAsync("Exists");
        await page.ClickOKClassCodeAsync();
        if (data.Condition("State != \"MD\""))
        {
            await page.EnterTotalPayrollEstimatedAsync(data.Resolve("{{data:class_code_frame_class_code_window_total_payroll_estimated_150}}"));
        }

        if (data.Condition("State == \"MD\""))
        {
            await page.EnterTotalPayrollEstimatedAsync(data.Resolve("{{data:class_code_frame_class_code_window_total_payroll_estimated_150}}"));
        }
        await page.EnterNumberOfPartTimeEmployeesAsync(data.Resolve("{{data:class_code_frame_class_code_window_number_of_part_time_employees_151}}"));
        await page.EnterNumberOfFullTimeEmployeesAsync(data.Resolve("{{data:class_code_frame_class_code_window_number_of_full_time_employees_152}}"));
        await page.ClickOKDetailsAsync();
        await page.WaitForClassCodeFrameAsync("Absent");
        await page.WaitForAddClassCodeAsync("Exists");
        await page.ClickAddClassCodeAsync();
        await page.VerifyOKClassCodeAsync("Absent", "");
        await page.WaitForSearchValueAsync("Exists");
        await page.EnterSearchValueAsync("");
        await page.EnterSearchValueAsync(data.Resolve("{{data:class_code_frame_class_code_window_searchvalue_160}}"));
        await page.EnterSelectClassCodeAsync(data.Resolve("{{data:class_code_frame_class_code_window_select_class_code_161}}"));
        await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
        await page.VerifySelectClassCodeAsync(data.Resolve("{{data:expected_class_code_frame_class_code_window_select_class_code_value_164}}"), "value");
        await page.WaitForOKClassCodeAsync("Exists");
        await page.ClickOKClassCodeAsync();
        await page.EnterTotalPayrollEstimatedAsync(data.Resolve("{{data:class_code_frame_class_code_window_total_payroll_estimated_168}}"));
        await page.EnterNumberOfPartTimeEmployeesAsync(data.Resolve("{{data:class_code_frame_class_code_window_number_of_part_time_employees_169}}"));
        await page.EnterNumberOfFullTimeEmployeesAsync(data.Resolve("{{data:class_code_frame_class_code_window_number_of_full_time_employees_170}}"));
        await page.ClickOKDetailsAsync();
        await page.WaitForClassCodeFrameAsync("Absent");

    }

    [Given(@"^I navigate to Entity Schedule$")]
    [When(@"^I navigate to Entity Schedule$")]
    [Then(@"^I navigate to Entity Schedule$")]
    public async Task NavigateToEntityScheduleAsync()
    {
        var data = _scenario.Get<ScenarioData>();
        data.GenerateRandom("EntityInfoFrameEntityInfoWindowFax_0109", "[0-9]{10}");
        data.GenerateRandom("EntityInfoFrameEntityInfoWindowBureauNumber_0109", "[0-9]{7}");
        data.GenerateRandom("EntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefault_0109", "[0-9]{6}");

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickEntityScheduleAsync();
        //await page.WaitForSignsHeadingAsync("Exists");
        await page.ClickLocationDetailAsync();
        await page.WaitForInsuredTypeAsync("Exists");
        await page.EnterEntityInfoFrameEntityInfoWindowFaxAsync(data.Resolve("{{runtime:EntityInfoFrameEntityInfoWindowFax_0109}}"));
        await page.EnterEntityInfoFrameEntityInfoWindowBureauNumberAsync(data.Resolve("{{runtime:EntityInfoFrameEntityInfoWindowBureauNumber_0109}}"));
        await page.EnterEntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefaultAsync(data.Resolve("{{runtime:EntityInfoFrameEntityInfoWindowStateUnemploymentNumberDefault_0109}}"));
        if (data.Condition("State == \"NJ\""))
        {
            await page.EnterTaxpayerIdAsync(data.Resolve("{{data:wc_nj_taxpayer_id}}"));
        }
     
        await page.EnterEMailAsync(data.Resolve("{{data:wc_entity_email}}"));
        await page.ClickOKAsync();

        await page.WaitForEntityInfoFrameAsync("Absent");
        await page.WaitForAssignLocationsAsync("Exists");
        await page.ClickAssignLocationsAsync();
        await page.WaitForAssignLocationAsync("Exists");
        await page.ClickAssignLocationAsync();
        await page.WaitForLocationIDAsync("Exists");
        await page.EnterLocationIDAsync("");
        await page.EnterLocationIDAsync(data.Resolve("{{data:location_assignment_entity_location_locationid_188}}"));
        //await page.VerifyLocationIDAsync(data.Resolve("{{data:location_assignment_entity_location_locationid_190}}"));
        await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
        await page.ClickSelectNAICSCodeAsync();

        await page.WaitForNAICSCodeSearchValueAsync("Exists");
        await page.EnterNAICSCodeSearchValueAsync(data.Resolve("{{data:location_assignment_entity_location_naicscodesearchvalue_195}}"));
        await page.EnterSelectAppropriateCodeAsync(data.Resolve("{{data:location_assignment_entity_location_select_appropriate_code_198}}"));
        //await page.VerifySelectAppropriateCodeAsync(data.Resolve("{{data:expected_location_assignment_entity_location_select_appropriate_code_value_199}}"), "value");
        //await page.WaitForLocationAssignmentAsync("Absent");
        //await page.EnterSelectAppropriateCodeAsync(data.Resolve("{{data:location_assignment_entity_location_select_appropriate_code_201}}"));
        //await page.VerifySelectAppropriateCodeAsync(data.Resolve("{{data:expected_location_assignment_entity_location_select_appropriate_code_value_202}}"), "value");
        //await page.WaitForLocationAssignmentAsync("Absent");
        //await page.VerifySelectAppropriateCodeAsync(data.Resolve("{{data:expected_location_assignment_entity_location_select_appropriate_code_value_204}}"), "value");
        await page.ClickOKFirstAsync();
        await page.WaitForOKSecondAsync("Absent");
        await page.ClickOKAsync();
        await page.WaitForLocationAssignmentAsync("Absent");

    }

    [Given(@"^I complete endorsements$")]
    [When(@"^I complete endorsements$")]
    [Then(@"^I complete endorsements$")]
    public async Task CompleteEndorsementsAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickWCNavigationLinksEndorsementsAsync();
        if (data.Condition("State == \"NY\""))
        {
            await page.EnterAreThereAnyOfficersThatShouldBeExcludedAsync(data.Resolve("{{data:wc_officers_excluded}}"));
        }

   
        //await page.WaitForEndorsementMainAddEndorsementAsync("Exists");


        //await page.ClickAddEndorsementsAsync();


        //await page.EnterEndrosmentType("Sole Proprietors, Partners, Officers And Others Coverage");


        //await page.ClickAddSoleProprietorInformationAsync();
        //await page.EnterSoleProprietorsAsync("TEst");

        //await page.ClickAddPartnerInformationAsync();


        //await page.EnterPartnersAsync("Test");
        //await page.ClickAddOthersInformationAsync();
        //await page.EnterOthersAsync("Test");

        //await page.ClickOKAsync();








    }

    [Given(@"^I complete WC UW Questions$")]
    [When(@"^I complete WC UW Questions$")]
    [Then(@"^I complete WC UW Questions$")]
    public async Task CompleteWCUWQuestionsAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickUWQuestionsWorkersCompAsync();
        await page.WaitForUWQuestionsUmbrellaUpdateAnswersAsync("Exists");
        await page.ClickUWQuestionsUmbrellaUpdateAnswersAsync();
        await page.WaitForArePhysicalsRequiredAfterOffersOfEmploymentAreMadeAsync("NotEqual");
        await page.EnterListAllPoliciesWithAmericanNationalAsync(data.Resolve("{{data:list_all_policies_with_american_national_217}}"));

    }

    [Given(@"^I navigate to Pricing Screen$")]
    [When(@"^I navigate to Pricing Screen$")]
    [Then(@"^I navigate to Pricing Screen$")]
    public async Task NavigateToPricingScreenAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickPricingAsync();
        //await page.WaitForPricingDetailAsync("Exists");
        //await page.ClickPricingDetailAsync();
        //await page.ClickPricingDetailOKAsync();
        //await page.WaitForPricingDetailAsync("Exists");


        if (data.Condition("State ==\"NH\""))
        {
            await page.ClickWorksheetAsync();
            await page.EnterEmployerSafetyDevices(data.Resolve("{{data:wc_employer_safety_devices_pricing}}"));
            await page.EnterEmployerSafetyDevicesComments(data.Resolve("{{data:wc_employer_safety_devices_comments}}"));
            await page.ClickOKAsync();
        }



        if (data.Condition(" State ==\"VT\" || State ==\"VA\" || State ==\"NV\" || State ==\"NY\" || State ==\"OK\" || State ==\"SD\" || State ==\"TN\" || State ==\"UT\" || State == \"AZ\" || State == \"CT\" || State == \"DE\" || State == \"GA\" || State == \"IA\" || State == \"IN\" || State == \"MD\" || State == \"MN\" || State == \"MO\""))
        {
            await page.ClickWorksheetAsync();
            await page.EnterPremisesCredit(data.Resolve("{{data:worksheet_multistate_premises_credit_255}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterPremisesComments(data.Resolve("{{data:worksheet_multistate_premises_comments_256}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterClassificationPecularities(data.Resolve("{{data:worksheet_multistate_classification_pecularities_257}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterClassificationPecularitiesComments(data.Resolve("{{data:worksheet_multistate_classification_comments_258}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterMedicalFacilities(data.Resolve("{{data:worksheet_multistate_medical_facilities_259}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterMedicalFacilitiesComments(data.Resolve("{{data:worksheet_multistate_medical_comments_260}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterSafetyDevices(data.Resolve("{{data:worksheet_multistate_safety_devices_264}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterSafetyDevicesComments(data.Resolve("{{data:worksheet_multistate_safety_comments_265}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterEmployeesSelection(data.Resolve("{{data:worksheet_multistate_employees_selection_266}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterEmployeeselectionComments(data.Resolve("{{data:worksheet_multistate_employees_comments_267}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterManagementSafetyOrganizationStateInput(data.Resolve("{{data:worksheet_multistate_management_safety_organization_268}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterManagementSafetyOrganizationStateInputComments(data.Resolve("{{data:worksheet_multistate_management_safety_organization_comments_269}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterManagementCooperationWithInsuranceCarrierStateInput(data.Resolve("{{data:worksheet_multistate_management_cooperation_270}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.EnterManagementCooperationWithInsuranceCarrierStateInputComments(data.Resolve("{{data:worksheet_multistate_management_cooperation_comments_271}}"));
            //await _scenario.Get<BrowserSession>().Page.Keyboard.PressAsync("Tab");
            await page.ClickOKAsync();
        }

        if (data.Condition("State ==\"NJ\""))
        {
            await page.ClickWorksheetAsync();
            await page.EnterPremisesCredit(data.Resolve("{{data:worksheet_pa_nj_premises_credit_255}}"));

            await page.EnterPremisesComments(data.Resolve("{{data:worksheet_pa_nj_premises_comments_256}}"));
            
            await page.EnterClassificationPecularities(data.Resolve("{{data:worksheet_pa_nj_classification_pecularities_257}}"));

            await page.EnterClassificationPecularitiesComments(data.Resolve("{{data:worksheet_pa_nj_classification_comments_258}}"));

            await page.EnterMedicalFacilities(data.Resolve("{{data:worksheet_pa_nj_medical_facilities_259}}"));


            await page.EnterMedicalFacilitiesComments(data.Resolve("{{data:worksheet_pa_nj_medical_comments_260}}"));

            await page.EnterSafetyDevices(data.Resolve("{{data:worksheet_pa_nj_safety_devices_264}}"));

            await page.EnterSafetyDevicesComments(data.Resolve("{{data:worksheet_pa_nj_safety_comments_265}}"));

            await page.EnterEmployeesSelection(data.Resolve("{{data:worksheet_pa_nj_employees_selection_267}}"));
            await page.EnterEmployeeselectionComments(data.Resolve("{{data:worksheet_pa_nj_employees_comments_268}}"));

            await page.ClickOKAsync();
        }



        if (data.Condition("State ==\"PA\""))
        {
            await page.ClickWorksheetAsync();
            await page.EnterPremisesCredit(data.Resolve("{{data:worksheet_multistate_premises_credit_255}}"));
            await page.EnterPremisesComments(data.Resolve("{{data:worksheet_multistate_premises_comments_256}}"));
            await page.EnterClassificationPecularities(data.Resolve("{{data:worksheet_multistate_classification_pecularities_257}}"));
            await page.EnterClassificationPecularitiesComments(data.Resolve("{{data:worksheet_multistate_classification_comments_258}}"));
            await page.EnterMedicalFacilities(data.Resolve("{{data:worksheet_multistate_medical_facilities_259}}"));
            await page.EnterMedicalFacilitiesComments(data.Resolve("{{data:worksheet_multistate_medical_comments_260}}"));
            await page.EnterSafetyDevices(data.Resolve("{{data:worksheet_multistate_safety_devices_264}}"));
            await page.EnterSafetyDevicesComments(data.Resolve("{{data:worksheet_multistate_safety_comments_265}}"));
            await page.EnterEmployeesSelection(data.Resolve("{{data:worksheet_multistate_employees_selection_267}}"));
            await page.EnterEmployeeselectionComments(data.Resolve("{{data:worksheet_multistate_employees_comments_268}}"));
            await page.ClickOKAsync();
        }

        if (data.Condition("State ==\"NH\""))
        {

            await page.ClickWorksheetAsync();
            await page.EnterEmployerSafetyDevices(data.Resolve("{{data:wc_employer_safety_devices_pricing_factor}}"));
       
            await page.EnterEmployerSafetyDevicesComments(data.Resolve("{{data:wc_employer_safety_devices_comments}}"));
     
            await page.ClickOKAsync();


        }


        }

    [Given(@"^I verify Class Codes on Policy are Valid$")]
    [When(@"^I verify Class Codes on Policy are Valid$")]
    [Then(@"^I verify Class Codes on Policy are Valid$")]
    public async Task VerifyClassCodesOnPolicyAreValidAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new BusinessClassificationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.VerifyInvalidClassCodeMessageAsync("Absent", "");

    }

    [Given(@"^I verify premium$")]
    [When(@"^I verify premium$")]
    [Then(@"^I verify premium$")]
    public async Task VerifyPremiumAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PricingPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.VerifyPremiumAsync(data.Resolve("{{data:expected_full_term_premium_value_288}}"), "value");


    }

    [Given(@"^I complete required billing information for billing$")]
    [When(@"^I complete required billing information for billing$")]
    [Then(@"^I complete required billing information for billing$")]
    public async Task CompleteRequiredBillingInformationForBillingAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickNavigationBillingAsync();
        await page.WaitForBillingAsync("Exists");
        await page.EnterBillTypeAsync(data.Resolve("{{data:bill_type_227}}"));
        await page.WaitForBillTypeAsync("Equal");
        await page.EnterPayPlanAsync(data.Resolve("{{data:pay_plan_230}}"));
        await page.WaitForPayPlanAsync("Equal");
        await page.WaitForEasyPayAsync("Exists");
        await page.EnterEasyPayAsync(data.Resolve("{{data:easy_pay_234}}"));

    }

    [Given(@"^I add notepad comment$")]
    [When(@"^I add notepad comment$")]
    [Then(@"^I add notepad comment$")]
    public async Task AddNotepadCommentAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickNotepadAsync();
        //await page.WaitForNotepadHeadingAsync("Exists");
        await page.ClickAddNotesRemarksAsync();
        await page.EnterTextBoxAsync(data.Resolve("{{data:wc_notepad_comment}}"));
        await page.ClickOKAsync();

    }

    [Given(@"^I complete required submission information$")]
    [When(@"^I complete required submission information$")]
    [Then(@"^I complete required submission information$")]
    public async Task CompleteRequiredSubmissionInformationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new NavigationPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.WaitForSubmissionAsync("Visible");
        await page.ClickSubmissionAsync();
        //await page.WaitForSubmissionHeadingAsync("Exists");
        //await page.EnterIsThisCoverageBoundAsync(data.Resolve("{{data:is_this_coverage_bound_245}}"));
        //await page.VerifyOrderAuditAsync("Exists", "");
        //await page.EnterOrderAuditAsync(data.Resolve("{{data:order_audit_247}}"));
        //await page.VerifySubmissionHeadingAsync("Absent", "");
        //await page.ClickSubmissionAsync();
        //await page.WaitForSubmissionHeadingAsync("Exists");

    }

    [Given(@"^I run Stoplight$")]
    [When(@"^I run Stoplight$")]
    [Then(@"^I run Stoplight$")]
    public async Task RunStoplightAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new SubmissionPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        //await page.VerifyIsThisCoverageBoundAsync("Exists", "");
        //await page.VerifyIsThisCoverageBoundAsync(data.Resolve("{{data:expected_is_this_coverage_bound_value_255}}"), "Value");
        //await page.EnterIsThisCoverageBoundAsync(data.Resolve("{{data:is_this_coverage_bound_256}}"));
        await page.ClickCompleteApplicationAsync();
        //await page.VerifyStoplightWaitingWindowCloseAsync("Absent", "");
        //await page.VerifyStoplightWaitingWindowErrorAsync("Exists", "");
        await page.ClickStoplightWaitingWindowFirstCloseButtonOnErrorAsync();
        //await page.ClickCompleteApplicationAsync();
        //await page.ClickStoplightWaitingWindowCloseAsync();
        //await page.WaitForStoplightWaitingWindowAsync("Absent");
        //await page.VerifyLoadingMessageAsync("Visible", "");
        //await page.VerifyAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsAsync("Exists", "");
        //await page.ClickCompleteApplicationAsync();
        //await page.VerifyStoplightWaitingWindowCloseAsync("Absent", "");
        //await page.VerifyStoplightWaitingWindowErrorAsync("Exists", "");
        //await page.ClickStoplightWaitingWindowFirstCloseButtonOnErrorAsync();
        //await page.ClickCompleteApplicationAsync();
        //await page.ClickStoplightWaitingWindowCloseAsync();
        //await page.WaitForStoplightWaitingWindowAsync("Absent");
        //await page.VerifyAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsAsync("Absent", "");

    }

    [Given(@"^I verify values in premium fields$")]
    [When(@"^I verify values in premium fields$")]
    [Then(@"^I verify values in premium fields$")]
    public async Task VerifyValuesInPremiumFieldsAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PricingPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.VerifyFullTermPremiumAsync(data.Resolve("{{data:expected_full_term_premium_value_288}}"), "value");
        await page.VerifyPremiumWrittenAsync(data.Resolve("{{data:expected_premium_written_value_289}}"), "value");
        await page.VerifyPriorPremiumAsync(data.Resolve("{{data:expected_prior_premium_value_290}}"), "value");
        await page.VerifyPremiumChangeAsync(data.Resolve("{{data:expected_premium_change_value_291}}"), "value");
        //await page.EnterTitleAsync(data.Resolve("{{data:title_293}}"));
        //await page.EnterJavaScriptAsync(data.Resolve("{{data:javascript_294}}"));
        //data.Set("SessionId", await page.CaptureResultAsync("value"));


        await page.ClickPolicyFormAsync();

    }

    [Given(@"^I complete forms verification$")]
    [When(@"^I complete forms verification$")]
    [Then(@"^I complete forms verification$")]
    public async Task CompleteFormsVerificationAsync()
    {
        var logger = _scenario.Get<RunLogger>();
        var browser = _scenario.Get<BrowserSession>();
        var playwrightPage = browser.Page;
        var logPath = Path.Combine(browser.ArtifactDirectory, "forms-verification-network.log");

        static bool IsTargetDcUrl(string? url) =>
            !string.IsNullOrWhiteSpace(url)
            && url.Contains("default.aspx", StringComparison.OrdinalIgnoreCase)
            && Regex.IsMatch(url, @"[\?&]_dc=", RegexOptions.IgnoreCase);

        static string ExtractDc(string url)
        {
            var m = Regex.Match(url, @"(?:\?|&)_dc=([^&]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value : string.Empty;
        }

        void EmitLog(string message)
        {
            logger.Info(message);
            Console.WriteLine(message);
            System.Diagnostics.Debug.WriteLine(message);
            TestContext.Progress.WriteLine(message);
            TestContext.WriteLine(message);
        }

        static Dictionary<string, string> LoadExpectedFormProdDocMap()
        {
            var results = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var current = new DirectoryInfo(AppContext.BaseDirectory);
            while (current is not null &&
                   !File.Exists(Path.Combine(current.FullName, "InsuranceAutomation.sln")) &&
                   !File.Exists(Path.Combine(current.FullName, "Framework.runsettings")))
            {
                current = current.Parent;
            }

            var repoRoot = current?.FullName ?? Directory.GetCurrentDirectory();
            var filePath = Path.Combine(repoRoot, "tests", "PersonalLines.DuckCreek.Tests", "TestData", "FormVerification", "WCBasic", "WC_BASIC.json");
            if (!File.Exists(filePath))
            {
                return results;
            }

            var root = JsonNode.Parse(File.ReadAllText(filePath)) as JsonObject;
            var formNode = root?["form"] as JsonObject;
            if (formNode is null)
            {
                return results;
            }

            foreach (var kvp in formNode)
            {
                var form = (kvp.Key ?? string.Empty).Trim();
                var prodDocName = (kvp.Value?.ToString() ?? string.Empty).Trim();
                if (!string.IsNullOrWhiteSpace(form) && !string.IsNullOrWhiteSpace(prodDocName))
                {
                    results[form] = prodDocName;
                }
            }

            return results;
        }

        IResponse? latestMatchingResponse = null;
        string latestDc = string.Empty;

        void OnResponse(object? _, IResponse response)
        {
            if (IsTargetDcUrl(response.Url)
                && response.Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
            {
                latestMatchingResponse = response;
                latestDc = ExtractDc(response.Url);
            }
        }

        try
        {
            playwrightPage.Response += OnResponse;

            await playwrightPage.WaitForResponseAsync(
                r => IsTargetDcUrl(r.Url)
                     && r.Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase),
                new PageWaitForResponseOptions { Timeout = 60000 });


            var response = latestMatchingResponse;
            if (response is null)
            {
                EmitLog("[FormsVerification] Matching response observed but latest reference is null.");
                return;
            }

            var responseBody = await response.TextAsync();
            var capturedProdDocNames = Regex.Matches(responseBody, "<printDoc\\b[^>]*\\bname=\"([^\"]+)\"", RegexOptions.IgnoreCase)
                .Select(m => m.Groups[1].Value)
                .Where(v => !string.IsNullOrWhiteSpace(v))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            EmitLog($"[FormsVerification] Response URL: {response.Url}");
            EmitLog($"[FormsVerification] Response Status: {response.Status}");
            EmitLog($"[FormsVerification] Latest _dc: {latestDc}");

            var expectedFormProdDocMap = LoadExpectedFormProdDocMap();
            var missing = new List<string>();

            foreach (var expected in expectedFormProdDocMap)
            {
                var form = expected.Key;
                var prodDocName = expected.Value;
                var found = capturedProdDocNames.Contains(prodDocName, StringComparer.OrdinalIgnoreCase);
                EmitLog($"[FormsVerification] Form='{form}' ProdDocName='{prodDocName}' Found={found}");

                if (!found)
                {
                    missing.Add($"{form}:{prodDocName}");
                }
            }

            EmitLog($"[FormsVerification] Captured ProdDocNames ({capturedProdDocNames.Count}): {string.Join(", ", capturedProdDocNames)}");

            var log = new StringBuilder();
            log.AppendLine($"Timestamp: {DateTime.UtcNow:O}");
            log.AppendLine($"Response URL: {response.Url}");
            log.AppendLine($"Response Status: {response.Status}");
            log.AppendLine($"Latest _dc: {latestDc}");
            log.AppendLine($"Captured ProdDocNames ({capturedProdDocNames.Count}): {string.Join(", ", capturedProdDocNames)}");
            log.AppendLine("Response Body:");
            log.AppendLine(responseBody);
            log.AppendLine(new string('-', 120));
            File.AppendAllText(logPath, log.ToString());

            if (missing.Count > 0)
            {
                EmitLog($"[FormsVerification] Missing Form->ProdDocName pairs: {string.Join(" | ", missing)}");
                Assert.Fail($"Missing expected ProdDocNames for forms: {string.Join(" | ", missing)}");
            }
        }
        catch (TimeoutException)
        {
            EmitLog("[FormsVerification] No response matched: POST default.aspx with query _dc=");
        }
        finally
        {
            playwrightPage.Response -= OnResponse;
        }
    }



    private static async Task EnterWithTabAndNonEmptyRetryAsync(

    Func<Task> enter,

    Func<Task> pressTab,

    Func<Task<string>> capture,

    string fieldName,

    int maxAttempts = 2)

    {

        for (var attempt = 1; attempt <= maxAttempts; attempt++)

        {

            await enter();

            await pressTab();



            var actual = (await capture())?.Trim() ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(actual))

            {

                return;

            }

        }


        throw new InvalidOperationException($"Value was empty after Tab commit for field '{fieldName}' after {maxAttempts} attempts.");

    }

    

    [Given(@"^I sign out of the application$")]
    [When(@"^I sign out of the application$")]
    [Then(@"^I sign out of the application$")]
    public async Task SignOutOfTheApplicationAsync()
    {
        var data = _scenario.Get<ScenarioData>();

        var page = new PolicyWorkflowPage(_scenario.Get<BrowserSession>(), _scenario.Get<UiActions>());

        await page.ClickLoggedInUserAsync();
        await page.ClickLogoutAsync();
        await page.VerifyBrowserCommunicationHTTPStatusZeroAsync("Exists", "");
        await page.ClickOKAsync();
        await page.WaitForOKAsync("Absent");
        await page.ClickLoggedInUserAsync();
        await page.ClickLogoutAsync();

    }

}
