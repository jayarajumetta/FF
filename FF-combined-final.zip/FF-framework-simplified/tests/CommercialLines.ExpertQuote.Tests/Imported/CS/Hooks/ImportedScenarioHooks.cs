using InsuranceAutomation.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Playwright;
using PnCTestAutomation.Clients;
using PnCTestAutomation.Configuration;
using PnCTestAutomation.Context;
using PnCTestAutomation.DataPool;
using PnCTestAutomation.Helpers;
using PnCTestAutomation.Models;
using PnCTestAutomation.Pages;
using PnCTestAutomation.Services;
using Reqnroll;
using Reqnroll.BoDi;
using System.Net.Http.Headers;

namespace PnCTestAutomation.Hooks;

[Binding]
[Scope(Tag = "cs_import")]
public sealed class ImportedScenarioHooks
{
    private readonly ScenarioContext _scenario;
    private readonly FeatureContext _feature;
    private readonly IObjectContainer _container;
    private ServiceProvider? _provider;
    private IServiceScope? _scope;
    private PlaywrightContext? _context;
    private IConfiguration? _configuration;
    private RetryDiagnostics? _diagnostics;

    public ImportedScenarioHooks(ScenarioContext scenario, FeatureContext feature, IObjectContainer container)
    { _scenario = scenario; _feature = feature; _container = container; }

    [BeforeScenario(Order = -50)]
    public async Task PrepareAsync()
    {
        // SGS PrepareScenario(-100) has already created the logger, report and BrowserSession.
        var directory = _scenario.Get<string>();
        _configuration = ImportedConfiguration.Load(directory);
        var data = new ScenarioContextData { QuoteNumberFilePath = Path.Combine(directory, "QuoteNumber.txt") };
        _scenario[ScenarioContextData.ContextKey] = data;
        var services = new ServiceCollection();
        new Startup().ConfigureServices(services, _scenario, _configuration);
        _context = new PlaywrightContext
        {
            Session = _scenario.Get<BrowserSession>(),
            ActionTimeoutMs = _configuration.GetValue<float?>("Playwright:ActionTimeoutMs") ?? 30000,
            NavigationTimeoutMs = _configuration.GetValue<float?>("Playwright:NavigationTimeoutMs") ?? 90000,
            Logger = _scenario.Get<RunLogger>(),
            HttpClient = new HttpClient { BaseAddress = new Uri(
                _configuration["Playwright:ExpertQuoteBase"] ?? throw new InvalidOperationException("Missing ExpertQuoteBase.")) }
        };
        services.AddSingleton(_context);
        _provider = services.BuildServiceProvider(validateScopes: true);
        _scope = _provider.CreateScope();
        Register<IConfiguration>();
        Register<CredentialsConfig>();
        Register<ExpressCredentialsConfig>();
        Register<OAuthConfig>();
        Register<PlaywrightContext>();
        Register<ScenarioContextData>();
        Register<NavigationService>();
        Register<SessionService>();
        Register<FormsValidationService>();
        Register<DuckCreekFormsClient>();
        Register<DuckCreekFormsConfig>();
        Register<IApiService>();
        Register<IDataPoolClient>();
        Register<PingSecretProvider>();
        Register<ApiHeaders>();
        _container.RegisterInstanceAs(_context.HttpClient);

        var policy = new TestHooks(_scenario, _feature, _configuration);
        if (policy.ShouldSkipScenarioForEnvironment(out var reason)
            || policy.ShouldSkipScenarioForDevStateFilter(out reason))
            global::NUnit.Framework.Assert.Ignore(reason);

        if (_scenario.ScenarioInfo.CombinedTags.Contains("RatePolicy", StringComparer.OrdinalIgnoreCase))
            new PnCTestAutomation.StepDefinitions.SFPSteps.SFP_RatePolicySteps(_context, data, _configuration)
                .RequireNonProductionEnvironment();

        if (_scenario.ScenarioInfo.CombinedTags.Any(t => t.Equals("API", StringComparison.OrdinalIgnoreCase)))
        {
            var secretId = _configuration["OAuthConfig:PingSecretId"]
                ?? Environment.GetEnvironmentVariable("PING_SECRET_ID")
                ?? throw new InvalidOperationException("PING_SECRET_ID is not configured.");
            var secret = await _scope.ServiceProvider.GetRequiredService<PingSecretProvider>().GetSecretAsync(secretId);
            var token = await AuthHelper.GetTokenWithClientCredentialsAsync(
                _scope.ServiceProvider.GetRequiredService<OAuthConfig>(), secret);
            _context.HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            _scenario["AccessToken"] = token;
        }
        else
        {
            await _context.OpenBrowserAsync();
            if (string.Equals(_configuration["Debugging:RetryDiagnostics"], "true", StringComparison.OrdinalIgnoreCase))
                _diagnostics = RetryDiagnostics.Start(_context.Page, _configuration["DuckCreekForms:CLASBaseUrl"] ?? string.Empty);
        }
    }

    private void Register<T>() where T : class =>
        _container.RegisterInstanceAs<T>(_scope!.ServiceProvider.GetRequiredService<T>(), dispose: false);

    [AfterStep(Order = -10)]
    public async Task CaptureImportedEvidenceAsync()
    {
        if (_context is null) return;
        if (_scenario.TryGetValue(ScenarioContextData.ContextKey, out var value) && value is ScenarioContextData data)
        {
            // Export only useful non-sensitive identifiers. Do not reflect SSN/payment/credential fields.
            var scenarioData = _scenario.Get<ScenarioData>();
            if (!string.IsNullOrWhiteSpace(data.QuoteNumber)) scenarioData.SetRuntime("EQ.QuoteNumber", data.QuoteNumber);
            _scenario.Get<RunLogger>().Info($"Imported EQ step finished: {_scenario.StepContext.StepInfo.Text}");
        }
        if (_scenario.TestError is not null && _context.ChecklistPage is { IsClosed: false } popup
            && _scenario.Get<FrameworkConfig>().Browser.ScreenshotOnFailure)
        {
            try
            {
                var path = Path.Combine(_scenario.Get<string>(), "checklist-failure.png");
                await popup.ScreenshotAsync(new() { Path = path, FullPage = true });
            }
            catch (Exception ex) { _scenario.Get<RunLogger>().Warn($"Checklist screenshot unavailable: {ex.Message}"); }
        }
    }

    [AfterScenario(Order = 90)]
    public async Task FinishAsync()
    {
        try
        {
            if (_scope is not null && _scenario.TestError is null
                && _scenario.ScenarioExecutionStatus == ScenarioExecutionStatus.OK
                && !_scenario.Get<DeferredVerificationCollector>().HasFailures)
            {
                var data = _scope.ServiceProvider.GetRequiredService<ScenarioContextData>();
                var record = QuoteRecordFactory.FromScenarioContext(data, _configuration!["Environment"] ?? "QA");
                if (record is not null)
                    await _scope.ServiceProvider.GetRequiredService<IDataPoolClient>().TryPersistAsync(record);
            }
        }
        catch (Exception ex) { _scenario.Get<RunLogger>().Warn($"Optional DataPool persistence failed: {ex.Message}"); }
        finally
        {
            // SGS finalizer(100) closes every page/context and publishes evidence after this hook.
            _diagnostics?.Dispose();
            _context?.ApiResponse?.Dispose();
            _context?.HttpClient?.Dispose();
            _scope?.Dispose();
            if (_provider is not null) await _provider.DisposeAsync();
        }
    }
}
