using PnCTestAutomation.Helpers;
using Microsoft.Extensions.Configuration;
using Reqnroll;
namespace PnCTestAutomation.Hooks;
// Policy helper only. SGS owns every scenario hook and all browser/report disposal.
public sealed class TestHooks
{
    private readonly ScenarioContext _scenarioContext;
    private readonly FeatureContext _featureContext;
    private readonly IConfiguration _configuration;
    public TestHooks(ScenarioContext scenario, FeatureContext feature, IConfiguration configuration)
    { _scenarioContext = scenario; _featureContext = feature; _configuration = configuration; }
    internal static bool ShouldSaveTrace(bool hasFailed, bool completed, bool saveTraceOnSuccess) =>
        hasFailed || (completed && saveTraceOnSuccess);
        internal bool ShouldSkipScenarioForEnvironment(out string reason)
        {
            var tags = (_scenarioContext.ScenarioInfo.Tags ?? [])
                .Concat(_featureContext.FeatureInfo.Tags ?? []);
            var environment = _configuration["Environment"]
                              ?? Environment.GetEnvironmentVariable("TEST_ENVIRONMENT")
                              ?? "QA";

            return IsEnvironmentRestricted(tags, environment, out reason);
        }

        internal static bool IsEnvironmentRestricted(
            IEnumerable<string> tags,
            string environment,
            out string reason)
        {
            reason = string.Empty;
            var tagSet = new HashSet<string>(tags ?? [], StringComparer.OrdinalIgnoreCase);
            var target = string.IsNullOrWhiteSpace(environment) ? "QA" : environment.Trim();

            if (tagSet.Contains("DevOnly") && !target.Equals("Dev", StringComparison.OrdinalIgnoreCase))
            {
                reason = $"Skipping DevOnly scenario in '{target}'. Set TEST_ENVIRONMENT=Dev to run it.";
                return true;
            }

            if (tagSet.Contains("QAOnly") && !target.Equals("QA", StringComparison.OrdinalIgnoreCase))
            {
                reason = $"Skipping QAOnly scenario in '{target}'. Set TEST_ENVIRONMENT=QA to run it.";
                return true;
            }

            return false;
        }

        internal bool ShouldSkipScenarioForDevStateFilter(out string reason)
        {
            reason = string.Empty;

            var envSetting = _configuration["Environment"]
                             ?? Environment.GetEnvironmentVariable("TEST_ENVIRONMENT")
                             ?? "QA";

            if (!envSetting.Equals("Dev", StringComparison.OrdinalIgnoreCase))
                return false;

            var allowedStates = _configuration
                .GetSection("StateFilters:DevAllowedStates")
                .Get<string[]>();

            if (allowedStates == null || allowedStates.Length == 0)
                return false;

            var scenarioState = TryGetScenarioStateAbbreviation();
            if (string.IsNullOrWhiteSpace(scenarioState))
                return false;

            var allowed = new HashSet<string>(
                allowedStates
                    .Where(s => !string.IsNullOrWhiteSpace(s))
                    .Select(s => s.Trim().ToUpperInvariant()),
                StringComparer.OrdinalIgnoreCase);

            if (allowed.Contains(scenarioState))
                return false;

            reason = $"Skipping Dev scenario for state '{scenarioState}'. Allowed Dev states: {string.Join(", ", allowed.Order())}.";
            return true;
        }

        private string? TryGetScenarioStateAbbreviation()
        {
            var args = _scenarioContext.ScenarioInfo.Arguments;
            if (args == null || args.Count == 0)
                return null;

            if (args.Contains("StateAbbv"))
            {
                var stateAbbv = args["StateAbbv"]?.ToString()?.Trim();
                if (!string.IsNullOrWhiteSpace(stateAbbv))
                    return stateAbbv.ToUpperInvariant();
            }

            if (args.Contains("State"))
            {
                var state = args["State"]?.ToString()?.Trim();
                if (!string.IsNullOrWhiteSpace(state) && state.Length == 2)
                    return state.ToUpperInvariant();
            }

            return null;
        }
}
