#nullable enable annotations
#nullable disable warnings
using Microsoft.Playwright;
using System;
using System.Linq;
using System.Threading.Tasks;
using static Microsoft.Playwright.Assertions;


namespace PnCTestAutomation.Helpers
{
    public class Helpers
    {
        public static async Task ClickSaveAsync(IPage page)
        {
            var candidates = new[]
            {
                page.GetByTestId("fields.data_Actions.save"),
                page.GetByTestId("fields.data_Next.saveLocation"),

            };

            foreach (var candidate in candidates)
            {
                if (await candidate.CountAsync() > 0 && await candidate.First.IsVisibleAsync())
                {
                    await candidate.First.ClickAsync();
                    return;
                }
            }

            throw new PlaywrightException("Save button not found using any known data-testid.");
        }

        // Dropdown handling
        public static async Task SelectByTextAsync(IPage page, ILocator matSelect, string optionText, int timeoutMs = 30000, bool blurAfterSelect = true)
        {
            await InsuranceAutomation.Core.ComponentAwareControlActions.SelectOrFillAsync(
                page, matSelect, (optionText ?? "").Trim(), timeoutMs, timeoutMs);
            if (blurAfterSelect) await matSelect.BlurAsync(new() { Timeout = timeoutMs });
        }

        public static Task SelectByTestIdAsync(IPage page, string testId, string optionText, int timeoutMs = 30000)
        {
            var matSelect = page.Locator($"mat-select[data-testid='{testId}']");
            return SelectByTextAsync(page, matSelect, optionText, timeoutMs);
        }


        // Button selection handling
        public static async Task SelectButtonAsync(
            IPage page,
            ILocator scope,
            string value,
            ILocator moreOptionsButton,
            int timeoutMs = 30000)
        {
            var target = (value ?? "").Trim();

            var button = scope.GetByRole(AriaRole.Button, new() { Name = target, Exact = true });

            if (await button.CountAsync() > 0 && await button.First.IsVisibleAsync())
            {
                await Expect(button.First).ToBeEnabledAsync(new() { Timeout = timeoutMs });
                await button.First.ScrollIntoViewIfNeededAsync();
                await button.First.ClickAsync(new() { Timeout = timeoutMs });
                return;
            }

            // The 'More Options' overflow button may not be present in all states. If it is not
            // visible, fail explicitly when a requested value cannot be selected.
            if (await moreOptionsButton.CountAsync() == 0 || !await moreOptionsButton.IsVisibleAsync())
            {
                throw new PlaywrightException($"Requested selection '{target}' is unavailable; no More Options control is visible.");
            }
            await Expect(moreOptionsButton).ToBeEnabledAsync(new() { Timeout = timeoutMs });
            await moreOptionsButton.ScrollIntoViewIfNeededAsync();
            await moreOptionsButton.ClickAsync(new() { Timeout = timeoutMs });

            var menuPanel = page.Locator(".cdk-overlay-pane .mat-menu-panel, .cdk-overlay-pane .mat-mdc-menu-panel").Last;
            await Expect(menuPanel).ToBeVisibleAsync(new() { Timeout = timeoutMs });

            var menuItem = menuPanel.GetByRole(AriaRole.Menuitem, new LocatorGetByRoleOptions { Name = target, Exact = true });

            await Expect(menuItem.First).ToBeVisibleAsync(new() { Timeout = timeoutMs });
            await menuItem.First.ClickAsync(new() { Timeout = timeoutMs });

            await Expect(menuPanel).ToBeHiddenAsync(new() { Timeout = timeoutMs });

        }

    }
}
