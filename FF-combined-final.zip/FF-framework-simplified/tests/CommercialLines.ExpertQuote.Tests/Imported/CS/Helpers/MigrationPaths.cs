namespace PnCTestAutomation.Helpers;

public static class MigrationPaths
{
    public static string ToolRoot()
    {
        var configured = global::NUnit.Framework.TestContext.Parameters.Get("PROJECT_ROOT", "");
        return string.IsNullOrWhiteSpace(configured) ? ProjectRoot() : Path.GetFullPath(configured);
    }

    public static string ArtifactDirectory(Microsoft.Extensions.Configuration.IConfiguration config)
    {
        var path = config["Migration:ArtifactDirectory"] ?? Path.Combine(
            global::NUnit.Framework.TestContext.CurrentContext.WorkDirectory, "Artifacts",
            global::NUnit.Framework.TestContext.CurrentContext.Test.ID);
        Directory.CreateDirectory(path);
        return Path.GetFullPath(path);
    }

    public static string ProjectRoot()
    {
        const string project = "CommercialLines.ExpertQuote.Tests.csproj";
        foreach (var start in new[] { AppContext.BaseDirectory, Directory.GetCurrentDirectory(), Path.GetDirectoryName(typeof(MigrationPaths).Assembly.Location)! })
        {
            for (var dir = new DirectoryInfo(start); dir is not null; dir = dir.Parent)
            {
                if (File.Exists(Path.Combine(dir.FullName, project))) return dir.FullName;
                var candidate = Path.Combine(dir.FullName, "tests", "CommercialLines.ExpertQuote.Tests");
                if (File.Exists(Path.Combine(candidate, project))) return candidate;
            }
        }
        throw new DirectoryNotFoundException("Cannot locate the EQ source project. Run source-dependent CSUnit tests from the combined checkout.");
    }
}
