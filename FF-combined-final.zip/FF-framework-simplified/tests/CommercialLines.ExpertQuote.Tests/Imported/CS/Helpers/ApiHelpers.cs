using System.Net.Http.Headers;
using System.Text;
namespace PnCTestAutomation.Helpers;
public static class ApiHelpers
{
    public static async Task<HttpResponseMessage> SendPostRequestAsync(HttpClient httpClient, string endpoint,
        string body, Dictionary<string, string> headers, string? token = null, string? cookieHeader = null)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, endpoint)
        { Content = new StringContent(body, Encoding.UTF8, "application/json") };
        foreach (var header in headers) request.Headers.TryAddWithoutValidation(header.Key, header.Value);
        if (!string.IsNullOrWhiteSpace(token)) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        if (!string.IsNullOrWhiteSpace(cookieHeader)) request.Headers.Add("Cookie", cookieHeader);
        // The caller owns the response and decides its assertions. Do not retry state-changing requests.
        return await httpClient.SendAsync(request);
    }
}
