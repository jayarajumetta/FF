#nullable enable annotations
#nullable disable warnings
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PnCTestAutomation.Configuration
{
    public class OAuthConfig
    {
        public string AuthUrl { get; set; }
        public string TokenUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string RedirectUri { get; set; }
        public string Scope { get; set; } = "openid profile";
        public string GrantType { get; set; } = "password";
        /// <summary>
        /// The secret ID passed to PingSecretProvider for API test token retrieval.
        /// Set via OAuthConfig:PingSecretId in appsettings or PING_SECRET_ID env var.
        /// </summary>
        public string PingSecretId { get; set; }
    }
}
