using Microsoft.Extensions.Configuration;
namespace PnCTestAutomation.Configuration;

public static class ImportedConfiguration
{
    public static IConfigurationRoot Load(string artifactDirectory)
    {
        var basePath = AppContext.BaseDirectory;
        var baseline = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(basePath, "appsettings.json"), optional: false).Build();
        var environment = Environment.GetEnvironmentVariable("TEST_ENVIRONMENT")
            ?? baseline["Environment"] ?? "QA";
        // Environment labels are used only to select a known local JSON file.
        var selected = Directory.EnumerateFiles(basePath, "appsettings.*.json")
            .SingleOrDefault(path => Path.GetFileName(path).Equals(
                $"appsettings.{environment}.json", StringComparison.OrdinalIgnoreCase));
        var builder = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(basePath, "appsettings.json"), optional: false);
        if (selected is not null) builder.AddJsonFile(selected, optional: false);
        var aliases = new Dictionary<string, string?>();
        AddAlias("Credentials:Username", "CL_EQ_USERNAME");
        AddAlias("Credentials:Password", "CL_EQ_PASSWORD");
        AddAlias("QAExpressCreds:Username", "CL_DC_USERNAME");
        AddAlias("QAExpressCreds:Password", "CL_DC_PASSWORD");
        AddAlias("DuckCreekForms:CLASUsername", "CL_DC_USERNAME");
        AddAlias("DuckCreekForms:CLASPassword", "CL_DC_PASSWORD");
        AddAlias("DuckCreekForms:Password", "DUCKCREEK_PASSWORD");
        builder.AddInMemoryCollection(aliases).AddEnvironmentVariables();
        builder.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Environment"] = environment,
            ["DuckCreekForms:ResultsBasePath"] = Path.Combine(artifactDirectory, "FormsCheck"),
            ["Migration:ArtifactDirectory"] = artifactDirectory
        });
        return builder.Build();
        void AddAlias(string key, string variable)
        {
            var value = Environment.GetEnvironmentVariable(variable);
            if (!string.IsNullOrWhiteSpace(value)) aliases[key] = value;
        }
    }
}
