using InsuranceAutomation.Core;
using Microsoft.Playwright;
namespace PnCTestAutomation.Context;

// Compatibility contract for imported pages. Browser ownership stays with SGS.
public sealed class PlaywrightContext
{
    public HttpClient HttpClient { get; set; } = null!;
    public HttpResponseMessage ApiResponse { get; set; } = null!;
    public IPage Page { get; set; } = null!;
    public IPage ChecklistPage { get; set; } = null!;
    internal float ActionTimeoutMs { get; set; } = 30000;
    internal float NavigationTimeoutMs { get; set; } = 90000;
    internal BrowserSession? Session { get; set; }
    internal RunLogger? Logger { get; set; }
    private int _sessionNumber;

    public async Task CloseBrowserAsync()
    {
        if (Session is null || Logger is null)
            throw new InvalidOperationException("The imported scenario has no SGS browser owner.");
        await Session.CloseAsync(Logger);
        // Preserve closed-session trace/HAR before a smoke-test relaunch reuses their names.
        var previous = Path.Combine(Session.ArtifactDirectory, $"session-{++_sessionNumber:D2}");
        Directory.CreateDirectory(previous);
        foreach (var file in new[] { "trace.zip", "network.har.zip" })
        {
            var path = Path.Combine(Session.ArtifactDirectory, file);
            if (File.Exists(path)) File.Copy(path, Path.Combine(previous, file), overwrite: true);
        }
        Page = null!;
        ChecklistPage = null!;
    }

    public async Task OpenBrowserAsync()
    {
        if (Session is null || Logger is null)
            throw new InvalidOperationException("The imported scenario has no SGS browser owner.");
        await Session.OpenAsync(Logger);
        Session.FailureScreenshotCaptured = false;
        Page = Session.Page;
        Page.Context.SetDefaultTimeout(ActionTimeoutMs);
        Page.Context.SetDefaultNavigationTimeout(NavigationTimeoutMs);
    }
}
