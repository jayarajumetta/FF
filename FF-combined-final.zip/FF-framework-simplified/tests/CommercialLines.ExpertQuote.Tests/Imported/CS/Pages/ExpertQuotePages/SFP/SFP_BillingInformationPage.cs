#nullable enable annotations
#nullable disable warnings
using Microsoft.Playwright;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PnCTestAutomation.Helpers;
using PnCTestAutomation.Pages.ExpertQuotePages.SFP;

namespace PnCTestAutomation.Pages
{
    public class SFP_BillingInformationPage : BasePage
    {
        public SFP_BillingInformationPage(IPage page) : base(page) { }

        public async Task CompleteRatePolicyBillingAsync(
            ScenarioContextData data, IReadOnlyDictionary<string, string> values)
        {
            foreach (var (question, supported) in new[]
            {
                ("BillingAccount", "Create New"), ("PrimaryPayer", "Primary Insured"),
                ("PaymentType", "Easy Pay"), ("PaymentPlan", "12 Payments"),
                ("PaymentAmount", "Minimum"), ("PaymentMethod", "Check")
            })
                SfpRequiredTable.RequireValue(question, values[question], supported);

            var form = new SFP_NativeFormPage(_page);
            await form.SelectChoiceAsync("_PolicyPaymentInputDoc.BillingCenterAccount",
                SFP_NativeFormPage.Caption("Create New Billing Account"));
            var first = FlexibleNamePart(data.ClientFirstName);
            var middle = FlexibleNamePart(data.ClientMiddleName ?? "");
            var last = FlexibleNamePart(data.ClientLastName);
            var insured = new Regex(
                $@"^\s*(?:Primary Insured|{first}\s+(?:{middle}\s+)?{last})(?:\s*\(Primary Insured\))?(?:\s*\d{{4}}-\d{{2}}-\d{{2}})?\s*$",
                RegexOptions.IgnoreCase);
            await form.SelectChoiceAsync("SubsequentPaymentData.PayerID", insured);
            var easyPay = new Regex(@"^\s*Easy\s*Pay\s*$", RegexOptions.IgnoreCase);
            await form.SelectChoiceAsync("SubsequentPaymentData.PaymentMethod", easyPay);
            await form.SelectChoiceAsync("SubsequentBankData.ExistingDraftAccount",
                new Regex(@"^\s*(?:Create\s+New(?:\s+Bank)?(?:\s+Account)?|New\s+Account)\s*$",
                    RegexOptions.IgnoreCase));
            await form.SelectChoiceAsync("SubsequentBankData.AccountUse", SFP_NativeFormPage.Caption("Personal"));
            await form.SelectChoiceAsync("SubsequentBankData.AccountType", SFP_NativeFormPage.Caption("Checking"));
            await form.SelectChoiceAsync("SubsequentBankData.AccountOwnerSelect", insured);
            await form.SetAsync("SubsequentBankData.RoutingNumber", values["RoutingNumber"]);
            await form.SetAsync("SubsequentBankData.AccountNumber", values["AccountNumber"]);
            await form.SetAsync("SubsequentBankData.Name", values["BankName"]);
            await form.SelectChoiceAsync("SubsequentPaymentData.PaymentPlan",
                SFP_NativeFormPage.Caption(values["PaymentPlan"]));
            await form.SetAsync("SubsequentPaymentData.DueDate", values["PaymentDueDate"]);
            await form.SelectChoiceByValueAsync("InitialPaymentData.AmountSelection", "Min");
            await form.SelectChoiceAsync("InitialPaymentData.PaymentMethod", SFP_NativeFormPage.Caption("Check"));
            data.CheckNumber = Random.Shared.Next(1000, 99999).ToString(System.Globalization.CultureInfo.InvariantCulture);
            await form.SetControlAsync(InitialCheckNumberInput, data.CheckNumber);

            await form.VerifyChoiceAsync("SubsequentPaymentData.PaymentMethod", easyPay);
            await form.VerifyChoiceAsync("SubsequentPaymentData.PaymentPlan", SFP_NativeFormPage.Caption(values["PaymentPlan"]));
            await form.VerifyAsync("SubsequentBankData.RoutingNumber", values["RoutingNumber"]);
            await form.VerifyAsync("SubsequentBankData.AccountNumber", values["AccountNumber"]);
            await form.VerifyAsync("SubsequentBankData.Name", values["BankName"]);
            await form.VerifyAsync("SubsequentPaymentData.DueDate", values["PaymentDueDate"]);
            await ClickNextAsync(spinnerTimeoutMs: 120000);
        }

        private static string FlexibleNamePart(string value) =>
            string.Join(@"\s*", Regex.Split(value.Trim(), @"\s+").Select(Regex.Escape));

        // ===== Billing Account Setup =====
        // Select from existing Billing Accounts or Create New
        public ILocator CreateNewBillingAccountButton => _page.GetByTestId("fields._PolicyPaymentInputDoc._PolicyPaymentInputDoc$billingCenterAccount.value-0");

        // Select the Primary Payer for the new account
        public ILocator PrimaryPayerPrimaryInsuredButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$payerID.value-0");
        public ILocator PrimaryPayerOtherButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$payerID.value-1");

        // ===== Future Payment Plan Setup =====
        // Select Payment Type
        public ILocator PaymentTypeEasyPayButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentMethod.value-0");
        public ILocator PaymentTypeDirectBillButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentMethod.value-1");

        // Select from existing Bank Accounts or Create New
        public ILocator FutureBankAccountCreateNewButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$existingDraftAccount.value-0");

        // Select the Bank Account use
        public ILocator FutureBankAccountUsePersonalButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountUse.value-0");
        public ILocator FutureBankAccountUseBusinessButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountUse.value-1");

        // Select the Bank Account type
        public ILocator FutureBankAccountTypeCheckingButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountType.value-0");
        public ILocator FutureBankAccountTypeSavingsButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountType.value-1");

        // Select the Bank Account Owner
        public ILocator FutureBankAccountOwnerPrimaryButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountOwnerSelect.value-0");
        public ILocator FutureBankAccountOwnerOtherButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountOwnerSelect.value-1");

        // Bank Details
        public ILocator FutureBankRoutingNumberInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$routingNumber.value");
        public ILocator FutureBankAccountNumberInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$accountNumber.value");
        public ILocator FutureNameOfBankInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentBankData$name.value");

        // ===== Select Payment Plan =====
        public ILocator PaymentPlan1PaymentButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentPlan.value-0");
        public ILocator PaymentPlan2PaymentsButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentPlan.value-1");
        public ILocator PaymentPlan4PaymentsButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentPlan.value-2");
        public ILocator PaymentPlan12PaymentsButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$paymentPlan.value-3");

        // Choose payment due date (text input, max 2 digits)
        public ILocator PaymentDueDateInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.subsequentPaymentData$dueDate.value");

        // ===== Initial Payment =====
        // Select a payment amount
        public ILocator PaymentAmountMinimumButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$amountSelection.value-0");
        public ILocator PaymentAmountFullBalanceButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$amountSelection.value-1");
        public ILocator PaymentAmountCustomButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$amountSelection.value-2");

        // Select Payment Method
        public ILocator InitialPaymentMethodQuickPayButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$paymentMethod.value-0");
        public ILocator InitialPaymentMethodCheckButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$paymentMethod.value-1");
        public ILocator InitialPaymentMethodCreditCardButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$paymentMethod.value-2");

        // Initial Payment - Check Number
        public ILocator InitialCheckNumberInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.initialPaymentData$checkNumber.value");

        // Select Create New to input Quick Pay details
        public ILocator InitialBankAccountCreateNewButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$existingDraftAccount.value-0");

        // Select the Bank Account use
        public ILocator InitialBankAccountUsePersonalButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountUse.value-0");
        public ILocator InitialBankAccountUseBusinessButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountUse.value-1");

        // Select the Bank Account type
        public ILocator InitialBankAccountTypeCheckingButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountType.value-0");
        public ILocator InitialBankAccountTypeSavingsButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountType.value-1");

        // Select the Account Owner
        public ILocator InitialBankAccountOwnerPrimaryButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountOwnerSelect.value-0");
        public ILocator InitialBankAccountOwnerOtherButton => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountOwnerSelect.value-1");

        // Bank Details
        public ILocator InitialBankRoutingNumberInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$routingNumber.value");
        public ILocator InitialBankAccountNumberInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$accountNumber.value");
        public ILocator InitialNameOfBankInput => _page.GetByTestId("fields._PolicyPaymentInputDoc.bankData$name.value");
    }
}
