using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class BusinessClassificationPage
{
    private readonly BrowserSession _browser;
    private readonly BusinessClassificationLocators _locators;
    private readonly UiActions _ui;

    public BusinessClassificationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new BusinessClassificationLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForIndustryClassCodeRestrictionsHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.IndustryClassCodeRestrictionsHeading, expected);

    public Task PressNoneOfTheAboveAsync(string key) =>
        _ui.PressAsync(_locators.NoneOfTheAbove, key);

    public Task ClickNoneOfTheAboveAsync() =>
        _ui.ClickAsync(_locators.NoneOfTheAbove);

    public Task ClickNoneOfTheAboveLiabilityQuestionsAsync() =>
        _ui.ClickAsync(_locators.NoneOfTheAboveLiabilityQuestions);
    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

}
