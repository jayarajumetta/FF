using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class BuildingsPage
{
    private readonly BrowserSession _browser;
    private readonly BuildingsLocators _locators;
    private readonly UiActions _ui;

    public BuildingsPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new BuildingsLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterActualCashValueAsync(string value) =>
        _ui.FillAsync(_locators.ActualCashValue, value);

    public Task PressActualCashValueAsync(string key) =>
        _ui.PressAsync(_locators.ActualCashValue, key);

    public Task ClickActualCashValueAsync() =>
        _ui.ClickAsync(_locators.ActualCashValue);

    public Task EnterAddANoteAsync(string value) =>
        _ui.FillAsync(_locators.AddANote, value);

    public Task ClickAddBuildingBPPAsync() =>
        _ui.ClickAsync(_locators.AddBuildingBPP);

    public Task EnterBuildingLimitAsync(string value) =>
        _ui.FillAsync(_locators.Building, value);

    public Task WaitForAddResidenceHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.AddResidenceHeader, expected);

    public Task ClickAddResidenceToLocationAsync() =>
        _ui.ClickAsync(_locators.AddResidenceToLocation);

    public Task PressAdditionalDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalDescription, key);

    public Task SelectAutomaticCommercialCookingExhaustAndExtinguishingANSULSystemYesAsync(string value) =>
        _ui.SelectAsync(_locators.AutomaticCommercialCookingExhaustAndExtinguishingANSULSystemYes, value);

    public Task PressBVSButtonAsync(string key) =>
        _ui.PressAsync(_locators.BVSButton, key);

    public Task ClickBVSButtonAsync() =>
        _ui.ClickAsync(_locators.BVSButton);

    public Task ClickBVSGroupAsync() =>
        _ui.ClickAsync(_locators.BVSGroup);

    public Task PressBVSGroupComboboxAsync(string key) =>
        _ui.PressAsync(_locators.BVSGroup, key);

    public Task SelectBVSGroupAsync(string value) =>
        _ui.SelectAsync(_locators.BVSGroup, value);

    public Task ClickBVSResultAsync() =>
        _ui.ClickAsync(_locators.BVSResult);

    public Task PressBVSResultsComboboxAsync(string key) =>
        _ui.PressAsync(_locators.BVSResult, key);

    public Task SelectBVSResultAsync(string value) =>
        _ui.SelectAsync(_locators.BVSResult, value);

    public Task EnterYearBuiltValuationAsync(string value) =>
        _ui.FillAsync(_locators.GetValuation, value);

    public Task SelectRoofTypeValuationAsync(string value) =>
        _ui.SelectAsync(_locators.RoofTypeValuation, value);

    public Task PressBuildingAsync(string key) =>
        _ui.PressAsync(_locators.Building, key);

    public Task WaitForBuildingContainsHabitationalOccupanciesCheckedAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingContainsHabitationalOccupanciesChecked, expected);

    public Task PressBuildingContainsHabitationalOccupanciesUncheckedAsync(string key) =>
        _ui.PressAsync(_locators.BuildingContainsHabitationalOccupanciesChecked, key);

    public Task PressBuildingCoverageAngularAsync(string key) =>
        _ui.PressAsync(_locators.BuildingCoverageAngular, key);

    public Task ClickBuildingCoverageAngularAsync() =>
        _ui.ClickAsync(_locators.BuildingCoverageAngular);

    public Task WaitForBuildingDetailsHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingDetailsHeading, expected);

    public Task ClickBuildingPhoto1Async() =>
        _ui.ClickAsync(_locators.BuildingPhoto1);

    public Task WaitForBuildingPhoto1HeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto2Async(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto2HeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto3Async(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto3HeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto4Async(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForBuildingPhoto4HeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingPhoto1, expected);

    public Task WaitForClassCodeCheckboxAsync(string expected) =>
        _ui.WaitAsync(_locators.ClassCodeCheckbox, expected);

    public Task PressClassCodeCheckboxAsync(string key) =>
        _ui.PressAsync(_locators.ClassCodeCheckbox, key);

    public Task ClickClassCodeCheckboxAsync() =>
        _ui.ClickAsync(_locators.ClassCodeCheckbox);

    public Task WaitForClassCodesAsync(string expected) =>
        _ui.WaitAsync(_locators.ClassCodes, expected);

    public Task PressCommercialButtonAsync(string key) =>
        _ui.PressAsync(_locators.CommercialButton, key);

    public Task ClickCommercialButtonAsync() =>
        _ui.ClickAsync(_locators.CommercialButton);

    public Task ClickDoesTheClientHaveASolidFuelHeatingTypeNoAsync() =>
        _ui.ClickAsync(_locators.DoesTheClientHaveASolidFuelHeatingTypeNo);

    public Task PressDoesTheResidenceHaveAThermostaticallyControlledDeviceYesAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheResidenceHaveAThermostaticallyControlledDeviceYes, key);

    public Task WaitForEChecklistEChecklistOKAsync(string expected) =>
        _ui.WaitAsync(_locators.EChecklistEChecklistOK, expected);

    public Task ClickEChecklistEChecklistOKAsync() =>
        _ui.ClickAsync(_locators.EChecklistEChecklistOK);

    public Task VerifyEQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestionsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestions, expected, property);

    public Task VerifyEQBOPBuildingBuildingDetailsSelectBurglarAlarmAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestions, expected, property);

    public Task VerifyEQBOPBuildingBuildingDetailsSelectPelletStoveAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestions, expected, property);

    public Task VerifyEQBOPBuildingBuildingDetailsSelectWoodFurnaceAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestions, expected, property);

    public Task VerifyEQBOPBuildingBuildingDetailsSelectWoodStoveAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQBOPBuildingBuildingDetailsAnswerAnyExtraPropertyAdditionalQuestions, expected, property);

    public Task ClickExceptionAsync() =>
        _ui.ClickAsync(_locators.Exception);

    public Task PressFrameAsync(string key) =>
        _ui.PressAsync(_locators.Frame, key);

    public Task ClickFrameAsync() =>
        _ui.ClickAsync(_locators.Frame);

    public Task WaitForFunctionalPersonalPropertyCheckedAsync(string expected) =>
        _ui.WaitAsync(_locators.BuildingContainsHabitationalOccupanciesChecked, expected);

    public Task PressFunctionalPersonalPropertyUncheckedAsync(string key) =>
        _ui.PressAsync(_locators.BuildingContainsHabitationalOccupanciesChecked, key);

    public Task PressGetValuationAsync(string key) =>
        _ui.PressAsync(_locators.GetValuation, key);

    public Task ClickGetValuationAsync() =>
        _ui.ClickAsync(_locators.GetValuationButton);

    public Task PressGrossSalesReceiptsAsync(string key) =>
        _ui.PressAsync(_locators.GrossSalesReceipts, key);

    public Task EnterGrossSalesReceiptsAsync(string value) =>
        _ui.FillAsync(_locators.GrossSalesReceipts, value);

    public Task PressHeatingYearAsync(string key) =>
        _ui.PressAsync(_locators.HeatingYear, key);

    public Task EnterHeatingYearAsync(string value) =>
        _ui.FillAsync(_locators.HeatingYear, value);

    public Task PressInsuranceAmountAsync(string key) =>
        _ui.PressAsync(_locators.InsuranceAmount, key);

    public Task EnterInsuredOccupancySqFtAsync(string value) =>
        _ui.FillAsync(_locators.InsuredOccupancySqFt, value);

    public Task PressInsuredOccupancySqFtAngularAsync(string key) =>
        _ui.PressAsync(_locators.InsuredOccupancySqFt, key);

    public Task SelectIsAnyHeatSourceThermostaticallyControlledYesAsync(string value) =>
        _ui.SelectAsync(_locators.IsAnyHeatSourceThermostaticallyControlledYes, value);

    public Task ClickIsAnyHeatSourceThermostaticallyControlledYesAsync() =>
        _ui.ClickAsync(_locators.IsAnyHeatSourceThermostaticallyControlledYes.Filter(new() { HasText = "Yes" }));

    public Task PressIsTheBuildingHeatedWithOneOfTheFollowingNoneOfTheAboveCheckboxAngularAsync(string key) =>
        _ui.PressAsync(_locators.IsTheBuildingHeatedWithOneOfTheFollowingNoneOfTheAboveCheckboxAngular, key);

    public Task ClickIsTheBuildingHeatedWithOneOfTheFollowingNoneOfTheAboveCheckboxAngularAsync() =>
        _ui.ClickAsync(_locators.IsTheBuildingHeatedWithOneOfTheFollowingNoneOfTheAboveCheckboxAngular);
public Task PressNumberOfStoriesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfStories, key);

    public Task EnterNumberOfStoriesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfStories, value);

    public Task WaitForOccupancySQFTHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.OccupancySQFTHeading, expected);

    public Task VerifyOccupancySqFootageTotalAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.OccupancySqFootageTotal, expected, property);

    public Task EnterOccupancySqFootageTotalAsync(string value) =>
        _ui.FillAsync(_locators.OccupancySqFootageTotal, value);

    public Task PressOccupancySqFtLimitAsync(string key) =>
        _ui.PressAsync(_locators.OccupancySqFtLimit, key);

    public Task EnterPerilsAsync(string value) =>
        _ui.FillAsync(_locators.Perils, value);

    public Task PressPersonalPropertyLimitAsync(string key) =>
        _ui.PressAsync(_locators.PersonalPropertyLimit, key);

    public Task EnterPersonalPropertyLimitAsync(string value) =>
        _ui.FillAsync(_locators.PersonalPropertyLimit, value);

    public Task WaitForPersonalPropertyLimitCheckBoxAngularAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalPropertyLimitCheckBoxAngular, expected);

    public Task PressPersonalPropertyLimitCheckBoxAngularAsync(string key) =>
        _ui.PressAsync(_locators.PersonalPropertyLimitCheckBoxAngular, key);

    public Task ClickPersonalPropertyLimitCheckBoxAngularAsync() =>
        _ui.ClickAsync(_locators.PersonalPropertyLimitCheckBoxAngular);

    public Task PressPlumbingYearAsync(string key) =>
        _ui.PressAsync(_locators.PlumbingYear, key);

    public Task EnterPlumbingYearAsync(string value) =>
        _ui.FillAsync(_locators.PlumbingYear, value);

    public Task ClickRCTAsync() =>
        _ui.ClickAsync(_locators.RCT);

    public Task PressRateType1Async(string key) =>
        _ui.PressAsync(_locators.RateType1, key);

    public Task PressReplacementCostAsync(string key) =>
        _ui.PressAsync(_locators.ActualCashValue, key);

    public Task ClickReplacementCostAsync() =>
        _ui.ClickAsync(_locators.ActualCashValue.Filter(new() { HasText = "Replacement Cost" }));

    public Task VerifyResidenceCoverageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ResidenceCoverage, expected, property);

    public Task PressResidenceCoverageAsync(string key) =>
        _ui.PressAsync(_locators.ResidenceCoverage, key);

    public Task ClickResidenceCoverageAsync() =>
        _ui.ClickAsync(_locators.ResidenceCoverage);

    public Task EnterRoofImpact1Async(string value) =>
        _ui.FillAsync(_locators.RoofImpact1, value);

    public Task EnterRoofType1Async(string value) =>
        _ui.FillAsync(_locators.RoofType1, value);

    public Task SelectRoofType1Async(string value) =>
        _ui.SelectAsync(_locators.RoofType1, value);

    public Task PressRoofTypeMainAsync(string key) =>
        _ui.PressAsync(_locators.GetValuation, key);

    public Task ClickRoofTypeSelectionAsync() =>
        _ui.ClickAsync(_locators.GetValuation);

    public Task PressRoofYearAsync(string key) =>
        _ui.PressAsync(_locators.AutomaticCommercialCookingExhaustAndExtinguishingANSULSystemYes, key);

    public Task EnterRoofYearAsync(string value) =>
        _ui.FillAsync(_locators.AutomaticCommercialCookingExhaustAndExtinguishingANSULSystemYes, value);

    public Task PressSaveAsync(string key) =>
        _ui.PressAsync(_locators.Save, key);

    public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task ClickSeasonalOrVacantNoAsync() =>
        _ui.ClickAsync(_locators.SeasonalOrVacantNo);

    public Task PressSelectAnyOfTheFollowingWhichApplyToThisBuildingNoneOfTheAboveCheckboxAngularAsync(string key) =>
        _ui.PressAsync(_locators.SelectAnyOfTheFollowingWhichApplyToThisBuildingNoneOfTheAboveCheckboxAngular, key);

    public Task ClickSelectAnyOfTheFollowingWhichApplyToThisBuildingNoneOfTheAboveCheckboxAngularAsync() =>
        _ui.ClickAsync(_locators.SelectAnyOfTheFollowingWhichApplyToThisBuildingNoneOfTheAboveCheckboxAngular);

    public Task WaitForSelectIfClientOwnsOrRentsTheBuildingAsync(string expected) =>
        _ui.WaitAsync(_locators.SelectIfClientOwnsOrRentsTheBuilding, expected);

    public Task EnterTotalBuildingSqFootageAsync(string value) =>
        _ui.FillAsync(_locators.SelectIfClientOwnsOrRentsTheBuilding, value);

    public Task PressSingleFamilyAsync(string key) =>
        _ui.PressAsync(_locators.SingleFamily, key);

    public Task WaitForSprinklerYesAsync(string expected) =>
        _ui.WaitAsync(_locators.SprinklerYes, expected);

    public Task SelectSprinklerYesAsync(string value) =>
        _ui.SelectAsync(_locators.SprinklerYes, value);

    public Task ClickSprinklerYesAsync() =>
        _ui.ClickAsync(_locators.SprinklerYes.Filter(new() { HasText = "Yes" }));

    public Task PressSquareFeetAsync(string key) =>
        _ui.PressAsync(_locators.SquareFeet, key);

    public Task ClickStandardRCTUseDefaultsAsync() =>
        _ui.ClickAsync(_locators.StandardRCTUseDefaults);

    public Task PressWiringYearAsync(string key) =>
        _ui.PressAsync(_locators.WiringYear, key);

    public Task EnterWiringYearAsync(string value) =>
        _ui.FillAsync(_locators.WiringYear, value);

    public Task PressYearBuiltAsync(string key) =>
        _ui.PressAsync(_locators.YearBuilt, key);

    public Task EnterYearBuiltAsync(string value) =>
        _ui.FillAsync(_locators.YearBuilt, value);

    public Task PressYearBuiltRenovatedAsync(string key) =>
        _ui.PressAsync(_locators.YearBuiltRenovated, key);

    public Task EnterYearBuiltRenovatedAsync(string value) =>
        _ui.FillAsync(_locators.YearBuiltRenovated, value);
}
