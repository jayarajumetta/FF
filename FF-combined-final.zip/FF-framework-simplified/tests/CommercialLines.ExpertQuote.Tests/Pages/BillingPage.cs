using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class BillingPage
{
    private readonly BrowserSession _browser;
    private readonly BillingLocators _locators;
    private readonly UiActions _ui;

    public BillingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new BillingLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAddress1Async(string key) =>
        _ui.PressAsync(_locators.Address1, key);

    public Task EnterAddress1Async(string value) =>
        _ui.FillAsync(_locators.Address1, value);

    public Task WaitForBillingAsync(string expected) =>
        _ui.WaitAsync(_locators.Billing, expected);

    public Task WaitForBillingInformationHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.BillingInformationHeading, expected);

    public Task PressBusinessNameAsync(string key) =>
        _ui.PressAsync(_locators.BusinessName, key);

    public Task EnterBusinessNameAsync(string value) =>
        _ui.FillAsync(_locators.BusinessName, value);

    public Task PressCheckButtonAsync(string key) =>
        _ui.PressAsync(_locators.CheckButton, key);

    public Task WaitForCheckNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.CheckNumber, expected);

    public Task VerifyCheckNumberAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CheckNumber, expected, property);

    public Task PressCheckNumberAsync(string key) =>
        _ui.PressAsync(_locators.CheckNumber, key);

    public Task EnterCheckNumberAsync(string value) =>
        _ui.FillAsync(_locators.CheckNumber, value);

    public Task PressChoosePaymentDueDateAsync(string key) =>
        _ui.PressAsync(_locators.ChoosePaymentDueDate, key);

    public Task EnterChoosePaymentDueDateAsync(string value) =>
        _ui.FillAsync(_locators.ChoosePaymentDueDate, value);

    public Task PressCityAsync(string key) =>
        _ui.PressAsync(_locators.City, key);

    public Task EnterCityAsync(string value) =>
        _ui.FillAsync(_locators.City, value);

    public Task ClickCreateNewBillingAccountAsync() =>
        _ui.ClickAsync(_locators.CreateNewBillingAccount);

    public Task PressCreditCardButtonAsync(string key) =>
        _ui.PressAsync(_locators.CheckButton, key);

    public Task PressDirectBillButtonAsync(string key) =>
        _ui.PressAsync(_locators.DirectBillButton, key);

    public Task ClickDirectBillButtonAsync() =>
        _ui.ClickAsync(_locators.DirectBillButton);

    public Task PressFirstNameAsync(string key) =>
        _ui.PressAsync(_locators.FirstName, key);

    public Task EnterFirstNameAsync(string value) =>
        _ui.FillAsync(_locators.FirstName, value);

    public Task ClickInitialPaymentFullBalanceAsync() =>
        _ui.ClickAsync(_locators.InitialPaymentFullBalance);

    public Task ClickCheckButtonAsync() =>
        _ui.ClickAsync(_locators.CheckButton);

    public Task ClickNextSubmissionAsync() =>
        _ui.ClickAsync(_locators.NextSubmission);

    public Task PressLastNameAsync(string key) =>
        _ui.PressAsync(_locators.LastName, key);

    public Task EnterLastNameAsync(string value) =>
        _ui.FillAsync(_locators.LastName, value);
public Task PressN1PaymentButtonAsync(string key) =>
        _ui.PressAsync(_locators.N1PaymentButton, key);

    public Task ClickN1PaymentButtonAsync() =>
        _ui.ClickAsync(_locators.N1PaymentButton);

    public Task ClickOTHERButtonAsync() =>
        _ui.ClickAsync(_locators.OTHERButton);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task PressStateAsync(string key) =>
        _ui.PressAsync(_locators.State, key);

    public Task SelectStateAsync(string value) =>
        _ui.SelectAsync(_locators.State, value);

    public Task VerifyTableRowCellLinkAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.TableRowCellLink, expected, property);

    public Task PressZipCodeAsync(string key) =>
        _ui.PressAsync(_locators.ZipCode, key);

    public Task EnterZipCodeAsync(string value) =>
        _ui.FillAsync(_locators.ZipCode, value);
}
