using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class LossHistoryPage
{
    private readonly BrowserSession _browser;
    private readonly LossHistoryLocators _locators;
    private readonly UiActions _ui;

    public LossHistoryLocators Locators => _locators;

    public LossHistoryPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new LossHistoryLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickADDCLAIMAsync() =>
        _ui.ClickAsync(_locators.ADDCLAIM);

    public Task ClickAddClaimAsync() =>
        _ui.ClickAsync(_locators.AddClaim);

    public Task WaitForAddANoteAsync(string expected) =>
        _ui.WaitAsync(_locators.AddANote, expected);

    public Task PressAddANoteAsync(string key) =>
        _ui.PressAsync(_locators.AddANote, key);

    public Task EnterAllLinkAsync(string value) =>
        _ui.FillAsync(_locators.AllLink, value);

    public Task PressAmountPaidAsync(string key) =>
        _ui.PressAsync(_locators.AmountPaid, key);

    public Task EnterAmountPaidAsync(string value) =>
        _ui.FillAsync(_locators.AmountPaid, value);

    public Task PressAmountReservedAsync(string key) =>
        _ui.PressAsync(_locators.AmountReserved, key);

    public Task EnterAmountReservedAsync(string value) =>
        _ui.FillAsync(_locators.AmountReserved, value);

    public Task VerifyClaimSummaryTableRowCellExplicitNameAmountAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClaimSummaryTableRowCellExplicitNameAmount, expected, property);

    public Task VerifyClaimSummaryTableRowCellExplicitNameCATClaimAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClaimSummaryTableRowCellExplicitNameCATClaim, expected, property);

    public Task VerifyClaimSummaryTableRowCellExplicitNameClaimDateAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClaimSummaryTableRowCellExplicitNameClaimDate, expected, property);

    public Task VerifyClaimSummaryTableRowCellExplicitNameLineOfCoverageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClaimSummaryTableRowCellExplicitNameLineOfCoverage, expected, property);

    public Task VerifyClaimSummaryTableRowCellExplicitNameTypeOfLossAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClaimSummaryTableRowCellExplicitNameTypeOfLoss, expected, property);

    public Task PressDateOfOccurrenceAsync(string key) =>
        _ui.PressAsync(_locators.ADDCLAIM, key);

    public Task EnterDateOfOccurrenceAsync(string value) =>
        _ui.FillAsync(_locators.ADDCLAIM, value);

    public Task PressDescriptionOfOccurrenceOrClaimAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfOccurrenceOrClaim, key);

    public Task EnterDescriptionOfOccurrenceOrClaimAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfOccurrenceOrClaim, value);

    public Task WaitForEChecklistEChecklistOKAsync(string expected) =>
        _ui.WaitAsync(_locators.EChecklistEChecklistOK, expected);

    public Task ClickEChecklistEChecklistOKAsync() =>
        _ui.ClickAsync(_locators.EChecklistEChecklistOK);

    public Task ClickExceptionAsync() =>
        _ui.ClickAsync(_locators.Exception);

    public Task PressExpenseAmountAsync(string key) =>
        _ui.PressAsync(_locators.ExpenseAmount, key);

    public Task EnterExpenseAmountAsync(string value) =>
        _ui.FillAsync(_locators.ExpenseAmount, value);
public Task WaitForLossRuns3YearsHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.LossRuns3YearsHeader, expected);

    public Task WaitForLossRunsHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.LossRuns3YearsHeader, expected);

    public Task PressN3YearsAsync(string key) =>
        _ui.PressAsync(_locators.N3Years, key);

    public Task ClickN3YearsAsync() =>
        _ui.ClickAsync(_locators.N3Years);

    public Task ClickOpenButtonAsync() =>
        _ui.ClickAsync(_locators.OpenButton);

    public Task ClickSaveClaimAsync() =>
        _ui.ClickAsync(_locators.SaveClaim);

    public Task PressPolicyExpireAsync(string key) =>
        _ui.PressAsync(_locators.PolicyExpire, key);

    public Task EnterPolicyExpireAsync(string value) =>
        _ui.FillAsync(_locators.PolicyExpire, value);

    public Task PressPolicyStartAsync(string key) =>
        _ui.PressAsync(_locators.PolicyStart, key);

    public Task EnterPolicyStartAsync(string value) =>
        _ui.FillAsync(_locators.PolicyStart, value);

    public Task PressPriorInsuranceLatestCarrierAsync(string key) =>
        _ui.PressAsync(_locators.PriorInsuranceLatestCarrier, key);

    public Task EnterPriorInsuranceLatestCarrierAsync(string value) =>
        _ui.FillAsync(_locators.PriorInsuranceLatestCarrier, value);

    public Task PressPriorInsuranceLatestExpirationDateAsync(string key) =>
        _ui.PressAsync(_locators.PriorInsuranceLatestExpirationDate, key);

    public Task EnterPriorInsuranceLatestExpirationDateAsync(string value) =>
        _ui.FillAsync(_locators.PriorInsuranceLatestExpirationDate, value);

    public Task SelectPriorPolicyNoAsync(string value) =>
        _ui.SelectAsync(_locators.PriorPolicyNo, value);

    public Task ClickPriorPolicyNoAsync() =>
        _ui.ClickAsync(_locators.PriorPolicyNo);

    public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task PressTypeOfLossDropdownAsync(string key) =>
        _ui.PressAsync(_locators.TypeOfLossDropdown, key);

    public Task EnterTypeOfLossDropdownAsync(string value) =>
        _ui.FillAsync(_locators.TypeOfLossDropdown, value);

    public Task ClickTypeOfLossSelectionAsync() =>
        _ui.ClickAsync(_locators.ADDCLAIM);

    public Task PressYearsInBusinessAsync(string key) =>
        _ui.PressAsync(_locators.YearsInBusiness, key);

}
