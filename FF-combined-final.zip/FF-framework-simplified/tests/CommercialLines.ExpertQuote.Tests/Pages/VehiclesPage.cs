using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class VehiclesPage
{
    private readonly BrowserSession _browser;
    private readonly VehiclesLocators _locators;
    private readonly UiActions _ui;
    private readonly QuoteSearchLocators _quoteSearchLocators;

    public VehiclesPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new VehiclesLocators(browser.Page);
        _ui = ui;
        _quoteSearchLocators = new QuoteSearchLocators(browser.Page);
    }

    public Task WaitForAddCoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.AddCoverage, expected);

    public Task SelectAddCoverageAsync(string value) =>
        _ui.SelectAsync(_locators.AddCoverage, value);

    public Task ClickClientInfoSearchAsync() =>
        _ui.ClickAsync(_quoteSearchLocators.QuoteSearchButton);

    public Task PressDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.Description, key);

    public Task PressLimitAsync(string key) =>
        _ui.PressAsync(_locators.Limit, key);
public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task WaitForScheduledPersonalPropertyHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.ScheduledPersonalPropertyHeader, expected);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task PressSearchByNameOrCodeAsync(string key) =>
        _ui.PressAsync(_locators.SearchByNameOrCode, key);

    public Task EnterTrueAsync(string value) =>
        _ui.ClickAsync(_locators.ScheduledPersonalPropertyHeader);

    public Task PressYearOfLastAppraisalAsync(string key) =>
        _ui.PressAsync(_locators.YearOfLastAppraisal, key);

}
