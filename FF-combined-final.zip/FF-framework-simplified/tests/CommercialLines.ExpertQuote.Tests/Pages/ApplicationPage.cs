using System.Text.RegularExpressions;
using InsuranceAutomation.Core;
using Microsoft.Playwright;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class ApplicationPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly UiActions _ui;

    public ApplicationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _ui = ui;
    }

    private ILocator Username => _page.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions { NameRegex = new Regex("User ?Name|Username", RegexOptions.IgnoreCase) });
    private ILocator Password => _page.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions { NameRegex = new Regex("Password", RegexOptions.IgnoreCase) });
    private ILocator SignIn => _page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { NameRegex = new Regex("Sign On|Sign In|Login", RegexOptions.IgnoreCase) });

    public async Task NavigateAsync(string url)
    {
        if (string.IsNullOrWhiteSpace(url)) throw new ArgumentException("Application URL is required.", nameof(url));
        await _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
    }

    public async Task SignInAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Username is required.", nameof(username));
        if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Password is required.", nameof(password));

        // If the session is still authenticated (e.g., returning from Duck Creek), the app may
        // skip the login form and land directly on the dashboard. Detect that before waiting on the form.
        var newQuoteButton = _page.GetByRole(AriaRole.Button, new() { Name = "New Quote", Exact = true });
        bool isAlreadySignedIn;
        try
        {
            isAlreadySignedIn = await newQuoteButton.IsVisibleAsync(new LocatorIsVisibleOptions { Timeout = 3000 });
        }
        catch
        {
            isAlreadySignedIn = false;
        }

        if (!isAlreadySignedIn)
        {
            await _ui.FillAsync(Username, username);
            await _ui.FillAsync(Password, password);
            await _ui.ClickAsync(SignIn);

            // Wait for navigation to complete after sign-in
            await _page.WaitForLoadStateAsync(LoadState.NetworkIdle, new PageWaitForLoadStateOptions { Timeout = 60000 });
        }

        // Wait for the dashboard to be ready by checking for the New Quote button
        await newQuoteButton.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 30000 });
    }
}
