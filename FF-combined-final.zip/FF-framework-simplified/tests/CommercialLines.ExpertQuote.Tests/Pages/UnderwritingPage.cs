using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class UnderwritingPage
{
    private readonly BrowserSession _browser;
    private readonly UnderwritingLocators _locators;
    private readonly UiActions _ui;

    public UnderwritingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new UnderwritingLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAcceptAsync(string expected) =>
        _ui.WaitAsync(_locators.Accept, expected);

    public Task EnterAgentCommentsAsync(string value) =>
        EnterAgentCommentsWithRetryAsync(_locators.AgentComments, value, "AgentComments");

    public Task EnterAgentComments2Async(string value) =>
        EnterAgentCommentsWithRetryAsync(_locators.AgentComments2, value, "AgentComments2");

    // The Agent Comments input is occasionally re-rendered/reset by Angular change detection right after
    // keystrokes are entered, so the typed value can silently disappear. Verifying the value stuck and
    // retrying makes the interaction deterministic instead of intermittently failing.
    private async Task EnterAgentCommentsWithRetryAsync(ILocator locator, string value, string controlName)
    {

        await locator.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible });
        const int maxAttempts = 3;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await _ui.PressSequentiallyAsync(locator, value);

            // Commit the value so Angular's change detection binds it to the model instead of
            // leaving it as a transient DOM-only value that can be wiped by a later re-render.
            try { await locator.BlurAsync(); } catch (Exception ex) when (ex is PlaywrightException or TimeoutException) { }

            // Angular can re-render the control asynchronously after the input/blur events fire,
            // silently resetting the value a few hundred ms later. Re-check after a short settle
            // delay so we don't declare success on a value that is about to be wiped out.

            string actual;
            try
            {
                actual = await locator.InputValueAsync();
            }
            catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
            {
                actual = string.Empty;
            }
            if (string.Equals(actual, value, StringComparison.Ordinal)) return;
            if (attempt < maxAttempts) await Task.Delay(500);
        }
    }

    public async Task<bool> IsAgentCommentsVisibleAndEditableAsync()
    {
        try
        {
            await _locators.AgentComments.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 3000 });
        }
        catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
        {
            return false;
        }
        return await _locators.AgentComments.IsVisibleAsync() && await _locators.AgentComments.IsEditableAsync();
    }

    public async Task<bool> IsAgentComments2VisibleAndEditableAsync()
    {
        try
        {
            await _locators.AgentComments2.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 3000 });
        }
        catch (Exception ex) when (ex is PlaywrightException or TimeoutException)
        {
            return false;
        }
        return await _locators.AgentComments2.IsVisibleAsync() && await _locators.AgentComments2.IsEditableAsync();
    }

    public Task ClickAcceptAsync() =>
        _ui.ClickAsync(_locators.Accept);

    public Task ClickReferToUWAsync() =>
        _ui.ClickAsync(_locators.ReferToUW);

    public Task PressBuildingEligibilityQuestionsNoneOfTheAboveCheckboxAngularAsync(string key) =>
        _ui.PressAsync(_locators.BuildingEligibilityQuestionsNoneOfTheAboveCheckboxAngular, key);

    public Task ClickBuildingEligibilityQuestionsNoneOfTheAboveCheckboxAngularAsync() =>
        _ui.ClickAsync(_locators.BuildingEligibilityQuestionsNoneOfTheAboveCheckboxAngular);

    public Task EnterEntityTypeAsync(string value) =>
        _ui.FillAsync(_locators.EntityType, value);

    public Task PressInsuranceScoreConsentAsync(string key) =>
        _ui.PressAsync(_locators.InsuranceScoreConsent, key);

    public Task ClickInsuranceScoreConsentAsync() =>
        _ui.ClickAsync(_locators.InsuranceScoreConsent);
public Task PressNoneOfTheAboveCheckBoxAsync(string key) =>
        _ui.PressAsync(_locators.NoneOfTheAboveCheckBox, key);

    public Task ClickNoneOfTheAboveCheckBoxAsync() =>
        _ui.ClickAsync(_locators.NoneOfTheAboveCheckBox);

    public Task<string> CapturePremiumAsync(string property = "") =>
        _ui.CaptureAsync(_locators.Premium, property);

    public Task ClickPrimaryInsuredAsync() =>
        _ui.ClickAsync(_locators.PrimaryInsured);

    public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task<bool> IsKeepGoingConfirmPresentAsync() =>
        _ui.ExistsAsync(_locators.KeepGoingConfirm);

    public async Task ClickKeepGoingConfirmAsync()
    {
        var locator = _locators.KeepGoingConfirm;
        try
        {
            await _ui.ClickAsync(locator);
        }
        catch (Exception ex) when (ex is TimeoutException or PlaywrightException)
        {
            await locator.ScrollIntoViewIfNeededAsync();
            try
            {
                await locator.ClickAsync(new LocatorClickOptions { Force = true, Timeout = 5000 });
            }
            catch (Exception ex2) when (ex2 is TimeoutException or PlaywrightException)
            {
                await locator.EvaluateAsync("el => el.click()");
            }
        }
    }

    public async Task ClickKeepGoingConfirmIfPresentAsync()
    {
        if (await IsKeepGoingConfirmPresentAsync())
            await ClickKeepGoingConfirmAsync();
    }

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task VerifyTABLERowCellExplicitName1Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TABLERowCellExplicitName1, expected, property);
}
