using InsuranceAutomation.Core;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class SocialSecurityPage
{
    private readonly SocialSecurityLocators _locators;
    private readonly UiActions _ui;

    public SocialSecurityPage(BrowserSession browser, UiActions ui)
    {
        _locators = new SocialSecurityLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifySsnNotFoundMessageAsync() =>
        _ui.VerifyAsync(_locators.SsnNotFoundMessage, "Visible", "");

    public Task EnterSsnAsync(string value) =>
        _ui.FillAsync(_locators.SsnInput, value);

    public Task VerifySubmitAsync() =>
        _ui.VerifyAsync(_locators.SubmitAngular, "Visible", "");

    public async Task ClickSubmitAsync()
    {
        // The Angular overlay sometimes blocks clicks, use JavaScript click as workaround
        await _locators.SubmitAngular.EvaluateAsync("el => el.click()");
    }
    public Task ClickContinueAsync() =>
        _ui.ClickAsync(_locators.Continue);

    public Task<bool> IsContinuePresentAsync() => _ui.ExistsAsync(_locators.Continue);

    public Task VerifyNoPrefillMatchFoundAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NoPrefillMatchFound, expected, property);

    public Task<bool> IsNoPrefillMatchFoundPresentAsync() => _ui.ExistsAsync(_locators.NoPrefillMatchFound);

    // Compatibility methods for other generated bindings.
    public Task VerifyEChecklistEChecklistSubmitAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SubmitAngular, expected, property);

    public Task ClickEChecklistEChecklistSubmitAsync() => ClickSubmitAsync();
    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NoPrefillMatchFound, expected, property);
    public Task<bool> IsScreenHeadingPresentAsync() => _ui.ExistsAsync(_locators.NoPrefillMatchFound);
    public Task WaitForSubmitAngularAsync(string expected) =>
        _ui.WaitAsync(_locators.SubmitAngular, expected);
    public Task PressSubmitAngularAsync(string key) =>
        _ui.PressAsync(_locators.SubmitAngular, key);
    public Task ClickSubmitAngularAsync() => ClickSubmitAsync();
    public Task WaitForTheSSNCouldNotBeFoundPleaseEnterAnSSNAsync(string expected) =>
        _ui.WaitAsync(_locators.SsnNotFoundMessage, expected);
    public Task VerifyTheSSNCouldNotBeFoundPleaseEnterAnSSNAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SsnNotFoundMessage, expected, property);
    public Task EnterTheSSNCouldNotBeFoundPleaseEnterAnSSNAsync(string value) => EnterSsnAsync(value);
}
