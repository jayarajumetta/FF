using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class AccountInformationPage
{
    private readonly BrowserSession _browser;
    private readonly AccountInformationLocators _locators;
    private readonly UiActions _ui;

    public AccountInformationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new AccountInformationLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifyAccountInformationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AccountInformation, expected, property);

    public Task WaitForAccountInformationHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountInformation, expected);

    public Task PressAdditionalInterestsNextAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInterestsNext, key);

    public Task ClickAdditionalInterestsNextAsync() =>
        _ui.ClickAsync(_locators.AdditionalInterestsNext);

    public Task EnterAddress2Async(string value) =>
        _ui.FillAsync(_locators.Address2, value);

    public Task PressAddress2Async(string key) =>
        _ui.PressAsync(_locators.Address2, key);

    public Task EnterCityAsync(string value) =>
        _ui.FillAsync(_locators.City, value);

    public Task PressCityAsync(string key) =>
        _ui.PressAsync(_locators.City, key);

    public Task SelectHaveYouReceivedMailAtThisAddressForAtLeast90DaysYesAsync(string value) =>
        _ui.SelectAsync(_locators.HaveYouReceivedMailAtThisAddressForAtLeast90DaysYes, value);

    public Task SelectIsTheAccountAddressAlsoWhereTheClientResidesYesAsync(string value) =>
        _ui.SelectAsync(_locators.IsTheAccountAddressAlsoWhereTheClientResidesYes, value);

    public Task SelectHaveYouReceivedMailAtThisAddressForAtLeast90DaysYesAsync() =>
    _ui.ClickAsync(_locators.HaveYouReceivedMailAtThisAddressForAtLeast90DaysYes);

    public Task SelectIsTheAccountAddressAlsoWhereTheClientResidesYesAsync() =>
        _ui.ClickAsync(_locators.IsTheAccountAddressAlsoWhereTheClientResidesYes);

    public Task WaitForMapAsync(string expected) =>
        _ui.WaitAsync(_locators.Map, expected);

    public Task VerifyMapAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Map, expected, property);

    public Task<bool> IsMapPresentAsync() =>
        _ui.ExistsAsync(_locators.Map);

    public Task SelectMarriedAsync(string value) =>
        _ui.SelectAsync(_locators.Married, value);

    public Task ClickMarriedAsync() =>
        _ui.ClickAsync(_locators.Married);

    public Task EnterOwnerMiddleNameAsync(string value) =>
        _ui.FillAsync(_locators.OwnerMiddleName, value);

    public Task PressOwnerMiddleNameAsync(string key) =>
        _ui.PressAsync(_locators.OwnerMiddleName, key);

    public Task WaitForSatelliteAsync(string expected) =>
        _ui.WaitAsync(_locators.Satellite, expected);

    public Task VerifySatelliteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Satellite, expected, property);

    public Task<bool> IsSatellitePresentAsync() =>
        _ui.ExistsAsync(_locators.Satellite);

    public Task SelectStateAsync(string value) =>
        _ui.SelectAsync(_locators.StateDropdown, value);

    public Task SelectState0110EAsync(string value) =>
    _ui.SelectAsync(_locators.StateDropdown, value);

    public Task EnterStateAE19AAsync(string value) =>
        _ui.FillAsync(_locators.StateDropdown, value);

    public Task ClickStateDropdownAsync() =>
        _ui.ClickAsync(_locators.StateDropdown);


    public Task EnterStreetAddressAsync(string value) =>
        _ui.FillAsync(_locators.StreetAddress, value);

    public Task PressStreetAddressAsync(string key) =>
        _ui.PressAsync(_locators.StreetAddress, key);

    public Task EnterZipAsync(string value) =>
        _ui.FillAsync(_locators.Zip, value);

    public Task PressZipAsync(string key) =>
        _ui.PressAsync(_locators.Zip, key);

    public Task EnterCountyAsync(string value) =>
        _ui.FillAsync(_locators.County, value);

    public Task PressCountyAsync(string key) =>
        _ui.PressAsync(_locators.County, key);


    public Task EnterOwnerPhoneAsync(string value) =>
        _ui.FillAsync(_locators.OwnerPhone, value);


    public Task EnterOwnerEmailAsync(string value) =>
        _ui.FillAsync(_locators.OwnerEmail, value);

}
