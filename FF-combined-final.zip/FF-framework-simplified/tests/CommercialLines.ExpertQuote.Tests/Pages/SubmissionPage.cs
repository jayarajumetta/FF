using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class SubmissionPage
{
    private readonly BrowserSession _browser;
    private readonly SubmissionLocators _locators;
    private readonly UiActions _ui;

    public SubmissionPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new SubmissionLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsAsync(string expected) =>
        _ui.WaitAsync(_locators.AllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabs, expected);

    public Task VerifyAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabs, expected, property);

    public Task<bool> IsAllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabsPresentAsync() =>
        _ui.ExistsAsync(_locators.AllRequiredFieldsHaveNotBeenCompletedPleaseCompleteHighlightedTabs);

    public Task VerifyCloseAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Close, expected, property);

    public Task ClickCloseAsync() =>
        _ui.ClickAsync(_locators.Close);

    public Task<bool> IsClosePresentAsync() =>
        _ui.ExistsAsync(_locators.Close);

    public Task ClickCompleteApplicationAsync() =>
        _ui.ClickAsync(_locators.CompleteApplication);

    public Task<bool> IsCompleteApplicationPresentAsync() =>
        _ui.ExistsAsync(_locators.CompleteApplication);

    public Task VerifyIsThisCoverageBoundAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IsThisCoverageBound, expected, property);

    public Task PressIsThisCoverageBoundAsync(string key) =>
        _ui.PressAsync(_locators.IsThisCoverageBound, key);

    public Task<bool> IsIsThisCoverageBoundPresentAsync() =>
        _ui.ExistsAsync(_locators.IsThisCoverageBound);

    public Task ClickLaunchToChecklistButtonAsync() =>
        _ui.ClickAsync(_locators.LaunchToChecklistButton);
public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task<bool> IsLoadingMessagePresentAsync() =>
        _ui.ExistsAsync(_locators.LoadingMessage);

    public Task VerifyNoReferralNeededVerificationAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LaunchToChecklistButton, expected, property);

    public Task ClickReferToUWAsync() =>
        _ui.ClickAsync(_locators.ReferToUW);

    public Task WaitForStoplightWaitingWindowAsync(string expected) =>
        _ui.WaitAsync(_locators.StoplightWaitingWindow, expected);

    public Task<bool> IsStoplightWaitingWindowPresentAsync() =>
        _ui.ExistsAsync(_locators.StoplightWaitingWindow);

    public Task VerifyStoplightWaitingWindowErrorAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.StoplightWaitingWindowError, expected, property);

    public Task<bool> IsStoplightWaitingWindowErrorPresentAsync() =>
        _ui.ExistsAsync(_locators.StoplightWaitingWindowError);

    public Task ClickStoplightWaitingWindowFirstCloseButtonOnErrorAsync() =>
        _ui.ClickAsync(_locators.StoplightWaitingWindowFirstCloseButtonOnError);

    public Task<bool> IsStoplightWaitingWindowFirstCloseButtonOnErrorPresentAsync() =>
        _ui.ExistsAsync(_locators.StoplightWaitingWindowFirstCloseButtonOnError);

    public Task WaitForSubmissionScreenHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.SubmissionScreenHeading, expected);

    public Task VerifyTABLERowCellExplicitName1Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TABLERowCellExplicitName1, expected, property);

    public Task VerifyTABLERowCellExplicitName2Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TABLERowCellExplicitName2, expected, property);

    public Task VerifyTABLERowCellExplicitName4Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TABLERowCellExplicitName4, expected, property);

    public Task VerifyTABLERowCellExplicitName5Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TABLERowCellExplicitName5, expected, property);

    public Task ClickTransmitAsync() =>
        _ui.ClickAsync(_locators.TransmitButton);

    public Task WaitForTransmitConfirmationAsync(string expected = "Visible") =>
        _ui.WaitAsync(_locators.TransmitConfirmationHeading, expected);

    public Task VerifyTransactionStatusAsync(string expected, string property = "InnerText") =>
        _ui.VerifyAsync(_locators.TransactionStatus, expected, property);

    public async Task WaitForTransactionStatusAsync(string expected)
    {
        await _locators.TransactionStatus.WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible });
        await VerifyTransactionStatusAsync(expected);
    }

    public Task PressUnderwritingRulesAgentCommentsAsync(string key) =>
        _ui.PressAsync(_locators.ReferToUW, key);
}
