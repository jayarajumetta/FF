using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class CoveragesPage
{
    private readonly BrowserSession _browser;
    private readonly CoveragesLocators _locators;
    private readonly UiActions _ui;

    public CoveragesPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new CoveragesLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAddCoverageAsync(string key) =>
        _ui.PressAsync(_locators.AddCoverage, key);

    public Task ClickApproveAsync() =>
        _ui.ClickAsync(_locators.Approve);

    public Task EnterBlanketFPPAsync(string value) =>
        _ui.FillAsync(_locators.BlanketFPP, value);

    public Task PressBlanketFPPAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task WaitForCECoverageAsync(string expected) =>
        _ui.WaitAsync(_locators.CECoverage, expected);

    public Task PressCECoverageAsync(string key) =>
        _ui.PressAsync(_locators.CECoverage, key);

    public Task PressCheckBoxAsync(string key) =>
        _ui.PressAsync(_locators.CheckBox, key);

    public Task PressChoiceAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task PressChoiceWithHorseAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task EnterDeductibleAsync(string value) =>
        _ui.FillAsync(_locators.Deductible, value);

    public Task PressDescriptionAsync(string key) =>
        _ui.PressAsync(_locators.Description, key);

    public Task PressDoesTheInsuredAndAnyExecutiveOfficerOrOwnerHaveAnyKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaintAsync(string key) =>
        _ui.PressAsync(_locators.DoesTheInsuredAndAnyExecutiveOfficerOrOwnerHaveAnyKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint, key);

    public Task PressHaveThereBeenAnyEPLClaimsSuitsOrComplaintsOrAreThereAnyNowPendingAgainstTheInsuredOrAnyExecutiveOfficerOrOwnerAsync(string key) =>
        _ui.PressAsync(_locators.HaveThereBeenAnyEPLClaimsSuitsOrComplaintsOrAreThereAnyNowPendingAgainstTheInsuredOrAnyExecutiveOfficerOrOwner, key);

    public Task SelectHaveThereBeenAnyEPLClaimsSuitsOrComplaintsOrAreThereAnyNowPendingAgainstTheInsuredOrAnyExecutiveOfficerOrOwnerAsync(string value) =>
        _ui.SelectAsync(_locators.HaveThereBeenAnyEPLClaimsSuitsOrComplaintsOrAreThereAnyNowPendingAgainstTheInsuredOrAnyExecutiveOfficerOrOwner, value);

    public async Task SelectDoesTheInsuredAndAnyExecutiveOfficerOrOwnerHaveAnyKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaintAsync(string value)
    {
        await _locators.DoesTheInsuredAndAnyExecutiveOfficerOrOwnerHaveAnyKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint
            .WaitForAsync(new LocatorWaitForOptions { State = WaitForSelectorState.Visible, Timeout = 20000 });
        await _ui.SelectAsync(_locators.DoesTheInsuredAndAnyExecutiveOfficerOrOwnerHaveAnyKnowledgeOrInformationOfAnyActErrorOrOmissionWhichMightGiveRiseToAnEPLClaimSuitOrComplaint, value);
    }

    public Task ClickNextAdditionalInterestsAsync() =>
        _ui.ClickAsync(_locators.NextAdditionalInterests);

    public async Task ClickEndLiquorLiabilityNoneOfTheAboveIfPresentAsync()
    {
        if (await _ui.ExistsAsync(_locators.EndLiquorLiabilityNoneOfTheAbove))
            await _ui.ClickAsync(_locators.EndLiquorLiabilityNoneOfTheAbove);
    }

    public Task VerifyIFRAMEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IFRAME, expected, property);

    public Task<bool> IsIFRAMEPresentAsync() =>
        _ui.ExistsAsync(_locators.IFRAME);

    public Task WaitForIFRAMEDuckCreekPolicyIFRAMEOKAsync(string expected) =>
        _ui.WaitAsync(_locators.IFRAMEDuckCreekPolicyIFRAMEOK, expected);

    public Task ClickIFRAMEDuckCreekPolicyIFRAMEOKAsync() =>
        _ui.ClickAsync(_locators.IFRAMEDuckCreekPolicyIFRAMEOK);

    public Task VerifyIsThisCoverageBoundAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IsThisCoverageBound, expected, property);

    public Task PressIsThisCoverageBoundAsync(string key) =>
        _ui.PressAsync(_locators.IsThisCoverageBound, key);

    public Task<bool> IsIsThisCoverageBoundPresentAsync() =>
        _ui.ExistsAsync(_locators.IsThisCoverageBound);

    public Task EnterLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.LiabilityLimit, value);

    public Task PressLimitAsync(string key) =>
        _ui.PressAsync(_locators.Limit, key);
public Task PressPremierAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task PressPremierWithHorseAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task VerifyReferRequestIssuanceAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ReferRequestIssuance, expected, property);

    public Task ClickReferRequestIssuanceAsync() =>
        _ui.ClickAsync(_locators.ReferRequestIssuance);

    public Task<bool> IsReferRequestIssuancePresentAsync() =>
        _ui.ExistsAsync(_locators.ReferRequestIssuance);

    public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task PressSearchByNameOrCodeAsync(string key) =>
        _ui.PressAsync(_locators.SearchByNameOrCode, key);

    public Task PressSelectAsync(string key) =>
        _ui.PressAsync(_locators.Select, key);

    public Task PressSelectWithHorseAsync(string key) =>
        _ui.PressAsync(_locators.BlanketFPP, key);

    public Task EnterUnscheduledStructuresAsync(string value) =>
        _ui.FillAsync(_locators.UnscheduledStructures, value);

    public Task EnterWaterDamageAsync(string value) =>
        _ui.FillAsync(_locators.WaterDamage, value);
}
