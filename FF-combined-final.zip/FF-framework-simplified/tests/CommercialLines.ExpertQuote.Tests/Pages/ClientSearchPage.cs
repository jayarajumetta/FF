using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class ClientSearchPage
{
    private readonly BrowserSession _browser;
    private readonly ClientSearchLocators _locators;
    private readonly UiActions _ui;

    public ClientSearchPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new ClientSearchLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAdditionalInterestsNextAsync(string key) =>
        _ui.PressAsync(_locators.AdditionalInterestsNext, key);

    public Task ClickAdditionalInterestsNextAsync() =>
        _ui.ClickAsync(_locators.AdditionalInterestsNext);

    public Task WaitForClientInfoAsync(string expected) =>
        _ui.WaitAsync(_locators.ClientInfo, expected);

    public Task VerifyClientInfoAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClientInfo, expected, property);

    public Task ClickClientInfoSearchAsync() =>
        _ui.ClickAsync(_locators.ClientInfoSearch);

    public Task ClickCreateNewClientAsync() =>
        _ui.ClickAsync(_locators.CreateNewClient);

    public Task ClickCreateNewClient1Async() =>
        _ui.ClickAsync(_locators.CreateNewClient);

    public Task ClickExistingClientSuggestionAsync() =>
        _ui.ClickAsync(_locators.ExistingClientSuggestion);

    public Task ClickPrimaryInsuredSelectionNextAsync() =>
        _ui.ClickAsync(_locators.PrimaryInsuredSelectionNext);

    public Task EnterCustomerDateOfBirthAsync(string value) =>
        _ui.FillAsync(_locators.CustomerDateOfBirth, value);

    public Task EnterCustomerNameFirstAsync(string value) =>
        _ui.FillAsync(_locators.CustomerNameFirst, value);

    public Task EnterCustomerNameLastAsync(string value) =>
        _ui.FillAsync(_locators.CustomerNameLast, value);

    public Task WaitForExistingClientMatchAsync(string expected) =>
        _ui.WaitAsync(_locators.ExistingClientMatch, expected);

    public Task VerifyExistingClientMatchAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ExistingClientMatch, expected, property);

    public Task<bool> IsExistingClientMatchPresentAsync() =>
        _ui.ExistsAsync(_locators.ExistingClientMatch);

    public Task WaitForNewExistingClientSearchAsync(string expected) =>
        _ui.WaitAsync(_locators.NewExistingClientSearch, expected);

    public Task VerifyNewQuoteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NewQuote, expected, property);

    public Task ClickNewQuoteAsync() =>
        _ui.ClickAsync(_locators.NewQuote);

}
