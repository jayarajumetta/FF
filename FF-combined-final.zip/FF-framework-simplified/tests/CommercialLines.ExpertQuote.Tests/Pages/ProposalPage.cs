using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class ProposalPage
{
    private readonly BrowserSession _browser;
    private readonly ProposalLocators _locators;
    private readonly UiActions _ui;

    public ProposalPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new ProposalLocators(browser.Page);
        _ui = ui;
    }

    public Task EnterAgentPCAsync(string value) =>
        _ui.FillAsync(_locators.AgentPC, value);

    public Task PressAgentPCAsync(string key) =>
        _ui.PressAsync(_locators.AgentPC, key);

    public Task SelectBusinessOwnersAsync(string value) =>
        _ui.SelectAsync(_locators.BusinessOwnersChip, value);

    public Task ClickBusinessOwnersAsync() =>
        _ui.ClickAsync(_locators.BusinessOwnersChip);

    public Task EnterEffectiveDate6F16BAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task<string> CaptureEffectiveDate6F16BAsync(string property = "") =>
        _ui.CaptureAsync(_locators.EffectiveDate, property);

    public Task PressEffectiveDate78F67Async(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task<string> CaptureEffectiveDate78F67Async(string property = "") =>
        _ui.CaptureAsync(_locators.EffectiveDate, property);

    public Task EnterIndividualAsync(string value) =>
        _ui.ReviewRequiredAsync($"BusinessType source parameter = '{value}'. This is orchestration data, not an editable control.");

    public Task EnterIndividualDBAAsync(string value) =>
        _ui.FillAsync(_locators.DbaOrTaNameField, value);

    public Task ClickIndividuallyOwnedDBAOrTAAsync() =>
        _ui.ClickAsync(_locators.IndividuallyOwnedDbaCheckbox);

    public Task SelectLessorsRiskNoAsync(string value) =>
        _ui.SelectAsync(_locators.LessorsRiskNoChip, value);

    public Task ClickLessorsRiskNoAsync() =>
    _ui.ClickAsync(_locators.LessorsRiskNoChip);

    public Task SelectMissouriAsync(string value) =>
        _ui.SelectAsync(_locators.Missouri, value);

    public Task ClickRatingStateDropdownOptionAsync(string value) =>
    _ui.ClickAsync(_locators.GetDropdownOption(value));

    
    public Task ClickRatingStateDropdownAsync() =>
    _ui.ClickAsync(_locators.RatingStateDropdown);

    public Task SetNewAccountAddressAsync(string value) =>
        _ui.SmartSetAsync(_locators.AccountAddressRadio, value);

    public Task ClickNoAsync() =>
        _ui.ClickAsync(_locators.LessorsRiskNoChip);

    public Task EnterPolicyTermAsync(string value) =>
        _ui.FillAsync(_locators.PolicyTermDropdown, value);

    public Task PressPolicyTermAsync(string key) =>
        _ui.PressAsync(_locators.PolicyTermDropdown, key);

    public Task VerifyProposalDetailsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ProposalDetailsHeader, expected, property);

    public Task WaitForProposalDetailsHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.ProposalDetailsHeader, expected);

    public Task PressSearchBusinessNameAsync(string key) =>
        _ui.PressAsync(_locators.BusinessNameSearchField, key);

    public Task ClickSelectSFPCEAsync() =>
        _ui.ClickAsync(_locators.SelectSFPCE);

    public Task SelectSpecialFarmPackageAsync(string value) =>
        _ui.SelectAsync(_locators.SpecialFarmPackageChip, value);

    public Task ClickStartQuoteAsync() =>
        _ui.ClickAsync(_locators.StartQuoteButton);

    public Task SelectStateAsync(string value) =>
        _ui.SelectAsync(_locators.RatingStateDropdown, value);

    public Task PressStateDropdownAsync(string key) =>
        _ui.PressAsync(_locators.RatingStateDropdown, key);

    public Task ClickStateDropdownAsync() =>
        _ui.ClickAsync(_locators.RatingStateDropdown);

    // Semantic alias retained for source-step compatibility; one physical Page method owns the control.
    public Task EnterTrueAsync(string value) => SetNewAccountAddressAsync(value);

}
