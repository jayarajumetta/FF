using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class PolicyWorkflowPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly PolicyWorkflowLocators _locators;
    private readonly UiActions _ui;

    public PolicyWorkflowLocators Locators => _locators;

    public PolicyWorkflowPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _locators = new PolicyWorkflowLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAddLiabilityYesAsync(string key) =>
        _ui.PressAsync(_locators.AddLiabilityYes, key);

    public Task ClickAddLiabilityYesAsync() =>
        _ui.ClickAsync(_locators.AddLiabilityYes);

    public Task ClickAddNarrativeAsync() =>
        _ui.ClickAsync(_locators.AddNarrative);

    public Task VerifyAlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbeAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, expected, property);

    public Task<bool> IsAlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbePresentAsync() =>
        _ui.ExistsAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe);

    public Task WaitForBODY4F40DAsync(string expected) =>
        _ui.WaitAsync(_locators.BODY4F40D, expected);

    public Task WaitForBODYABC33Async(string expected) =>
        _ui.WaitAsync(_locators.BODY4F40D, expected);

    public Task VerifyButtonAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Button, expected, property);

    public Task ClickButtonAsync() =>
        _ui.ClickAsync(_locators.Button);

    public Task<bool> IsButtonPresentAsync() =>
        _ui.ExistsAsync(_locators.Button);

    public Task ClickClientInfoSearchAsync() =>
        _ui.ClickAsync(_locators.SearchButton);

    public Task ClickCloseQuoteAsync() =>
        _ui.ClickAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe);

    public Task VerifyDescriptionOfOperationsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.DescriptionOfOperations, expected, property);

    public Task PressDescriptionOfOperationsAsync(string key) =>
        _ui.PressAsync(_locators.DescriptionOfOperations, key);

    public Task EnterDescriptionOfOperationsAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfOperations, value);

    public Task EnterDescriptionOfTheBusinessExposuresActivitiesAndExperienceAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfTheBusinessExposuresActivitiesAndExperience, value);

    public Task WaitForEChecklistEChecklistOKAsync(string expected) =>
        _ui.WaitAsync(_locators.EChecklistEChecklistOK, expected);

    public Task VerifyEChecklistEChecklistOKAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EChecklistEChecklistOK, expected, property);

    public Task ClickEChecklistEChecklistOKAsync() =>
        _ui.ClickAsync(_locators.EChecklistEChecklistOK);

    public Task<bool> IsEChecklistEChecklistOKPresentAsync() =>
        _ui.ExistsAsync(_locators.EChecklistEChecklistOK);

    public Task ClickEQCommonPrimaryInsuredRequiredAsync() =>
        _ui.ClickAsync(_locators.EQCommonPrimaryInsuredRequired);

    public Task ClickEditAsync() =>
        _ui.ClickAsync(_locators.Edit);

    public Task<bool> IsEditPresentAsync() =>
        _ui.ExistsAsync(_locators.Edit);

    public Task PressExistingClientAsync(string key) =>
        _ui.PressAsync(_locators.ExistingClient, key);

    public Task VerifyIFRAMEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IFRAME, expected, property);

    public Task<bool> IsIFRAMEPresentAsync() =>
        _ui.ExistsAsync(_locators.IFRAME);

    public Task VerifyIFRAMEDuckCreekPolicyAlertErrorMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.IFRAMEDuckCreekPolicyAlertErrorMessage, expected, property);

    public Task<bool> IsIFRAMEDuckCreekPolicyAlertErrorMessagePresentAsync() =>
        _ui.ExistsAsync(_locators.IFRAMEDuckCreekPolicyAlertErrorMessage);

    public Task ClickIndividualSoleProprietorAsync() =>
        _ui.ClickAsync(_locators.IndividualSoleProprietor);

    public Task PressInspectionContactAsync(string key) =>
        _ui.PressAsync(_locators.InspectionContact, key);

    public Task EnterLiabilityLimitAsync(string value) =>
        _ui.FillAsync(_locators.LiabilityLimit, value);

    public Task PressLivestockHorsesAsync(string key) =>
        _ui.PressAsync(_locators.LivestockHorses, key);

    public Task PressLivestockLargeAsync(string key) =>
        _ui.PressAsync(_locators.LivestockLarge, key);

    public Task PressLivestockSmallAsync(string key) =>
        _ui.PressAsync(_locators.LivestockSmall, key);
public Task VerifyLoadingMessage4DE37Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage4DE37, expected, property);

    public Task<bool> IsLoadingMessage4DE37PresentAsync() =>
        _ui.ExistsAsync(_locators.LoadingMessage4DE37);

    public Task VerifyLoadingMessageC7A0DAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage4DE37, expected, property);

    public Task<bool> IsLoadingMessageC7A0DPresentAsync() =>
        _ui.ExistsAsync(_locators.LoadingMessage4DE37);

    public Task VerifyLockedThisQuoteHasBeenSubmittedAndYouCanNoLongerMakeChangesToThisTextAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AddNarrative, expected, property);

    public Task ClickLoggedInUser5A005Async() =>
        _ui.ClickAsync(_locators.LoggedInUser5A005);

    public Task<bool> IsLoggedInUser5A005PresentAsync() =>
        _ui.ExistsAsync(_locators.LoggedInUser5A005);

    public Task ClickLoggedInUser6AD12Async() =>
        _ui.ClickAsync(_locators.LoggedInUser5A005);

    public Task<bool> IsLoggedInUser6AD12PresentAsync() =>
        _ui.ExistsAsync(_locators.LoggedInUser5A005);

    public Task ClickLoggedInUser8A0DDAsync() =>
        _ui.ClickAsync(_locators.LoggedInUser5A005);

    public Task<bool> IsLoggedInUser8A0DDPresentAsync() =>
        _ui.ExistsAsync(_locators.LoggedInUser5A005);

    public Task VerifyLogoutAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Logout, expected, property);

    public Task ClickLogoutAsync() =>
        _ui.ClickAsync(_locators.Logout);

    public Task<bool> IsLogoutPresentAsync() =>
        _ui.ExistsAsync(_locators.Logout);

    public Task ClickLogoutLogOutAsync() =>
        _ui.ClickAsync(_locators.Logout);

    public Task<bool> IsLogoutLogOutPresentAsync() =>
        _ui.ExistsAsync(_locators.Logout);

    public Task VerifyNameAndQuoteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, expected, property);

    public Task<string> CaptureNameAndQuoteAsync(string property = "") =>
        _ui.CaptureAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, property);

    public Task<string> CaptureNameAndQuoteNum8EB77Async(string property = "") =>
        _ui.CaptureAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, property);

    public Task WaitForNameAndQuoteNumCA893Async(string expected) =>
        _ui.WaitAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, expected);

    public Task VerifyNameAndQuoteNumCA893Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe, expected, property);

    public Task<bool> IsNameAndQuoteNumCA893PresentAsync() =>
        _ui.ExistsAsync(_locators.AlertErrorMessageBoxPolicyNumberExistsForThisQuoteNumbe);

    public Task WaitForNarrativeScreenHeadingAsync(string expected) =>
        _ui.WaitAsync(_locators.AddNarrative, expected);

    public Task ClickNextBOPAsync() =>
        _ui.ClickAsync(_locators.NextBOP);

    public Task ClickNextSFPAsync() =>
        _ui.ClickAsync(_locators.NextSFP);

    public Task PressNoneOfTheAboveCheckboxAsync(string key) =>
        _ui.PressAsync(_locators.NoneOfTheAboveCheckbox, key);

    public Task PressNumberOfFulltimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfFulltimeEmployees, key);

    public Task EnterNumberOfFulltimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfFulltimeEmployees, value);

    public Task PressNumberOfPartTimeEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfPartTimeEmployees, key);

    public Task EnterNumberOfPartTimeEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfPartTimeEmployees, value);

    public Task PressNumberOfSeasonalEmployeesAsync(string key) =>
        _ui.PressAsync(_locators.NumberOfSeasonalEmployees, key);

    public Task EnterNumberOfSeasonalEmployeesAsync(string value) =>
        _ui.FillAsync(_locators.NumberOfSeasonalEmployees, value);

    public Task ClickOkToUpdateFromChecklistAsync() =>
        _ui.ClickAsync(_locators.OkToUpdateFromChecklist);

    public async Task ClickRaceAndGenderInformationNoIfPresentAsync()
    {
        if (await _ui.ExistsAsync(_locators.RaceAndGenderInformationNo))
            await _ui.ClickAsync(_locators.RaceAndGenderInformationNo);
    }

    public async Task ClickFarmBureauMemberNoIfPresentAsync()
    {
        if (await _ui.ExistsAsync(_locators.FarmBureauMemberNo))
            await _ui.ClickAsync(_locators.FarmBureauMemberNo);
    }

    public Task ClickQuickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.QuickSearchButton);

    public Task EnterQuoteSearchInputAsync(string value) =>
        _ui.FillAsync(_locators.QuoteSearchInput, value);

    public Task PressQuoteSearchInputAsync(string key) =>
        _ui.PressAsync(_locators.QuoteSearchInput, key);

    public Task WaitForResponseRequiredToContinueAsync(string expected) =>
        _ui.WaitAsync(_locators.ResponseRequiredToContinue, expected);

    public Task<bool> IsResponseRequiredToContinuePresentAsync() =>
        _ui.ExistsAsync(_locators.ResponseRequiredToContinue);

    public Task VerifyResultsTABLEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ResultsTABLE, expected, property);

    public Task<bool> IsResultsTABLEPresentAsync() =>
        _ui.ExistsAsync(_locators.ResultsTABLE);

    public Task VerifyResultsTABLERowCellExplicitNameNameAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ResultsTABLERowCellExplicitNameName, expected, property);

    public Task<bool> IsResultsTABLERowCellExplicitNameNamePresentAsync() =>
        _ui.ExistsAsync(_locators.ResultsTABLERowCellExplicitNameName);

    public Task WaitForReturnToAdminAsync(string expected) =>
        _ui.WaitAsync(_locators.ReturnToAdmin, expected);

    public Task VerifyReturnToAdminAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ReturnToAdmin, expected, property);

    public Task ClickReturnToAdminAsync() =>
        _ui.ClickAsync(_locators.ReturnToAdmin);

    public Task<bool> IsReturnToAdminPresentAsync() =>
        _ui.ExistsAsync(_locators.ReturnToAdmin);

    public Task PressSaveAsync(string key) =>
        _ui.PressAsync(_locators.Save, key);

    public Task ClickSaveAsync() =>
        _ui.ClickAsync(_locators.Save);

    public Task VerifySaveForLaterAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SaveForLater, expected, property);

    public Task ClickSaveForLaterAsync() =>
        _ui.ClickAsync(_locators.SaveForLater);

    public Task<bool> IsSaveForLaterPresentAsync() =>
        _ui.ExistsAsync(_locators.SaveForLater);

    public Task WaitForSaveForLaterOKAsync(string expected) =>
        _ui.WaitAsync(_locators.SaveForLaterOK, expected);

    public Task ClickSaveForLaterOKAsync() =>
        _ui.ClickAsync(_locators.SaveForLaterOK);

    public Task<bool> IsSaveForLaterOKPresentAsync() =>
        _ui.ExistsAsync(_locators.SaveForLaterOK);

    public Task VerifyScreenHeading69631Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading69631, expected, property);

    public Task<bool> IsScreenHeading69631PresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading69631);

    public Task VerifyScreenHeading9696CAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading69631, expected, property);

    public Task<bool> IsScreenHeading9696CPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading69631);

    public Task VerifyScreenHeadingDCABFAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading69631, expected, property);

    public Task<bool> IsScreenHeadingDCABFPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading69631);

    public Task WaitForSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchButton, expected);

    public Task PressSearchButtonAsync(string key) =>
        _ui.PressAsync(_locators.SearchButton, key);

    public Task ClickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.SearchButton);

    public Task PressSearchMethodEGDescriptionPolicyAsync(string key) =>
        _ui.PressAsync(_locators.SearchMethodEGDescriptionPolicy, key);

    public Task EnterSearchTextAsync(string value) =>
        _ui.FillAsync(_locators.SearchText, value);

    public Task PressSearchTextAsync(string key) =>
        _ui.PressAsync(_locators.SearchText, key);

    public Task VerifyTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36BAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B, expected, property);

    public Task<bool> IsTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36BPresentAsync() =>
        _ui.ExistsAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B);

    public Task VerifyTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus06F740Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B, expected, property);

    public Task<bool> IsTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus06F740PresentAsync() =>
        _ui.ExistsAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B);

    public Task VerifyTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus0B8256Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B, expected, property);

    public Task<bool> IsTheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus0B8256PresentAsync() =>
        _ui.ExistsAsync(_locators.TheBrowserWasUnableToCommunicateWithTheServerHTTPStatusErrorHTTPStatus01C36B);

    public Task WaitForTransactionTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.TransactionType, expected);

    public Task VerifyUncheckedNoneOfTheAboveAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ResponseRequiredToContinue, expected, property);

    public Task PressUncheckedNoneOfTheAboveAsync(string key) =>
        _ui.PressAsync(_locators.ResponseRequiredToContinue, key);

    public Task<bool> IsUncheckedNoneOfTheAbovePresentAsync() =>
        _ui.ExistsAsync(_locators.ResponseRequiredToContinue);

    public Task PressUnlistedAcreageAsync(string key) =>
        _ui.PressAsync(_locators.UnlistedAcreage, key);

    public Task WaitForUserDateAndTimestampAsync(string expected) =>
        _ui.WaitAsync(_locators.UserDateAndTimestamp, expected);

    public Task VerifyUserDateAndTimestampAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.UserDateAndTimestamp, expected, property);

    public Task VerifyUserNameE0ACDAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.UserNameE0ACD, expected, property);

    public Task<bool> IsUserNameE0ACDPresentAsync() =>
        _ui.ExistsAsync(_locators.UserNameE0ACD);

    public Task VerifyUserNameE65A8Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.UserNameE0ACD, expected, property);

    public Task<bool> IsUserNameE65A8PresentAsync() =>
        _ui.ExistsAsync(_locators.UserNameE0ACD);

    public Task WaitForViewPolicy0AC0BAsync(string expected) =>
        _ui.WaitAsync(_locators.ViewPolicy0AC0B, expected);

    public Task ClickViewPolicy0AC0BAsync() =>
        _ui.ClickAsync(_locators.ViewPolicy0AC0B);

    public Task WaitForViewPolicy56E09Async(string expected) =>
        _ui.WaitAsync(_locators.ViewPolicy0AC0B, expected);

    public Task PressViewPolicy56E09Async(string key) =>
        _ui.PressAsync(_locators.ViewPolicy0AC0B, key);

    public Task ClickExposuresInsuredAN90DaysNoAsync() =>
        _ui.ClickAsync(_locators.ExposuresInsuredAN90DaysNo);

    public Task EnterYearsInBusinessAsync(string value) =>
        _ui.FillAsync(_locators.YearsInBusiness, value);

    public Task ClickYearsMaintainedContinuousInsuranceCoverage3PlusAsync() =>
        _ui.ClickAsync(_locators.YearsMaintainedContinuousInsuranceCoverage3Plus);

    public Task NavigateAsync(string url) =>
        _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
    public Task NoteAsync(string note) =>
        _ui.ReviewRequiredAsync(note);

}
