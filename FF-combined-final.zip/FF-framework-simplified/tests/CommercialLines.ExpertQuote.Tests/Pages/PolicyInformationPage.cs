using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class PolicyInformationPage
{
    private readonly BrowserSession _browser;
    private readonly PolicyInformationLocators _locators;
    private readonly UiActions _ui;

    public PolicyInformationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new PolicyInformationLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickAddSecondaryFarmTypeToggleAsync() =>
        _ui.ClickAsync(_locators.AddSecondaryFarmTypeToggle);

    public Task EnterGrossFarmIncomeAsync(string value) =>
        _ui.FillAsync(_locators.GrossFarmIncome, value);

    public Task SelectIndustrialHempNoAsync(string value) =>
        _ui.SelectAsync(_locators.IndustrialHempNo, value);

    public Task SelectIndustrialHempYesAsync(string value) =>
        _ui.SelectAsync(_locators.IndustrialHempNo, value);
public Task ClickPrimaryFarmCategoryAsync() =>
        _ui.ClickAsync(_locators.PrimaryFarmCategory);

    public Task WaitForPrimaryFarmTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryFarmType, expected);

    public Task ClickPrimaryFarmTypeAsync() =>
        _ui.ClickAsync(_locators.PrimaryFarmType);

    public Task VerifyScreenHeadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ScreenHeading, expected, property);

    public Task<bool> IsScreenHeadingPresentAsync() =>
        _ui.ExistsAsync(_locators.ScreenHeading);

    public Task WaitForSecondaryFarmCategoryAsync(string expected) =>
        _ui.WaitAsync(_locators.SecondaryFarmCategory, expected);

    public Task ClickSecondaryFarmCategoryAsync() =>
        _ui.ClickAsync(_locators.SecondaryFarmCategory);

    public Task WaitForSecondaryFarmTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.SecondaryFarmType, expected);

    public Task ClickSecondaryFarmTypeAsync() =>
        _ui.ClickAsync(_locators.SecondaryFarmType);

}
