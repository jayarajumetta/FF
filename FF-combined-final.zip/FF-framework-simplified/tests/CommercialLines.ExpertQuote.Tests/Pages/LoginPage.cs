using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.CLEQ.Pages.Locators;

namespace InsuranceAutomation.CLEQ.Pages;

public sealed class LoginPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly LoginLocators _locators;
    private readonly UiActions _ui;

    public LoginPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _locators = new LoginLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForBODYAsync(string expected) =>
        _ui.WaitAsync(_locators.BODY, expected);

    public Task<bool> IsBODYPresentAsync() =>
        _ui.ExistsAsync(_locators.BODY);

    public Task EnterGetSessionIDBufferAsync(string value) =>
        _ui.FillAsync(_locators.GetSessionIDBuffer, value);
public Task VerifyLoadingMessageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoadingMessage, expected, property);

    public Task<bool> IsLoadingMessagePresentAsync() =>
        _ui.ExistsAsync(_locators.LoadingMessage);

    public Task VerifyLoggedInUserAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LoggedInUser, expected, property);

    public Task<bool> IsLoggedInUserPresentAsync() =>
        _ui.ExistsAsync(_locators.LoggedInUser);

    public Task WaitForLogin07237Async(string expected) =>
        _ui.WaitAsync(_locators.Login07237, expected);

    public Task<bool> IsLogin07237PresentAsync() =>
        _ui.ExistsAsync(_locators.Login07237);

    public Task WaitForLogin0D21AAsync(string expected) =>
        _ui.WaitAsync(_locators.Login07237, expected);

    public Task WaitForLoginC45A2Async(string expected) =>
        _ui.WaitAsync(_locators.Login07237, expected);

    public Task ClickQuickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.QuickSearchButton);

    public Task EnterSearchModeAsync(string value) =>
        _ui.FillAsync(_locators.SearchMode, value);

    public Task EnterSearchTextAsync(string value) =>
        _ui.FillAsync(_locators.SearchText, value);

    public Task PressSearchTextAsync(string key) =>
        _ui.PressAsync(_locators.SearchText, key);

    public Task WaitForUserNameAsync(string expected) =>
        _ui.WaitAsync(_locators.UserName, expected);

    public Task WaitForUsernameAsync(string expected) =>
        _ui.WaitAsync(_locators.UserName, expected);

    public Task WaitForViewPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.ViewPolicy, expected);

    public Task ClickViewPolicyAsync() =>
        _ui.ClickAsync(_locators.ViewPolicy);

    public Task NavigateAsync(string url) =>
        _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
    public Task NoteAsync(string note) =>
        _ui.ReviewRequiredAsync(note);

}
