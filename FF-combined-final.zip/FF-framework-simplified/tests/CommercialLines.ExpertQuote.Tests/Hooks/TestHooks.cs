using InsuranceAutomation.NUnit;
using Reqnroll;
namespace InsuranceAutomation.CLEQ.Hooks;

[Binding]
public sealed class TestHooks
{
    private readonly ScenarioLifecycle _lifecycle;
    public TestHooks(ScenarioContext scenario, FeatureContext feature) =>
        _lifecycle = new ScenarioLifecycle(scenario, feature, typeof(TestHooks).Assembly.GetName().Name!);
    [BeforeTestRun(Order = -1000)] public static void ValidateConfiguration() => ScenarioLifecycle.ValidateConfiguration();
    [BeforeScenario(Order = -100)] public void PrepareScenario() => _lifecycle.PrepareScenario();
    [BeforeStep] public void BeforeStep() => _lifecycle.BeforeStep();
    [AfterStep] public Task AfterStepAsync() => _lifecycle.AfterStepAsync();
    [AfterScenario(Order = 100)] public Task FinishScenarioAsync() => _lifecycle.FinishScenarioAsync();
}
