@CL_EQ @BOP @basic @bop_basic @cleq_basic @basic_new_business_policy

Feature: EQ BOP Basic Policy
  As a Commercial Lines ExpertQuote policy processing user
  I want to complete the EQ BOP Basic Policy workflow
  So that the business transaction is executed with source-traceable data and verification

  Background: Prepare Commercial Lines ExpertQuote for policy processing
    Given I open a browser session
  Scenario Outline: EQ BOP Basic Policy - <stateCode>
    Given test data "<dataFile>" and external data "<externalDataFile>" are loaded
    And I open the configured Commercial Lines ExpertQuote application
    And I sign in to Commercial Lines ExpertQuote using configured credentials
    When I create a new client and begin the quote
    And I enter client search information
    And I create a new client
    And I enter account details
    And I start the policy proposal
    And I enter and validate the insured social security number
    And I search and add a Class Code to the policy
    And I complete industry Class Code Restrictions
    And I confirm Primary Insured Details and select existing client
    And I enter Required Info
    And I complete general UW Questions
    And I complete industry Class Code Questions
    And I navigate to Claims/Prior Insurance screen
    And I complete Claims/Prior Insurance Screen
    And I complete Client Details and navigate to Narrative screen
    And I add/Edit a Narrative and Verify Timestamp
    And I navigate to Locations/Buildings screen
    And I complete edit a Location
    And I add a Building Button
    And I select Own or rent and Building SQ Footage Basic
    And I select Additional Coverages - Building, Functional Personal Property or Habitational
    And I enter supplimental data- for class
    And I select Cost Estimator & Calculate Valuations
    And I select Building Detail Fields
    And I answer Building Eligibility Questions
    And I navigate to Policy Coverages screen
    And I navigate to Additional Coverages screen
    And I answer EPLI Questions
    And I navigate to Billing screen
    And I complete billing Account Setup
    And I complete future Payment Plan 1
    And I complete initial Payment
    And I complete Agent Comments
    And I launch to Checklist
    And I click Refer to UW
    And I capture the quote identity and close the current quote
    Given I open the configured Commercial Lines Duck Creek application
    Given I sign in to Commercial Lines Duck Creek using configured credentials
    And I search for the policy by Description in Duck Creek
    And I click the insured name in the Duck Creek search results
    And I navigate to the Submission window in Duck Creek
    And I click Complete Application in Duck Creek
    And I open the configured Commercial Lines ExpertQuote application
    And I sign in to Commercial Lines ExpertQuote using configured credentials
    And I retrieve the quote and verify its identity
    Then I go to submission and transmit the policy

    Examples:
      | stateCode | dataFile                                          | stateVariant | stateName      | externalDataFile                    |
      | AL        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_al.json | AL           | Alabama        | TestData/ExternalDataOverrides.json |
      | AR        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ar.json | AR           | Arkansas       | TestData/ExternalDataOverrides.json |
      | AZ        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_az.json | AZ           | Arizona        | TestData/ExternalDataOverrides.json |
      | CA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ca.json | CA           | California     | TestData/ExternalDataOverrides.json |
      | CO        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_co.json | CO           | Colorado       | TestData/ExternalDataOverrides.json |
      | CT        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ct.json | CT           | Connecticut    | TestData/ExternalDataOverrides.json |
      | DE        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_de.json | DE           | Delaware       | TestData/ExternalDataOverrides.json |
      | GA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ga.json | GA           | Georgia        | TestData/ExternalDataOverrides.json |
      | IA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ia.json | IA           | Iowa           | TestData/ExternalDataOverrides.json |
      | ID        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_id.json | ID           | Idaho          | TestData/ExternalDataOverrides.json |
      | IL        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_il.json | IL           | Illinois       | TestData/ExternalDataOverrides.json |
      | IN        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_in.json | IN           | Indiana        | TestData/ExternalDataOverrides.json |
      | KS        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ks.json | KS           | Kansas         | TestData/ExternalDataOverrides.json |
      | KY        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ky.json | KY           | Kentucky       | TestData/ExternalDataOverrides.json |
      | LA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_la.json | LA           | Louisiana      | TestData/ExternalDataOverrides.json |
      | MA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ma.json | MA           | Massachusetts  | TestData/ExternalDataOverrides.json |
      | MD        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_md.json | MD           | Maryland       | TestData/ExternalDataOverrides.json |
      | ME        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_me.json | ME           | Maine          | TestData/ExternalDataOverrides.json |
      | MN        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_mn.json | MN           | Minnesota      | TestData/ExternalDataOverrides.json |
      | MO        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_mo.json | MO           | Missouri       | TestData/ExternalDataOverrides.json |
      | MS        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ms.json | MS           | Mississippi    | TestData/ExternalDataOverrides.json |
      | MT        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_mt.json | MT           | Montana        | TestData/ExternalDataOverrides.json |
      | ND        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_nd.json | ND           | North Dakota   | TestData/ExternalDataOverrides.json |
      | NE        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ne.json | NE           | Nebraska       | TestData/ExternalDataOverrides.json |
      | NH        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_nh.json | NH           | New Hampshire  | TestData/ExternalDataOverrides.json |
      | NJ        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_nj.json | NJ           | New Jersey     | TestData/ExternalDataOverrides.json |
      | NM        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_nm.json | NM           | New Mexico     | TestData/ExternalDataOverrides.json |
      | NV        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_nv.json | NV           | Nevada         | TestData/ExternalDataOverrides.json |
      | NY        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ny.json | NY           | New York       | TestData/ExternalDataOverrides.json |
      | OH        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_oh.json | OH           | Ohio           | TestData/ExternalDataOverrides.json |
      | OK        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ok.json | OK           | Oklahoma       | TestData/ExternalDataOverrides.json |
      | OR        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_or.json | OR           | Oregon         | TestData/ExternalDataOverrides.json |
      | PA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_pa.json | PA           | Pennsylvania   | TestData/ExternalDataOverrides.json |
      | RI        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ri.json | RI           | Rhode Island   | TestData/ExternalDataOverrides.json |
      | SC        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_sc.json | SC           | South Carolina | TestData/ExternalDataOverrides.json |
      | SD        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_sd.json | SD           | South Dakota   | TestData/ExternalDataOverrides.json |
      | TN        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_tn.json | TN           | Tennessee      | TestData/ExternalDataOverrides.json |
      | TX        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_tx.json | TX           | Texas          | TestData/ExternalDataOverrides.json |
      | UT        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_ut.json | UT           | Utah           | TestData/ExternalDataOverrides.json |
      | VA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_va.json | VA           | Virginia       | TestData/ExternalDataOverrides.json |
      | VT        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_vt.json | VT           | Vermont        | TestData/ExternalDataOverrides.json |
      | WA        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_wa.json | WA           | Washington     | TestData/ExternalDataOverrides.json |
      | WI        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_wi.json | WI           | Wisconsin      | TestData/ExternalDataOverrides.json |
      | WV        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_wv.json | WV           | West Virginia  | TestData/ExternalDataOverrides.json |
      | WY        | TestData/Scenarios/Basic/02_eq_bop_basic_policy_wy.json | WY           | Wyoming        | TestData/ExternalDataOverrides.json |

