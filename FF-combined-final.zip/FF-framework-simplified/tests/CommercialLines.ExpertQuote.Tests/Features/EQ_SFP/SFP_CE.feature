@cs_import
@SFP @CE @ExpertQuote
Feature: SFP Country Estate Policy

  @Regression
  Scenario Outline: SFP Country Estate Policy - <State>

    # Step 1: Log into Expert Quote
    Given I navigate to the Expert Quote login page
    When I enter valid credentials and Click LogIn

    # Step 2: Perform client search
    And user enters a Random Name in the search field and clicks search
      | Question  | Answer        |
      | FirstName | {{firstName}} |
      | LastName  | {{lastName}}  |

    # Step 3: Start a new quote
    And user clicks New Quote button

    # Step 4: Enter client information and search
    And user enters client information and clicks search
      | Question     | Answer          |
      | DOB          | {{randomDOB}}   |
      | BestPhone    | {{randomPhone}} |
      | EmailAddress | {{randomEmail}} |

    # Step 5: Create a new client
    And user selects Create New Client and clicks the Next button

    # Step 6: Enter account owner details
    And user enters account owner information and clicks Next
      | Question           | Answer         |
      | MiddleName         | <StateAbbv>    |
      | MaritalStatus      | Married        |
      | StreetAddress      | <Address>      |
      | AptNumber          | <AddressLine2> |
      | City               | <City>         |
      | State              | <State>        |
      | ZipCode            | <Zip>          |
      | ReceivedMail       | Yes            |
      | WhereClientResides | Yes            |

    # Step 7: Select SFP Country Estate and quote details
    And user selects Special Farm Package and inputs Quote Details
      | Question         | Answer                                      |
      | ProductSelection | CE                                          |
      | EffectiveDate    | {{laterOfTomorrow:04/03/2027}}              |
      | PolicyTerm       | 12 months                                   |
      | AgentCode        | D2102                                       |
      | RatingState      | <State>                                     |
      | OwnershipType    | Individually Owned                          |
      | WritingCompany   | American National Property And Casualty Co. |
      | RiskAddress      | <Address>, <City>, <StateAbbv> <Zip>        |
      | LessorRisk       | No                                          |

    # Step 8: Answer SSN Popup
    When user handles SSN popup and enters SSN
      | Question | Answer        |
      | SSN      | {{randomSSN}} |

    # Step 9: Enter SFP policy details
    And user enters SFP policy details and clicks Next button
      | Question           | Answer |
      | PrimaryFarmType    | Crops  |
      | LivestockType      | Berry  |
      | GrossFarmIncome    | 500    |
      | GrowIndustrialHemp | No     |

    # Step 10: Navigate to Prequalification and answer General Eligibility
    When user enters Pre-Qualification information and continues
      | Question                | Answer            |
      | EligibilityRestrictions | None Of The Above |

    # Step 11: Navigate to Primary Insured
    When user selects Primary Insured and continues

    # Step 13: Answer UW Questions
    When user answers UW Questions and continues
      | Question       | Answer |
      | NoneOfTheAbove | Yes    |

    # Step 14: Add Claims/Prior Insurance
    When user enters Claims and Prior Insurance Information and continues
      | Question                | Answer   |
      | PriorFFANPolicy         | No       |
      | YearsInBusiness         | 5        |
      | YearsContinuousCoverage | 3+ Years |
      | PriorInsuranceExpDate   | 1/1/2025 |
      | PriorInsuranceCarrier   | GEICO    |

    # Step 15: Edit Client Role on Client Details page
    When user validates Client Details and selects Inspection Contact

    # Step 16: Add a Narrative
    When user Adds Narrative and continues
      | Question  | Answer           |
      | Narrative | Test Narrative 1 |

    # Step 17: Add Policy Wide Coverages
    When user selects Policy Wide or Division Specific Coverages
      | CoverageType | CoverageName               | Select |
      | Policy       | Country Estate Endorsement | Yes    |

    # Step 17A: Edit Coverage - Country Estate
    When user edits Country Estate coverage and continues
      | Question                          | Answer              |
      | CEDivisionIWaterDamage            | $5,000              |
      | CEDivisionIIUnscheduledStructures | $5,000              |
      | CEDivisionIIIBlanketFppSublimit   |               31000 |
      | CEDivisionIIIBlanketFppDeductible | $1,000              |
      | CEDivisionVLiabilityLimit         | $500,000/$1,000,000 |


    # Step 18: Add a Primary Location
    # Wind/Hail deductible verification and selection are performed within this step based on zip code and state
    When user provides location information and continues
      | Question                | Answer                |
      | LocationNickname        | Primary Location      |
      | LocationType            | Both                  |
      | MilesFromFireDepartment |                     3 |
      | FeetFromHydrant         | 101-250               |
      | TotalAcreage            |                     6 |
      | Territory               | <Territory>           |
      | AllPerilDeductible      | <AllPerilDeductible>  |
      | WindHailDeductible      | <WindHailDeductible>  |
      | HurricaneDeductible     | <HurricaneDeductible> |
      | HurricaneOptional       | <HurricaneOptional>   |

    # Step 19: Add a Residence
    When user adds a Country Estate Residence to the Location
      | Question          | Answer        |
      | AdditionalDesc    | Main House    |
      | YearBuilt         | 1995          |
      | NumberOfFamilies  | Single Family |
      | RateType          | Frame         |
      | ConditionRating   | 1             |
      | RoofYear          | 2016          |
      | HeatingYear       | 2022          |
      | PlumbingYear      | 2020          |
      | ElectricalYear    | 2017          |
      | RoofType          | Asphalt       |
      | RoofImpact        | UL 2          |
      | SolidFuelQuestion | No            |

    # Step 20: Add Residence Coverage
    When user adds and verifies Country Estate Residence Coverage
      | Question                | Answer                    |
      | InsuranceAmount         | 375000                    |
      | HouseholdContentsAmount | 187500                    |
      | SquareFeet              | 1800                      |
      | Perils                  | 6                         |
      | ThermostatQuestion      | Yes                       |
      | ActualCashValue         | Expanded Replacement Cost |
      | RCTOption               | Standard                  |
      | UseDefaults             | Yes                       |

    # Step 21: Skip Optional Coverages
    When user skips Optional Coverages and continues

    # Step 21A: Add and verify the approved Division IV items
    When user adds and verifies Country Estate Scheduled Personal Property
      | Code | Description                        | AmountOfInsurance | UnattendedVehicle | NamedPersonCount | NamedPersonNames |
      | 409  | Stamp Collections                  | 5000              | Yes               |                  |                  |
      | 411  | Auto Trailer Home Personal Effects | 10000             | Yes               | 0                | {{fullName}}     |

    # Step 22: Run the Insurance Score
    When user runs Insurance Score
      | Question              | Answer          |
      | EntityType            | Primary Insured |
      | InsuranceScoreConsent | Accept          |

    # Step 23: Add a Mortgagee
    When user adds Additional Interest Mortgagee
      | Question              | Answer           |
      | SearchName            | Connect One Bank |
      | Location              | Primary          |
      | Residence             | Main House       |
      | CopyOfDEC             | No               |
      | AccountNumber         | 123456789        |
      | DescriptionOfInterest | Mortgage Lender  |
      | EscrowBilled          | Yes              |

    # Step 23: Verify Premium on Pricing Screen
    Then user verifies Premium on Pricing screen

    # Step 24: Navigate to Billing via left menu
    When user navigates to the "Billing" page via the left menu

    # Step 25: Complete Billing Information
    When user completes Billing Information
      | Question       | Answer          |
      | BillingAccount | Create New      |
      | PrimaryPayer   | Primary Insured |
      | PaymentType    | Easy Pay        |
      | RoutingNumber  | 021000021       |
      | AccountNumber  | 123456789       |
      | BankName       | Test Bank       |
      | PaymentPlan    | 12 Payments     |
      | PaymentDueDate | 01              |
      | PaymentAmount  | Minimum         |
      | PaymentMethod  | Check           |

    # Step 26: Visit the Checklist page
    When user navigates to Submission and opens Checklist
    Then user verifies no referrals are needed

    # Step 27: Enter required information for Checklist (Residence Photo #1)
    When user completes Checklist item
      | Question      | Answer              |
      | ItemName      | Residence Photo #1  |
      | Action        | Exception           |
      | ExceptionNote | Photo not available |
      | Note          | Photo not available |

    # Step 28: Enter required information for Checklist (UL Roof Type Credit)
    When user completes Checklist item
      | Question      | Answer              |
      | ItemName      | UL Roof Type Credit |
      | Action        | Exception           |
      | ExceptionNote | Roof type confirmed |
      | Note          | Roof type confirmed |

    # Step 29: Enter required information for Checklist (Easy Pay)
    When user completes Checklist item
      | Question      | Answer      |
      | ItemName      | Easy Pay    |
      | Action        | Exception   |
      | ExceptionNote | EasyPay set |
      | Note          | EasyPay set |
      | Optional      | Yes         |

    # Step 30: Enter required information for Checklist (Loss Runs)
    When user completes Checklist item
      | Question      | Answer                                             |
      | ItemName      | Loss Runs (Tiered - 5 Years; Not tiered - 3 years) |
      | Action        | Exception                                          |
      | ExceptionNote | Loss runs on file                                  |
      | Note          | Loss runs on file                                  |

    # Step 31: Close Checklist and confirm Update
    When user closes Checklist and confirms Update

    # Step 32: Verify Transmit button is enabled
    Then user verifies Transmit button is enabled on Submission page

    # Step 33: Validate Forms attachment via Duckcreek
    When user validates Forms via Duckcreek for state "<StateAbbv>"

    @Shard4 @Debug
    Examples:
      | State   | StateAbbv | Address       | AddressLine2 | City     | Zip   | County     | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Alabama | AL        | 2210 Wood Ave |          111 | Florence | 35630 | Lauderdale |           |                    | 1%                 |                     |                   |

    @Shard4
    Examples:
      | State       | StateAbbv | Address                | AddressLine2 | City          | Zip   | County       | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Arkansas    | AR        | 2400 Harrison St       |          111 | Batesville    | 72502 | Independence |           |                    | 1%                 |                     |                   |
      | Arizona     | AZ        | 11811 N Tatum Blvd     |          111 | Phoenix       | 85028 | Maricopa     |           |                    | 1%                 |                     |                   |
      | Colorado    | CO        | 19592 E 8th Ave        |          111 | Aurora        | 80011 | Adams        |           |                    | 1%                 |                     |                   |
      | Connecticut | CT        | 50 Columbus Blvd       |          111 | Hartford      | 06106 | Hartford     |           |                    | 1%                 |                     |                   |
      | Delaware    | DE        | 40 E Main St           |          111 | Newark        | 19711 | New Castle   |           |                    | 1%                 |                     |                   |
      | Georgia     | GA        | 1250 Caroline St NE    |          111 | Atlanta       | 30307 | Fulton       |           |                    | 1%                 |                     |                   |
      | Idaho       | ID        | 915 W Appleway Ave     |          111 | Coeur D Alene | 83815 | Kootenai     |           |                    | 1%                 |                     |                   |
      | Illinois    | IL        | 4601 E State St        |          111 | Rockford      | 61109 | Winnebago    |           |                    | 1%                 |                     |                   |
      | Indiana     | IN        | 6935 Indianapolis Blvd |          111 | Hammond       | 46323 | Lake         |           |                    | 1%                 |                     |                   |
      | Iowa        | IA        | 900 Montgomery St      |          111 | Decorah       | 52144 | Winneshiek   |           |                    | 1%                 |                     |                   |
      | Kansas      | KS        | 10900 Parallel Pkwy    |          111 | Kansas City   | 66109 | Wyandotte    |           |                    | 1%                 |                     |                   |
      | Kentucky    | KY        | 201 Clinic Dr          |          111 | Paducah       | 42003 | McCracken    |           |                    | 1%                 |                     |                   |
      | Louisiana   | LA        | 401 N Parkerson Ave    |          111 | Crowley       | 70526 | Acadia       |           |                    | 1%                 |                     |                   |

    @Shard4 @DevOnly
    Examples:
      | State      | StateAbbv | Address          | AddressLine2 | City   | Zip   | County   | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | California | CA        | 3300 Glenwood St |          111 | Eureka | 95501 | Humboldt |           |                    | None               |                     |                   |

    @Shard5 @Debug
    Examples:
      | State       | StateAbbv | Address            | AddressLine2 | City     | Zip   | County   | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Mississippi | MS        | 15190 Community Rd |          111 | Gulfport | 39503 | Harrison |           |                    | 1%                 |                     |                   |

    @Shard5
    Examples:
      | State         | StateAbbv | Address                | AddressLine2 | City          | Zip   | County       | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Missouri      | MO        | 4141 S Fremont Ave     |          111 | Springfield   | 65804 | Greene       |           |                    | 1%                 |                     |                   |
      | Massachusetts | MA        | 75 Tyler St            |          111 | Pittsfield    | 01202 | Berkshire    |           |                    | 1%                 |                     |                   |
      | Maine         | ME        | 21 Main St             |          111 | Caribou       | 04736 | Aroostook    |           |                    | 1%                 |                     |                   |
      | Minnesota     | MN        | 1800 University Ave SE |          111 | Minneapolis   | 55414 | Hennepin     |           |                    | 1%                 |                     |                   |
      | Montana       | MT        | 307 W Front St         |          111 | Missoula      | 59802 | Missoula     |           |                    | None               |                     |                   |
      | Nebraska      | NE        | 2502 1st Ave           |          111 | Scottsbluff   | 69363 | Scotts Bluff |           |                    | 1%                 |                     |                   |
      | Nevada        | NV        | 4850 W Flamingo Rd     |          111 | Las Vegas     | 89103 | Clark        |           |                    | 1%                 |                     |                   |
      | New Hampshire | NH        | 149 Emerald St         |          111 | Keene         | 03431 | Cheshire     |           |                    | 1%                 |                     |                   |
      | New Jersey    | NJ        | 120 Albany St          |          111 | New Brunswick | 08901 | Middlesex    |           |                    | 1%                 |                     |                   |
      | New Mexico    | NM        | 2501 N Prince St       |          111 | Clovis        | 88103 | Curry        |           |                    | 1%                 |                     |                   |
      | North Dakota  | ND        | 4204 Ottawa St         |          111 | Bismarck      | 58503 | Burleigh     |           |                    | None               |                     |                   |
      | Oklahoma      | OK        | 621 W Broadway Ave     |          111 | Enid          | 73701 | Garfield     |           |                    | 1%                 |                     |                   |

    @Shard5
    Examples:
      | State    | StateAbbv | Address              | AddressLine2 | City    | Zip   | County     | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Maryland | MD        | 18400 Muncaster Road |              | Derwood | 20855 | Montgomery |       007 | $1,000             | 2%                 | 2%                  | Yes               |

    @Shard5 @DevOnly
    Examples:
      | State    | StateAbbv | Address            | AddressLine2 | City        | Zip   | County      | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Virginia | VA        | 15235 Whitehead Rd |          111 | Branchville | 23828 | Southampton |           |                    | 1%                 |                     |                   |

    @Shard6 @Debug
    Examples:
      | State | StateAbbv | Address       | AddressLine2 | City  | Zip   | County | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Ohio  | OH        | 433 N Main St |          111 | Akron | 44310 | Summit |           |                    | 1%                 |                     |                   |

    @Shard6
    Examples:
      | State          | StateAbbv | Address                       | AddressLine2 | City        | Zip   | County     | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Oregon         | OR        | 1111 NW 9th St                |          111 | Corvallis   | 97330 | Benton     |           |                    | 1%                 |                     |                   |
      | Rhode Island   | RI        | 790 N Main St                 |          111 | Providence  | 02904 | Providence |           |                    | 1%                 |                     |                   |
      | South Carolina | SC        | 100 Laurens St SW             |          111 | Aiken       | 29801 | Aiken      |           |                    | 1%                 |                     |                   |
      | South Dakota   | SD        | 1616 N Harrison Ave           |          111 | Pierre      | 57532 | Hughes     |           |                    | 1%                 |                     |                   |
      | Tennessee      | TN        | 100 W Martin Luther King Blvd |          111 | Chattanooga | 37402 | Hamilton   |           |                    | 1%                 |                     |                   |
      | Texas          | TX        | 6100 Camp Bowie Blvd          |          111 | Fort Worth  | 76116 | Tarrant    |           |                    | 1%                 |                     |                   |
      | Utah           | UT        | 1380 N Main St                |          111 | Logan       | 84341 | Cache      |           |                    | 1%                 |                     |                   |
      | Washington     | WA        | 505 W Riverside Ave           |          111 | Spokane     | 99201 | Spokane    |           |                    | 1%                 |                     |                   |
      | Wisconsin      | WI        | 4502 Regent St                |          111 | Madison     | 53705 | Dane       |           |                    | 1%                 |                     |                   |
      | Wyoming        | WY        | 730 E 2nd St                  |          111 | Casper      | 82609 | Natrona    |           |                    | 1%                 |                     |                   |

    @Shard6
    Examples:
      | State        | StateAbbv | Address               | AddressLine2 | City      | Zip   | County    | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | Pennsylvania | PA        | 2451 Kissel Hill Road |              | Lancaster | 17601 | Lancaster |       001 | $2,000             | None               | None                | No                |
      | Vermont      | VT        | 69 Old River Road     |              | Woodstock | 05091 | Windsor   |       031 | $2,500             | 1%                 | None                | No                |

    @Shard6 @DevOnly
    Examples:
      | State         | StateAbbv | Address                  | AddressLine2 | City     | Zip   | County | Territory | AllPerilDeductible | WindHailDeductible | HurricaneDeductible | HurricaneOptional |
      | West Virginia | WV        | 108 Victorian Commons Rd |              | Winfield | 25213 | Putnam |           |                    | 1%                 |                     |                   |
