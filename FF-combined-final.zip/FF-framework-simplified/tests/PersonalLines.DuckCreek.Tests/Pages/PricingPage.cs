using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class PricingPage
{
    private readonly BrowserSession _browser;
    private readonly PricingLocators _locators;
    private readonly UiActions _ui;

    public PricingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new PricingLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForHeaderPricingDetailsAsync(string expected) =>
        _ui.WaitAsync(_locators.HeaderPricingDetails, expected);

    public Task WaitForHeaderPricingDetailsAsync() =>
        _locators.HeaderPricingDetails.WaitForAsync(new LocatorWaitForOptions
        {
            State = WaitForSelectorState.Visible,
            Timeout = 30_000
        });
public Task ClickPricingDetailsNewNextAsync() =>
        _ui.ClickAsync(_locators.PricingDetailsNewNext);

    public Task ClickPricingDetailsNavAsync() =>
        _ui.ClickAsync(_locators.PricingDetailsNav);

}
