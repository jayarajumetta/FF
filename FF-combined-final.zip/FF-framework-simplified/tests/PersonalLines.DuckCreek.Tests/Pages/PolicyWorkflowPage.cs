using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class PolicyWorkflowPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly PolicyWorkflowLocators _locators;
    private readonly UiActions _ui;

    public PolicyWorkflowPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _locators = new PolicyWorkflowLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForAddEditAdditionalInterestFirstMortgageeSearchAsync(string expected) =>
        _ui.WaitAsync(_locators.AddEditAdditionalInterestFirstMortgageeSearch, expected);

    public Task ClickAddEditAdditionalInterestFirstMortgageeSearchAsync() =>
        _ui.ClickAsync(_locators.AddEditAdditionalInterestFirstMortgageeSearch);

    public Task WaitForSearchTextAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchText, expected);

    public Task EnterSearchTextAsync(string value) =>
        _ui.FillAsync(_locators.SearchText, value);

    public Task PressSearchTextAsync(string key) =>
        _ui.PressAsync(_locators.SearchText, key);

    public Task EnterSearchTextSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchText, value, delayMs);

    public Task WaitForQuickSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.QuickSearchButton, expected);

    public Task ClickQuickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.QuickSearchButton);

    public Task WaitForSearchMethodEGDescriptionPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchMethodEGDescriptionPolicy, expected);

    public Task EnterSearchMethodEGDescriptionPolicyAsync(string value) =>
        _ui.FillAsync(_locators.SearchMethodEGDescriptionPolicy, value);

    public Task PressSearchMethodEGDescriptionPolicyAsync(string key) =>
        _ui.PressAsync(_locators.SearchMethodEGDescriptionPolicy, key);

    public Task EnterSearchMethodEGDescriptionPolicySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchMethodEGDescriptionPolicy, value, delayMs);

    public Task WaitForSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchButton, expected);

    public Task ClickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.SearchButton);

    public Task WaitForSearchResultsInsuredNameColumnHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchResultsInsuredNameColumnHeader, expected);

    public Task ClickSearchResultInsuredNameLinkAsync() =>
        _ui.ClickAsync(_locators.SearchResultInsuredNameLink);

    public Task WaitForCommercialAutoQuoteLinkAsync(string expected) =>
        _ui.WaitAsync(_locators.CommercialAutoQuoteLink, expected);

    public Task ClickCommercialAutoQuoteLinkAsync() =>
        _ui.ClickAsync(_locators.CommercialAutoQuoteLink);

    public Task ClickAdditionalDeathBenefitAsync() =>
        _ui.ClickAsync(_locators.AdditionalDeathBenefit);

    public Task ClickAdditionalPIPAsync() =>
        _ui.ClickAsync(_locators.AdditionalPIP);

    public Task ClickAutoHealthInsurerAsync() =>
        _ui.ClickAsync(_locators.AutoHealthInsurer);

    public Task ClickBroadenedPIPAsync() =>
        _ui.ClickAsync(_locators.BroadenedPIP);

    public Task WaitForBtnCreateNewClientAsync(string expected) =>
        _ui.WaitAsync(_locators.BtnCreateNewClient, expected);

    public Task ClickBtnCreateNewClientAsync() =>
        _ui.ClickAsync(_locators.BtnCreateNewClient);

    public Task SelectExtraPIPOptionAsync(string value) =>
        _ui.SelectAsync(_locators.ExtraPIPOption, value);

    public Task ClickHouseholdMembersAge65OrReceivingPensionAsync() =>
        _ui.ClickAsync(_locators.HouseholdMembersAge65OrReceivingPension);

    public Task WaitForLblClientInfoAsync(string expected) =>
        _ui.WaitAsync(_locators.LblClientInfo, expected);

    public Task VerifyLblClientInfoAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LblClientInfo, expected, property);

    public Task ClickMedicalExpenseEliminationAsync() =>
        _ui.ClickAsync(_locators.MedicalExpenseElimination);

    public Task ClickPIPDeductibleAsync() =>
        _ui.ClickAsync(_locators.PIPDeductible);

    public Task ClickPIPLimitAsync() =>
        _ui.ClickAsync(_locators.PIPLimit);

    public Task ClickPIPStackingAsync() =>
        _ui.ClickAsync(_locators.PIPStacking);

    public Task ClickPricingDetailsNextAsync() =>
        _ui.ClickAsync(_locators.PricingDetailsNext);

    public Task EnterTxtFirstAsync(string value) =>
        _ui.FillAsync(_locators.TxtFirst, value);

    public Task EnterTxtLastAsync(string value) =>
        _ui.FillAsync(_locators.TxtLast, value);

    public Task ClickWaiverOfIncomeLossAsync() =>
        _ui.ClickAsync(_locators.WaiverOfIncomeLoss);

    public Task SelectWorkLossNoAsync(string value) =>
        _ui.SelectAsync(_locators.WorkLossNo, value);

    public Task<bool> IsHouseholdMembersAge65OrReceivingPensionPresentAsync() =>
        _ui.ExistsAsync(_locators.HouseholdMembersAge65OrReceivingPension);

    public Task<bool> IsPIPLimitPresentAsync() =>
        _ui.ExistsAsync(_locators.PIPLimit);

    public Task<bool> IsPIPDeductiblePresentAsync() =>
        _ui.ExistsAsync(_locators.PIPDeductible);

    public Task<bool> IsAdditionalPIPPresentAsync() =>
        _ui.ExistsAsync(_locators.AdditionalPIP);

    public Task<bool> IsPIPStackingPresentAsync() =>
        _ui.ExistsAsync(_locators.PIPStacking);

    public Task<bool> IsExtraPIPOptionPresentAsync() =>
        _ui.ExistsAsync(_locators.ExtraPIPOption);

    public Task<bool> IsAutoHealthInsurerPresentAsync() =>
        _ui.ExistsAsync(_locators.AutoHealthInsurer);

    public Task<bool> IsMedicalExpenseEliminationPresentAsync() =>
        _ui.ExistsAsync(_locators.MedicalExpenseElimination);

    public Task<bool> IsWorkLossNoPresentAsync() =>
        _ui.ExistsAsync(_locators.WorkLossNo);

    public Task<bool> IsBroadenedPIPPresentAsync() =>
        _ui.ExistsAsync(_locators.BroadenedPIP);

    public Task<bool> IsAdditionalDeathBenefitPresentAsync() =>
        _ui.ExistsAsync(_locators.AdditionalDeathBenefit);

    public Task<bool> IsWaiverOfIncomeLossPresentAsync() =>
        _ui.ExistsAsync(_locators.WaiverOfIncomeLoss);

    public Task NavigateAsync(string url) =>
        _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });

}
