using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class DriversPage
{
    private readonly BrowserSession _browser;
    private readonly DriversLocators _locators;
    private readonly UiActions _ui;

    public DriversPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new DriversLocators(browser.Page);
        _ui = ui;
    }

    public async Task ClickCLOSEQUOTEAsync()
    {
        if (await IsIneligibleQuotePresentAsync())
        {
            await _ui.ClickAsync(_locators.CLOSEQUOTE);
        }
    }

    public Task WaitForCONTINUEAsync(string expected) =>
        _ui.WaitAsync(_locators.CONTINUE, expected);

    public Task VerifyCONTINUEAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CONTINUE, expected, property);

    public Task ClickCONTINUEAsync() =>
        _ui.ClickAsync(_locators.CONTINUE);

    public Task WaitForCONTINUED555DAsync(string expected) =>
        _ui.WaitAsync(_locators.CONTINUED555D, expected);

    public Task ClickCONTINUED555DAsync() =>
        _ui.ClickAsync(_locators.CONTINUED555D);

    public Task<bool> IsCONTINUED555DPresentAsync() =>
        _ui.ExistsAsync(_locators.CONTINUED555D);

    public Task ClickDriverAssignmentTabAsync() =>
        _ui.ClickAsync(_locators.DriverAssignmentTab);

    public Task WaitForDriverAssignmentHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.DriverAssignmentHeader, expected);

    public Task ClickDriver1PrincipalOccasionalAsync() =>
        _ui.ClickAsync(_locators.Driver1PrincipalOccasional);

    public Task ClickDriver1VehicleAsync() =>
        _ui.ClickAsync(_locators.Driver1Vehicle);

    public Task ClickDriver1VehicleTesla3Async() =>
        _ui.ClickAsync(_locators.Driver1VehicleTesla3);

    public Task ClickSelectAVehicleToassignDriverAsync() =>
        _ui.ClickAsync(_locators.SelectVehicleToAssignDriver);



    public Task ClickDriverAssignmentNextAsync() =>
         _ui.ClickAsync(_locators.DriverAssignmentNextAsync);

    public Task PressDriver2PrincipalOccasionalAsync(string key) =>
        _ui.PressAsync(_locators.Driver2PrincipalOccasional, key);

    public Task ClickDriver2PrincipalOccasionalAsync() =>
        _ui.ClickAsync(_locators.Driver2PrincipalOccasional);

    public Task PressDriver2VehicleAsync(string key) =>
        _ui.PressAsync(_locators.Driver2Vehicle, key);

    public Task ClickDriver2VehicleAsync() =>
        _ui.ClickAsync(_locators.Driver2Vehicle);

    public Task PressDriver3PrincipalOccasionalAsync(string key) =>
        _ui.PressAsync(_locators.Driver3PrincipalOccasional, key);

    public Task ClickDriver3PrincipalOccasionalAsync() =>
        _ui.ClickAsync(_locators.Driver3PrincipalOccasional);

    public Task PressDriver3VehicleAsync(string key) =>
        _ui.PressAsync(_locators.Driver3Vehicle, key);

    public Task ClickDriver3VehicleAsync() =>
        _ui.ClickAsync(_locators.Driver3Vehicle);

    public Task PressDriver4PrincipalOccasionalAsync(string key) =>
        _ui.PressAsync(_locators.Driver4PrincipalOccasional, key);

    public Task ClickDriver4PrincipalOccasionalAsync() =>
        _ui.ClickAsync(_locators.Driver4PrincipalOccasional);

    public Task PressDriver4VehicleAsync(string key) =>
        _ui.PressAsync(_locators.Driver4Vehicle, key);

    public Task ClickDriver4VehicleAsync() =>
        _ui.ClickAsync(_locators.Driver4Vehicle);

    public Task PressDriver5PrincipalOccasionalAsync(string key) =>
        _ui.PressAsync(_locators.Driver5PrincipalOccasional, key);

    public Task ClickDriver5PrincipalOccasionalAsync() =>
        _ui.ClickAsync(_locators.Driver5PrincipalOccasional);

    public Task PressDriver5VehicleAsync(string key) =>
        _ui.PressAsync(_locators.Driver5Vehicle, key);

    public Task ClickDriver5VehicleAsync() =>
        _ui.ClickAsync(_locators.Driver5Vehicle);

    public Task PressDriverInformationNextAsync(string key) =>
        _ui.PressAsync(_locators.CLOSEQUOTE, key);

    public Task ClickDriverInformationNextAsync() =>
        _ui.ClickAsync(_locators.Btn_Next);

    public Task ClickExistingClient1Async() =>
        _ui.ClickAsync(_locators.ExistingClient1);

    public Task VerifyIneligibleQuoteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CLOSEQUOTE, expected, property);

    public Task<bool> IsIneligibleQuotePresentAsync() =>
        _ui.ExistsAsync(_locators.InEligibleHeading);

    public Task ClickCloseQuoteAsync() =>
        _locators.CLOSEQUOTE.EvaluateAsync("el => el.click()");
    public Task ClickMultipleDriverAssignmentNextAsync() =>
        _ui.ClickAsync(_locators.Btn_Next);

    public Task<bool> IsCONTINUEPresentAsync() => _ui.ExistsAsync(_locators.CONTINUE);

}
