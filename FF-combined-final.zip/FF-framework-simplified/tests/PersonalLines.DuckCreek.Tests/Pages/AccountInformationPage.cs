using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class AccountInformationPage
{
    private readonly BrowserSession _browser;
    private readonly AccountInformationLocators _locators;
    private readonly UiActions _ui;

    public AccountInformationPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new AccountInformationLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAccountDetailsNextAsync(string key) =>
        _ui.PressAsync(_locators.AccountDetailsNext, key);

    public Task ClickAccountDetailsNextAsync() =>
        _ui.ClickAsync(_locators.AccountDetailsNext);

    public Task WaitForAccountInformationAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountInformation, expected);

    public Task EnterBestPhoneAccountOwnerAsync(string value) =>
        _ui.FillAsync(_locators.BestPhoneAccountOwner, value);

    public Task EnterDOBAsync(string value) =>
        _ui.FillAsync(_locators.DOB, value);

    public Task ClickDivorcedAsync() =>
        _ui.ClickAsync(_locators.Divorced);

    public Task SelectDrpdwnStateAsync(string value) =>
        _ui.SelectAsync(_locators.DrpdwnState, value);

    public Task EnterEmailAccountOwnerAsync(string value) =>
        _ui.FillAsync(_locators.EmailAccountOwner, value);

    public Task WaitForEnterALocationAsync(string expected) =>
        _ui.WaitAsync(_locators.EnterALocation, expected);

    public Task EnterEnterALocationAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.EnterALocation, value);

    public Task VerifyFirstNameAccountOwnerAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.FirstNameAccountOwner, expected, property);

    public Task WaitForIsTheAccountAddressAlsoWhereTheClientResidesAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountInformation, expected);

    public Task WaitForMaritalStatusAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountInformation, expected);

    public Task SelectMarriedAsync(string value) =>
        _ui.SelectAsync(_locators.Divorced, value);

    public Task WaitForOwnerAddressCityNewAsync(string expected) =>
        _ui.WaitAsync(_locators.OwnerAddressCityNew, expected);

    public Task EnterOwnerAddressCityNewAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.OwnerAddressCityNew, value);

    public Task WaitForOwnerAddressLine2Async(string expected) =>
        _ui.WaitAsync(_locators.OwnerAddressLine2, expected);

    public Task EnterOwnerAddressLine2Async(string value) =>
        _ui.PressSequentiallyAsync(_locators.OwnerAddressLine2, value);

    public Task WaitForOwnerAddressZipAsync(string expected) =>
        _ui.WaitAsync(_locators.OwnerAddressZip, expected);

    public Task EnterOwnerAddressZipAsync(string value) =>
        _ui.PressSequentiallyAsync(_locators.OwnerAddressZip, value);

    public async Task WaitForSatelliteAsync(string expected)
    {
        if (string.Equals(expected, "Visible", StringComparison.OrdinalIgnoreCase) &&
            !await _ui.ExistsAsync(_locators.Satellite))
        {
            return;
        }

        await _ui.WaitAsync(_locators.Satellite, expected);
    }

    public Task ClickSingleAsync() =>
        _ui.ClickAsync(_locators.Single);

    public Task SelectStateNameAsync(string value) =>
        _ui.SelectAsync(_locators.AccountDetailsNext, value);

    public Task SelectStateAsync(string value) =>
        _ui.SelectAsync(_locators.StateDropdown, value);

    public Task EnterStateAsync(string value) =>
    _ui.FillAsync(_locators.StateDropdown, value);

    public Task SelectYesAtLeast90DaysAsync(string value) =>
        _ui.SelectAsync(_locators.YesAtLeast90Days, value);

    public Task WaitForYesClientResidesAsync(string expected) =>
        _ui.WaitAsync(_locators.YesClientResides, expected);
    public Task WaitForYesAtLeast90DaysAsync(string expected) =>
        _ui.WaitAsync(_locators.YesAtLeast90Days, expected);

    public Task ClickYesAtLeast90DaysAsync() =>
        _ui.ClickAsync(_locators.YesAtLeast90Days);

    public Task SelectYesClientResidesAsync(string value) =>
        _ui.SelectAsync(_locators.YesClientResides, value);

    public Task VerifyMapAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Map, expected, property);

    public Task<bool> IsMapPresentAsync() =>
        _ui.ExistsAsync(_locators.Map);

    public Task VerifySatelliteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Satellite, expected, property);

    public Task<bool> IsSatellitePresentAsync() =>
        _ui.ExistsAsync(_locators.Satellite);

    public Task SelectHaveYouReceivedMailAtThisAddressForAtLeast90DaysYesAsync() =>
        _ui.ClickAsync(_locators.YesAtLeast90Days);

    public Task SelectIsTheAccountAddressAlsoWhereTheClientResidesYesAsync() =>
        _ui.ClickAsync(_locators.YesClientResides);

    public Task ClickAdditionalInterestsNextAsync() =>
        _ui.ClickAsync(_locators.AdditionalInterestsNext);

}
