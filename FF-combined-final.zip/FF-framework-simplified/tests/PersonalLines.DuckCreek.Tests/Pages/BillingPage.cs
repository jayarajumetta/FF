using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class BillingPage
{
    private readonly BrowserSession _browser;
    private readonly BillingLocators _locators;
    private readonly UiActions _ui;

    public BillingPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new BillingLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickBillingNavAsync() =>
        _ui.ClickAsync(_locators.BillingNav);

    public Task ClickBillingNEXTAsync() =>
        _ui.ClickAsync(_locators.BillingNEXT);

    public Task WaitForCHECKAsync(string expected) =>
        _ui.WaitAsync(_locators.CHECK, expected);

    public Task ClickCHECKAsync() =>
        _ui.ClickAsync(_locators.CHECK);
    public Task WaitForCHECKAsyncAsync(string expected) =>
        _ui.WaitAsync(_locators.CHECK, expected);

    public Task WaitForCheckNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.CheckNumber, expected);

    public Task EnterCheckNumberAsync(string value) =>
        _ui.FillAsync(_locators.CheckNumber, value);

    public Task ClickCreateNewBillingAccountAsync() =>
        _ui.ClickAsync(_locators.CreateNewBillingAccount);

    public Task PressDirectBillAsync(string key) =>
        _ui.PressAsync(_locators.DirectBill, key);

    public Task WaitForDirectBillAsync(string expected) =>
        _ui.WaitAsync(_locators.DirectBill, expected);

    public Task ClickDirectBillAsync() =>
        _ui.ClickAsync(_locators.DirectBill);

    public Task WaitForHdrBillingAsync(string expected) =>
        _ui.WaitAsync(_locators.HdrBilling, expected);

    public Task WaitForN1PaymentAsync(string expected) =>
        _ui.WaitAsync(_locators.N1Payment, expected);
    
    public Task ClickN1PaymentAsync() =>
        _ui.ClickAsync(_locators.N1Payment);

    public Task WaitForPaymentDueDateAsync(string expected) =>
        _ui.WaitAsync(_locators.PaymentDueDate, expected);

    public Task EnterPaymentDueDateAsync(string value) =>
        _ui.FillAsync(_locators.PaymentDueDate, value);

    public Task PressPrimaryAccountHolderNameAsync(string key) =>
        _ui.PressAsync(_locators.PrimaryAccountHolderName, key);

    public Task WaitForPrimaryAccountHolderNameAsync(string expected) =>
        _ui.WaitAsync(_locators.PrimaryAccountHolderName, expected);

    public Task ClickPrimaryAccountHolderNameAsync() =>
        _ui.ClickAsync(_locators.PrimaryAccountHolderName);

    public Task WaitForRdBtnFullBalanceAsync(string expected) =>
        _ui.WaitAsync(_locators.RdBtnFullBalance, expected);

    public Task ClickRdBtnFullBalanceAsync() =>
        _ui.ClickAsync(_locators.RdBtnFullBalance);

    public Task WaitRdBtnFullBalanceAsync(string expected) =>
        _ui.WaitAsync(_locators.RdBtnFullBalance, expected);

}
