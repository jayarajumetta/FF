using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class DiscountsPage
{
    private readonly BrowserSession _browser;
    private readonly DiscountsLocators _locators;
    private readonly UiActions _ui;

    public DiscountsPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new DiscountsLocators(browser.Page);
        _ui = ui;
    }

    public Task VerifyCommercialAutoAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CommercialAuto, expected, property);

    public Task WaitForDiscountNEWNextAsync(string expected) =>
        _ui.WaitAsync(_locators.DiscountNEWNext, expected);

    public Task ClickDiscountNEWNextAsync() =>
        _ui.ClickAsync(_locators.DiscountNEWNext);

    public Task ClickDiscountsAdjustmentsNavAsync() =>
        _ui.ClickAsync(_locators.DiscountsAdjustmentsNav);

    public Task WaitForDiscountsAdjustmentsHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.DiscountsAdjustmentsHeader, expected);

public Task VerifyLoadingAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Loading, expected, property);

    public Task<bool> IsLoadingPresentAsync() =>
        _ui.ExistsAsync(_locators.Loading);

    public Task VerifyMultiCarDiscountAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CommercialAuto, expected, property);

    public Task ClickN1500030000Async() =>
        _ui.ClickAsync(_locators.N1500030000);

    public Task<bool> IsGreaterThan25000050000AndLessThan100000300000PresentAsync() =>
        _ui.ExistsAsync(_locators.GreaterThan25000050000AndLessThan100000300000);

    public Task ClickGreaterThan25000050000AndLessThan100000300000Async() =>
        _ui.ClickAsync(_locators.GreaterThan25000050000AndLessThan100000300000);

    public Task<bool> IsNotResidentialPropertyOwnerPresentAsync() =>
        _ui.ExistsAsync(_locators.NotResidentialPropertyOwner);

    public Task ClickNotResidentialPropertyOwnerAsync() =>
        _ui.ClickAsync(_locators.NotResidentialPropertyOwner);

    public Task SelectNoDefensiveDriverDiscountAsync(string value) =>
        _ui.SelectAsync(_locators.NoDefensiveDriver, value);

    public Task<bool> IsDefensiveDriverCourseBasicPresentAsync() =>
        _ui.ExistsAsync(_locators.DefensiveDriverCourseBasic);

    public Task ClickDefensiveDriverCourseBasicAsync() =>
        _ui.ClickAsync(_locators.DefensiveDriverCourseBasic);

    public Task SetOnAsync(string value) =>
        _ui.SmartSetAsync(_locators.On, value);

    public Task ClickSetOnAsync() =>
        _locators.On.EvaluateAsync("el => el.click()");

    public Task<bool> IsAutoHomeDiscountOnPresentAsync() =>
        _ui.ExistsAsync(_locators.AutoHomeDiscountOn);

    public Task ClickAutoHomeDiscountOnAsync() =>
        _ui.ClickAsync(_locators.AutoHomeDiscountOn);

    public Task PressResidentiaProperty1Async(string key) =>
        _ui.PressAsync(_locators.ResidentiaProperty1, key);

    public Task ClickResidentiaProperty1Async() =>
        _ui.ClickAsync(_locators.ResidentiaProperty1);

    public Task ClickRBodyInjurelessthanor30k60kAsync() =>
        _ui.ClickAsync(_locators.LessThanOrEqualTo30k60k);

    public Task ClickRiderGroupDiscountAsync() =>
        _ui.ClickAsync(_locators.RiderGroupDiscount);

    public Task<bool> IsRiderGroupDiscountPresentAsync() =>
        _ui.ExistsAsync(_locators.RiderGroupDiscount);

    public Task ClickSafeCycleDiscountAsync() =>
        _ui.ClickAsync(_locators.SafeCycleDiscountYes);

    public Task EnterSafeCycleDiscountDateAsync(string value) =>
        _ui.FillAsync(_locators.SafeCycleDiscountDate, value);

    public Task<bool> IsSafeCycleDiscountDatePresentAsync() =>
        _ui.ExistsAsync(_locators.SafeCycleDiscountDate);

    public Task VerifySpecialFarmPackageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CommercialAuto, expected, property);

    public Task ClickStateMDAsync() =>
        _ui.ClickAsync(_locators.StateMD);

    public Task<bool> IsStateMDPresentAsync() =>
        _ui.ExistsAsync(_locators.StateMD);

    public Task<bool> IsOnPresentAsync() =>
        _ui.ExistsAsync(_locators.On);

    public Task SetCommercialAutoOverrideOnAsync(string value) =>
        _ui.SmartSetAsync(_locators.CommercialAutoOverride, value);

    public Task ClickCommercialAutoOverrideOnAsync() =>
        _ui.ClickAsync(_locators.CommercialAutoOverride);

    public Task<bool> IsCommercialAutoOverridePresentAsync() =>
        _ui.ExistsAsync(_locators.CommercialAutoOverride);

    public Task SetSpecialFarmPackageOverrideOnAsync(string value) =>
        _ui.SmartSetAsync(_locators.SpecialFarmPackageOverride, value);
    public Task ClickSpecialFarmPackageOverrideOnAsync() =>
        _ui.ClickAsync(_locators.SpecialFarmPackageOverride);

    public Task<bool> IsSpecialFarmPackageOverridePresentAsync() =>
        _ui.ExistsAsync(_locators.SpecialFarmPackageOverride);

}
