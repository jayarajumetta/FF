using InsuranceAutomation.Core;
using InsuranceAutomation.PLDC.Pages.Locators;
using Microsoft.Playwright;
using System.Globalization;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class ProposalPage
{
    private readonly BrowserSession _browser;
    private readonly ProposalLocators _locators;
    private readonly UiActions _ui;

    public ProposalPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new ProposalLocators(browser.Page);
        _ui = ui;
    }
    public Task EnterAgentCodeAsync(string value) =>
        _ui.FillAsync(_locators.AgentCode, value);
    public Task ClickAgentCodeAsync() =>
        _ui.ClickAsync(_locators.WritingCompany);

    public Task PressAgentCodeAsync(string key) =>
        _ui.PressAsync(_locators.AgentCode, key);

    public Task VerifyCONFIRMAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SubmitAngular, expected, property);

    public Task ClickCONFIRMAsync() =>
        _locators.SubmitAngular.EvaluateAsync("el => el.click()");

    public Task ClickCONFIRMEditAsync() =>
        _locators.ConfirmEdit.EvaluateAsync("el => el.click()");

    public Task<bool> IsCONFIRMPresentAsync() =>
        _ui.ExistsAsync(_locators.ConfirmSSN);

    public Task ClickEditAsync() =>
        _ui.ClickAsync(_locators.ConfirmEdit);

    public Task<bool> IsEditPresentAsync() =>
        _ui.ExistsAsync(_locators.ConfirmEdit);

    public Task ClickCREATENEWACCOUNTAsync() =>
       _locators.CREATENEWACCOUNT.EvaluateAsync("el => el.click()");

    public Task<bool> IsCREATENEWACCOUNTPresentAsync() =>
        _ui.ExistsAsync(_locators.CREATENEWACCOUNT);

    public Task VerifyClientAlreadyExistsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ClientAlreadyExists, expected, property);

    public Task<bool> IsClientAlreadyExistsPresentAsync() =>
        _ui.ExistsAsync(_locators.ClientAlreadyExists);

    public Task EnterCountyComboBoxAsync(string value) =>
        _ui.SelectAsync(_locators.CountyComboBox, value);

    public Task WaitForCountyYesAsync(string expected) =>
        _ui.WaitAsync(_locators.countyYesAsync, expected);

    public Task SelectCountyYesAsync(string value) =>

  _locators.countyYesAsync.EvaluateAsync("el => el.click()");

    public Task EnterEffectiveDateAsync(string value) =>
        _ui.FillAsync(_locators.EffectiveDate, value);

    public Task PressEffectiveDateAsync(string key) =>
        _ui.PressAsync(_locators.EffectiveDate, key);

    public Task ClickMotorcycleAsync() =>
        _ui.ClickAsync(_locators.Motorcycle);

    public Task WaitForNewQuoteAsync(string expected) =>
        _ui.WaitAsync(_locators.NewQuote, expected);

    public Task VerifyNewQuoteAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NewQuote, expected, property);

    public Task ClickNewQuoteAsync() =>
        _ui.ClickAsync(_locators.NewQuote);

    public Task VerifyPROCEEDAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.CONFIRM, expected, property);

    public Task ClickPROCEEDAsync() =>
        _ui.ClickAsync(_locators.CONFIRM);

    public Task<bool> IsPROCEEDPresentAsync() =>
        _ui.ExistsAsync(_locators.PotentialInvalidAddress);

    public Task WaitForPersonalAutoAsync(string expected) =>
        _ui.WaitAsync(_locators.PersonalAuto, expected);

    public Task ClickPersonalAutoAsync() =>
        _ui.ClickAsync(_locators.PersonalAuto);

    public Task VerifyProposalStartProceedSSNSUBMITAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SubmitAngular, expected, property);

    //public Task ClickProposalStartProceedSSNSUBMITAsync() =>
    //    _ui.ClickAsync(_locators.SubmitAngular);

    public async Task ClickProposalStartProceedSSNSUBMITAsync()
    {
        // The Angular overlay sometimes blocks clicks, use JavaScript click as workaround
        await _locators.SubmitAngular.EvaluateAsync("el => el.click()");
    }

    public string GetTodayEffectiveDate() =>
        DateTime.Today.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
    public string GetTomorrowEffectiveDate() =>
        DateTime.Today.AddDays(1).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

    public Task WaitForCaptureQuoteNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.NameAndQuote, expected);

    public Task<string> CaptureQNumAsync(string property = "") =>
            _ui.CaptureAsync(_locators.NameAndQuote, property);

    public Task<string> CaptureQuoteNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.QuoteNumber, property);

    public Task ClickRecreationalVehicleAsync() =>
        _ui.ClickAsync(_locators.RecreationalVehicleChip);

    public Task WaitForSSNAsync(string expected) =>
        _ui.WaitAsync(_locators.SSN, expected);

    public Task VerifySSNAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.SSN, expected, property);

    public Task EnterSSNAsync(string value) =>
        _ui.FillAsync(_locators.SsnInput, value);

    public Task<bool> IsSSNPresentAsync() =>
        _ui.ExistsAsync(_locators.SSN);

    public Task WaitForSameAsMailingAddressAsync(string expected) =>
        _ui.WaitAsync(_locators.SameAsMailingAddress, expected);

    public Task PressSameAsMailingAddressAsync(string key) =>
        _ui.PressAsync(_locators.SameAsMailingAddress, key);

    public Task ClickSameAsMailingAddressAsync() =>
        _ui.ClickAsync(_locators.SameAsMailingAddress);

    public Task WaitForStartQuoteAsync(string expected) =>
        _ui.WaitAsync(_locators.StartQuote, expected);

    public Task ClickStartQuoteAsync() =>
        _ui.ClickAsync(_locators.StartQuote);

    public Task EnterStateAsync(string value) =>
        _ui.FillAsync(_locators.State, value);

    public Task SelectStateAsync(string value) =>

    _ui.SelectAsync(_locators.State, value);


    public Task PressStateAsync(string key) =>
        _ui.PressAsync(_locators.State, key);

    public Task ClickStateMONTANAAsync() =>
        _ui.ClickAsync(_locators.StateMONTANA);

    public Task<bool> IsStateMONTANAPresentAsync() =>
        _ui.ExistsAsync(_locators.StateMONTANA);

    public Task SelectStateNameAsync(string value) =>
        _ui.SelectAsync(_locators.State, value);

    public Task WaitForUSEEXISTINGACCOUNTAsync(string expected) =>
        _ui.WaitAsync(_locators.CONFIRM, expected);

    public Task ClickUSEEXISTINGACCOUNTAsync() =>
         _locators.SubmitAngular.EvaluateAsync("el => el.click()");
    //_ui.ClickAsync(_locators.CONFIRM);

    public Task<bool> IsUSEEXISTINGACCOUNTPresentAsync() =>
        _ui.ExistsAsync(_locators.ClientExists);

    public Task EnterWritingCompanyAsync(string value) =>

        _ui.FillAsync(_locators.WritingCompany, value);

    public Task SelectWritingCompanyAsync(string value) =>
        _ui.SelectAsync(_locators.WritingCompany, value);

    public Task PressWritingCompanyAsync(string key) =>
        _ui.PressAsync(_locators.WritingCompany, key);

}
