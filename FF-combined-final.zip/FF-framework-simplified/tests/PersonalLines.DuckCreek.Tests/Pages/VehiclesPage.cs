using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class VehiclesPage
{
    private readonly BrowserSession _browser;
    private readonly VehiclesLocators _locators;
    private readonly UiActions _ui;

    public VehiclesPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new VehiclesLocators(browser.Page);
        _ui = ui;
    }

    public Task PressAccountOwnerAsync(string key) =>
        _ui.PressAsync(_locators.AccountOwner, key);

    public Task ClickAccountOwnerAsync() =>
        _ui.ClickAsync(_locators.AccountOwner);

    public Task VerifyAccountOwnerReadOnlyAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AccountOwnerReadOnly, expected, property);

    public Task ClickActiveDisablingDeviceAsync() =>
        _ui.ClickAsync(_locators.ActiveDisablingDevice);

    public Task ClickAddAdditionalVehicleAsync() =>
        _ui.ClickAsync(_locators.AddAdditionalVehicle);

    public Task ClickAddCycleNextNextAsync() =>
        _ui.ClickAsync(_locators.AddCycleNextNext);

    public Task ClickAddVehicleAsync() =>
        _ui.ClickAsync(_locators.AddVehicle);

    public Task WaitForAdditionalVehicleAsync(string expected) =>
        _ui.WaitAsync(_locators.AddAdditionalVehicle, expected);

    public Task ClickAdditionalVehicleAsync() =>
        _ui.ClickAsync(_locators.AdditionalVehicle);

    public Task<bool> IsAdditionalVehiclePresentAsync() =>
        _ui.ExistsAsync(_locators.AdditionalVehicle);


    public Task<bool> IsMoreOptionsDropdownLabelPresentAsync() =>
        _ui.ExistsAsync(_locators.MoreOptionsDropdownLabel);

    public Task ClickMoreOptionsDropdownLabelAsync() =>
        _ui.ClickAsync(_locators.MoreOptionsDropdownLabel);

    public Task<bool> IsSelectVehiclesToBeCoveredHeaderPresentAsync() =>
        _ui.ExistsAsync(_locators.SelectVehiclesToBeCoveredHeader);

    public Task ClickAdditionalVehicleSMenuItemAsync() =>
        _ui.ClickAsync(_locators.AdditionalVehicleSMenuItem);

    public Task<bool> IsAdditionalVehicleSMenuItemPresentAsync() =>
        _ui.ExistsAsync(_locators.AdditionalVehicleSMenuItem);

    public Task ClickAutoVehiclePrefillSelectionNextAsync() =>
        _ui.ClickAsync(_locators.AutoVehiclePrefillSelectionNext);


    public Task<bool> IsSaveAndContinuePresentAsync() =>
       _ui.ExistsAsync(_locators.SaveAndContinue);

    public Task ClickAdditionalVehicleS62C9AAsync() =>
        _ui.ClickAsync(_locators.AdditionalVehicleS62C9A);

    public Task ClickAdditionalVehicleSF5D93Async() =>
        _ui.ClickAsync(_locators.AdditionalVehicleS62C9A);

    public Task<bool> IsAdditionalVehicleSF5D93PresentAsync() =>
        _ui.ExistsAsync(_locators.AdditionalVehicleS62C9A);

    public Task EnterAgreedValue8E288Async(string value) =>
        _ui.FillAsync(_locators.AgreedValue8E288, value);

    public Task ClickVehicleOwnedOrFinancedOwnAgreedValueAsync() =>
        _ui.ClickAsync(_locators.VehicleOwnedOrFinancedOwnAgreedValue);

    public Task EnterAgreedValueF302BAsync(string value) =>
        _ui.FillAsync(_locators.AgreedValue8E288, value);

    public Task EnterAnnualMileage12A49Async(string value) =>
        _ui.FillAsync(_locators.AnnualMileage12A49, value);

    public Task<bool> IsAnnualMileage12A49PresentAsync() =>
        _ui.ExistsAsync(_locators.AnnualMileage12A49);

    public Task EnterAnnualMileage51344Async(string value) =>
        _ui.FillAsync(_locators.AnnualMileage51344, value);

    public Task PressAnnualMileage51344Async(string key) =>
        _ui.PressAsync(_locators.AnnualMileage51344, key);

    public Task<bool> IsActiveDisablingDeviceAndWindowGlassEtchingPresentAsync() =>
        _ui.ExistsAsync(_locators.ActiveDisablingDeviceAndWindowGlassEtching);

    public Task ClickActiveDisablingDeviceAndWindowGlassEtchingAsync() =>
        _ui.ClickAsync(_locators.ActiveDisablingDeviceAndWindowGlassEtching);

    public Task<bool> IsAntiTheftYesPresentAsync() =>
        _ui.ExistsAsync(_locators.AntiTheftYes);

    public Task SelectAntiTheftYesAsync(string value) =>
        _ui.SelectAsync(_locators.AntiTheftYes, value);

    public Task<bool> IsAntiTheftCategory1PresentAsync() =>
        _ui.ExistsAsync(_locators.AntiTheftCategory1);

    public Task ClickAntiTheftCategory1Async() =>
        _ui.ClickAsync(_locators.AntiTheftCategory1);

    public Task<bool> IsAntiTheftCategory1WithoutLockPresentAsync() =>
        _ui.ExistsAsync(_locators.AntiTheftCategory1WithoutLock);

    public Task ClickAntiTheftCategory1WithoutLockAsync() =>
        _ui.ClickAsync(_locators.AntiTheftCategory1WithoutLock);

    public Task<bool> IsVehicleUsedForBusinessNoPresentAsync() =>
        _ui.ExistsAsync(_locators.VehicleUsedForBusinessNo);

    public Task ClickVehicleUsedForBusinessNoAsync() =>
        _ui.ClickAsync(_locators.VehicleUsedForBusinessNo);

    public Task<bool> IsVehicleUsedForBusinessNoVeh4PresentAsync() =>
        _ui.ExistsAsync(_locators.VehicleUsedForBusinessNoVeh4);

    public Task ClickVehicleUsedForBusinessNoVeh4Async() =>
        _ui.ClickAsync(_locators.VehicleUsedForBusinessNoVeh4);

    public Task<bool> IsHowManyDaysPerWeek1PresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyDaysPerWeek1);

    public Task ClickHowManyDaysPerWeek1Async() =>
        _ui.ClickAsync(_locators.HowManyDaysPerWeek1);

    public Task<bool> IsHowManyDaysPerWeek1Veh4PresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyDaysPerWeek1Veh4);

    public Task ClickHowManyDaysPerWeek1Veh4Async() =>
        _ui.ClickAsync(_locators.HowManyDaysPerWeek1Veh4);

    public Task<bool> IsHowManyMilesPerDayOneWayPresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyMilesPerDayOneWay);

    public Task EnterHowManyMilesPerDayOneWayAsync(string value) =>
        _ui.FillAsync(_locators.HowManyMilesPerDayOneWay, value);

    public Task<bool> IsHowManyMilesPerDayOneWayVeh4PresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyMilesPerDayOneWayVeh4);

    public Task EnterHowManyMilesPerDayOneWayVeh4Async(string value) =>
        _ui.FillAsync(_locators.HowManyMilesPerDayOneWayVeh4, value);

    public Task<bool> IsHowManyAnnualMilesDrivenOutsidePresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyAnnualMilesDrivenOutside);

    public Task<bool> IsHowManyAnnualMilesDrivenOutsideVeh4PresentAsync() =>
        _ui.ExistsAsync(_locators.HowManyAnnualMilesDrivenOutsideVeh4);

    public Task EnterHowManyAnnualMilesDrivenOutsideAsync(string value) =>
        _ui.FillAsync(_locators.HowManyAnnualMilesDrivenOutside, value);

    public Task EnterHowManyAnnualMilesDrivenOutsideVeh4Async(string value) =>
        _ui.FillAsync(_locators.HowManyAnnualMilesDrivenOutsideVeh4, value);

    public Task<bool> IsHistoricalPlatesVintagePresentAsync() =>
        _ui.ExistsAsync(_locators.HistoricalPlatesVintage);

    public Task ClickHistoricalPlatesVintageAsync() =>
        _ui.ClickAsync(_locators.HistoricalPlatesVintage);

    public Task EnterAppraisalDate8A115Async(string value) =>
        _ui.FillAsync(_locators.AppraisalDate8A115, value);

    public Task PressAppraisalDate8A115Async(string key) =>
        _ui.PressAsync(_locators.AppraisalDate8A115, key);

    public Task EnterAppraisalDateD909CAsync(string value) =>
        _ui.FillAsync(_locators.AppraisalDate8A115, value);

    public Task PressAssignedAsync(string key) =>
        _ui.PressAsync(_locators.Assigned, key);

    public Task ClickAssignedAsync() =>
        _ui.ClickAsync(_locators.Assigned);

    public Task ClickFinancialResponsibiltySR44NoAsync() =>
        _ui.ClickAsync(_locators.FinancialResponsibilitySR44No);

    public Task WaitForCONTINUED555DAsync(string expected) =>
        _ui.WaitAsync(_locators.CONTINUED555D, expected);

    public Task ClickCONTINUED555DAsync() =>

        _locators.CONTINUED555D.EvaluateAsync("el => el.click()");
    public Task<bool> IsCONTINUED555DPresentAsync() =>
        _ui.ExistsAsync(_locators.CONTINUED555D);

    public Task ClickCONTINUEF07C7Async() =>
        _locators.CONTINUED555D.EvaluateAsync("el => el.click()");

    public Task<bool> IsCONTINUEF07C7PresentAsync() =>
        _ui.ExistsAsync(_locators.CONTINUED555D);

    public Task SelectCamperShellNoAsync(string value) =>
        _ui.SelectAsync(_locators.CamperShellNo, value);

    public Task ClickCategoryIAsync() =>
        _ui.ClickAsync(_locators.CategoryI);

    public Task PressClassicAsync(string key) =>
        _ui.PressAsync(_locators.Classic, key);

    public Task ClickClassicAsync() =>
        _ui.ClickAsync(_locators.Classic);

    public Task PressCollectorCarAsync(string key) =>
        _ui.PressAsync(_locators.CollectorCar, key);

    public Task ClickCollectorCarAsync() =>
        _ui.ClickAsync(_locators.CollectorCar);

    public Task SelectCollectorCarTypeMoreOptionsAsync(string value) =>
        _ui.SelectAsync(_locators.CollectorCarTypeMoreOptions, value);

    public Task WaitForCollegeDegreeGraduateWorkAsync(string expected) =>
        _ui.WaitAsync(_locators.CollegeDegreeGraduateWork, expected);

    public Task ClickCollegeDegreeGraduateWorkAsync() =>
        _ui.ClickAsync(_locators.CollegeDegreeGraduateWork);

    public Task ClickContinueAsync() =>
        _ui.ClickAsync(_locators.CONTINUED555D);

    public Task EnterCurrentValueAsync(string value) =>
        _ui.FillAsync(_locators.CurrentValue, value);

    public Task WaitForCurrentlyInCollegeAsync(string expected) =>
        _ui.WaitAsync(_locators.CurrentlyInCollege, expected);

    public Task ClickCurrentlyInCollegeAsync() =>
        _ui.ClickAsync(_locators.CurrentlyInCollege);

    public Task ClickCycle1734D7Async() =>
        _ui.ClickAsync(_locators.Cycle1734D7);

    public Task ClickCycle1C1864Async() =>
        _ui.ClickAsync(_locators.SelectFirstVehicle);

    public Task ClickCycleAccessoriesV3Async() =>
        _ui.ClickAsync(_locators.CycleAccessoriesV3);

    public Task ClickCycleAccessoriesV4Async() =>
        _ui.ClickAsync(_locators.CycleAccessoriesV3);

    public Task EnterCycleNonDriverComboBoxAsync(string value) =>
        _ui.FillAsync(_locators.CycleNonDriverComboBox, value);

    public Task ClickCyclePreFillSelectionNextAsync() =>
        _ui.ClickAsync(_locators.AddCycleNextNext);

    public Task WaitForCycleVINAsync(string expected) =>
        _ui.WaitAsync(_locators.Cycle1734D7, expected);

    public Task EnterCycleVINAsync(string value) =>
        _ui.FillAsync(_locators.Cycle1734D7, value);

    public Task PressCycleVINAsync(string key) =>
        _ui.PressAsync(_locators.Cycle1734D7, key);

    public Task EnterDaysOperatedUninsuredAsync(string value) =>
        _ui.FillAsync(_locators.DaysOperatedUninsured, value);

    public Task EnterDescriptionOfModsAsync(string value) =>
        _ui.FillAsync(_locators.DescriptionOfMods, value);

    public Task EnterEngineCCAsync(string value) =>
        _ui.FillAsync(_locators.engineCC, value);

    public Task ClickDivorcedAsync() =>
        _ui.ClickAsync(_locators.Divorced);

    public Task WaitForDoesThisVehicleHaveAnyNonFactoryAdditionsAlterationsOrModifications051FDAsync(string expected) =>
        _ui.WaitAsync(_locators.DoesThisVehicleHaveAnyNonFactoryAdditionsAlterationsOrModifications051FD, expected);

    public Task WaitForDoesThisVehicleHaveAnyNonFactoryAdditionsAlterationsOrModifications21ABDAsync(string expected) =>
        _ui.WaitAsync(_locators.DoesThisVehicleHaveAnyNonFactoryAdditionsAlterationsOrModifications051FD, expected);

    public Task EnterDriverSLicenseNumberAsync(string value) =>
        _ui.FillAsync(_locators.DriverLicenceNumber, value);


    public Task PressDriverSLicenseNumberAsync(string key) =>
        _ui.PressAsync(_locators.DriversLicenseNumber, key);

    public Task VerifyEQCAVerifiedMileageAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQCAVerifiedMileage, expected, property);

    public Task WaitForGraduateDegreeJDMastersAsync(string expected) =>
        _ui.WaitAsync(_locators.GraduateDegreeJDMasters, expected);

    public Task ClickGraduateDegreeJDMastersAsync() =>
        _ui.ClickAsync(_locators.GraduateDegreeJDMasters);

    public Task VerifyHighSchoolDiplomaOrGEDAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.HighSchoolDiplomaOrGED, expected, property);

    public Task ClickHighSchoolDiplomaOrGEDAsync() =>
        _ui.ClickAsync(_locators.HighSchoolDiplomaOrGED);

    public Task<bool> IsHighSchoolDiplomaOrGEDPresentAsync() =>
        _ui.ExistsAsync(_locators.HighSchoolDiplomaOrGED);

    public Task ClickILCategory1Async() =>
        _ui.ClickAsync(_locators.ILCategory1);

    public Task WaitForIsThisDriverANamedInsuredAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountOwnerReadOnly, expected);

    public Task WaitForIsThisVehicleOwnedOrFinancedAsync(string expected) =>
        _ui.WaitAsync(_locators.Cycle1734D7, expected);

    public Task WaitForLblDescriptionOfModsAsync(string expected) =>
        _ui.WaitAsync(_locators.LblDescriptionOfMods, expected);

    public Task VerifyLblOwnedPopupAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.LblOwnedPopup, expected, property);

    public Task<bool> IsLblOwnedPopupPresentAsync() =>
        _ui.ExistsAsync(_locators.LblOwnedPopup);

    public Task ClickLeased14EA4Async() =>
        _ui.ClickAsync(_locators.Leased14EA4);

    public Task ClickLeased26B32Async() =>
        _ui.ClickAsync(_locators.Leased26B32);

    public Task ClickLeased87268Async() =>
        _ui.ClickAsync(_locators.Leased26B32);

    public Task EnterLicenseStateAsync(string value) =>
        _ui.FillAsync(_locators.DaysOperatedUninsured, value);

    public Task ClickLoan4369DAsync() =>
        _ui.ClickAsync(_locators.Loan49242);

    public Task ClickLoan49242Async() =>
        _ui.ClickAsync(_locators.Loan49242);

    public Task ClickLoanED36CAsync() =>
        _ui.ClickAsync(_locators.Loan49242);

    public Task ClickMDNJEducationLevelUnknownAsync() =>
        _ui.ClickAsync(_locators.MDNJEducationLevelUnknown);

    public Task<bool> IsMDNJEducationLevelUnknownPresentAsync() =>
        _ui.ExistsAsync(_locators.MDNJEducationLevelUnknown);

    public Task WaitForMOREOPTIONSAsync(string expected) =>
        _ui.WaitAsync(_locators.MOREOPTIONS, expected);

    public Task SelectMOREOPTIONSAsync(string value) =>
        _ui.SelectAsync(_locators.MOREOPTIONS, value);

    public Task<bool> IsMOREOPTIONSPresentAsync() =>
        _ui.ExistsAsync(_locators.MOREOPTIONS);

    public Task ClickMaritalStatusSingleAsync() =>
        _ui.ClickAsync(_locators.MaritalStatusSingle);

    public Task<bool> IsMaritalStatusSinglePresentAsync() =>
        _ui.ExistsAsync(_locators.MaritalStatusSingle);

    public Task<bool> IsGenderPresentAsync() =>
        _ui.ExistsAsync(_locators.GenderLabel);

    public Task ClickGenderMaleAsync() =>
        _ui.ClickAsync(_locators.GenderMale);

    public Task ClickOperatorStatusAssignedAsync() =>
        _ui.ClickAsync(_locators.OperatorStatusAssigned);

    public Task SelectMarriedAsync(string value) =>
        _ui.SelectAsync(_locators.Divorced, value);

    public Task ClickMedicalConditionAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task ClickMilitaryAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task ClickMissionaryAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task PressModernClassicAsync(string key) =>
        _ui.PressAsync(_locators.ModernClassic, key);

    public Task ClickModernClassicAsync() =>
        _ui.ClickAsync(_locators.ModernClassic);

    public Task EnterMonthsLicensedCurrentStateAsync(string value) =>
        _ui.FillAsync(_locators.MonthsLicensedCurrentState, value);

    public Task PressMonthsLicensedCurrentStateAsync(string key) =>
        _ui.PressAsync(_locators.DaysOperatedUninsured, key);

    public Task SelectMoreOptionsEduAsync(string value) =>
        _ui.SelectAsync(_locators.MoreOptionsEdu, value);

    public Task SelectMoreOptionsFarmUseAsync(string value) =>
        _ui.SelectAsync(_locators.MoreOptionsFarmUse, value);

    public Task SelectMoreOptionsNonDriverAsync(string value) =>
        _ui.SelectAsync(_locators.AccountOwnerReadOnly, value);

    public Task ClickN1DayAsync() =>
        _ui.ClickAsync(_locators.N1Day);

    public Task EnterNYFFCICTotalAnnualMilesAsync(string value) =>
        _ui.FillAsync(_locators.NYFFCICTotalAnnualMiles, value);

    public Task PressNYFFCICTotalAnnualMilesAsync(string key) =>
        _ui.PressAsync(_locators.NYFFCICTotalAnnualMiles, key);

    public Task PressNamedInsuredAsync(string key) =>
        _ui.PressAsync(_locators.NamedInsured, key);

    public Task ClickNamedInsuredAsync() =>
        _ui.ClickAsync(_locators.NamedInsured);

    public Task SelectNativeAmericanRegisterNOAsync(string value) =>
        _ui.SelectAsync(_locators.NativeAmericanRegisterNO, value);

    public Task ClickNeverLicensedAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task SelectNo7C269Async(string value) =>
        _ui.SelectAsync(_locators.No7C269, value);

    public Task SelectNoCoverageV1TowingAsync(string value) =>
        _ui.SelectAsync(_locators.NoCoverageV1Towing, value);

    public Task SelectNoCycleLicenseAsync(string value) =>
        _ui.SelectAsync(_locators.AccountOwnerReadOnly, value);

    public Task PressNoD053AAsync(string key) =>
        _ui.PressAsync(_locators.NoD053A, key);

    public Task ClickNoD053AAsync() =>
        _ui.ClickAsync(_locators.NoD053A);

    public Task SelectNoD9E4DAsync(string value) =>
        _ui.SelectAsync(_locators.No7C269, value);

    public Task VerifyNoNeedWasNotLicensedAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.NoNeedWasNotLicensed, expected, property);

    public Task PressNoNeedWasNotLicensedAsync(string key) =>
        _ui.PressAsync(_locators.NoNeedWasNotLicensed, key);

    public Task ClickNoNeedWasNotLicensedAsync() =>
        _ui.ClickAsync(_locators.NoNeedWasNotLicensed);

    public Task<bool> IsNoNeedWasNotLicensedAsync() =>
        _ui.ExistsAsync(_locators.NoNeedWasNotLicensed);

    public Task<bool> IsNoNeedWasNotLicensedPresentAsync() =>
        _ui.ExistsAsync(_locators.NoNeedWasNotLicensed);

    public Task SelectNoPreviouslyInsuredAsync(string value) =>
        _ui.SelectAsync(_locators.NoPreviouslyInsured, value);


    public Task ClickNB3NotLicensedAsync() =>
      _ui.ClickAsync(_locators.NB3NotLicensedLink);


    public Task<bool> IsNoPreviouslyInsuredPresentAsync() =>
        _ui.ExistsAsync(_locators.NoPreviouslyInsured);

    public Task SelectNoRegisteredFedTribeAsync(string value) =>
        _ui.SelectAsync(_locators.NoRegisteredFedTribe, value);

    public Task SelectNonDriverAsync(string value) =>
        _ui.SelectAsync(_locators.Assigned, value);

    public Task PressNonDriverAsync(string key) =>
        _ui.PressAsync(_locators.Assigned, key);

    public Task ClickNonDriverAsync() =>
        _ui.ClickAsync(_locators.Assigned);

    public Task WaitForNonDriverReasonAsync(string expected) =>
        _ui.WaitAsync(_locators.AccountOwnerReadOnly, expected);

    public Task EnterNonWorkAnnualMilesAsync(string value) =>
        _ui.FillAsync(_locators.NonWorkAnnualMiles, value);

    public Task PressNonWorkAnnualMilesAsync(string key) =>
        _ui.PressAsync(_locators.NonWorkAnnualMiles, key);

    public Task PressNotANamedInsuredAsync(string key) =>
        _ui.PressAsync(_locators.NamedInsured, key);

    public Task ClickNotANamedInsuredAsync() =>
        _ui.ClickAsync(_locators.NamedInsured);

    public Task SelectNotPleasureUseAsync(string value) =>
        _ui.SelectAsync(_locators.NotPleasureUse, value);

    public Task EnterOdometer3843FAsync(string value) =>
        _ui.FillAsync(_locators.Odometer3843F, value);

    public Task PressOdometer3843FAsync(string key) =>
        _ui.PressAsync(_locators.Odometer3843F, key);

    public Task EnterOdometerVeh4Async(string value) =>
        _ui.FillAsync(_locators.OdometerVeh4, value);

    public Task EnterVehicleTotalAnnualMileageAsync(string value) =>
        _ui.FillAsync(_locators.VehicleTotalAnnualMileage, value);

    public Task EnterOdometerD648FAsync(string value) =>
        _ui.FillAsync(_locators.OdometerD648F, value);

    public Task<bool> IsOdometerRows0PresentAsync() =>
        _ui.ExistsAsync(_locators.OdometerRows0);

    public Task EnterOdometerRows0Async(string value) =>
        _ui.FillAsync(_locators.OdometerRows0, value);

    public Task PressOdometerD648FAsync(string key) =>
        _ui.PressAsync(_locators.OdometerD648F, key);

    public Task ClickOptOutAsync() =>
        _ui.ClickAsync(_locators.OptOut);

    public Task<bool> IsOptOutPresentAsync() =>
        _ui.ExistsAsync(_locators.OptOut);

    public Task ClickOriginalPartsV3Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickOriginalPartsV4Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickOtherInsuranceAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task ClickOwn49EECAsync() =>
        _ui.ClickAsync(_locators.Own7C709);

    public Task ClickVehicleOwnedOrFinancedOwnAsync() =>
        _ui.ClickAsync(_locators.VehicleOwnedOrFinancedOwn);

    public Task ClickVehicleTypeAutomobileAsync() =>
        _ui.ClickAsync(_locators.VehicleTypeAutomobile);

    public Task<bool> IsCustomizedEquipmentNoPresentAsync() =>
        _ui.ExistsAsync(_locators.CustomizedEquipmentNo);

    public Task ClickCustomizedEquipmentNoAsync() =>
        _ui.ClickAsync(_locators.CustomizedEquipmentNo);

    public Task ClickCustomizedEquipmentNoVeh4Async() =>
        _ui.ClickAsync(_locators.CustomizedEquipmentNoVeh4);

    public Task<bool> IsUsedInTravellingOrPermanentResidenceNoPresentAsync() =>
        _ui.ExistsAsync(_locators.UsedInTravellingOrPermanentResidenceNo);

    public Task ClickUsedInTravellingOrPermanentResidenceNoAsync() =>
        _ui.ClickAsync(_locators.UsedInTravellingOrPermanentResidenceNo);

    public Task ClickOwn7C709Async() =>
        _ui.ClickAsync(_locators.Own7C709);

    public Task PressOwnB8575Async(string key) =>
        _ui.PressAsync(_locators.OwnB8575, key);

    public Task ClickOwnB8575Async() =>
        _ui.ClickAsync(_locators.OwnB8575);

    public Task ClickOwnD044EAsync() =>
        _ui.ClickAsync(_locators.Own7C709);

    public Task ClickPermitDriverAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task WaitForPleaseSelectTheVehicleBBB72Async(string expected) =>
        _ui.WaitAsync(_locators.Cycle1734D7, expected);

    public Task WaitForPleaseSelectTheVehicleCD741Async(string expected) =>
        _ui.WaitAsync(_locators.PleaseSelectVehicleHeading, expected);

    public Task<bool> IsleaseSelectTheVehicleCD741Async() =>
        _ui.ExistsAsync(_locators.PleaseSelectVehicleHeading);

    public Task ClickPleasureCANYFFCICAsync() =>
        _ui.ClickAsync(_locators.PleasureCANYFFCIC);

    public Task ClickPleasureCANYFFCICVeh4Async() =>
        _ui.ClickAsync(_locators.PleasureCANYFFCICVeh4);

    public Task ClickPleasureUseAsync() =>
        _ui.ClickAsync(_locators.PleasureUse);


    public Task<bool> IsPleasureWorkUsePresentAsync() =>
        _ui.ExistsAsync(_locators.PleasureWorkUse);

    public Task ClickPleasureWorkUseAsync() =>
        _ui.ClickAsync(_locators.PleasureWorkUse);

    public Task ClickVechicle2PleasureUseAsync() =>
        _ui.ClickAsync(_locators.Vechicle2);


    public Task WaitForPostGraduateDegreeMedicalDegreePhDEdDEtcAsync(string expected) =>
        _ui.WaitAsync(_locators.PostGraduateDegreeMedicalDegreePhDEdDEtc, expected);

    public Task ClickPostGraduateDegreeMedicalDegreePhDEdDEtcAsync() =>
        _ui.ClickAsync(_locators.PostGraduateDegreeMedicalDegreePhDEdDEtc);

    public Task WaitForPricingDetailsNextAsync(string expected) =>
        _ui.WaitAsync(_locators.PricingDetailsNext, expected);

    public Task ClickPricingDetailsNextAsync() =>
        _ui.ClickAsync(_locators.PricingDetailsNext);

    public Task PressPrimaryNamedInsuredAsync(string key) =>
        _ui.PressAsync(_locators.NamedInsured, key);

    public Task ClickPrimaryNamedInsuredAsync() =>
        _ui.ClickAsync(_locators.NamedInsured);

    public Task VerifyPriorCarrierNameAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.PriorCarrierName, expected, property);

    public Task<bool> IsPriorCarrierNamePresentAsync() =>
        _ui.ExistsAsync(_locators.PriorCarrierName);

        public Task<bool> IsClinetInsuredANAsync() =>
        _ui.ExistsAsync(_locators.ClientInsuredAN);

    public Task ClickClientInsuredNoAsync() =>
        _ui.ClickAsync(_locators.ClientInsuredANNo);

    public Task<bool> IsUnderWriterRulesAsync() =>
        _ui.ExistsAsync(_locators.UnderWriterRulesHeader);

    public Task EnterPurchaseDate736F4Async(string value) =>
        _ui.FillAsync(_locators.PurchaseDate736F4, value);

    public Task EnterPurchaseDateVeh4Async(string value) =>
        _ui.FillAsync(_locators.PurchaseDateVeh4, value);

    public Task EnterPurchaseDateBB8AFAsync(string value) =>
        _ui.FillAsync(_locators.PurchaseDateBB8AF, value);

    public Task PressPurchaseDateBB8AFAsync(string key) =>
        _ui.PressAsync(_locators.PurchaseDateBB8AF, key);

    public Task PressRelatedAsync(string key) =>
        _ui.PressAsync(_locators.Assigned, key);

    public Task ClickRelatedAsync() =>
        _ui.ClickAsync(_locators.Assigned);

    public Task SelectRelationshipToAccountOwnerNULLAsync(string value) =>
        _ui.SelectAsync(_locators.RelationshipToAccountOwnerNULL, value);

    public Task PressRentalReimbursementCoverageV1Async(string key) =>
        _ui.PressAsync(_locators.RentalReimbursementCoverageV1, key);

    public Task ClickRentalReimbursementCoverageV1Async() =>
        _ui.ClickAsync(_locators.RentalReimbursementCoverageV1);

    public Task PressRentalReimbursementCoverageV2Async(string key) =>
        _ui.PressAsync(_locators.RentalReimbursementCoverageV2, key);

    public Task ClickRentalReimbursementCoverageV2Async() =>
        _ui.ClickAsync(_locators.RentalReimbursementCoverageV2);

    public Task PressRentalReimbursementCoverageV3Async(string key) =>
        _ui.PressAsync(_locators.RentalReimbursementCoverageV3, key);

    public Task ClickRentalReimbursementCoverageV3Async() =>
        _ui.ClickAsync(_locators.RentalReimbursementCoverageV3);

    public Task PressRentalReimbursementCoverageV4Async(string key) =>
        _ui.PressAsync(_locators.RentalReimbursementCoverageV4, key);

    public Task ClickRentalReimbursementCoverageV4Async() =>
        _ui.ClickAsync(_locators.RentalReimbursementCoverageV4);

    public Task PressRestrictedUseAsync(string key) =>
        _ui.PressAsync(_locators.RestrictedUse, key);

    public Task<bool> IsRestrictedUsePresentAsync() =>
        _ui.ExistsAsync(_locators.RestrictedUse);

    public Task ClickRestrictedUseAsync() =>
        _ui.ClickAsync(_locators.RestrictedUse);

    public Task WaitForRestrictedUseAsync(string expected) =>
        _ui.WaitAsync(_locators.RestrictedUse, expected);

    public Task PressRoadsideAssistanceCoverageV1Async(string key) =>
        _ui.PressAsync(_locators.RoadsideAssistanceCoverageV1, key);

    public Task ClickRoadsideAssistanceCoverageV1Async() =>
        _ui.ClickAsync(_locators.RoadsideAssistanceCoverageV1);

    public Task PressRoadsideAssistanceCoverageV2Async(string key) =>
        _ui.PressAsync(_locators.RoadsideAssistanceCoverageV2, key);

    public Task ClickRoadsideAssistanceCoverageV2Async() =>
        _ui.ClickAsync(_locators.RoadsideAssistanceCoverageV2);

    public Task PressRoadsideAssistanceCoverageV3Async(string key) =>
        _ui.PressAsync(_locators.RoadsideAssistanceCoverageV3, key);

    public Task ClickRoadsideAssistanceCoverageV3Async() =>
        _ui.ClickAsync(_locators.RoadsideAssistanceCoverageV3);

    public Task ClickRoadsideAssistanceCoverageV4Async() =>
        _ui.ClickAsync(_locators.RoadsideAssistanceCoverageV4);

    public Task ClickRoommateAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task ClickSaveAndContinue8EF26Async() =>
        _ui.ClickAsync(_locators.SaveandContinue);
    
    public async Task WaitForSaveAndContinue8EF26Async(string expected)
    {
        await _locators.SaveandContinue.ScrollIntoViewIfNeededAsync();
        await _ui.WaitAsync(_locators.SaveandContinue, expected);
    }

    public Task<bool> IsSaveAndContinue8EF26PresentAsync() =>
        _ui.ExistsAsync(_locators.SaveAndContinue8EF26);

    public Task ClickFinancialResponsibilityNoAsync() =>
        _ui.ClickAsync(_locators.FinancialResponsibilityNo);

    public Task<bool> IsFinancialResponsibilityNoPresentAsync() =>
        _ui.ExistsAsync(_locators.FinancialResponsibilityNo);

    public Task<bool> IsInsuredWithANPriorLabelPresentAsync() =>
        _ui.ExistsAsync(_locators.InsuredWithANPriorLabel);

    public Task ClickInsuredWithANPriorNoChipAsync() =>
        _ui.ClickAsync(_locators.InsuredWithANPriorNoChip);

    public Task ClickSaveAndContinue9CB7AAsync() =>
        _ui.ClickAsync(_locators.SaveAndContinue8EF26);

    public Task<bool> IsSaveAndContinue9CB7APresentAsync() =>
        _ui.ExistsAsync(_locators.SaveAndContinue8EF26);

    public Task ClickSaveAndContinueBE6CDAsync() =>
        _ui.ClickAsync(_locators.SaveAndContinue8EF26);

    public Task ClickSaveContinue2E7CDAsync() =>
        _ui.ClickAsync(_locators.SaveContinue2E7CD);

    public Task ClickSaveContinue86B78Async() =>
        _ui.ClickAsync(_locators.SaveContinue86B78);

    public Task WaitForSelectVehicleAsync(string expected) =>
        _ui.WaitAsync(_locators.VehicleTypeHeading, expected);

    public Task<bool> IsSelectVehiclePresentAsync() =>
        _ui.ExistsAsync(_locators.SelectVehicle);

    public Task VerifySingleAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Divorced, expected, property);

    public Task ClickSingleAsync() =>
        _ui.ClickAsync(_locators.Divorced);

    public Task<bool> IsSinglePresentAsync() =>
        _ui.ExistsAsync(_locators.Divorced);

    public Task WaitForSomeCollegeAsync(string expected) =>
        _ui.WaitAsync(_locators.SomeCollege, expected);

    public Task ClickSomeCollegeAsync() =>
        _ui.ClickAsync(_locators.SomeCollege);

    public Task VerifySpouseAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AccountOwner, expected, property);

    public Task ClickSurrenderedAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task ClickTheftDeductibleV1Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickTheftDeductibleV2Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickTheftDeductibleV3Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickTheftDeductibleV4Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task EnterTotalAnnualMileageAsync(string value) =>
        _ui.FillAsync(_locators.TotalAnnualMileage, value);

    public Task<bool> IsTotalAnnualMileagePresentAsync() =>
        _ui.ExistsAsync(_locators.TotalAnnualMileage);

    public Task PressTotalAnnualMileageAsync(string key) =>
        _ui.PressAsync(_locators.TotalAnnualMileage, key);

    public Task EnterTotalAnnualMileageVeh4Async(string value) =>
        _ui.FillAsync(_locators.TotalAnnualMileageVeh4, value);

    public Task<bool> IsTotalAnnualMileageVeh4PresentAsync() =>
        _ui.ExistsAsync(_locators.TotalAnnualMileageVeh4);

    public Task ClickUIMPDCoverageV1Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUIMPDCoverageV2Async() =>
        _ui.ClickAsync(_locators.NoCoverageV2Towing);

    public Task ClickUIMPDCoverageV3Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUIMPDCoverageV4Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task PressUMPDCoverageVehicle1Async(string key) =>
        _ui.PressAsync(_locators.UMPDCoverageVehicle1, key);

    public Task ClickUMPDCoverageVehicle1Async() =>
        _ui.ClickAsync(_locators.UMPDCoverageVehicle1);

    public Task ClickUMPDCoverageVehicle2Async() =>
        _ui.ClickAsync(_locators.UMPDCoverageVehicle2);

    public Task ClickUMPDCoverageVehicle3Async() =>
        _ui.ClickAsync(_locators.UMPDCoverageVehicle3);

    public Task ClickUMPDCoverageVehicle4Async() =>
        _ui.ClickAsync(_locators.UMPDCoverageVehicle4);

    public Task SelectUMPDMoreOptionsCoveragesAsync(string value) =>
        _ui.SelectAsync(_locators.UMPDMoreOptionsCoverages, value);

    public async Task SelectUMPDVehicle1OneHundredThousandAsync()
    {
        await _ui.ClickAsync(_locators.UMPDVehicle1MoreOptions);
        await _ui.ClickAsync(_locators.UMPDOneHundredThousandOption);
    }

    public async Task SelectUMPDVehicle2OneHundredThousandAsync()
    {
        await _ui.ClickAsync(_locators.UMPDVehicle2MoreOptions);
        await _ui.ClickAsync(_locators.UMPDOneHundredThousandOption);
    }

    public Task ClickUMPDUIMPDV1Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUMPDUIMPDV2Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUMPDUIMPDV3Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUMPDUIMPDV4Async() =>
        _ui.ClickAsync(_locators.NoCoverageV1Towing);

    public Task ClickUnderConstructionAsync() =>
        _ui.ClickAsync(_locators.UnderConstruction);

    public Task ClickUnderageAsync() =>
        _ui.ClickAsync(_locators.AccountOwnerReadOnly);

    public Task SelectUnknownNoHighSchoolDiplomaOrGEDAsync(string value) =>
        _ui.SelectAsync(_locators.UnknownNoHighSchoolDiplomaOrGED, value);

    public Task SelectUseCAMoreOptionsAsync(string value) =>
        _ui.SelectAsync(_locators.UseCAMoreOptions, value);

    public Task WaitForVIN06D01Async(string expected) =>
        _ui.WaitAsync(_locators.VIN06D01, expected);

    public Task EnterVIN06D01Async(string value) =>
        _ui.FillAsync(_locators.VIN06D01, value);

    public Task PressVIN06D01Async(string key) =>
        _ui.PressAsync(_locators.VIN06D01, key);

    public Task ClickVIN06D01Async() =>
        _ui.ClickAsync(_locators.VIN06D01);

    public Task<bool> IsVIN06D01PresentAsync() =>
        _ui.ExistsAsync(_locators.VIN06D01);

    public Task WaitForVIN0A17CAsync(string expected) =>
        _ui.WaitAsync(_locators.Cycle1734D7, expected);

    public Task EnterVIN0A17CAsync(string value) =>
        _ui.FillAsync(_locators.Cycle1734D7, value);

    public Task PressVIN0A17CAsync(string key) =>
        _ui.PressAsync(_locators.Cycle1734D7, key);

    public Task WaitForVIN8EE56Async(string expected) =>
        _ui.WaitAsync(_locators.Cycle1734D7, expected);

    public Task EnterVIN8EE56Async(string value) =>
        _ui.FillAsync(_locators.Cycle1734D7, value);

    public Task PressVIN8EE56Async(string key) =>
        _ui.PressAsync(_locators.Cycle1734D7, key);

    public Task ClickVeh1Async() =>
        _ui.ClickAsync(_locators.Veh1);

    public Task ClickVeh3Async() =>
        _ui.ClickAsync(_locators.Veh3);

    public Task ClickVeh4Async() =>
        _ui.ClickAsync(_locators.Veh4);

    public Task ClickVehicle1Async() =>
        _ui.ClickAsync(_locators.Vehicle1);


    public Task ClickVehicleNB1Async() =>
        _ui.ClickAsync(_locators.VehicleNB1);

    public Task<bool> IsVehicle1PresentAsync() =>
        _ui.ExistsAsync(_locators.Vehicle1);


    public Task ClickVehicleInformationNextAsync() =>
        _ui.ClickAsync(_locators.PricingDetailsNext);

    public Task SelectVehicleMoreOptionsAsync(string value) =>
        _ui.SelectAsync(_locators.VehicleMoreOptions, value);

    public Task PressVehicleMoreOptionsAsync(string key) =>
        _ui.PressAsync(_locators.VehicleMoreOptions, key);

    public Task ClickVehicleMoreOptionsAsync() =>
        _ui.ClickAsync(_locators.VehicleMoreOptions);

    public Task ClickVehicleTypeMoreOptionsAsync() =>
        _ui.ClickAsync(_locators.VehicleTypeMoreOptions);

    public Task WaitForVehicleTypeAsync(string expected) =>
        _ui.WaitAsync(_locators.VehicleTypeHeading, expected);

    public Task ClickVintageAsync() =>
        _ui.ClickAsync(_locators.SelectVintage);

    public Task ClickMotorCycleAsync() =>
        _ui.ClickAsync(_locators.SelectMotorCycle);

    public Task ClickVocationalOrTradeSchoolDegreeAsync() =>
        _ui.ClickAsync(_locators.VocationalOrTradeSchoolDegree);

    public Task VerifyWasThisClientInsuredWithAmericanNationalImmediatelyPriorToTheCarrierListedAboveAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.AccountOwnerReadOnly, expected, property);

    public Task<bool> IsWasThisClientInsuredWithAmericanNationalImmediatelyPriorToTheCarrierListedAbovePresentAsync() =>
        _ui.ExistsAsync(_locators.AccountOwnerReadOnly);

    public Task EnterWorkMilesDayAsync(string value) =>
        _ui.FillAsync(_locators.WorkMilesDay, value);

    public Task PressWorkMilesDayAsync(string key) =>
        _ui.PressAsync(_locators.WorkMilesDay, key);

    public Task SelectYesAsync(string value) =>
        _ui.SelectAsync(_locators.Yes, value);

    public Task EnterYrsLicensedAllStatesAsync(string value) =>
        _ui.FillAsync(_locators.YrsLicensecAllStates, value);

    public Task PressYrsLicensedAllStatesAsync(string key) =>
        _ui.PressAsync(_locators.YrsLicensedAllStates, key);

    public Task EnterAllStatesTimeLicensedMonthsAsync(string value) =>
        _ui.FillAsync(_locators.AllStatesTimeLicensedMonths, value);

    public Task PressAllStatesTimeLicensedMonthsAsync(string key) =>
        _ui.PressAsync(_locators.AllStatesTimeLicensedMonths, key);

    public Task EnterYrsLicensedCurrentStateAsync(string value) =>
        _ui.FillAsync(_locators.YrsLicensedCurrentState, value);

    public Task PressYrsLicensedCurrentStateAsync(string key) =>
        _ui.PressAsync(_locators.YrsLicensedCurrentState, key);

    public Task<bool> IsGenderMalePresentAsync() =>
        _ui.ExistsAsync(_locators.Male);

    public Task<bool> IsSelectAdditionalVehicleAsync() =>
        _ui.ExistsAsync(_locators.AddAdditionalVehicle);


    public Task WaitForDriverSummaryHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.DriverInformationHeader, expected);

    public Task ClickGenderMaledriverAsync() =>
     _ui.ClickAsync(_locators.Male);

}
