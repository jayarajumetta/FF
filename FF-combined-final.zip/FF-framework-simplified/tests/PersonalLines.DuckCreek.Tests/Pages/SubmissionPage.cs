using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class SubmissionPage
{
    private readonly BrowserSession _browser;
    private readonly IPage _page;
    private readonly SubmissionLocators _locators;
    private readonly UiActions _ui;

    public SubmissionPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _page = browser.Page;
        _locators = new SubmissionLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickAutoCycleRVApplicationAsync() =>
        _ui.ClickAsync(_locators.AutoCycleRVApplication);

    public Task<bool> IsAutoCycleRVApplicationPresentAsync() =>
        _ui.ExistsAsync(_locators.AutoCycleRVApplication);

    public Task EnterButtonAsync(string value) =>
        _ui.FillAsync(_locators.Button, value);

    public Task EnterCaptionAsync(string value) =>
        _ui.FillAsync(_locators.Caption, value);

    public Task<bool> IsCaptionPresentAsync() =>
        _ui.ExistsAsync(_locators.Caption);

    public Task VerifyChecklist1Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.LaunchToChecklist, expected, property);

    public Task ClickChecklist1Async() =>
        _ui.ClickAsync(_locators.LaunchToChecklist);

    public Task<bool> IsChecklist1PresentAsync() =>
        _ui.ExistsAsync(_locators.LaunchToChecklist);

    public Task ClickChecklistCloseOkAsync() =>
        _ui.ClickAsync(_locators.ChecklistCloseOk);

    public Task VerifyCommentsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.Comments, expected, property);

    public Task EnterCommentsAsync(string value) =>
        _ui.FillAsync(_locators.Comments, value);

    public Task<bool> IsCommentsPresentAsync() =>
        _ui.ExistsAsync(_locators.Comments);

    public async Task<int> FillAllAgentCommentsAsync(string value)
    {
        var fields = _locators.AgentCommentFields;
        var count = await fields.CountAsync();
        for (var index = 0; index < count; index++)
        {
            var field = fields.Nth(index);
            await _ui.FillAsync(field, value);
            await Assertions.Expect(field).ToHaveValueAsync(value);
        }
        return count;
    }

    public Task VerifyCorrectionNeededStep1Async(string expected, string property) =>
        _ui.VerifyAsync(_locators.CorrectionNeededStep1, expected, property);

    public Task<bool> IsCorrectionNeededStep1PresentAsync() =>
        _ui.ExistsAsync(_locators.CorrectionNeededStep1);

    public Task<string> CaptureDIVAgentDocumentsCountAsync(string property = "") =>
        _ui.CaptureAsync(_locators.DIVAgentDocumentsCount, property);

    public Task ClickDIVDragAndDropFilesHereToUploadOrClickHereToOpenAFileExplorerAsync() =>
        _ui.ClickAsync(_locators.AutoCycleRVApplication);

    public Task<bool> IsDIVDragAndDropFilesHereToUploadOrClickHereToOpenAFileExplorerPresentAsync() =>
        _ui.ExistsAsync(_locators.AutoCycleRVApplication);

    public Task ClickDIVSubmissionAsync() =>
        _ui.ClickAsync(_locators.DIVSubmission);

    public Task<bool> IsDIVSubmissionPresentAsync() =>
        _ui.ExistsAsync(_locators.DIVSubmission);

    public Task VerifyEQCommonLoadingIndicatorWaitAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.EQCommonLoadingIndicatorWait, expected, property);

    public Task EnterFilePathAsync(string value) =>
        _ui.FillAsync(_locators.FilePath, value);

    public Task ClickNewQuoteSearchAsync() =>
        _ui.ClickAsync(_locators.NewQuoteSearch);

    public Task WaitForPolicyNumberAsync(string expected) =>
        _ui.WaitAsync(_locators.PolicyNumber, expected);

    public async Task WaitForGeneratedPolicyNumberAsync()
    {
        await _ui.WaitAsync(_locators.PolicyNumberValue, "Visible");
        await Assertions.Expect(_locators.PolicyNumberValue).ToHaveTextAsync(
            new System.Text.RegularExpressions.Regex(@"\S"),
            new() { Timeout = 30_000, UseInnerText = true });
    }

    public Task WaitForTransmitConfirmationAsync(string expected) =>
        _ui.WaitAsync(_locators.TransmitConfirmation, expected);

    public Task<string> CapturePolicyNumberAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PolicyNumber, property);

    public Task EnterQuotePolicySearchAsync(string value) =>
        _ui.FillAsync(_locators.QuotePolicySearch, value);

    public Task PressQuotePolicySearchAsync(string key) =>
        _ui.PressAsync(_locators.QuotePolicySearch, key);

    public Task<bool> IsQuotePolicySearchPresentAsync() =>
        _ui.ExistsAsync(_locators.QuotePolicySearch);

    public Task VerifyReferUWAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.ReferUW, expected, property);

    public Task ClickReferUWAsync() =>
        _ui.ClickAsync(_locators.ReferUW);

    public Task<bool> IsReferUWPresentAsync() =>
        _ui.ExistsAsync(_locators.ReferUW);

    public Task ClickSaveExit1Async() =>
        _ui.ClickAsync(_locators.SaveExit1);

    public Task<bool> IsSaveExit1PresentAsync() =>
        _ui.ExistsAsync(_locators.SaveExit1);

    public Task WaitForSubmission1Async(string expected) =>
        _ui.WaitAsync(_locators.Submission1, expected);

    public async Task WaitForSubmissionReadyAsync()
    {
        await _page.WaitForLoadStateAsync(LoadState.Load, new() { Timeout = 60_000 });
        await _locators.Submission1.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = 60_000 });
    }
    public Task WaitForTransmitAsync(string expected) =>
        _ui.WaitAsync(_locators.Transmit, expected);

    public Task WaitForTransmitAsync() =>
        _locators.Transmit.WaitForAsync(new LocatorWaitForOptions
        {
            State = WaitForSelectorState.Visible,
            Timeout = 30_000
        });

    public Task ClickTransmitAsync() =>
        _ui.ClickAsync(_locators.Transmit);

    public Task EnterTransmitConfirmationAsync(string value) =>
        _ui.FillAsync(_locators.TransmitConfirmation, value);

    public Task NavigateAsync(string url) =>
        _page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });

    public Task ClickChecklistOpenedOKAsync() =>
        _ui.ClickAsync(_locators.ChecklistOpenedOK);

    public Task ClickSubmissionLinkAsync() =>
        _ui.ClickAsync(_locators.Lnk_Submission);

}
