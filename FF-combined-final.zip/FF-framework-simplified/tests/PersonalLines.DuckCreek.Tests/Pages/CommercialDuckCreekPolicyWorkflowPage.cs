using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class CommercialDuckCreekPolicyWorkflowPage
{
    private readonly BrowserSession _browser;
    private readonly CommercialDuckCreekPolicyWorkflowLocators _locators;
    private readonly UiActions _ui;

    public CommercialDuckCreekPolicyWorkflowPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new CommercialDuckCreekPolicyWorkflowLocators(browser.Page);
        _ui = ui;
    }

    public Task WaitForUserNameInitialAsync(string expected) =>
        _ui.WaitAsync(_locators.UserNameInitial, expected);

    public Task ClickUserNameInitialAsync() =>
        _ui.ClickAsync(_locators.UserNameInitial);

    public Task WaitForLogoutAsync(string expected) =>
        _ui.WaitAsync(_locators.Logout, expected);

    public Task ClickLogoutAsync() =>
        _ui.ClickAsync(_locators.Logout);

    public Task WaitForLogoutOkButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.LogoutOkButton, expected);

    public async Task ClickLogoutOkButtonAsync()
    {
        try
        {
            await _locators.LogoutOkButton.ClickAsync(new LocatorClickOptions { Timeout = 5000 });
        }
        catch (PlaywrightException)
        {
            // The OK click can trigger a page navigation/reload that destroys the
            // current execution context mid-click; treat that as success since the
            // dialog has already been dismissed by the click action itself.
        }

        await _browser.Page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
    }

    public async Task<bool> LogoutOkButtonIsVisibleAsync() =>
        await _locators.LogoutOkButton.CountAsync() > 0 && await _locators.LogoutOkButton.IsVisibleAsync();

    public Task WaitForQuickSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.QuickSearchButton, expected);

    public Task ClickQuickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.QuickSearchButton);

    public Task WaitForSearchButtonAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchButton, expected);

    public Task ClickSearchButtonAsync() =>
        _ui.ClickAsync(_locators.SearchButton);

    public Task WaitForSearchResultsInsuredNameColumnHeaderAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchResultsInsuredNameColumnHeader, expected);

    public Task ClickSearchResultInsuredNameLinkAsync() =>
        _ui.ClickAsync(_locators.SearchResultInsuredNameLink);

    public Task WaitForCommercialAutoQuoteLinkAsync(string expected) =>
        _ui.WaitAsync(_locators.CommercialAutoQuoteLink, expected);

    public Task ClickCommercialAutoQuoteLinkAsync() =>
        _ui.ClickAsync(_locators.CommercialAutoQuoteLink);

    public Task WaitForSearchMethodEGDescriptionPolicyAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchMethodEGDescriptionPolicy, expected);

    public Task EnterSearchMethodEGDescriptionPolicySequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchMethodEGDescriptionPolicy, value, delayMs);

    public Task PressSearchMethodEGDescriptionPolicyAsync(string key) =>
        _ui.PressAsync(_locators.SearchMethodEGDescriptionPolicy, key);

    public Task WaitForSearchTextAsync(string expected) =>
        _ui.WaitAsync(_locators.SearchText, expected);

    public Task EnterSearchTextSequentiallyAsync(string value, int delayMs = 20) =>
        _ui.PressSequentiallyAsync(_locators.SearchText, value, delayMs);
}
