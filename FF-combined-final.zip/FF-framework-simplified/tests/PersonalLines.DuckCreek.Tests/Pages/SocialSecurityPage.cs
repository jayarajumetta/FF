using InsuranceAutomation.Core;
using Microsoft.Playwright;
using InsuranceAutomation.PLDC.Pages.Locators;

namespace InsuranceAutomation.PLDC.Pages;

public sealed class SocialSecurityPage
{
    private readonly BrowserSession _browser;
    private readonly SocialSecurityLocators _locators;
    private readonly UiActions _ui;

    public SocialSecurityPage(BrowserSession browser, UiActions ui)
    {
        _browser = browser;
        _locators = new SocialSecurityLocators(browser.Page);
        _ui = ui;
    }

    public Task ClickDriverInformationAsync() =>
        _ui.ClickAsync(_locators.DriverInformation);

    public Task ClickPrefillDriverSNavAsync() =>
        _ui.ClickAsync(_locators.PrefillDriverSNav);

    public Task<bool> IsReasonForNotIncludingThisIndividualPresentAsync() =>
        _ui.ExistsAsync(_locators.ReasonForNotIncludingThisIndividualLabel);

    public Task<bool> IsReasonForNotIncludingThisIndividualPresentAsync(int row) =>
        _ui.ExistsAsync(_locators.GetReasonForNotIncludingThisIndividual(row));

    public Task SelectReasonForNotIncludingThisIndividualAsync(int row, string value) =>
        _ui.SelectAsync(_locators.GetReasonForNotIncludingThisIndividual(row), value);

    public Task EnterMATFORMFIELDAsync(string value) =>
        _ui.FillAsync(_locators.MATFORMFIELD, value);


    public Task<bool> IsRaymondNotIncludingIndividualPropertyAsync() =>
        _ui.ExistsAsync(_locators.ReasonForNOnLivingResidencyRaymond);

    public Task EnterRaymondNotIncludingIndividualPropertyAsync(string value) =>
        _ui.FillAsync(_locators.ReasonForNOnLivingResidencyRaymond, value);

    public Task<bool> IsReasonForIndividualProperyAsync() =>
    _ui.ExistsAsync(_locators.ReasonForIndividualPropery);

    public Task EnterReasonForIndividualProperyAsync(string value) =>
    _ui.FillAsync(_locators.ReasonForIndividualPropery, value);




    public Task<bool> IsReasonForNotIncludingPropertyAsync() =>
    _ui.ExistsAsync(_locators.ReasonForNotIncludingProperty);


    public Task EnterReasonForNotIncludingPropertyAsync(string value) =>
  _ui.FillAsync(_locators.ReasonForNotIncludingProperty, value);





    public Task<bool> IsMATFORMFIELDPresentAsync() =>
        _ui.ExistsAsync(_locators.MATFORMFIELD);

    public Task<int> GetPrefillReasonDropdownCountAsync() =>
        _locators.PrefillReasonDropdowns.CountAsync();

    public async Task<int> SelectFirstReasonForAllPrefillDriversAsync()
    {
        var dropdowns = _locators.PrefillReasonDropdowns;
        var count = await dropdowns.CountAsync();
        for (var index = 0; index < count; index++)
        {
            var dropdown = dropdowns.Nth(index);

            await _ui.ClickAsync(dropdown);
            await _ui.ClickAsync(_locators.PrefillReasonFirstOption);
            await Assertions.Expect(dropdown).ToHaveAttributeAsync("aria-expanded", "false");
            await Assertions.Expect(dropdown).Not.ToHaveClassAsync(new System.Text.RegularExpressions.Regex(@"\bmat-mdc-select-empty\b"));
        }
        return count;
    }

    public Task PressNeverResidedInTheHouseholdAndDoesnTRegularlyUseOrHaveAccessToPolicyVehicleSAsync(string key) =>
        _ui.PressAsync(_locators.NeverResidedInTheHouseholdAndDoesnTRegularlyUseOrHaveAccessToPolicyVehicleS, key);

    public Task WaitForPrefilledDriversAsync(string expected) =>
        _ui.WaitAsync(_locators.PrefilledDrivers, expected);

    public Task<string> CapturePrefilledDriversAsync(string property = "") =>
        _ui.CaptureAsync(_locators.PrefilledDrivers, property);

    public Task<bool> IsPrefilledDriversPresentAsync() =>
        _ui.ExistsAsync(_locators.PrefilledDrivers);

    public Task<bool> IsPrefilledDriversRequiredAsync() =>
        _ui.ExistsAsync(_locators.PreFilledDriversRequired);

    public Task ClickSaveAndContinueAsync() =>
        _ui.ClickAsync(_locators.SaveAndContinue);

    public Task<bool> IsSaveAndContinuePresentAsync() =>
        _ui.ExistsAsync(_locators.SaveAndContinue);

    public Task EnterStateAsync(string value) =>
        _ui.FillAsync(_locators.State, value);

    public Task VerifyUnselectedClientSuggestionsAsync(string expected, string property) =>
        _ui.VerifyAsync(_locators.UnselectedClientSuggestions, expected, property);

    public Task<bool> IsUnselectedClientSuggestionsPresentAsync() =>
        _ui.ExistsAsync(_locators.UnselectedClientSuggestions);

    public Task<bool> IsUnderWriterRulesAsync() =>
        _ui.ExistsAsync(_locators.UnderWriterRulesHeader);

    public Task ClickCONTINUEF07C7Async() =>
        _locators.CONTINUED555D.EvaluateAsync("el => el.click()");

}
