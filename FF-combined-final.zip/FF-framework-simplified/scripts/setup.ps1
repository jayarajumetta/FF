param([ValidateSet('chrome','edge','msedge','chromium')][string]$Browser = 'edge')
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'build.ps1') -Configuration Release
& (Join-Path $PSScriptRoot 'install-browsers.ps1') -Browser $Browser -Configuration Release
Write-Host 'Setup complete. Set credentials and run scripts/run.ps1.'
