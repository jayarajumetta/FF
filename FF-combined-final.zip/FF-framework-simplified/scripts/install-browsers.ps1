param(
    [ValidateSet('chrome','edge','msedge','chromium')][string]$Browser = 'edge',
    [ValidateSet('Debug','Release')][string]$Configuration = 'Release'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$driver = Join-Path $root "bin/CommercialLines.ExpertQuote.Tests/$Configuration/net8.0/playwright.ps1"
if (-not (Test-Path -LiteralPath $driver)) { throw 'Build the solution before installing browsers.' }
$channel = if ($Browser -eq 'edge') { 'msedge' } else { $Browser }
& $driver install $channel
if ($LASTEXITCODE -ne 0) { throw "Browser installation failed for $channel." }
