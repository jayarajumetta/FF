param(
    [Parameter(Mandatory)][string]$StagingDirectory,
    [string]$SourceRoot = (Split-Path $PSScriptRoot -Parent),
    [ValidateSet('Debug','Release')][string]$BuildConfiguration = 'Release'
)
$ErrorActionPreference = 'Stop'
$SourceRoot = [IO.Path]::GetFullPath($SourceRoot)
$package = [IO.Path]::GetFullPath((Join-Path $StagingDirectory 'testpackage'))
if ($SourceRoot.StartsWith($package + [IO.Path]::DirectorySeparatorChar) -or
    $package -eq $SourceRoot -or $package.StartsWith((Join-Path $SourceRoot 'bin') + [IO.Path]::DirectorySeparatorChar)) {
    throw 'Use a staging directory separate from source and compiled outputs.'
}
# Never delete or merge into an old package. A fresh directory prevents stale test DLLs.
if (Test-Path -LiteralPath $package) { throw "Staging package already exists: $package" }
$projects = @('CommercialLines.DuckCreek.Tests','CommercialLines.ExpertQuote.Tests','PersonalLines.DuckCreek.Tests')
foreach ($project in $projects) {
    $base = Join-Path $SourceRoot "bin/$project/$BuildConfiguration/net8.0"
    foreach ($file in @("$project.dll","$project.deps.json","$project.runtimeconfig.json",'playwright.ps1','NUnit3.TestAdapter.dll')) {
        if (-not (Test-Path (Join-Path $base $file))) { throw "Build output missing: $base/$file" }
    }
}
New-Item -ItemType Directory -Path $package | Out-Null
foreach ($relative in @('config','scripts/install-browsers.ps1','scripts/Generate-ConsolidatedReport.ps1','scripts/TestOutput.ps1','tools/generate_consolidated_report.py','Framework.runsettings','README.md')) {
    $destination = Join-Path $package $relative
    New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
    Copy-Item -LiteralPath (Join-Path $SourceRoot $relative) -Destination $destination -Recurse
}
foreach ($project in $projects) {
    $destination = Join-Path $package "bin/$project/$BuildConfiguration"
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Copy-Item -LiteralPath (Join-Path $SourceRoot "bin/$project/$BuildConfiguration/net8.0") -Destination $destination -Recurse
    # Data lookup uses repository-relative project paths; copy all reviewed resources and nested bindings.
    Get-ChildItem (Join-Path $SourceRoot "tests/$project") -Recurse -File |
        Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' } |
        ForEach-Object {
            $relative = [IO.Path]::GetRelativePath($SourceRoot, $_.FullName)
            $target = Join-Path $package $relative
            New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
            Copy-Item -LiteralPath $_.FullName -Destination $target
        }
}
Write-Host "Compiled test package ready: $package"
