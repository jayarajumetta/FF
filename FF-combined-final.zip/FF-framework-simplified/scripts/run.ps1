param(
    [ValidateSet('ALL','CLDC','CLEQ','PLDC')][string]$Project = 'ALL',
    [string]$Filter = '',
    [ValidateSet('Debug','Release')][string]$Configuration = 'Release',
    [string]$ResultsDirectory = '',
    [ValidateSet('chrome','edge','msedge','chromium')][string]$Browser = '',
    [switch]$Headless,
    [switch]$NoBuild
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TestOutput.ps1')
$projects = [ordered]@{
    'CLDC' = '.\tests\CommercialLines.DuckCreek.Tests\CommercialLines.DuckCreek.Tests.csproj'
    'CLEQ' = '.\tests\CommercialLines.ExpertQuote.Tests\CommercialLines.ExpertQuote.Tests.csproj'
    'PLDC' = '.\tests\PersonalLines.DuckCreek.Tests\PersonalLines.DuckCreek.Tests.csproj'
}
Push-Location (Split-Path $PSScriptRoot -Parent)
$run = $null
$oldBrowser = $env:TEST_BROWSER
$oldHeadless = $env:TEST_HEADLESS
$oldResultsRoot = $env:TEST_RESULTS_ROOT
$oldRepositoryRoot = $env:TEST_REPOSITORY_ROOT
$oldConfigPath = $env:TEST_FRAMEWORK_CONFIG
$exitCode = 0
try {
    $repositoryRoot = (Get-Location).Path
    $output = Get-TestOutputConfiguration $repositoryRoot $ResultsDirectory
    $run = Initialize-TestResultsRoot $repositoryRoot $output.ResultsRoot
    $resultsFull = $run.Path
    $env:TEST_RESULTS_ROOT = $resultsFull
    $env:TEST_REPOSITORY_ROOT = $repositoryRoot
    $env:TEST_FRAMEWORK_CONFIG = $output.ConfigPath
    . (Join-Path $PSScriptRoot 'Resolve-ParallelWorkers.ps1')
    $workers = Resolve-ParallelWorkerCount -FrameworkConfigPath $output.ConfigPath
    if ($Browser) { $env:TEST_BROWSER = $Browser }
    if ($Headless) { $env:TEST_HEADLESS = 'true' }
    $nunitXmlDirectory = Join-Path $resultsFull 'NUnit'
    New-Item -ItemType Directory -Force -Path $nunitXmlDirectory | Out-Null
    Write-Host "Results and evidence: $resultsFull"

    $targets = if ($Project -eq 'ALL') { $projects.GetEnumerator() } else { @([pscustomobject]@{ Key = $Project; Value = $projects[$Project] }) }
    foreach ($target in $targets) {
        $resultFile = "$($target.Key).trx"
        $args = @(
            'test', $target.Value,
            '-c', $Configuration,
            '--settings', (Join-Path $repositoryRoot 'Framework.runsettings'),
            '--results-directory', $resultsFull,
            '--logger', "trx;LogFileName=$resultFile",
            '--logger', 'console;verbosity=normal'
        )
        if ($NoBuild) { $args += @('--no-build','--no-restore') }
        if (-not [string]::IsNullOrWhiteSpace($Filter)) { $args += @('--filter', $Filter) }
        elseif ($target.Key -eq 'CLEQ') { $args += @('--filter', 'TestCategory!=CSUnit&TestCategory!=Tools') }
        $workDirectory = Join-Path $resultsFull "NUnitWork/$($target.Key)"
        New-Item -ItemType Directory -Force -Path $workDirectory | Out-Null
        $args += @('--', "NUnit.TestOutputXml=$nunitXmlDirectory", "NUnit.WorkDirectory=$workDirectory", "NUnit.NumberOfTestWorkers=$workers")

        & dotnet @args
        if ($LASTEXITCODE -ne 0) { $exitCode = $LASTEXITCODE }
    }
    $run.Lock.Dispose()
    try {
      if (Get-ChildItem -LiteralPath $resultsFull -Recurse -Filter scenario-result.json | Select-Object -First 1) {
        & (Join-Path $PSScriptRoot 'Generate-ConsolidatedReport.ps1') -ResultsDirectory $resultsFull
      }
    } catch {
        Write-Warning "Consolidated report generation failed: $_"
        if ($exitCode -eq 0) { $exitCode = 1 }
    }
}
finally {
    if ($null -ne $run) { $run.Lock.Dispose() }
    $env:TEST_BROWSER = $oldBrowser
    $env:TEST_HEADLESS = $oldHeadless
    $env:TEST_RESULTS_ROOT = $oldResultsRoot
    $env:TEST_REPOSITORY_ROOT = $oldRepositoryRoot
    $env:TEST_FRAMEWORK_CONFIG = $oldConfigPath
    Pop-Location
}
exit $exitCode
