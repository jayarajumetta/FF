param([ValidateSet('Debug','Release')][string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
Push-Location (Split-Path $PSScriptRoot -Parent)
try {
    & dotnet restore InsuranceAutomation.sln
    if ($LASTEXITCODE -ne 0) { throw 'Restore failed.' }
    & dotnet build InsuranceAutomation.sln -c $Configuration --no-restore
    if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
} finally { Pop-Location }
