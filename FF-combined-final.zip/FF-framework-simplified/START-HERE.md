Open [README.md](README.md) for setup, Chrome/Edge commands, test structure and validation.

Open [docs/FRAMEWORK-REVIEW.md](docs/FRAMEWORK-REVIEW.md) for the review decisions and known source limitations.
