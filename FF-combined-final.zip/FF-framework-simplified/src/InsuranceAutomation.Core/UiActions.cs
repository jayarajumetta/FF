using Microsoft.Playwright;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using static Microsoft.Playwright.Assertions;

namespace InsuranceAutomation.Core;

/// <summary>Thin, reported actions on the exact locator supplied by a page object.</summary>
public sealed class UiActions
{
    private readonly RunLogger _logger;
    private readonly BrowserSession _browser;
    private readonly FrameworkConfig _config;
    private readonly ScenarioReport? _report;
    private readonly DeferredVerificationCollector? _verificationFailures;

    public UiActions(BrowserSession browser, FrameworkConfig config, RunLogger logger)
        : this(browser, config, logger, null, "Unknown") { }

    public UiActions(BrowserSession browser, FrameworkConfig config, RunLogger logger,
        ScenarioReport? report, string applicationName, DeferredVerificationCollector? verificationFailures = null)
    {
        _browser = browser;
        _config = config;
        _logger = logger;
        _report = report;
        _verificationFailures = verificationFailures;
    }

    public Task ClickAsync(ILocator locator, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(ClickAsync), null,
            () => locator.ClickAsync(new() { Timeout = _config.Browser.ActionTimeoutMs }));

    // Existing page objects use Fill for both text fields and select components.
    public Task FillAsync(ILocator locator, string value, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(FillAsync), value,
            () => ComponentAwareControlActions.SelectOrFillAsync(_browser.Page, locator, value,
                _config.Browser.ActionTimeoutMs, _config.Waits.DropdownOptionTimeoutMs));

    public Task PressSequentiallyAsync(ILocator locator, string value, int delayMs = 20,
        [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(PressSequentiallyAsync), value,
            () => ComponentAwareControlActions.DomPressSequentiallyAsync(locator, value, delayMs, _config.Browser.ActionTimeoutMs));

    public Task PressAsync(ILocator locator, string key, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(PressAsync), null, async () =>
        {
            var normalized = NormalizeKey(key);
            if (normalized.Equals("CLICK", StringComparison.OrdinalIgnoreCase))
                await locator.ClickAsync(new() { Timeout = _config.Browser.ActionTimeoutMs });
            else if (normalized.Equals("DOUBLECLICK", StringComparison.OrdinalIgnoreCase))
                await locator.DblClickAsync(new() { Timeout = _config.Browser.ActionTimeoutMs });
            else
                await locator.PressAsync(normalized, new() { Timeout = _config.Browser.ActionTimeoutMs });
        });

    public Task SmartSetAsync(ILocator locator, string value, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(SmartSetAsync), value, () => SetCoreAsync(locator, value));

    public Task SelectAsync(ILocator locator, string value, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(SelectAsync), value, () => SetCoreAsync(locator, value));

    public Task ActivateTabAsync(ILocator container, string tabName, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(container, caller, source, nameof(ActivateTabAsync), tabName,
            () => container.GetByRole(AriaRole.Tab, new() { Name = tabName, Exact = true }).ClickAsync());

    public Task ClickDialogActionAsync(ILocator dialog, string actionName, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(dialog, caller, source, nameof(ClickDialogActionAsync), actionName,
            () => dialog.GetByRole(AriaRole.Button, new() { Name = actionName, Exact = true }).ClickAsync());

    public Task ToggleExpansionPanelAsync(ILocator panel, bool expanded, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(panel, caller, source, nameof(ToggleExpansionPanelAsync), expanded.ToString(), async () =>
        {
            var tag = await panel.EvaluateAsync<string>("e => e.tagName.toLowerCase()");
            var header = tag == "mat-expansion-panel-header" ? panel : panel.Locator("mat-expansion-panel-header, [role=button]");
            var state = await header.GetAttributeAsync("aria-expanded");
            if (state is not "true" and not "false") throw new InvalidOperationException("Expansion control must expose aria-expanded.");
            if ((state == "true") != expanded) await header.ClickAsync();
            await Expect(header).ToHaveAttributeAsync("aria-expanded", expanded ? "true" : "false", new() { Timeout = _config.Waits.VerifyTimeoutMs });
        });

    public Task ClickGridCellAsync(ILocator grid, string cellText, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(grid, caller, source, nameof(ClickGridCellAsync), cellText,
            () => grid.Locator("td,[role=gridcell]").Filter(new() { HasTextRegex = ExactText(cellText) }).ClickAsync());

    /// <summary>Bounded optional visibility check. Invalid selectors and closed pages still fail.</summary>
    public Task<bool> ExistsAsync(ILocator locator, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(ExistsAsync), null, async () =>
        {
            try
            {
                await locator.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = _config.Waits.ElementReadyTimeoutMs });
                return true;
            }
            catch (TimeoutException) { return false; }
        });

    public Task WaitAsync(ILocator locator, string expected, [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(WaitAsync), expected, () => WaitCoreAsync(locator, expected));

    // Only callers explicitly requesting a best-effort readiness hint may continue after a timeout.
    public Task WaitReadyBestEffortAsync(ILocator locator, int timeoutMs,
        [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(WaitReadyBestEffortAsync), null, async () =>
        {
            try { await locator.WaitForAsync(new() { State = WaitForSelectorState.Visible, Timeout = timeoutMs }); }
            catch (TimeoutException ex) { _logger.Warn($"Optional readiness wait: {caller}: {ex.Message}"); }
        });

    public Task VerifyAsync(ILocator locator, string expected, string property,
        [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(VerifyAsync), expected, async () =>
        {
            try { await VerifyCoreAsync(locator, expected, property); }
            catch (Exception ex) when (_config.Execution.DeferVerificationFailures && _verificationFailures is not null &&
                ex is PlaywrightException or TimeoutException && !IsClosed(ex))
            {
                string? screenshot = null;
                if (_browser.IsStarted && _config.Browser.ScreenshotOnFailure)
                {
                    try { screenshot = await _browser.CaptureScreenshotAsync($"verification_{Guid.NewGuid():N}.png"); }
                    catch (Exception captureError) { _logger.Warn($"Verification screenshot unavailable: {captureError.Message}"); }
                }
                var failure = new DeferredVerificationFailure(DateTimeOffset.Now, _report?.CurrentStep ?? "",
                    Path.GetFileNameWithoutExtension(source), caller, property, expected, ex.Message, screenshot);
                _verificationFailures.Add(failure);
                _report?.RecordDeferredVerification(failure);
                _logger.Error($"DEFERRED VERIFICATION: {caller}: {ex.Message}");
            }
        });

    public Task<string> CaptureAsync(ILocator locator, string property,
        [CallerMemberName] string caller = "", [CallerFilePath] string source = "") =>
        TraceAsync(locator, caller, source, nameof(CaptureAsync), null, async () =>
        {
            if (await UsesInputValueAsync(locator, property)) return await locator.InputValueAsync();
            return (await locator.InnerTextAsync()).Trim();
        });

    public Task ReviewRequiredAsync(string reason, [CallerMemberName] string caller = "", [CallerFilePath] string source = "")
    {
        if (_report is null) { _logger.Warn($"REVIEW NOTE: {reason}"); return Task.CompletedTask; }
        return _report.TraceActionAsync($"{Path.GetFileNameWithoutExtension(source)}.{caller}", nameof(ReviewRequiredAsync), "",
            new Dictionary<string, string> { ["reason"] = reason }, () => Task.FromResult(true));
    }

    private async Task SetCoreAsync(ILocator locator, string value)
    {
        var tag = await locator.EvaluateAsync<string>("e => e.tagName.toLowerCase()");
        var role = await locator.GetAttributeAsync("role") ?? "";
        if (role is "radiogroup" or "listbox" || tag is "mat-radio-group" or "mat-chip-list" or "mat-chip-listbox")
        {
            await locator.Locator("[role=radio],[role=option],mat-radio-button,mat-chip-option,mat-chip")
                .Filter(new() { HasTextRegex = ExactText(value) }).ClickAsync();
        }
        else if (tag is "mat-checkbox" or "mat-slide-toggle" || role is "checkbox" or "switch")
            await ComponentAwareControlActions.SetBooleanAsync(locator, ComponentAwareControlActions.ParseBoolean(value));
        else if (tag is "button" or "a" or "mat-chip" or "mat-chip-option" || role is "button" or "radio" or "option" or "tab")
            await locator.ClickAsync();
        else
            await ComponentAwareControlActions.SelectOrFillAsync(_browser.Page, locator, value,
                _config.Browser.ActionTimeoutMs, _config.Waits.DropdownOptionTimeoutMs);
    }

    private Task WaitCoreAsync(ILocator locator, string expected)
    {
        if (expected.Equals("Enabled", StringComparison.OrdinalIgnoreCase))
            return Expect(locator).ToBeEnabledAsync(new() { Timeout = _config.Waits.VerifyTimeoutMs });
        if (expected.Equals("Disabled", StringComparison.OrdinalIgnoreCase))
            return Expect(locator).ToBeDisabledAsync(new() { Timeout = _config.Waits.VerifyTimeoutMs });
        var state = expected.Contains("Absent", StringComparison.OrdinalIgnoreCase) ? WaitForSelectorState.Detached :
            expected.Contains("Hidden", StringComparison.OrdinalIgnoreCase) ? WaitForSelectorState.Hidden : WaitForSelectorState.Visible;
        return locator.WaitForAsync(new() { State = state, Timeout = _config.Waits.VerifyTimeoutMs });
    }

    private async Task VerifyCoreAsync(ILocator locator, string expected, string property)
    {
        var text = (expected ?? "").Trim();
        if (text.Equals("Visible", StringComparison.OrdinalIgnoreCase) || text.Equals("Exists", StringComparison.OrdinalIgnoreCase) || text.Equals("True", StringComparison.OrdinalIgnoreCase))
        { await Expect(locator).ToBeVisibleAsync(new() { Timeout = _config.Waits.VerifyTimeoutMs }); return; }
        if (text.Equals("Hidden", StringComparison.OrdinalIgnoreCase))
        { await Expect(locator).ToBeHiddenAsync(new() { Timeout = _config.Waits.VerifyTimeoutMs }); return; }
        if (text.Equals("Absent", StringComparison.OrdinalIgnoreCase))
        { await Expect(locator).ToHaveCountAsync(0, new() { Timeout = _config.Waits.VerifyTimeoutMs }); return; }
        if (text.Equals("Enabled", StringComparison.OrdinalIgnoreCase) || text.Equals("Disabled", StringComparison.OrdinalIgnoreCase))
        { await WaitCoreAsync(locator, text); return; }

        var spec = (property ?? "").Trim();
        var mode = new[] { "Regex:", "NotEqual:", "Contains:" }.FirstOrDefault(prefix =>
            spec.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
        if (mode is not null)
        {
            if (spec.StartsWith(mode, StringComparison.OrdinalIgnoreCase)) spec = spec[mode.Length..].Trim();
            if (text.StartsWith(mode, StringComparison.OrdinalIgnoreCase)) text = text[mode.Length..];
        }
        var pattern = mode == "Regex:" ? new Regex(text, RegexOptions.None, TimeSpan.FromSeconds(2)) :
            mode == "Contains:" ? new Regex(Regex.Escape(text), RegexOptions.IgnoreCase) : ExactText(text);
        var assertion = mode == "NotEqual:" ? Expect(locator).Not : Expect(locator);
        if (await UsesInputValueAsync(locator, spec))
            await assertion.ToHaveValueAsync(pattern, new() { Timeout = _config.Waits.VerifyTimeoutMs });
        else
            await assertion.ToHaveTextAsync(pattern, new() { Timeout = _config.Waits.VerifyTimeoutMs, UseInnerText = true });
    }

    private static async Task<bool> UsesInputValueAsync(ILocator locator, string property) =>
        property.Contains("Value", StringComparison.OrdinalIgnoreCase) &&
        await locator.EvaluateAsync<bool>("e => ['INPUT','TEXTAREA','SELECT'].includes(e.tagName)");

    private Task<T> TraceAsync<T>(ILocator locator, string caller, string source, string operation, string? value, Func<Task<T>> action)
    {
        var target = locator.ToString() ?? "";
        // Never include passwords or other field contents in action telemetry. ScenarioData supplies a masked snapshot.
        var data = new Dictionary<string, string>();
        return _report is null ? action() : _report.TraceActionAsync($"{Path.GetFileNameWithoutExtension(source)}.{caller}", operation, target, data, action);
    }

    private async Task TraceAsync(ILocator locator, string caller, string source, string operation, string? value, Func<Task> action) =>
        await TraceAsync(locator, caller, source, operation, value, async () => { await action(); return true; });

    private static Regex ExactText(string text) => new(@"^\s*" + Regex.Escape(text) + @"\s*$", RegexOptions.IgnoreCase);
    private static bool IsClosed(Exception ex) => new[] { "target closed", "has been closed", "context closed", "page closed" }
        .Any(x => ex.Message.Contains(x, StringComparison.OrdinalIgnoreCase));
    private static string NormalizeKey(string key) => key.Trim()
        .Replace("POST:", "", StringComparison.OrdinalIgnoreCase).Replace("PRE:", "", StringComparison.OrdinalIgnoreCase)
        .Replace("{TAB}", "Tab", StringComparison.OrdinalIgnoreCase).Replace("{ENTER}", "Enter", StringComparison.OrdinalIgnoreCase)
        .Replace("{ESC}", "Escape", StringComparison.OrdinalIgnoreCase);
}
