using System.Text.Json;

namespace InsuranceAutomation.Core;

public sealed class FrameworkConfig
{
    private const long MaxConfigBytes = 1 * 1024 * 1024;

    public BrowserOptions Browser { get; init; } = new();
    public ReportingOptions Reporting { get; init; } = new();
    public WaitOptions Waits { get; init; } = new();
    public ExecutionOptions Execution { get; init; } = new();

    public static FrameworkConfig Load()
    {
        var repositoryRoot = SafeFileAccess.FindRepositoryRoot();
        var configRelativePath = Path.Combine("config", "framework.json");
        var safePath = SafeFileAccess.ResolveExistingFileUnderRoot(configRelativePath, MaxConfigBytes, ".json");
        var expectedPath = Path.GetFullPath(Path.Combine(repositoryRoot, configRelativePath));
        if (!safePath.Equals(expectedPath, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Resolved framework configuration path is invalid.");

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        using var configStream = File.Open(safePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        var config = JsonSerializer.Deserialize<FrameworkConfig>(configStream, options)
                     ?? throw new InvalidOperationException($"Unable to parse framework configuration: {safePath}");
        var browser = Environment.GetEnvironmentVariable("TEST_BROWSER");
        if (!string.IsNullOrWhiteSpace(browser)) config.Browser.Channel = browser;
        var headless = Environment.GetEnvironmentVariable("TEST_HEADLESS");
        if (!string.IsNullOrWhiteSpace(headless))
        {
            if (!bool.TryParse(headless, out var enabled)) throw new InvalidOperationException("TEST_HEADLESS must be true or false.");
            config.Browser.Headless = enabled;
        }
        config.Validate(safePath);
        config.Reporting.ResultsRoot = TestOutputPaths.ResolveResultsRoot(repositoryRoot, config.Reporting.ResultsRoot);
        config.Reporting.ArtifactRoot = TestOutputPaths.ResolveArtifactRoot(config.Reporting.ResultsRoot, config.Reporting.ArtifactRoot);
        return config;
    }

    public void Validate(string path)
    {
        if (Execution.RetryCount < 0 || Execution.RetryCount == int.MaxValue)
            throw new InvalidOperationException($"execution.retryCount must be between 0 and {int.MaxValue - 1}. Config: {path}");
        if (Browser.ActionTimeoutMs <= 0 || Browser.NavigationTimeoutMs <= 0)
            throw new InvalidOperationException($"Browser timeouts must be positive. Config: {path}");
        if (Waits.ElementReadyTimeoutMs <= 0 || Waits.VerifyTimeoutMs <= 0 || Waits.DropdownOptionTimeoutMs <= 0)
            throw new InvalidOperationException($"Wait timeouts must be positive. Config: {path}");
        Browser.Channel = BrowserOptions.NormalizeChannel(Browser.Channel);
        if (Browser.ViewportWidth <= 0 || Browser.ViewportHeight <= 0)
            throw new InvalidOperationException($"Viewport dimensions must be positive. Config: {path}");
        if (!Reporting.AttachmentMode.Equals("all", StringComparison.OrdinalIgnoreCase) &&
            !Reporting.AttachmentMode.Equals("key", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"reporting.attachmentMode must be 'all' or 'key'. Config: {path}");
        if (Reporting.MaxSingleAttachmentBytes <= 0 || Reporting.MaxAttachmentCount <= 0)
            throw new InvalidOperationException($"Reporting attachment limits must be positive. Config: {path}");



    }
}

public sealed class BrowserOptions
{
    public string Channel { get; set; } = "msedge";
    public static string NormalizeChannel(string channel) => channel.Trim().ToLowerInvariant() switch
    {
        "chrome" => "chrome",
        "edge" or "msedge" => "msedge",
        "chromium" => "chromium",
        _ => throw new InvalidOperationException("Browser must be chrome, edge, msedge, or chromium.")
    };
    public bool Headless { get; set; }
    public bool IgnoreHttpsErrors { get; init; } = true;
    public bool Maximize { get; init; } = true;
    public int ViewportWidth { get; init; } = 1440;
    public int ViewportHeight { get; init; } = 900;
    public int ActionTimeoutMs { get; init; } = 15000;
    public int NavigationTimeoutMs { get; init; } = 30000;
    public bool Trace { get; init; }
    public bool Video { get; init; }
    public bool Har { get; init; }
    public bool ScreenshotOnFailure { get; init; } = true;
    public bool ScreenshotEachStep { get; init; }
    public bool ScreenshotAtScenarioEnd { get; init; }
}


public sealed class WaitOptions
{
    public int ElementReadyTimeoutMs { get; init; } = 20000;
    public int VerifyTimeoutMs { get; init; } = 20000;
    public int DropdownOptionTimeoutMs { get; init; } = 3000;
}

public sealed class ReportingOptions
{
    public bool ExcludeVideos { get; init; } = true;
    public bool ExcludePassedVideos { get; init; } = true;
    public bool ShouldExcludeVideo(bool passed) => ExcludeVideos || (ExcludePassedVideos && passed);
    public bool CollectConsole { get; init; }
    public bool CollectNetwork { get; init; }
    public EvidenceAttachmentPolicy Passed { get; init; } = EvidenceAttachmentPolicy.PassedDefaults();
    public EvidenceAttachmentPolicy Failed { get; init; } = EvidenceAttachmentPolicy.FailedDefaults();
    public string ResultsRoot { get; set; } = "TestResults";
    public string ArtifactRoot { get; set; } = "Artifacts";
    public bool HtmlReport { get; init; } = true;
    public bool IncludeResolvedData { get; init; } = true;
    public bool IncludeConsoleErrors { get; init; }
    public bool IncludeNetworkErrors { get; init; }
    public bool CreateEvidenceBundle { get; init; } = true;

    // NUnit/Visual Studio/Azure DevOps test-result evidence integration.
    // "all" attaches every scenario-owned file; "key" attaches the report/log,
    // screenshots, trace, HAR, videos, evidence manifest and bundle only.
    public bool AttachEvidenceToTestResult { get; init; } = true;
    public bool AttachPassedEvidenceToTestResult { get; init; } = true;
    public string AttachmentMode { get; init; } = "all";
    public long MaxSingleAttachmentBytes { get; init; } = 536870912; // 512 MiB guardrail
    public int MaxAttachmentCount { get; init; } = 5000;
}

public sealed class EvidenceAttachmentPolicy
{
    public bool Screenshot { get; init; } = true;
    public bool ExecutionLog { get; init; } = true;
    public bool HtmlReport { get; init; } = true;
    public bool Video { get; init; }
    public bool Trace { get; init; }
    public bool Har { get; init; }
    public bool Console { get; init; }
    public bool Network { get; init; }
    public bool Bundle { get; init; } = false;
    public static EvidenceAttachmentPolicy PassedDefaults() => new();
    public static EvidenceAttachmentPolicy FailedDefaults() => new();
}

public sealed class ExecutionOptions
{
    public int RetryCount { get; init; } = 0;
    public bool StrictUnknownConditions { get; init; } = true;
    // Verification failures can be accumulated after Playwright assertions and fail at scenario end,
    // allowing later steps and all requested evidence to complete. Fatal browser/action failures still fail immediately.
    public bool DeferVerificationFailures { get; init; } = true;

    // scripts/run.ps1 maps this to NUnit.NumberOfTestWorkers (3 or 1).
    public bool Parallel { get; init; } = true;
}
