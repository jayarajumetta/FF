using System.IO.Compression;
using System.Linq;
using Microsoft.Playwright;
namespace InsuranceAutomation.Core;
public sealed class BrowserSession : IAsyncDisposable
{
    private readonly FrameworkConfig _config;
    private readonly object _evidenceGate = new();
    private readonly SemaphoreSlim _screenshotGate = new(1, 1);
    private readonly List<string> _stepConsoleErrors = [];
    private readonly List<string> _stepNetworkErrors = [];
    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IBrowserContext? _context;
    private IPage? _page;
    private string _artifactDirectory = string.Empty;
    private string _consoleLogPath = string.Empty;
    private string _networkLogPath = string.Empty;
    public BrowserSession(FrameworkConfig config) => _config = config;
    public bool IsStarted => _page is not null;
    public IPage Page => _page ?? throw new InvalidOperationException("Browser is not open. Ensure the Feature Background contains: Given I open a browser session.");
    public string ArtifactDirectory => _artifactDirectory;
    public string? TracePath { get; private set; }
    public string? VideoPath { get; private set; }
    public string? HarPath { get; private set; }
    public string? EvidenceBundlePath { get; private set; }
    public string? ScreenshotPath { get; private set; }
    // Tracks whether a failure screenshot was already captured mid-scenario (e.g. AfterStep),
    // so the scenario-end finalizer does not capture a second, duplicate failure screenshot.
    public bool FailureScreenshotCaptured { get; set; }
    public void SetArtifactDirectory(string artifactDirectory)
    {
        _artifactDirectory = artifactDirectory;
        Directory.CreateDirectory(_artifactDirectory);
        _consoleLogPath = Path.Combine(_artifactDirectory, "console.log");
        _networkLogPath = Path.Combine(_artifactDirectory, "network.log");
    }
    public async Task OpenAsync(RunLogger logger)
    {
        if (IsStarted) return;
        FailureScreenshotCaptured = false;
        ScreenshotPath = TracePath = VideoPath = HarPath = EvidenceBundlePath = null;
        _playwright = await Playwright.CreateAsync();
        try { _browser = await LaunchAsync(logger); }
        catch { _playwright.Dispose(); _playwright = null; throw; }
        var videoDirectory = Path.Combine(_artifactDirectory, "video");
        var recordVideo = _config.Browser.Video && !_config.Reporting.ExcludeVideos;
        if (recordVideo) Directory.CreateDirectory(videoDirectory);
        HarPath = _config.Browser.Har ? Path.Combine(_artifactDirectory, "network.har.zip") : null;
        _context = await _browser.NewContextAsync(new BrowserNewContextOptions
        {
            IgnoreHTTPSErrors = _config.Browser.IgnoreHttpsErrors,
            ViewportSize = _config.Browser.Maximize && !_config.Browser.Headless ? ViewportSize.NoViewport : new ViewportSize { Width = _config.Browser.ViewportWidth, Height = _config.Browser.ViewportHeight },
            RecordVideoDir = recordVideo ? videoDirectory : null,
            RecordHarPath = HarPath,
            RecordHarMode = _config.Browser.Har ? HarMode.Full : null,
            RecordHarContent = _config.Browser.Har ? HarContentPolicy.Attach : null
        });
        _context.SetDefaultTimeout(_config.Browser.ActionTimeoutMs);
        _context.SetDefaultNavigationTimeout(_config.Browser.NavigationTimeoutMs);
        if (_config.Browser.Trace)
        {
            await _context.Tracing.StartAsync(new TracingStartOptions { Screenshots = true, Snapshots = true, Sources = true });
        }
        _page = await _context.NewPageAsync();
        if (_config.Reporting.CollectConsole || _config.Reporting.CollectNetwork)
        {
            WireEvidence(logger, _page);
            _context.Page += (_, page) => WireEvidence(logger, page);
        }
        logger.Info($"Browser session opened. Channel={_config.Browser.Channel}; Headless={_config.Browser.Headless}; HAR={_config.Browser.Har}; Console={_config.Reporting.CollectConsole}; Network={_config.Reporting.CollectNetwork}");
    }
    public void BeginStepEvidence()
    {
        lock (_evidenceGate)
        {
            _stepConsoleErrors.Clear();
            _stepNetworkErrors.Clear();
        }
    }
    public StepEvidence EndStepEvidence()
    {
        lock (_evidenceGate)
        {
            return new StepEvidence(_stepConsoleErrors.ToArray(), _stepNetworkErrors.ToArray());
        }
    }
    public async Task<string?> CaptureScreenshotAsync(string fileName)
    {
        if (_page is null) return null;
        var path = Path.Combine(_artifactDirectory, "screenshots", Safe(fileName));
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await _screenshotGate.WaitAsync();
        try
        {
            await _page.ScreenshotAsync(new PageScreenshotOptions { Path = path, FullPage = true });
            ScreenshotPath = path;
            return path;
        }
        finally { _screenshotGate.Release(); }
    }
    /// <summary>
    /// Switches the active page to a newly opened tab/window (e.g. a checklist launched via
    /// window.open/target=_blank) and waits for it to finish loading. If no new page opens within
    /// the timeout, the current page remains active.
    /// </summary>
    public async Task<IPage> SwitchToNewPageAsync(Func<Task> triggerAction, int timeoutMs = 15000)
    {
        if (_context is null) throw new InvalidOperationException("Browser is not open. Ensure the Feature Background contains: Given I open a browser session.");
        var newPage = await _context.RunAndWaitForPageAsync(triggerAction,
            new BrowserContextRunAndWaitForPageOptions { Timeout = timeoutMs });
        await newPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded, new PageWaitForLoadStateOptions { Timeout = timeoutMs });
        _page = newPage;
        await _page.BringToFrontAsync();
        return _page;
    }
    /// <summary>
    /// Switches the active page back to the first (original) window/tab opened in this browser
    /// context, e.g. returning from a checklist popup to the primary ExpertQuote window.
    /// </summary>
    public Task<IPage> SwitchToFirstPageAsync() => SwitchToPageAtAsync(0);
    /// <summary>
    /// Switches the active page to the browser context page at the given index (0-based, in the
    /// order the pages were opened). Closed pages are skipped so a popup that closed itself
    /// (e.g. the checklist window) does not shift the index of the still-open original window.
    /// </summary>
    public async Task<IPage> SwitchToPageAtAsync(int index)
    {
        if (_context is null) throw new InvalidOperationException("Browser is not open. Ensure the Feature Background contains: Given I open a browser session.");
        var openPages = _context.Pages.Where(p => !p.IsClosed).ToList();
        if (index < 0 || index >= openPages.Count)
            throw new InvalidOperationException($"Cannot switch to page index {index}; browser context currently has {openPages.Count} open page(s).");
        _page = openPages[index];
        // BringToFrontAsync makes the browser visually activate/focus this tab/window, not just
        // retarget subsequent Playwright actions to it, so the user actually sees the switch happen.
        await _page.BringToFrontAsync();
        return _page;
    }
    public async Task CloseAsync(RunLogger logger)
    {
        if (_context is null && _browser is null && _playwright is null) return;
        IVideo? video = null;
        try { video = _page?.Video; } catch { }
        if (_context is not null && _config.Browser.Trace)
        {
            TracePath = Path.Combine(_artifactDirectory, "trace.zip");
            try { await _context.Tracing.StopAsync(new TracingStopOptions { Path = TracePath }); }
            catch (Exception ex) { logger.Warn($"Unable to stop trace: {ex.Message}"); }
        }
        // Video is finalized when the browser context closes. Resolve Video.PathAsync only after close;
        // resolving it before close can leave Visual Studio with no completed video attachment.
        try { if (_context is not null) await _context.CloseAsync(); }
        catch (Exception ex) { logger.Warn($"Unable to close browser context cleanly: {ex.Message}"); }
        try
        {
            if (video is not null)
            {
                var resolvedVideoPath = await video.PathAsync();
                VideoPath = PersistFinalizedVideo(resolvedVideoPath, logger);
                logger.Info($"Playwright video finalized: {VideoPath}");
            }
        }
        catch (Exception ex) { logger.Warn($"Unable to resolve finalized Playwright video path: {ex.Message}"); }
        try { if (_browser is not null) await _browser.CloseAsync(); } catch { }
        _playwright?.Dispose();
        _page = null; _context = null; _browser = null; _playwright = null;
    }
    public void ApplyVideoRetention(bool passed)
    {
        if (!_config.Reporting.ShouldExcludeVideo(passed)) return;
        var directory = Path.Combine(_artifactDirectory, "video");
        if (Directory.Exists(directory)) Directory.Delete(directory, recursive: true);
        VideoPath = null;
    }

    private string PersistFinalizedVideo(string resolvedPath, RunLogger logger)
    {
        if (string.IsNullOrWhiteSpace(resolvedPath) || !File.Exists(resolvedPath))
            return resolvedPath;
        var videoDirectory = Path.Combine(_artifactDirectory, "video");
        Directory.CreateDirectory(videoDirectory);
        var full = Path.GetFullPath(resolvedPath);
        var persistent = Path.GetFullPath(Path.Combine(videoDirectory, Path.GetFileName(full)));
        if (full.Equals(persistent, StringComparison.OrdinalIgnoreCase)) return full;
        try
        {
            File.Copy(full, persistent, true);
            using (File.Open(persistent, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)) { }
            return persistent;
        }
        catch (Exception ex)
        {
            logger.Warn($"Unable to copy finalized Playwright video into scenario artifact directory: {ex.Message}");
            return full;
        }
    }
    public string? CreateEvidenceBundle(RunLogger logger)
    {
        if (!_config.Reporting.CreateEvidenceBundle || string.IsNullOrWhiteSpace(_artifactDirectory) || !Directory.Exists(_artifactDirectory)) return null;
        var path = Path.Combine(_artifactDirectory, "evidence-bundle.zip");
        try
        {
            if (File.Exists(path)) File.Delete(path);
            using var archive = ZipFile.Open(path, ZipArchiveMode.Create);
            foreach (var file in Directory.EnumerateFiles(_artifactDirectory, "*", SearchOption.AllDirectories))
            {
                if (Path.GetFullPath(file).Equals(Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase)) continue;
                archive.CreateEntryFromFile(file, Path.GetRelativePath(_artifactDirectory, file), CompressionLevel.Optimal);
            }
            EvidenceBundlePath = path;
            return path;
        }
        catch (Exception ex)
        {
            logger.Warn($"Unable to create evidence bundle: {ex.Message}");
            return null;
        }
    }
    private void WireEvidence(RunLogger logger, IPage page)
    {
        // When collection is re-enabled, initialize the real log files at wiring time.
        if (!File.Exists(_consoleLogPath)) File.WriteAllText(_consoleLogPath, string.Empty);
        if (!File.Exists(_networkLogPath)) File.WriteAllText(_networkLogPath, string.Empty);
        page.Console += (_, message) =>
        {
            if (!_config.Reporting.CollectConsole) return;
            var line = $"{DateTimeOffset.Now:O} BROWSER {message.Type}: {message.Text}";
            AppendEvidenceLine(_consoleLogPath, line);
            logger.Info(line);
            if (_config.Reporting.CollectConsole && (message.Type.Equals("error", StringComparison.OrdinalIgnoreCase) || message.Type.Equals("warning", StringComparison.OrdinalIgnoreCase)))
            {
                lock (_evidenceGate) _stepConsoleErrors.Add(line);
            }
        };
        page.PageError += (_, error) =>
        {
            if (!_config.Reporting.CollectConsole) return;
            var line = $"{DateTimeOffset.Now:O} PAGE ERROR: {error}";
            AppendEvidenceLine(_consoleLogPath, line);
            logger.Error(line);
            if (_config.Reporting.CollectConsole) lock (_evidenceGate) _stepConsoleErrors.Add(line);
        };
        page.Request += (_, request) =>
        {
            if (!_config.Reporting.CollectNetwork) return;
            AppendEvidenceLine(_networkLogPath, $"{DateTimeOffset.Now:O} REQUEST {request.Method} {LogUrl(request.Url)}");
        };
        page.RequestFailed += (_, request) =>
        {
            if (!_config.Reporting.CollectNetwork) return;
            var line = $"{DateTimeOffset.Now:O} REQUEST FAILED: {request.Method} {LogUrl(request.Url)} :: {request.Failure}";
            AppendEvidenceLine(_networkLogPath, line);
            logger.Error(line);
            if (_config.Reporting.CollectNetwork) lock (_evidenceGate) _stepNetworkErrors.Add(line);
        };
        page.Response += (_, response) =>
        {
            if (!_config.Reporting.CollectNetwork) return;
            var line = $"{DateTimeOffset.Now:O} RESPONSE {response.Status}: {response.Request.Method} {LogUrl(response.Url)}";
            AppendEvidenceLine(_networkLogPath, line);
            if (response.Status < 400) return;
            logger.Warn(line);
            if (_config.Reporting.CollectNetwork) lock (_evidenceGate) _stepNetworkErrors.Add(line);
        };
    }
    private void AppendEvidenceLine(string path, string line)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        lock (_evidenceGate)
        {
            try { File.AppendAllText(path, line + Environment.NewLine); } catch { }
        }
    }
    private Task<IBrowser> LaunchAsync(RunLogger logger)
    {
        var channel = BrowserOptions.NormalizeChannel(_config.Browser.Channel);
        return _playwright!.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
        {
            Channel = channel == "chromium" ? null : channel,
            Headless = _config.Browser.Headless,
            Args = _config.Browser.Maximize && !_config.Browser.Headless ? new[] { "--start-maximized" } : null
        });
    }
    public async ValueTask DisposeAsync()
    {
        try { if (_context is not null) await _context.CloseAsync(); } catch { }
        try { if (_browser is not null) await _browser.CloseAsync(); } catch { }
        _playwright?.Dispose();
        _page = null; _context = null; _browser = null; _playwright = null;
    }
    private static string LogUrl(string url) => Uri.TryCreate(url, UriKind.Absolute, out var uri) ? uri.GetLeftPart(UriPartial.Path) : "<invalid-url>";
    private static string Safe(string value) => string.Concat(value.Select(c => char.IsLetterOrDigit(c) || c is '.' or '_' or '-' ? c : '_'));
}
public sealed record StepEvidence(IReadOnlyList<string> ConsoleErrors, IReadOnlyList<string> NetworkErrors);
