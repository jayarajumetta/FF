using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Playwright;
using static Microsoft.Playwright.Assertions;

namespace InsuranceAutomation.Core;

/// <summary>Explicit adapters for native controls and known rendered dropdowns. No retries or selector substitution.</summary>
public static class ComponentAwareControlActions
{
    private const string OptionSelector = "[role=option],mat-option,.x-boundlist-item,.dropdown-item:not(.disabled)";

    public static async Task SelectOrFillAsync(IPage page, ILocator control, string value,
        int timeoutMs = 15000, int optionTimeoutMs = 3000)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentNullException.ThrowIfNull(control);
        value ??= string.Empty;
        var meta = await ReadMetaAsync(control);
        if (meta.Tag == "select")
        {
            // SelectOption auto-waits for the requested option, including asynchronously populated lists.
            await control.SelectOptionAsync(new SelectOptionValue { Label = value }, new() { Timeout = timeoutMs });
            return;
        }
        if (meta.Type is "checkbox" or "radio")
        {
            await control.SetCheckedAsync(ParseBoolean(value), new() { Timeout = timeoutMs });
            return;
        }
        if (meta.Role is "combobox" or "listbox" || meta.Popup is "listbox" or "menu" ||
            meta.Tag == "mat-select" || meta.Cls.Contains("mat-select") || meta.Cls.Contains("x-combo") ||
            meta.Cls.Contains("autocomplete") || !string.IsNullOrEmpty(meta.Autocomplete))
        {
            if (meta.Tag is "input" or "textarea" && !meta.ReadOnly)
                await control.FillAsync(value, new() { Timeout = timeoutMs });
            else
                await control.ClickAsync(new() { Timeout = timeoutMs });

            // Root the popup in the SAME document as the supplied control, including explicit frame locators.
            // This never probes frames or searches for an alternative control.
            var document = control.Locator("xpath=/html");
            var popupId = (await control.GetAttributeAsync("aria-controls") ?? await control.GetAttributeAsync("aria-owns") ?? "")
                .Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            var options = string.IsNullOrWhiteSpace(popupId) ? document.Locator(OptionSelector) :
                document.Locator("[id=" + JsonSerializer.Serialize(popupId) + "]").Locator(OptionSelector);
            var option = options.Filter(new()
            {
                HasTextRegex = new Regex(@"^\s*" + Regex.Escape(value) + @"\s*$", RegexOptions.IgnoreCase),
                Visible = true
            });
            await option.ClickAsync(new() { Timeout = optionTimeoutMs });
            return;
        }
        await control.FillAsync(value, new() { Timeout = timeoutMs });
        // Preserve the existing set/commit contract for change-on-blur application fields.
        await control.BlurAsync(new() { Timeout = timeoutMs });
    }

    public static async Task SetBooleanAsync(ILocator control, bool desired, int timeoutMs = 15000)
    {
        var meta = await ReadMetaAsync(control);
        if (meta.Tag == "input" && meta.Type is "checkbox" or "radio")
        {
            await control.SetCheckedAsync(desired, new() { Timeout = timeoutMs });
            return;
        }
        var nestedInput = control.Locator("input[type=checkbox],input[type=radio]");
        if (await nestedInput.CountAsync() == 1)
        {
            await nestedInput.SetCheckedAsync(desired, new() { Timeout = timeoutMs });
            return;
        }
        var current = await control.GetAttributeAsync("aria-checked");
        if (current is not "true" and not "false")
            throw new InvalidOperationException("Boolean control must expose an input or aria-checked; provide a specific page locator.");
        if ((current == "true") != desired) await control.ClickAsync(new() { Timeout = timeoutMs });
        await Expect(control).ToHaveAttributeAsync("aria-checked", desired ? "true" : "false", new() { Timeout = timeoutMs });
    }

    // Compatibility names used by existing page methods; all now use normal Playwright actions.
    public static Task DomClickAsync(ILocator control, int timeoutMs = 15000) =>
        control.ClickAsync(new() { Timeout = timeoutMs });
    public static Task DomFillAsync(ILocator control, string value, int timeoutMs = 15000) =>
        control.FillAsync(value ?? string.Empty, new() { Timeout = timeoutMs });
    public static async Task DomPressSequentiallyAsync(ILocator control, string value, int delayMs = 20,
        int timeoutMs = 15000)
    {
        await control.FillAsync(string.Empty, new() { Timeout = timeoutMs });
        await control.PressSequentiallyAsync(value ?? string.Empty, new() { Delay = Math.Max(0, delayMs), Timeout = timeoutMs });
    }
    public static Task DomPressAsync(ILocator control, string key, int timeoutMs = 15000) =>
        control.PressAsync(key, new() { Timeout = timeoutMs });

    internal static bool ParseBoolean(string value) => value.Trim().ToLowerInvariant() switch
    {
        "true" or "yes" or "checked" or "1" => true,
        "false" or "no" or "unchecked" or "0" => false,
        _ => throw new ArgumentException($"Expected an explicit boolean value, received '{value}'.", nameof(value))
    };

    private static Task<ControlMeta> ReadMetaAsync(ILocator control) => control.EvaluateAsync<ControlMeta>(@"el => ({
        tag: el.tagName.toLowerCase(), type: (el.getAttribute('type') || '').toLowerCase(),
        role: (el.getAttribute('role') || '').toLowerCase(), popup: (el.getAttribute('aria-haspopup') || '').toLowerCase(),
        cls: typeof el.className === 'string' ? el.className.toLowerCase() : '',
        autocomplete: el.getAttribute('aria-autocomplete') || '', readOnly: !!el.readOnly
    })");
    private sealed class ControlMeta
    {
        public string Tag { get; set; } = "";
        public string Type { get; set; } = "";
        public string Role { get; set; } = "";
        public string Popup { get; set; } = "";
        public string Cls { get; set; } = "";
        public string Autocomplete { get; set; } = "";
        public bool ReadOnly { get; set; }
    }
}
