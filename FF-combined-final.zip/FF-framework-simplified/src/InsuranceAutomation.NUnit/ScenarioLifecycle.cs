using InsuranceAutomation.Core;
using Reqnroll;

namespace InsuranceAutomation.NUnit;

public sealed class ScenarioLifecycle
{
    private readonly ScenarioContext _scenario;
    private readonly FeatureContext _feature;
    private static readonly Lazy<FrameworkConfig> Config = new(FrameworkConfig.Load);
    private readonly string _assemblyName;

    public ScenarioLifecycle(ScenarioContext scenario, FeatureContext feature, string assemblyName)
    {
        _scenario = scenario;
        _feature = feature;
        _assemblyName = assemblyName;
    }

    public static void ValidateConfiguration()
    {
        _ = Config.Value;
    }

    public void PrepareScenario()
    {
        var config = Config.Value;
        var scenarioName = Safe(_scenario.ScenarioInfo.Title);
        var artifactDirectory = Path.Combine(
            config.Reporting.ArtifactRoot,
            _assemblyName,
            Safe(_feature.FeatureInfo.Title),
            scenarioName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + "_" + Guid.NewGuid().ToString("N")[..8]);

        Directory.CreateDirectory(artifactDirectory);
        var testEvidenceContext = NUnitTestEvidenceContext.Capture(_feature.FeatureInfo.Title, _scenario.ScenarioInfo.Title, artifactDirectory);
        var logger = new RunLogger(artifactDirectory);
        var browser = new BrowserSession(config);
        browser.SetArtifactDirectory(artifactDirectory);
        var data = new ScenarioData(config);
        var report = new ScenarioReport(artifactDirectory);
        var verificationFailures = new DeferredVerificationCollector();
        var ui = new UiActions(browser, config, logger, report, _assemblyName, verificationFailures);

        _scenario.Set(config);
        _scenario.Set(artifactDirectory);
        _scenario.Set(logger);
        _scenario.Set(browser);
        _scenario.Set(data);
        _scenario.Set(ui);
        _scenario.Set(report);
        _scenario.Set(verificationFailures);
        _scenario.Set(testEvidenceContext);

    }

    public void BeforeStep()
    {
        var step = _scenario.StepContext.StepInfo.Text;


        _scenario.Get<BrowserSession>().BeginStepEvidence();
        _scenario.Get<ScenarioData>().BeginStep();
        _scenario.Set(_scenario.Get<DeferredVerificationCollector>().Failures.Count, "DeferredVerificationCountAtStepStart");
        _scenario.Get<RunLogger>().Info($"START STEP: {step}");
        _scenario.Get<ScenarioReport>().StartStep(step);
    }

    public async Task AfterStepAsync()
    {
        var config = _scenario.Get<FrameworkConfig>();
        var logger = _scenario.Get<RunLogger>();
        var data = _scenario.Get<ScenarioData>();
        var report = _scenario.Get<ScenarioReport>();
        var browser = _scenario.Get<BrowserSession>();
        var verificationFailures = _scenario.Get<DeferredVerificationCollector>();
        var beforeDeferred = _scenario.ContainsKey("DeferredVerificationCountAtStepStart") ? _scenario.Get<int>("DeferredVerificationCountAtStepStart") : 0;
        var deferredInStep = verificationFailures.Failures.Count > beforeDeferred;
        var failed = _scenario.TestError is not null || deferredInStep;
        string? screenshot = null;

        if (browser.IsStarted && (config.Browser.ScreenshotEachStep || (failed && config.Browser.ScreenshotOnFailure)))
        {
            try { screenshot = await browser.CaptureScreenshotAsync($"failure_{DateTime.UtcNow:HHmmssfff}_{Guid.NewGuid():N}.png"); browser.FailureScreenshotCaptured |= failed; }
            catch (Exception ex) { logger.Warn($"Unable to capture failure screenshot: {ex.Message}"); }
        }

        if (_scenario.TestError is not null)
            logger.Error($"FAILED STEP: {_scenario.StepContext.StepInfo.Text} :: {_scenario.TestError}");
        else if (deferredInStep)
            logger.Warn($"STEP COMPLETED WITH DEFERRED VERIFICATION: {_scenario.StepContext.StepInfo.Text}");
        else
            logger.Info($"PASSED STEP: {_scenario.StepContext.StepInfo.Text}");

        var evidence = browser.EndStepEvidence();
        var stepError = _scenario.TestError?.Message ?? (deferredInStep ? "Verification failed; deferred until scenario end." : null);
        var binding = _scenario.StepContext.StepInfo.BindingMatch?.StepBinding?.Method;
        report.SetScenarioData(config.Reporting.IncludeResolvedData ? data.Snapshot() : new Dictionary<string, string>());
        report.EndStep(!failed, stepError, config.Reporting.IncludeResolvedData ? data.StepSnapshot() : new Dictionary<string, string>(), screenshot,
            new StepEvidence(config.Reporting.IncludeConsoleErrors ? evidence.ConsoleErrors : [], config.Reporting.IncludeNetworkErrors ? evidence.NetworkErrors : []),
            binding is null ? null : $"{binding.Type.FullName}.{binding.Name}", bindingCaptured: true);
    }

    public Task FinishScenarioAsync() =>
        NUnitScenarioEvidenceFinalizer.FinishAsync(
            _scenario.Get<BrowserSession>(),
            _scenario.Get<RunLogger>(),
            _scenario.Get<FrameworkConfig>(),
            _scenario.Get<ScenarioReport>(),
            _scenario.Get<DeferredVerificationCollector>(),
            _scenario.Get<string>(),
            _feature.FeatureInfo.Title,
            _scenario.ScenarioInfo.Title,
            _scenario.TestError,
            _scenario.Get<NUnitTestEvidenceContext>());

    private static string Safe(string value) =>
        string.Concat(value.Select(c => char.IsLetterOrDigit(c) ? c : '_')).Trim('_');
}
