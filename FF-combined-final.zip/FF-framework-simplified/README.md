# Insurance automation framework

Combined SGS framework with the customer EQ tests, using .NET 8, Playwright 1.61.0, Reqnroll 3.3.4 and NUnit 4.6.1. Open `InsuranceAutomation.sln`.

## Quick start

Use .NET SDK 8.0.423 or a compatible 8.0.4xx patch, PowerShell 7.4+, Python 3, and access to the application environments. Windows is the primary supported execution environment for the supplied Azure and forms-maintenance scripts.

```powershell
pwsh ./scripts/setup.ps1 -Browser edge
# Alternatively install Chrome after building:
pwsh ./scripts/install-browsers.ps1 -Browser chrome
```

Set credentials in your shell or CI secret variables. `credentials.example.ps1` lists the SGS variables. Do not commit credentials.

```powershell
$env:CL_EQ_USERNAME = '<username>'
$env:CL_EQ_PASSWORD = '<password>'
$env:CL_DC_USERNAME = '<username>'
$env:CL_DC_PASSWORD = '<password>'
$env:DUCKCREEK_PASSWORD = '<forms-service-password>'
$env:TEST_ENVIRONMENT = 'QA'  # customer EQ configuration: Dev, QA or IT

pwsh ./scripts/run.ps1 -Project CLEQ -Browser edge -Headless -Filter 'TestCategory=cs_import&TestCategory=PipelineSmoke'
pwsh ./scripts/run.ps1 -Project CLEQ -Browser chrome -Headless -Filter 'TestCategory=cs_import&TestCategory=SFP&TestCategory!=DevOnly'
pwsh ./scripts/run.ps1 -Project CLDC -Browser edge
```

Project selectors: `CLDC`, `CLEQ`, `PLDC`, `ALL`. The default CLEQ run excludes `CSUnit` and `Tools`. Use an explicit filter for selected features, categories or test names. Source `DevOnly` and RatePolicy environment guards remain active.

For direct `dotnet test`, use `TEST_BROWSER=chrome|edge|msedge|chromium` and `TEST_HEADLESS=true|false`; environment values override `config/framework.json`. Chrome and Edge use their actual Playwright channels. An unavailable selected browser fails clearly; there is no silent fallback. Install the selected browser on every test agent. Browser channel is chosen per process; run separate commands for a browser matrix.

```powershell
$env:TEST_BROWSER = 'chrome'
$env:TEST_HEADLESS = 'true'
dotnet test tests/CommercialLines.ExpertQuote.Tests -c Release --filter 'TestCategory=cs_import&TestCategory=PipelineSmoke'
```

## Layout

| Location | Purpose |
| --- | --- |
| `src/InsuranceAutomation.Core` | Browser lifecycle, reported actions, standalone scenario data, logging and reports |
| `src/InsuranceAutomation.NUnit` | Shared scenario hooks, NUnit evidence publication and whole-scenario retry |
| `src/InsuranceAutomation.Retry.Generator` | Adds the configured retry attribute to generated scenario tests |
| `tests/CommercialLines.DuckCreek.Tests` | CLDC tests and regression workflows |
| `tests/CommercialLines.ExpertQuote.Tests` | SGS EQ tests and customer EQ tests |
| `tests/PersonalLines.DuckCreek.Tests` | PLDC tests |
| `tests/CommercialLines.ExpertQuote.Tests/Features/EQ_BOP` | Imported BOP test |
| `tests/CommercialLines.ExpertQuote.Tests/Features/EQ_SFP` | Imported SFP Basic, Country Estate, RatePolicy and smoke tests |
| `tests/CommercialLines.ExpertQuote.Tests/Features/EQ_PA` | Imported PA test |
| `tests/CommercialLines.ExpertQuote.Tests/Imported/CS` | Customer bindings, pages, helpers, services and unit tests |
| `tools/EQ.DataPool` | Optional quote history service; never auto-started by tests |
| `validation` | Verification results and file-by-file review inventory |

All 44 features and 806 expanded scenarios are retained. Customer bindings use `@cs_import` scope so existing SGS bindings and browser ownership remain separate. Features, bindings and business page methods have not been redesigned; required compatibility edits removed obsolete intent arguments and corrected the BAP regression data paths.

## Core behavior

- `UiActions` operates on the exact locator supplied by the page object. Playwright controls actionability and waiting. There are no locator rescues, runtime locator resolvers, locator caches, frame scans, forced-click fallbacks or fill-retry loops.
- Frame-specific page objects must supply `FrameLocator(...).Locator(...)`. The framework never guesses which iframe contains a control.
- Native selects use `SelectOptionAsync` by label. Known rendered dropdowns use exact visible option text in the same document as the supplied control, scoped to `aria-controls`/`aria-owns` when available. Partial/fuzzy option selection and Enter fallback are removed.
- Existing `FillAsync` page calls can still address text or select components. Text set operations retain the application’s change-on-blur behavior. Sequential entry clears once and types once. Requested Enter and Tab keys are sent.
- `WaitAsync` is a required wait and fails on timeout. Only `WaitReadyBestEffortAsync` is explicitly optional. `ExistsAsync` returns false on a visibility timeout; invalid selectors and closed-page errors propagate.
- Verification uses Playwright retrying assertions. `execution.deferVerificationFailures=true` preserves SGS soft-verification behavior: evidence is collected and the scenario fails at finalization. Set it to false to fail immediately.
- `execution.retryCount=0` means no whole-scenario retry. If enabled, the existing NUnit wrapper reruns the complete scenario with fresh hooks and separate evidence. WC Basic retains its original no-retry policy. Pipelines do not add another retry layer.
- Imported navigation uses DOM content loaded followed by the page objects’ own readiness checks. Core code no longer waits for network idle or inserts fixed pre-action sleeps.

The legacy `Dom*` helper names are compatibility entry points for existing page methods; their implementations use ordinary Playwright actions. `GetCanonicalField*` is retained as a data-access compatibility name, reading the plain `fields` object. Neither is a recovery mechanism.

## Test data and configuration

Each SGS scenario reads one JSON file under its project’s `TestData/Scenarios`. There is no layered-data directory or data manifest. Scenario files contain `application`, `dimensions`, `values`, `random`, `external` and, when needed, `fields`.

Value precedence remains runtime captures → explicit external overrides → scenario values → field values. Existing data expressions and condition evaluation remain supported because business steps use them. Operational document-share paths have not been rewritten; some still contain a historical tool name. They are business data, not a runtime dependency.

`config/framework.json` is the shared browser/reporting configuration. Customer `appsettings.json` plus its selected environment file provide EQ application URLs and domain settings, not browser ownership. Nested customer overrides use environment names such as `DataPool__BaseUrl` or `Debugging__RetryDiagnostics`.

Forms lookup/validation errors now fail by default (`Debugging:FailOnFormsValidationError=true`), rather than producing a false successful run. Baseline recording is off. Only use explicit baseline-generation tools or an intentional recording configuration when approving baseline work.

`execution.parallel` controls three versus one NUnit workers through `scripts/run.ps1`; `EnableParallelExecution=true|false` overrides it. Direct IDE/CLI execution uses the worker count in `Framework.runsettings` unless explicitly overridden. Builds no longer rewrite runsettings. Customer unit fixtures retain their nonparallel safety attributes.

## Failure evidence

Every framework failure screenshot uses `IPage.ScreenshotAsync(FullPage=true)` with no clip. Screenshot files have unique names under the scenario’s `screenshots` directory; the report links the captured path. Imported checklist popups and Express login failures also capture full pages. Playwright full-page capture covers the document’s scrollable page; independently scrolling embedded widgets are not stitched separately.

The same browser context is closed before trace, HAR, video and NUnit attachments are published. Screenshots remain on by default. Trace/HAR/video and console/network collection are optional. Video also requires `reporting.excludeVideos=false`. Scenario logs, JSON and HTML preserve the executed step binding. Direct Playwright page calls outside `UiActions` are not fabricated as action telemetry.

`run.ps1` writes to the configured results root (default `TestResults`) or `-ResultsDirectory`. It protects against clearing source folders, unowned directories or another active run. `TEST_RESULTS_ROOT` is honored by both scripts and the C# framework. A subsequent run in the same owned results directory replaces its previous contents; use a new directory when retaining runs.

```powershell
pwsh ./scripts/Generate-ConsolidatedReport.ps1 -ResultsDirectory TestResults
```

## Validation

```powershell
pwsh ./scripts/build.ps1 -Configuration Release
python -m pip install -r tools/validation-requirements.txt
python tools/validate_framework.py
python -m unittest discover -s tools -p 'test_*.py'
dotnet test tools/InsuranceAutomation.Retry.Tests -c Release --filter 'TestCategory!=FrameworkBrowser'
dotnet test tests/CommercialLines.ExpertQuote.Tests -c Release --filter 'TestCategory=CSUnit&TestCategory!=CSBrowserUnit' -- "NUnit.WorkDirectory=$pwd/TestResults/UnitWork"
```

Real Chrome/Edge contract tests use local HTML and verify actions, iframe input and full-page PNG dimensions. Run them on an agent with both channels installed:

```powershell
dotnet test tools/InsuranceAutomation.Retry.Tests -c Release --filter 'TestCategory=FrameworkBrowser'
# Imported DOM/browser unit tests:
dotnet test tests/CommercialLines.ExpertQuote.Tests -c Release --filter 'TestCategory=CSBrowserUnit'
```

See `validation/validation-summary.json` for the delivered package’s observed results. Offline/build checks do not prove that application locators work in a live environment. No live insurance workflow or Chrome/Edge end-to-end pass is claimed.

## CI and release execution

- `azure-pipelines-ci.yml` builds, runs offline checks, then publishes the compiled `testpackage` artifact.
- `azure-pipelines-cd.yml` downloads an exact CI build, installs the requested browser, and runs `VSTest@3`. Select by assembly filter or an existing Azure Test Plan suite. Map credentials to secret pipeline variables. Use a self-hosted Windows agent with internal application access when required.
- Results and attachments are published even after test failure. There is one execution job and no custom cross-agent evidence transport, temporary ADO-suite creation or classic release JSON.
- The optional `tests/CommercialLines.ExpertQuote.Tests/Pipelines/forms-delta-review.yml` retains the customer Forms Delta workflow, pinned-source hash checks, reviewed-change/package gates, and federated/certificate acquisition settings. It requires the organization’s existing `Playwright` pool and `PnC_DC_TestAutomation` variable group. It is not required for test execution.

Pipelines are parsed and packaging is checked locally; they still require queueing in your Azure organization to validate permissions, agents, variable groups and application connectivity.

## Customer capabilities retained and known source gaps

Forms XML validation, forms reports, baseline/delta tools, premium extraction, QA/Dev/IT settings, environment/state guards, optional diagnostics, checklist outage semantics, per-scenario quote records and optional DataPool persistence are retained. Authentication clients and resource disposal were corrected. `RetryDiagnostics` is observation only; it does not retry actions. DataPool ships with an empty history and can be started explicitly with `dotnet run --project tools/EQ.DataPool --urls http://localhost:5100`.

The inherited BOP PoC primary-insured step was not implemented in the supplied customer source; it remains explicitly inconclusive. `SFP_RATEPOLICY.json` remains an unpopulated expected-forms baseline, and its tests continue to reject it. These are source business-coverage gaps; the framework does not invent locators, baselines or successful outcomes for them.

Review `docs/FRAMEWORK-REVIEW.md` for the change decisions, compatibility limits and retained customer capabilities.
