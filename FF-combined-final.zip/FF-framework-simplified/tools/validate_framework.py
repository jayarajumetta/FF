from pathlib import Path
import argparse,re,json,sys
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
from gherkin.parser import Parser as GParser
from gherkin.pickles.compiler import Compiler
arguments=argparse.ArgumentParser(description='Check C# syntax, expanded feature bindings and scenario data paths.')
arguments.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parents[1])
ROOT=arguments.parse_args().root.resolve()
if not (ROOT/'InsuranceAutomation.sln').is_file():
 arguments.error(f'Framework solution not found under {ROOT}')
parser=Parser(Language(tree_sitter_c_sharp.language()))
methods=[]; syntax=[]
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
def literal(s):
 if s.startswith('@"'):return s[2:-1].replace('""','"')
 return json.loads(s)
for file in ROOT.rglob('*.cs'):
 if any(p in ['bin','obj'] for p in file.parts):continue
 text=file.read_bytes(); tree=parser.parse(text);rel=str(file.relative_to(ROOT))
 for node in walk(tree.root_node):
  if node.type=='ERROR' or node.is_missing:syntax.append({'file':rel,'line':node.start_point.row+1})
  if node.type=='method_declaration':
   name=node.child_by_field_name('name').text.decode();owner=node.parent
   while owner and owner.type!='class_declaration':owner=owner.parent
   if not owner:continue
   cl=owner.child_by_field_name('name').text.decode()
   attrs='\n'.join(c.text.decode() for c in node.children if c.type=='attribute_list')
   clattrs='\n'.join(c.text.decode() for c in owner.children if c.type=='attribute_list')
   method={'id':rel+'::'+cl+'.'+name+':'+str(node.start_point.row+1),'file':rel,'attrs':attrs,'scope':clattrs}
   methods.append(method)
bindings=[]
for m in methods:
 for b in re.finditer(r'\[(Given|When|Then|StepDefinition)\s*\(\s*(@"(?:[^"\r\n]|"")*"|"(?:[^"\\\r\n]|\\.)*")',m['attrs']):
  pat=literal(b.group(2))
  # SGS uses Cucumber string placeholders; incoming patterns use literal text/regex.
  pat=pat.replace('{string}', '(?:"[^"\\n]*"|\'[^\'\\n]*\')').replace('{int}',r'-?\d+').replace('{word}',r'\S+')
  bindings.append({'kind':b.group(1),'pattern':pat,'compiled':re.compile('(?:'+pat+')\\Z'),'scopes':[(k,literal(v)) for k,v in re.findall(r'Scope\(\s*(Feature|Tag)\s*=\s*("(?:[^"\\]|\\.)*")',m['scope']+'\n'+m['attrs'])],'method':m})
features=[];issues=[];totalcases=0;totalsteps=0
for f in sorted(ROOT.glob('tests/*/Features/**/*.feature')):
 doc=GParser().parse(f.read_text(encoding='utf-8-sig'));doc['uri']=str(f.relative_to(ROOT));ft=doc['feature']['name'];cases=Compiler().compile(doc);totalcases+=len(cases);imported='@cs_import' in f.read_text(encoding='utf-8-sig');unique={}
 appbindings=[b for b in bindings if b['method']['file'].startswith('tests/'+f.relative_to(ROOT).parts[1]+'/')]
 for case in cases:
  tags={t['name'].lstrip('@') for t in case['tags']}; app=f.relative_to(ROOT).parts[1]
  for step in case['steps']:
   totalsteps+=1;matches=[];
   for datafile in re.findall(r'"([^"]+\.json)"',step['text']):
    if 'TestData/' in datafile and not (ROOT/'tests'/f.relative_to(ROOT).parts[1]/datafile).is_file(): issues.append({'feature':doc['uri'],'missingData':datafile})
   kind={'Context':'Given','Action':'When','Outcome':'Then'}.get(step.get('type'),'StepDefinition')
   for b in appbindings:
    m=b['method']
    if not m['file'].startswith('tests/'+app+'/'):continue
    if b['kind'] not in [kind,'StepDefinition'] and kind!='StepDefinition':continue
    scopes=b['scopes']
    if scopes and not any((k=='Feature' and v==ft) or (k=='Tag' and v in tags) for k,v in scopes):continue
    try:match=b['compiled'].fullmatch(step['text'])
    except re.error as e:issues.append({'pattern':b['pattern'],'error':str(e)});continue
    if match:matches.append(b)
   # Scoped bindings outrank unscoped definitions, matching Reqnroll's specificity rules.
   scoped=[b for b in matches if '[Scope(' in b['method']['scope'] or '[Scope(' in b['method']['attrs']]
   if scoped:matches=scoped
   matches={b['method']['id']:b for b in matches}
   if len(matches)!=1:issues.append({'feature':doc['uri'],'case':case['name'],'step':step['text'],'matches':list(matches)})
   elif imported:
    b=next(iter(matches.values()));unique[b['method']['id']]=b
 record={'feature':doc['uri'],'title':ft,'imported':imported,'cases':len(cases),'uniqueBindings':len(unique)}
 features.append(record)
report={'note':'C# grammar and expanded Gherkin binding checks. Compilation and browser execution remain separate requirements.','csharpFiles':sum(1 for p in ROOT.rglob('*.cs') if not any(a in ['bin','obj'] for a in p.parts)),'syntaxErrors':syntax,'featureCount':len(features),'scenarioCases':totalcases,'expandedSteps':totalsteps,'bindingIssues':issues,'features':features}
if not features or not totalcases or not report['csharpFiles']:
 arguments.error('No framework sources or executable feature cases were found.')
out=ROOT/'validation/source-validation.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2))
print(json.dumps({k:(len(v) if k=='bindingIssues' else v) for k,v in report.items() if k not in ['features','note']},indent=2));print('Validation report:',out)
if syntax or issues:sys.exit(1)
