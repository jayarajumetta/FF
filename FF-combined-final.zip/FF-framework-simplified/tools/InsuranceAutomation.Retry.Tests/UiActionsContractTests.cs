using System.Reflection;
using InsuranceAutomation.Core;
using Microsoft.Playwright;
using NUnit.Framework;

namespace InsuranceAutomation.Framework.Tests;

[TestFixture]
[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
public class UiActionsContractTests
{
    private string _directory = null!;
    private RunLogger _logger = null!;
    private BrowserSession _browser = null!;
    private UiActions _ui = null!;
    [SetUp] public void SetUp()
    {
        _directory = Path.Combine(Path.GetTempPath(), "framework-" + Guid.NewGuid().ToString("N"));
        _logger = new RunLogger(_directory);
        var config = new FrameworkConfig();
        _browser = new BrowserSession(config);
        _browser.SetArtifactDirectory(_directory);
        _ui = new UiActions(_browser, config, _logger);
    }
    [TearDown] public void TearDown() { _logger.Dispose(); Directory.Delete(_directory, true); }

    [TestCase("chrome", "chrome")]
    [TestCase("edge", "msedge")]
    [TestCase("MSEDGE", "msedge")]
    [TestCase("chromium", "chromium")]
    public void BrowserChoiceIsExplicit(string input, string expected) =>
        Assert.That(BrowserOptions.NormalizeChannel(input), Is.EqualTo(expected));

    [Test] public void UnknownBrowserIsRejected() =>
        Assert.Throws<InvalidOperationException>(new Action(() => BrowserOptions.NormalizeChannel("unknown")));

    [Test] public async Task FailedClickIsNotRepeatedOrForced()
    {
        var calls = 0;
        var locator = InterfaceProbe.Create<ILocator>((m, a) =>
        {
            if (m.Name == "ClickAsync")
            {
                calls++;
                Assert.That(((LocatorClickOptions)a![0]!).Force, Is.Not.True);
                return Task.FromException(new TimeoutException("not actionable"));
            }
            throw new InvalidOperationException("Unexpected operation: " + m.Name);
        });
        Assert.ThrowsAsync<TimeoutException>(new Func<Task>(() => _ui.ClickAsync(locator)));
        Assert.That(calls, Is.EqualTo(1));
        await Task.CompletedTask;
    }

    [TestCase("{TAB}", "Tab")]
    [TestCase("{ENTER}", "Enter")]
    public async Task RequestedKeysAreNeverSuppressed(string input, string expected)
    {
        string? actual = null;
        var locator = InterfaceProbe.Create<ILocator>((m, a) =>
        {
            if (m.Name == "PressAsync") { actual = (string)a![0]!; return Task.CompletedTask; }
            throw new InvalidOperationException(m.Name);
        });
        await _ui.PressAsync(locator, input);
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test] public void RequiredWaitPropagatesTimeout()
    {
        var locator = InterfaceProbe.Create<ILocator>((m,a) => Task.FromException(new TimeoutException("absent")));
        Assert.ThrowsAsync<TimeoutException>(new Func<Task>(() => _ui.WaitAsync(locator, "Visible")));
    }

    [Test] public async Task OptionalExistsReturnsFalseOnlyOnTimeout()
    {
        var locator = InterfaceProbe.Create<ILocator>((m,a) => Task.FromException(new TimeoutException("absent")));
        Assert.That(await _ui.ExistsAsync(locator), Is.False);
        var invalid = InterfaceProbe.Create<ILocator>((m,a) => Task.FromException(new PlaywrightException("invalid selector")));
        Assert.ThrowsAsync<PlaywrightException>(new Func<Task>(async () => await _ui.ExistsAsync(invalid)));
    }

    [Test] public async Task ScreenshotCapturesWholePageAndUpdatesReportPath()
    {
        PageScreenshotOptions? captured = null;
        var page = InterfaceProbe.Create<IPage>((m,a) =>
        {
            if (m.Name == "ScreenshotAsync") { captured = (PageScreenshotOptions)a![0]!; return Task.FromResult(Array.Empty<byte>()); }
            throw new InvalidOperationException(m.Name);
        });
        typeof(BrowserSession).GetField("_page", BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(_browser, page);
        var path = await _browser.CaptureScreenshotAsync("failure.png");
        Assert.That(captured!.FullPage, Is.True);
        Assert.That(captured.Clip, Is.Null);
        Assert.That(_browser.ScreenshotPath, Is.EqualTo(path));
    }
}

public class InterfaceProbe : DispatchProxy
{
    public Func<MethodInfo, object?[]?, object?> Handler { get; set; } = null!;
    protected override object? Invoke(MethodInfo? method, object?[]? args) => Handler(method!, args);
    public static T Create<T>(Func<MethodInfo, object?[]?, object?> handler) where T : class
    {
        var proxy = DispatchProxy.Create<T, InterfaceProbe>();
        ((InterfaceProbe)(object)proxy).Handler = handler;
        return proxy;
    }
    public override string ToString() => "TestLocator";
}
