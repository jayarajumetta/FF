using System.Buffers.Binary;
using InsuranceAutomation.Core;
using NUnit.Framework;

namespace InsuranceAutomation.Framework.Tests;

[TestFixture, Category("FrameworkBrowser")]
[NonParallelizable]
public class BrowserContractTests
{
    // Local HTML only: validates real channels, iframe-scoped input, dropdowns and screenshot dimensions.
    [TestCase("chrome")]
    [TestCase("msedge")]
    public async Task RealBrowserActionsAndFullPageScreenshot(string channel)
    {
        var directory = Path.Combine(Path.GetTempPath(), "browser-contract-" + Guid.NewGuid().ToString("N"));
        var config = new FrameworkConfig { Browser = new BrowserOptions { Channel = channel, Headless = true, Maximize = false } };
        using var logger = new RunLogger(directory);
        await using var browser = new BrowserSession(config);
        browser.SetArtifactDirectory(directory);
        try
        {
            await browser.OpenAsync(logger);
            var page = browser.Page;
            await page.SetContentAsync("""<label>Name<input id="name"></label><select id="state"><option>AL</option><option>TX</option></select><iframe srcdoc="<input id='inside'>"></iframe><div style="height:2800px">End</div>""");
            var ui = new UiActions(browser, config, logger);
            await ui.FillAsync(page.Locator("#name"), "Example");
            await ui.VerifyAsync(page.Locator("#name"), "Example", "Value");
            await ui.SelectAsync(page.Locator("#state"), "TX");
            await ui.FillAsync(page.FrameLocator("iframe").Locator("#inside"), "Frame value");
            Assert.That(await page.FrameLocator("iframe").Locator("#inside").InputValueAsync(), Is.EqualTo("Frame value"));
            var screenshot = await browser.CaptureScreenshotAsync("whole-page.png");
            var bytes = await File.ReadAllBytesAsync(screenshot!);
            Assert.That(BinaryPrimitives.ReadInt32BigEndian(bytes.AsSpan(20, 4)), Is.GreaterThan(2800));
        }
        finally { await browser.CloseAsync(logger); }
    }
}
