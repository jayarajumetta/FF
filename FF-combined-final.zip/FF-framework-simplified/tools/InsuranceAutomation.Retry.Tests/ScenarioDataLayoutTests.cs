using InsuranceAutomation.Core;
using NUnit.Framework;

namespace InsuranceAutomation.Data.Tests;

[TestFixture]
[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
public sealed class ScenarioDataLayoutTests
{
    private string _directory = null!;
    [SetUp] public void SetUp()
    {
        _directory = Path.Combine(AppContext.BaseDirectory, "scenario-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_directory);
    }
    [TearDown] public void TearDown() => Directory.Delete(_directory, true);

    [TestCase("")]
    [TestCase("Basic")]
    [TestCase("Smoke")]
    [TestCase("Expanded/Nested")]
    public void LoadsStandaloneDataAtAnyDepth(string category)
    {
        var directory = Path.Combine(_directory, "TestData", "Scenarios", category);
        Directory.CreateDirectory(directory);
        var file = Path.Combine(directory, "sample.json");
        File.WriteAllText(file, """{"values":{"policy":"standalone"},"fields":{"Address 1":"100 Main Street"}}""");
        var data = new ScenarioData(new FrameworkConfig());
        data.Load(file, Path.Combine(_directory, "missing.json"));
        Assert.That(data.Get("POLICY"), Is.EqualTo("standalone"));
        Assert.That(data.GetCanonicalFieldRequired("Address 1"), Is.EqualTo("100 Main Street"));
    }

    [Test] public void RuntimeAndExternalOverridesRetainTheirPrecedence()
    {
        var file = Path.Combine(_directory, "scenario.json");
        var external = Path.Combine(_directory, "external.json");
        File.WriteAllText(file, """{"values":{"policy":"base"},"fields":{"policy":"field"}}""");
        File.WriteAllText(external, """{"values":{"policy":{"value":"override"}}}""");
        var data = new ScenarioData(new FrameworkConfig());
        data.Load(file, external);
        Assert.That(data.Get("policy"), Is.EqualTo("override"));
        data.SetRuntime("policy", "captured");
        Assert.That(data.Get("policy"), Is.EqualTo("captured"));
    }

    [Test] public void ReloadClearsRuntimeValuesAndStepEvidence()
    {
        var file = Path.Combine(_directory, "scenario.json");
        File.WriteAllText(file, """{"values":{"policy":"base"}}""");
        var data = new ScenarioData(new FrameworkConfig());
        data.Load(file, Path.Combine(_directory, "missing.json"));
        data.SetRuntime("old", "old");
        data.Load(file, Path.Combine(_directory, "missing.json"));
        Assert.That(data.Get("old"), Is.Empty);
        Assert.That(data.StepSnapshot().Values, Does.Not.Contain("old"));
    }

    [Test] public void InvalidJsonFailsInsteadOfSilentlySubstitutingData()
    {
        var file = Path.Combine(_directory, "scenario.json");
        File.WriteAllText(file, "not json");
        var data = new ScenarioData(new FrameworkConfig());
        Assert.Catch<System.Text.Json.JsonException>(new Action(() => data.Load(file, "missing.json")));
    }
}
