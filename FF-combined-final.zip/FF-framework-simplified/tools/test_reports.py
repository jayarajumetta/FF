"""Offline report regressions; no browser or Azure credentials required."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
ROOT = Path(__file__).resolve().parent.parent

class ReportTests(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def evidence(self, name, attempts=('PASS',)):
        results = self.root / name
        for number, status in enumerate(attempts, 1):
            directory = results / 'Artifacts' / 'CommercialLines.DuckCreek.Tests' / f'case-{number}'
            directory.mkdir(parents=True)
            (directory / 'scenario-result.json').write_text(json.dumps({'feature': 'GL smoke', 'scenario': name, 'status': status, 'executionId': name, 'testFullName': f'Example.{name}', 'attemptNumber': number, 'maxAttempts': len(attempts), 'durationMilliseconds': 100, 'steps': [], 'artifacts': {'trace': 'trace.zip'}}), encoding='utf-8')
            (directory / 'trace.zip').write_bytes(b'trace fixture')
        return results

    def test_runtime_binding_is_authoritative_and_legacy_inference_is_labeled(self):
        import generate_consolidated_report as generator
        import re
        candidate = generator.Binding('', 'Verify policy', 'WrongSteps', 'WrongMethod', 'wrong.cs', 1, re.compile('Verify policy'))
        steps = [{'text': 'Verify policy', 'binding': 'CorrectSteps.CorrectMethod', 'bindingCaptured': True}, {'text': 'Verify policy', 'binding': '', 'bindingCaptured': True}, {'text': 'Verify policy'}]
        generator.enrich([{'steps': steps}], [candidate])
        self.assertEqual('CorrectSteps.CorrectMethod', steps[0]['binding'])
        self.assertEqual('', steps[1]['binding'])
        self.assertIn('No step-definition method', steps[1]['bindingResolution'])
        self.assertEqual('WrongSteps.WrongMethod', steps[2]['binding'])
        self.assertIn('Inferred from source', steps[2]['bindingResolution'])

    def test_video_policy_defaults_and_boolean_validation(self):
        from generate_consolidated_report import video_policy, exclude_video
        self.assertEqual((True, True), video_policy(self.root))
        config = self.root / 'config'
        config.mkdir()
        (config / 'framework.json').write_text(json.dumps({'reporting': {'excludeVideos': False}}))
        self.assertEqual((False, True), video_policy(self.root))
        self.assertTrue(exclude_video((True, False), 'FAIL'))
        self.assertTrue(exclude_video((False, True), 'PASS'))
        self.assertFalse(exclude_video((False, True), 'FAIL'))
        (config / 'framework.json').write_text(json.dumps({'reporting': {'excludeVideos': 'false'}}))
        with self.assertRaisesRegex(ValueError, 'must be booleans'):
            video_policy(self.root)

    def test_report_generator_rejects_overlapping_and_external_roots(self):
        import generate_consolidated_report as generator
        evidence = self.evidence('roots')
        args = ['--evidence-root', str(evidence), '--source-root', str(ROOT), '--output-dir', str(self.root / 'report')]
        for roots in ((evidence, evidence / 'Artifacts'), (self.root,)):
            with self.subTest(roots=roots), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                generator.main(args + [value for root in roots for value in ('--scenario-root', str(root))])
    def test_skipped_and_unknown_results_keep_honest_summary_and_xml_totals(self):
        import generate_consolidated_report as generator
        import xml.etree.ElementTree as ET
        for group, statuses, expected in (
            ('skips', ['SKIP', 'SKIP'], ('SKIP', 0, 0, 2, 0)),
            ('mixed', ['PASS', 'FAIL', 'SKIP', 'UNKNOWN'], ('FAIL', 1, 1, 1, 1)),
        ):
            with self.subTest(group=group):
                for i, outcome in enumerate(statuses):
                    self.evidence(f'{group}/case-{i}', (outcome,))
                output = self.root / (group + '-report')
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(0, generator.main(['--evidence-root', str(self.root/group),
                        '--source-root', str(ROOT), '--output-dir', str(output)]))
                result = json.loads((output/'summary.json').read_text())
                self.assertEqual(expected, tuple(result[k] for k in ('status','passed','failed','skipped','unknown')))
                stat = ET.parse(output/'output.xml').find('./statistics/total/stat')
                self.assertEqual(str(expected[2] + expected[4]), stat.get('fail'))
                self.assertEqual(str(expected[3]), stat.get('skip'))

if __name__ == '__main__':
    unittest.main()
